module.exports = async (p, T) => {
  const r0 = await p.evaluate(() => { const G = window.__G3D; document.getElementById('start').style.display = 'none';
    const t = G.world.forest.trees.find(t => t.kind === 1 && G.terrain.height(t.x, t.y) > G.terrain.LV.sand);
    G.teleport(t.x - 60, t.y); G.look(0, 0); window._tt = t; return [t.x, t.y, t.trunkR]; });
  await p.keyboard.down('Shift'); await p.keyboard.down('w'); for (let i = 0; i < 8; i++) { await T.wait(3000); T.log(await p.evaluate(() => { const c = window.__G3D.player.c, t = window._tt; return (c.x - t.x).toFixed(1) + ',' + (c.y - t.y).toFixed(1); })); } await p.keyboard.up('w');
  T.log(await p.evaluate(() => { const G = window.__G3D, c = G.player.c, t = window._tt; return JSON.stringify({ dist: Math.hypot(c.x - t.x, c.y - t.y).toFixed(1), trunkR: t.trunkR.toFixed(1), passed: c.x > t.x + 20 }); }));
};
