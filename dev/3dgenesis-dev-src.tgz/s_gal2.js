module.exports = async (p, T) => {
  await p.click('[data-act="create"]'); await T.wait(3000);
  const n = +(process.env.N || 10), zoom = +(process.env.ZOOM || 0.75), rand = !!process.env.RAND, yaw = +(process.env.YAW || 0.8);
  for (let i = 0; i < n; i++) {
    await p.evaluate(([i, y, z, rand]) => { const G = window.__G3D, C = G.core, E = G.ED;
      let s = 1234 + i * 7919; const rng = () => ((s = s * 16807 % 2147483647) / 2147483647);
      E.des = rand ? C.randomDesign(rng, { diversity: 0.6 }) : C.defaultDesign(i); E.des._rev = 1; E.sel = null; E.cam.yaw = y; E.cam.pitch = 0.2; E.cam.zoom = z; }, [i, yaw, zoom, rand]);
    await T.wait(2500);
    await p.screenshot({ path: `gal_${i}.png`, clip: { x: 350, y: 60, width: 830, height: 780 } });
  }
};
