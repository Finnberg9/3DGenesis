const C = require('./core.js');
const world = C.makeWorld({ w: 12800, h: 8000, tileSize: 48, seed: 7, startPop: 20, startPlants: 200 });
const rng = world.rng;
let ok = true;
for (let p = 0; p < 10; p++) {
  const d = C.defaultDesign(p);
  const g = C.seedHerbivore(world, rng);
  g.design = d; C.compileDesign(g);
  const ph = C.develop(g);
  const sk = C.buildDesignSkeleton(d);
  const cls = C.classifyLimbs(d, sk);
  const c = C.makeCreature(g, 6000, 4000, 400);
  console.log(`plan ${p}: parts ${d.parts.length} limbs ${d.limbs.length} legs ${cls.legs} stand ${cls.stand.toFixed(2)} cost ${C.designCost(d)} | mass ${ph.mass.toFixed(1)} land ${ph.speedLand.toFixed(0)} water ${ph.speedWater.toFixed(0)} air ${ph.speedAir.toFixed(0)} fly ${ph.canFly} swim ${ph.canSwim} atk ${ph.attack.toFixed(1)} def ${ph.defense.toFixed(1)} sense ${ph.sense.toFixed(0)} upk ${ph.upkeep.toFixed(2)} nodes ${ph.nodeCount} juvMass ${c.ph.mass.toFixed(2)}`);
  for (const k of Object.keys(ph)) { const v = ph[k]; if (typeof v === 'number' && !isFinite(v)) { console.log('NONFINITE', p, k); ok = false; } }
  // mutation / crossover keep design
  let m = C.mutate(world, g, rng, 0.6);
  for (let i = 0; i < 50; i++) m = C.mutate(world, m, rng, 0.6);
  if (!m.design || !m.dx) { console.log('mutate lost design'); ok = false; }
  const x = C.crossover(g, C.seedHerbivore(world, rng), rng);
  if (!x.design) { console.log('crossover lost design'); ok = false; }
  C.develop(m); C.develop(x);
}
// run a world with designed creatures mixed in
for (let i = 0; i < 30; i++) { const g = C.seedHerbivore(world, rng); g.design = C.defaultDesign(i % 10); C.compileDesign(g); const c = C.makeCreature(g, 5000 + i * 40, 4000, 400); for (const q of c.cellState) q.grow = 1; c.ph = C.develop(g, c.cellState); c.energy = c.ph.storage; c.age = C.maturity(c.ph) + 1; world.creatures.push(c); }
for (let s = 0; s < 1500; s++) world.step(0.1);
const des = world.creatures.filter(c => c.alive && c.genome.design).length;
console.log('after sim: alive', world.creatures.filter(c=>c.alive).length, 'designed alive', des, ok ? 'OK' : 'FAIL');
