const C = require('./core.js');
const w = C.makeWorld({ w: 12800, h: 8000, tileSize: 48, seed: 11, startPop: 30, startPlants: 400 });
const rng = w.rng;
const mk = (plan, x, y) => { const g = C.seedHerbivore(w, rng); g.design = C.defaultDesign(plan); C.compileDesign(g); const c = C.makeCreature(g, x, y, 400); for (const q of c.cellState) q.grow = 1; c.ph = C.develop(g, c.cellState); c.energy = c.ph.storage * 0.5; return c; };
const isl = w.terrain.island; const X = isl.cx, Y = isl.cy;
const hunter = mk(2, X, Y), herb = mk(0, X + 30, Y), carn = mk(2, X - 40, Y);
w.creatures.push(hunter, herb, carn);
C.onHit(herb, hunter, 5); C.onHit(carn, hunter, 5);
console.log('reacts', herb.react, carn.react, herb.hurtT);
const e0 = C.hpOf(herb), h0 = C.hpOf(hunter), d0 = Math.hypot(herb.x - hunter.x, herb.y - hunter.y);
for (let i = 0; i < 20; i++) { hunter.x = X; hunter.y = Y; w.step(0.1); }   // hunter held still like the player
console.log('herb fled', d0.toFixed(0), '->', Math.hypot(herb.x - X, herb.y - Y).toFixed(0), 'herb hp', e0.toFixed(1), '->', C.hpOf(herb).toFixed(1), 'hurtT', herb.hurtT.toFixed(2));
console.log('hunter hit by carnivore:', (h0 - C.hpOf(hunter)).toFixed(1), 'hp lost over', hunter._hitSeq, 'hits');
for (let i = 0; i < 40; i++) w.step(0.1);
console.log('after 6s hurtT', herb.hurtT, 'foe', !!herb.foe);
