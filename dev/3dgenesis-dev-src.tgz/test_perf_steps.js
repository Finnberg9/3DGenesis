// The quality setting has to look after a machine that cannot keep up, and
// has to leave alone a player who has made a choice.
module.exports = async (p, h) => {
  const fail = [];
  const t = (n, c, x) => { h.log((c ? 'ok  ' : 'FAIL') + '  ' + n + (x != null ? '  ' + x : '')); if (!c) fail.push(n); };

  const order = await p.evaluate(() => window.__G3D.gfx.order());
  t('there are four levels', order.length === 4 && order[0] === 'low', JSON.stringify(order));

  // a machine nobody has measured does not start at the top
  const fresh = await p.evaluate(() => { try { localStorage.removeItem('g3d_gfx'); } catch (e) {} window.__G3D.gfx.reset('medium'); return { name: window.__G3D.gfx.name(), user: window.__G3D.gfx.userSet() }; });
  t('an unmeasured machine is not assumed to be fast', fresh.name === 'medium', fresh.name);

  // dire frames drop two levels at once rather than walking down
  const dire = await p.evaluate(() => { const G = window.__G3D; G.gfx.reset('ultra'); return { a: G.gfx.feed(500, 3), b: G.gfx.name() }; });
  t('half-a-second frames drop it hard and fast', dire.b === 'low' || dire.b === 'medium', 'ultra -> ' + dire.b);

  // merely slow frames step down ONE level, not two: only a dire machine gets
  // the double drop, or a mildly slow one lands two levels below where it
  // needed to be and looks worse than it has to.
  const one = await p.evaluate(() => { const G = window.__G3D; G.gfx.reset('ultra'); return G.gfx.feed(30, 2); });
  t('merely slow frames step down exactly one level', one === 'high', 'ultra -> ' + one);
  const slow = await p.evaluate(() => { const G = window.__G3D; G.gfx.reset('ultra'); const seq = []; for (let i = 0; i < 6; i++) { G.gfx.feed(30, 5); seq.push(G.gfx.name()); } return seq; });
  const idx = (n) => ['low', 'medium', 'high', 'ultra'].indexOf(n);
  t('and keep stepping down while they stay slow', slow.every((n, i) => i === 0 || idx(n) <= idx(slow[i - 1])), JSON.stringify(slow));
  t('and it bottoms out rather than running off the end', slow[slow.length - 1] === 'low', JSON.stringify(slow));

  // good frames do not thrash it back up immediately
  const steady = await p.evaluate(() => { const G = window.__G3D; G.gfx.reset('high'); G.gfx.feed(18, 6); return G.gfx.name(); });
  t('frames just inside the budget change nothing', steady === 'high', steady);

  // a long stretch of genuinely fast frames is allowed to climb
  const climb = await p.evaluate(() => { const G = window.__G3D; G.gfx.reset('low'); const a = G.gfx.feed(6, 4); const b = G.gfx.feed(6, 40); return { a, b }; });
  t('a few fast seconds are not enough to climb', climb.a === 'low', climb.a);
  t('but a long stretch of them is', climb.b !== 'low', 'low -> ' + climb.b);

  // and the player always wins
  const mine = await p.evaluate(() => {
    const G = window.__G3D;
    G.gfx.reset('high');
    G.gfxSet('ultra');                 // the player picks, explicitly
    const after = G.gfx.feed(500, 8);  // and the machine is dire
    return { user: G.gfx.userSet(), after };
  });
  t('picking a level yourself turns the stepping off', mine.user === true);
  t('and it is never overruled, however slow the machine', mine.after === 'ultra', mine.after);

  // the wet mouth detail is a high-end feature
  const g = await p.evaluate(() => {
    const G = window.__G3D, out = {};
    for (const n of ['low', 'medium', 'high', 'ultra']) { G.gfxSet(n); out[n] = G.gfx.gore(); }
    return out;
  });
  t('drool and tendrils are off on low and medium', g.low === false && g.medium === false, JSON.stringify(g));
  t('and on for high and ultra', g.high === true && g.ultra === true, JSON.stringify(g));

  h.log(fail.length ? '\nFAILED: ' + fail.join(' | ') : '\nALL PERFORMANCE CHECKS PASS');
};
