const C=require('./core.js');const legacy=process.env.LEG;
const w=C.makeWorld({ w: 12800, h: 8000, tileSize: 48, seed: 11, startPop: 50, startPlants: 400, founderDiversity: 0.4 });w.params.timeScale=1;
if(legacy)for(const c of w.creatures){let g=C.seedHerbivore(w,w.rng);for(let m=0;m<2;m++)g=C.mutate(w,g,w.rng,0.4);c.genome=g;c.ph=C.develop(g,c.cellState);}
const causes={};const seen=new Set();
for(let s=0;s<2600;s++){w.step(0.1);for(const c of w.creatures){ if(!seen.has(c)){seen.add(c);} }
 for(const c of seen){ if(c.alive===false&&!c._counted){c._counted=1;const k=c.deathCause+(c.age<C.maturity(c.ph)?'-juv':'');causes[k]=(causes[k]||0)+1;} }
 if(s%650==0){const cs=w.creatures;const a=cs[0];console.log((w.bt|0),cs.length,JSON.stringify(causes), 'mass',(cs.reduce((m,c)=>m+c.ph.mass,0)/cs.length).toFixed(1),'upk',(cs.reduce((m,c)=>m+c.ph.upkeep,0)/cs.length).toFixed(2),'spd',(cs.reduce((m,c)=>m+c.ph.speedLand,0)/cs.length).toFixed(0),'mat',C.maturity(a.ph).toFixed(0), 'en', (cs.reduce((m,c)=>m+c.energy/c.ph.storage,0)/cs.length).toFixed(2));}}
