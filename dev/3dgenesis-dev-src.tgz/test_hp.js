// The fight is a designed thing now, so its numbers are asserted, not hoped for.
const C = require('./core.js');
const world = C.makeWorld({ w: 12800, h: 8000, tileSize: 48, seed: 11, startPop: 4, startPlants: 20 });
const rng = world.rng;
let fails = 0;
const t = (name, cond, extra) => { console.log((cond ? 'ok  ' : 'FAIL') + '  ' + name + (extra != null ? '  ' + extra : '')); if (!cond) fails++; };
const q = (a, p) => { a = a.slice().sort((x, y) => x - y); return a[Math.floor(p * (a.length - 1))]; };

const mk = (plan, opt) => { const g = C.seedHerbivore(world, rng); g.design = C.defaultDesign(plan, opt || {}); C.compileDesign(g); return { g, ph: C.develop(g) }; };

// ---- health -----------------------------------------------------------------
const bases = [];
for (let pl = 0; pl < 10; pl++) bases.push(mk(pl).ph);
t('every stock body plan reads exactly 100 hp',
  bases.every(ph => Math.abs(ph.hpMax - 100) < 1e-9),
  bases.map(ph => ph.hpMax.toFixed(0)).join(','));

// a baby is not a lesser creature: it starts on the same 100
const gb = C.seedHerbivore(world, rng); gb.design = C.defaultDesign(2); C.compileDesign(gb);
const baby = C.makeCreature(gb, 100, 100, 400);
t('a newborn starts on 100 hp too', Math.abs(C.hpMaxOf(baby.ph) - 100) < 1e-9, C.hpMaxOf(baby.ph).toFixed(1) + ' (mass ' + baby.ph.mass.toFixed(2) + ')');

// only a genuinely big body goes above it, and sub-linearly
// Well past the heaviest body anyone can START as, which is what the reference
// mass is pinned to.
const big = C.hpMaxOf({ mass: 4 * C.HP_REF_MASS }), huge = C.hpMaxOf({ mass: 16 * C.HP_REF_MASS });
t('a large body carries more than 100', big > 150 && big < 400, big.toFixed(0));
t('and a giant more again, but not linearly', huge > big * 2 && huge < big * 4, huge.toFixed(0));
t('health is capped so nothing is unkillable', C.hpMaxOf({ mass: 1e6 }) <= 1500 + 1e-9, C.hpMaxOf({ mass: 1e6 }).toFixed(0));

// ---- damage -----------------------------------------------------------------
// a bare body, against a bare body
const bare = { mass: 10, defense: 0, weapon: 0 };
t('a body with no weapon on it hits for the stock 10',
  Math.abs(C.strikeDamage(bare, bare, 1) - 10) < 0.001, C.strikeDamage(bare, bare, 1).toFixed(2));
t('which is ten clean hits to a kill', Math.round(100 / C.strikeDamage(bare, bare, 1)) === 10);

// the ladder: the same body, one weapon at a time, worst tier to best
const tiers = ['weak', 'solid', 'super', 'ultra', 'alpha'];
const ladder = tiers.map(tt => {
  const a = { mass: 10, defense: 0, weapon: C.TIER_W[tt] * 0.75 };
  return { tt, d: C.strikeDamage(a, bare, 1) };
});
console.log('     one weapon, by tier: ' + ladder.map(r => r.tt + ' ' + r.d.toFixed(1)).join(' · '));
t('rarity is monotonic: a better part always hits harder',
  ladder.every((r, i) => i === 0 || r.d > ladder[i - 1].d));
t('an alpha weapon alone is a heavy hit', ladder[4].d > 55 && ladder[4].d < 85, ladder[4].d.toFixed(1));
const maxed = C.strikeDamage({ mass: 10, defense: 0, weapon: 1 }, bare, 1);
t('a fully armed body tops out at the stated 100', Math.abs(maxed - 100) < 0.5, maxed.toFixed(1));
t('and the ceiling holds however heavy the body', C.strikeDamage({ mass: 900, defense: 0, weapon: 1 }, bare, 1) <= 100.001, C.strikeDamage({ mass: 900, defense: 0, weapon: 1 }, bare, 1).toFixed(1));

// armour is a fraction and never more than its ceiling
const soft = C.strikeDamage(bare, { mass: 10, defense: 0 }, 1);
const hard = C.strikeDamage(bare, { mass: 10, defense: 400 }, 1);
t('armour reduces damage', hard < soft, hard.toFixed(1) + ' vs ' + soft.toFixed(1));
t('but never past its ceiling: a hit always lands', hard >= soft * 0.44, (hard / soft).toFixed(2));

// the ceiling on a fight: nothing takes more than thirty clean hits
let worst = 0, worstWhat = '';
for (let i = 0; i < 4000; i++) {
  const am = 0.5 + Math.random() * 60, dm = 0.5 + Math.random() * 60;
  const a = { mass: am, defense: 0, weapon: Math.random() * 0.15 };
  const d = { mass: dm, defense: Math.random() * 400 };
  const hits = C.hpMaxOf(d) / C.strikeDamage(a, d, 0.65);
  if (hits > worst) { worst = hits; worstWhat = 'att mass ' + am.toFixed(1) + ' vs def ' + d.defense.toFixed(0) + ' mass ' + dm.toFixed(1); }
}
t('the worst matchup in the game still ends inside 30 hits', worst <= 30.001, worst.toFixed(1) + '  (' + worstWhat + ')');

// ---- a real duel between two real designs -----------------------------------
const duels = [];
for (let i = 0; i < 300; i++) {
  const A = mk(i % 10), B = mk((i * 7 + 3) % 10);
  duels.push(C.hpMaxOf(B.ph) / C.strikeDamage(A.ph, B.ph, 1));
}
console.log('     stock-vs-stock hits to kill: p05 ' + q(duels, .05).toFixed(1) + '  median ' + q(duels, .5).toFixed(1) + '  p95 ' + q(duels, .95).toFixed(1));
t('two stock creatures settle it in about ten hits', q(duels, .5) >= 7 && q(duels, .5) <= 13, q(duels, .5).toFixed(1));

// looted bodies: the spread a match actually produces
const kitted = [];
for (let i = 0; i < 400; i++) {
  const g = C.seedHerbivore(world, rng);
  g.design = C.randomDesign(rng, { diversity: 0.85, diet: i % 2 ? 'carn' : 'herb', rarityCap: 'alpha' });
  C.compileDesign(g);
  const ph = C.develop(g);
  kitted.push({ hits: C.hpMaxOf(bare) / C.strikeDamage(ph, bare, 1), w: ph.weapon, dmg: C.strikeDamage(ph, bare, 1) });
}
const hs = kitted.map(r => r.hits), dm = kitted.map(r => r.dmg);
console.log('     kitted-vs-stock damage: p05 ' + q(dm, .05).toFixed(0) + '  median ' + q(dm, .5).toFixed(0) + '  p95 ' + q(dm, .95).toFixed(0) + '  max ' + Math.max(...dm).toFixed(0));
t('a looted body hits harder than a bare one', q(dm, .5) > 10.5, q(dm, .5).toFixed(1));
t('and the very best of them approaches 100', Math.max(...dm) > 60, Math.max(...dm).toFixed(0));
t('no hit exceeds the stated ceiling', Math.max(...dm) <= 100.5, Math.max(...dm).toFixed(1));

// ---- you do not hurt yourself by attacking -----------------------------------
t('a bite or a claw costs the attacker nothing', C.counterDamage({ counter: 60 }, 40, false) === 0);
const back = C.counterDamage({ counter: 60 }, 40, true);
t('ramming a spiked body costs at most a tenth of what you dealt', back <= 4.0001 && back > 0, back.toFixed(2));
t('and nothing at all against an unspiked one', C.counterDamage({ counter: 0 }, 40, true) === 0);

// ---- the pool itself ---------------------------------------------------------
const c1 = C.makeCreature(mk(0).g, 10, 10, 400);
t('health starts full', C.hpFrac(c1) === 1, C.hpOf(c1).toFixed(0));
C.hpHurt(c1, 35);
t('damage comes off it', Math.abs(C.hpOf(c1) - 65) < 1e-9, C.hpOf(c1).toFixed(1));
t('and the fraction follows', Math.abs(C.hpFrac(c1) - 0.65) < 1e-9);
C.hpHurt(c1, 1e6);
t('it never goes below zero', C.hpOf(c1) === 0);
C.hpHeal(c1, 30); t('healing works', C.hpOf(c1) === 30);
C.hpHeal(c1, 1e6); t('and never overfills', C.hpOf(c1) === C.hpMaxOf(c1.ph));
// growth keeps the wound, not the number
const c2 = C.makeCreature(mk(4).g, 10, 10, 400);
C.hpHurt(c2, C.hpMaxOf(c2.ph) * 0.5);
const before = C.hpFrac(c2);
c2.ph = Object.assign({}, c2.ph, { mass: c2.ph.mass * 8 });
t('growing bigger keeps the same fraction of health, not the same number',
  Math.abs(C.hpFrac(c2) - before) < 1e-6 && C.hpOf(c2) > 0, C.hpOf(c2).toFixed(0) + ' of ' + C.hpMaxOf(c2.ph).toFixed(0));

// health written straight onto a creature is respected, not silently healed
const c3 = C.makeCreature(mk(3).g, 10, 10, 400);
c3.hp = 42;
t('a health value set by hand is kept, not rounded back up to full', C.hpOf(c3) === 42, C.hpOf(c3).toFixed(1));
const c4 = C.makeCreature(mk(3).g, 10, 10, 400);
c4.hp = 1e9;
t('and one set above the ceiling is clamped to it', C.hpOf(c4) === C.hpMaxOf(c4.ph), C.hpOf(c4).toFixed(0));

console.log(fails ? '\n' + fails + ' FAILED' : '\nALL HP TESTS PASS');
process.exit(fails ? 1 : 0);
