module.exports = async (p, T) => {
  await p.click('[data-act="create"]'); await T.wait(5000);
  T.log(await p.evaluate(() => { const E = window.__G3D.ED; const m = E.des._mesh; return JSON.stringify({ q: m && m.q, key: m && m.key, rev: E.des._rev, tris: m && m.gpu && m.gpu.tris }); }));
  await p.evaluate(() => { const E = window.__G3D.ED; E.cam.yaw = 0.9; E.cam.pitch = 0.25; E.cam.zoom = 0.7; });
  await T.wait(1500); await T.shot('m1.png');
  await p.evaluate(() => { const E = window.__G3D.ED; E.cam.yaw = 2.4; E.cam.pitch = 0.35; E.cam.zoom = 0.7; });
  await T.wait(1500); await T.shot('m2.png');
};
