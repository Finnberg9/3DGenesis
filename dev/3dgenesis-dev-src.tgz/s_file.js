module.exports = async (p, T) => {
  await p.click('[data-act="create"]'); await T.wait(4000);
  T.log('pool', await p.evaluate(() => window.__G3D.meshDbg.pool));
  // slider-like rapid edits: bump rev repeatedly and confirm the mesh catches up
  T.log(await p.evaluate(async () => { const E = window.__G3D.ED; for (let i = 0; i < 10; i++) { E.des.bodyLen = 1 + i * 0.03; E.des._rev++; await new Promise(r => setTimeout(r, 30)); } await new Promise(r => setTimeout(r, 2500)); const m = E.des._mesh; return JSON.stringify({ key: m.key, rev: E.des._rev, q: m.q }); }));
};
