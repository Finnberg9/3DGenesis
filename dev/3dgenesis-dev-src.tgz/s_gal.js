module.exports = async (p, T) => {
  await p.click('[data-act="create"]'); await T.wait(3000);
  const plans = (process.env.PLANS || '0,1,2,3,4,5,6,7,8,9').split(',').map(Number);
  for (const pl of plans) {
    await p.evaluate(([pl, y]) => { const G = window.__G3D, E = G.ED; E.des = G.core.defaultDesign(pl); E.des._rev = 1; E.sel = null; E.cam.yaw = y; E.cam.pitch = 0.22; E.cam.zoom = 0.75; }, [pl, +(process.env.YAW || 0.8)]);
    await T.wait(2500);
    await p.screenshot({ path: `gal_${pl}.png`, clip: { x: 350, y: 60, width: 830, height: 780 } });
  }
};
