module.exports = async (p, T) => {
  const R = await p.evaluate(() => {
    const G = window.__G3D, C = G.core, F = G.FIGHT;
    document.getElementById('start').click();
    G.becomeDesigned(C.defaultDesign(2));
    G.stop();
    const me = G.player.c;
    for (const q of me.cellState) q.grow = 1; me.ph = C.develop(me.genome, me.cellState);
    const out = {};
    const st = (dt, n) => { for (let i = 0; i < n; i++) G.step(dt); };
    // an adult opponent right in front of us
    let att = null, bd = 1e9;
    for (const c of G.world.creatures) if (c.alive && c !== me && c.ph.mass > 1) { const d = Math.hypot(c.x - me.x, c.y - me.y); if (d < bd) { bd = d; att = c; } }
    const place = () => { att.x = me.x + Math.cos(G.player.yaw) * (me.ph.radius + att.ph.radius + 4); att.y = me.y + Math.sin(G.player.yaw) * (me.ph.radius + att.ph.radius + 4); att.foe = null; att.cooldown = 5; };
    const full = () => { me.energy = me.ph.storage; me.bleedT = 0; me.bleedR = 0; F.stam = 100; F.exhausted = false; F.stagger = 0; att._stagT = 0; F.pending.length = 0; };
    G.world.params.timeScale = 0.01;
    st(0.02, 5);
    // 1. unguarded strike: deferred, then lands in full
    full(); place();
    let e0 = me.energy;
    const r = G.fightFilter(me, att, 20);
    out.deferred = r === null && F.pending.length === 1;
    out.windup = +F.pending[0].dur.toFixed(2);
    st(0.02, 2); out.noDmgDuringWindup = Math.abs(me.energy - e0) < 1e-6 || me.energy >= e0 - 0.5;
    for (let i = 0; i < 60 && F.pending.length; i++) { place(); G.step(0.02); }
    out.unguarded = +(e0 - me.energy).toFixed(2);
    // 2. guarded (raised long before): 30% through, stamina spent
    full(); place(); G.press('q', true); F.blockT0 = G.simT - 5;
    e0 = me.energy; const s0 = F.stam;
    G.fightFilter(me, att, 20);
    for (let i = 0; i < 60 && F.pending.length; i++) { place(); G.step(0.02); }
    out.blocked = +(e0 - me.energy).toFixed(2); out.blockStam = +(s0 - F.stam).toFixed(1);
    G.press('q', false);
    // 3. parry: raise guard in the last 0.1 s
    full(); place(); e0 = me.energy;
    G.fightFilter(me, att, 20);
    while (F.pending.length && F.pending[0].t > 0.1) { place(); G.step(0.02); }
    G.press('q', true); F.blockT0 = G.simT;
    for (let i = 0; i < 20 && F.pending.length; i++) { place(); G.step(0.02); }
    out.parryDmg = +(e0 - me.energy).toFixed(2); out.parryStag = att._stagT > G.simT;
    out.staggeredCannotStrike = G.fightFilter(me, att, 20) === null && F.pending.length === 0;
    G.press('q', false);
    // 4. dodge timed into the strike: i-frames eat it
    full(); place(); e0 = me.energy;
    G.fightFilter(me, att, 20);
    while (F.pending.length && F.pending[0].t > 0.12) { place(); G.step(0.02); }
    const x0 = me.x, z0 = me.y; G.dodge();
    for (let i = 0; i < 25; i++) G.step(0.02);
    out.dodgeDmg = +(e0 - me.energy).toFixed(2); out.dodgeMoved = +Math.hypot(me.x - x0, me.y - z0).toFixed(1);
    // 5. guard with no stamina breaks
    full(); place(); G.press('q', true); F.blockT0 = G.simT - 5; F.stam = 2; e0 = me.energy;
    G.fightFilter(me, att, 20);
    for (let i = 0; i < 60 && F.pending.length; i++) { place(); G.step(0.02); }
    out.guardBreakDmg = +(e0 - me.energy).toFixed(2); out.guardBreakStagger = F.stagger > 0;
    G.press('q', false);
    // 6. lock-on and a swing that lands at its strike frame with knockback
    full(); place(); att.energy = att.ph.storage;
    G.lock(); out.locked = F.lock === att || !!F.lock;
    F.lock = att;
    const ae = att.energy, ax = att.x, az = att.y;
    G.attack(); out.swingDeferred = Math.abs(att.energy - ae) < 1e-6;
    for (let i = 0; i < 40; i++) { att.cooldown = 5; G.step(0.02); }
    out.swingDmg = +(ae - att.energy).toFixed(2);
    out.splats = F.splatN; out.blood = F.blood.length;
    // 7. sprinting drains stamina to exhaustion
    full(); G.press('w', true); G.press('shift', true); F.shiftT0 = -1;
    for (let i = 0; i < 350; i++) G.step(0.02);
    out.sprintStam = +F.stam.toFixed(1); out.exhausted = F.exhausted;
    G.press('w', false); G.press('shift', false);
    for (let i = 0; i < 250; i++) G.step(0.02);
    out.recovered = +F.stam.toFixed(1);
    // 8. natural: a provoked animal fights you through the core; strikes are telegraphed then land
    full(); F.lock = null; att.alive = true; att.energy = att.ph.storage; att.cooldown = 0; att._stagT = 0;
    att.x = me.x + 20; att.y = me.y;
    const seq0 = me._hitSeq || 0; let maxPend = 0; e0 = me.energy;
    for (let i = 0; i < 200; i++) { att.react = 'fight'; att.foe = me; att.foeT = 5; att.x = me.x + 20; att.y = me.y; G.step(0.02); maxPend = Math.max(maxPend, F.pending.length); }
    out.naturalHits = (me._hitSeq || 0) - seq0; out.naturalPend = maxPend; out.naturalDmg = +(e0 - me.energy).toFixed(1);
    return out;
  });
  T.log(JSON.stringify(R));
  // visual: third person, opponent winding up, blood on the ground, locked on
  await p.evaluate(() => {
    const G = window.__G3D, F = G.FIGHT, me = G.player.c;
    let att = F.lock; if (!att || !att.alive) for (const c of G.world.creatures) if (c.alive && c !== me) { att = c; break; }
    F.lock = att;
    att.x = me.x + Math.cos(G.player.yaw) * 40; att.y = me.y + Math.sin(G.player.yaw) * 40; att.cooldown = 9;
    for (let i = 0; i < 12; i++) { const a = i * 0.5; F.blood.length = 0; }
    me.bleedT = 5; me.bleedR = 0.01;
    G.fightFilter(me, att, 5);
    G.player.dist = 150; G.player.pitch = -0.35;
    for (let i = 0; i < 10; i++) G.step(0.016);
    G.renderFrame(G.simT);
  });
  await T.wait(1200);
  await T.shot('fight1.png');
};
