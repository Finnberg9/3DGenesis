# =====================================================================
# THE FIRST SCREEN IS TWO WORDS
#
# CAMPAIGN and ONLINE. Everything else that was on the front page --
# continue, load a creature, controls, options, about -- is still there and
# still reachable, it has just stopped competing with the only two decisions
# a player actually arrives wanting to make.
#
# CAMPAIGN is the single-player island, which is what the game already was,
# and it is where the story will go. ONLINE is the battle royale, which is
# the one that has to work.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, ('ANCHOR %d/%d' % (n, cnt), a[:110]); return s.replace(a, b)

p = 'g3.html'; s = open(p, encoding='utf-8').read()

s = sub1(s, """function menuItems() {
  const out = [];
  if (PROG.last) out.push({ id: 'continue', label: 'CONTINUE', desc: 'Play ' + (PROG.last.name || 'your last creature') + ' again on a fresh island.' });
  out.push({ id: 'new', label: 'NEW GAME', desc: 'Build a creature from scratch and hatch it into a new island.' });
  out.push({ id: 'load', label: 'LOAD CREATURE', desc: 'Pick one of the creatures you have saved and play it.' });
  out.push({ id: 'online', label: 'BATTLE ROYALE', desc: 'A fifteen-minute match. Twenty-four cages, one island, a closing fog. Last one standing wins.' });
  out.push({ id: 'controls', label: 'CONTROLS', desc: 'Every key and what it does: moving, fighting, flying and surviving.' });
  out.push({ id: 'options', label: 'OPTIONS', desc: 'Graphics quality, render scale, sound and the world settings.' });
  out.push({ id: 'credits', label: 'ABOUT', desc: 'What this game is and how its animals are made.' });
  return out;
}""",
"""// Two choices, and a third short line for everything that is not a choice
// about what to play.
function menuItems() {
  return [
    { id: 'campaign', label: 'CAMPAIGN', desc: 'One island, one creature, one life at a time. Build a beast and survive it.' },
    { id: 'online', label: 'ONLINE', desc: 'Battle royale. Everyone starts with nothing, the fog closes, one is left.' },
    { id: 'more', label: 'MORE', desc: 'Controls, options, saved creatures and what this is.' },
  ];
}""")
s = sub1(s, "  if (it.id === 'online') { menuPage('online'); return; }",
"""  if (it.id === 'online') { menuPage('online'); return; }
  if (it.id === 'campaign') { menuPage('campaign'); return; }
  if (it.id === 'more') { menuPage('more'); return; }""")

# the campaign page: what used to be three separate front-page entries
s = sub1(s, "  } else if (id === 'online') {",
"""  } else if (id === 'campaign') {
    const list = (PROG.saved || []);
    h = '<h2>CAMPAIGN</h2>' +
      '<p>You are one animal on one island. You hatch small, you grow into whatever your body can become, ' +
      'and everything you are carrying you took off something that is no longer using it. There is no story ' +
      'to follow yet: this is the world the story will be set in.</p>' +
      '<div class="mmopt">' +
      (PROG.last ? '<button class="mmb wide" data-camp="last">continue with your last creature</button>' : '') +
      '<button class="mmb wide" data-camp="new">build a new creature</button>' +
      (list.length ? '<button class="mmb wide" data-camp="load">load a saved creature</button>' : '') +
      '</div>' +
      '<p class="mmnote">Story mode is not built yet. Everything here is the free island it will run on.</p>';
  } else if (id === 'more') {
    h = '<h2>MORE</h2><div class="mmopt">' +
      '<button class="mmb wide" data-more="controls">controls</button>' +
      '<button class="mmb wide" data-more="options">options</button>' +
      '<button class="mmb wide" data-more="load">saved creatures</button>' +
      '<button class="mmb wide" data-more="credits">about</button>' +
      '</div>';
  } else if (id === 'online') {""")

# the buttons on those two pages
s = sub1(s, """    if (t.dataset.brgo != null) {""",
"""    if (t.dataset.camp != null) {
      const m = t.dataset.camp;
      if (m === 'last' && PROG.last) { becomeDesigned(C.cloneDesign(PROG.last)); menuStart(); return; }
      if (m === 'load') { menuPage('load'); return; }
      menuFresh(() => { stopMenuMusic(true); const st = document.getElementById('start'); if (st) st.style.display = 'none'; openEditor('start'); });
      return;
    }
    if (t.dataset.more != null) { menuPage(t.dataset.more); return; }
    if (t.dataset.brgo != null) {""")

# the online page describes the match this build actually runs
s = sub1(s, """      '<p>Twenty-four creatures, one island, fifteen minutes. You start locked in a numbered cage on the ring. ' +
      'The gates go up together. For the first five minutes no player can touch another: hunt the island\\'s own ' +
      'animals and take their parts. Then it is open. A fog closes in from the edge and kills whatever it catches. ' +
      'Kill a player and you eat them, grow, take a part off their body and earn ' + BONES_PER_KILL + ' bones; they choose to watch you ' +
      'or come back as your young, and a pack that wins, wins together.</p>' +""",
"""      '<p>One island, fifteen minutes, and nobody brings anything in. Everyone spawns as a bare body in a ' +
      'numbered cage on the ring, with a small pile on the cage floor holding a mouth and one weapon. That is ' +
      'your entire head start. The gates go up together and it is live from the first second.</p>' +
      '<p>There is no wildlife. Everything alive out there is somebody. What you fight with, you take off the ' +
      'island\\'s old bodies or off the players you beat, and the glowing mushrooms scattered across the map are ' +
      'four one-shot powers you carry and spend: double damage, untouchable, small and unseen, or bigger and ' +
      'faster and stronger. None of it leaves the match. A fog closes in from the edge and kills whatever it ' +
      'catches. Kill a player and you grow, take a pair of their parts and earn ' + BONES_PER_KILL + ' bones; they choose to watch ' +
      'you or come back as your young, and a pack that wins, wins together.</p>' +""")
s = sub1(s, """      '<p class="mmnote"><b>This build has no game server.</b> The match, the zone, the grace period, the looting, the ' +
      'packs and the win are all real and run to the end, but the other twenty-three are bots on this machine. Every ' +""",
"""      '<p class="mmnote"><b>This build has no game server.</b> The match, the zone, the looting, the ' +
      'packs and the win are all real and run to the end, but the other players are bots on this machine. Every ' +""")

open(p, 'w', encoding='utf-8').write(s)
print('menu: two doors ok')

# the checks drive the real menu rather than a stand-in
s = open(p, encoding='utf-8').read()
s = sub1(s, "  pick: (i) => choosePicked(i),",
"""  menu: {
    items: () => menuItems().map((it) => it.id),
    page: (id) => { menuPage(id); return MENU.page; },
    choose: (i) => { MENU.i = i | 0; menuRender(); menuChoose(); return MENU.page; },
  },
  pick: (i) => choosePicked(i),""")
open(p, 'w', encoding='utf-8').write(s)
print('menu: test surface ok')
