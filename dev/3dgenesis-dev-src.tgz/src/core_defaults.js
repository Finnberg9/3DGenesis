  // ---------------------------------------------------------- default designs
  // Each body plan ships with a starting body: eyes, a mouth and whatever
  // limbs the plan implies, placed by casting onto the real skin so they sit
  // exactly on the surface regardless of the plan's proportions.
  const PLAN_COLORS = [
    { base: [0.28, 0.62, 0.52], coat: [0.88, 0.84, 0.64], detail: [0.14, 0.33, 0.28], pat: 1 },
    { base: [0.86, 0.64, 0.30], coat: [0.97, 0.91, 0.76], detail: [0.46, 0.25, 0.12], pat: 3 },
    { base: [0.55, 0.34, 0.76], coat: [0.36, 0.76, 0.72], detail: [0.26, 0.12, 0.42], pat: 1 },
    { base: [0.36, 0.62, 0.22], coat: [0.90, 0.86, 0.52], detail: [0.14, 0.30, 0.10], pat: 2 },
    { base: [0.74, 0.24, 0.22], coat: [0.96, 0.72, 0.52], detail: [0.22, 0.06, 0.06], pat: 2 },
    { base: [0.26, 0.46, 0.76], coat: [0.72, 0.86, 0.96], detail: [0.10, 0.20, 0.42], pat: 1 },
    { base: [0.20, 0.50, 0.80], coat: [0.93, 0.95, 0.98], detail: [0.96, 0.60, 0.20], pat: 1 },
    { base: [0.86, 0.46, 0.26], coat: [0.98, 0.89, 0.72], detail: [0.36, 0.16, 0.10], pat: 0 },
    { base: [0.50, 0.52, 0.58], coat: [0.78, 0.75, 0.72], detail: [0.30, 0.30, 0.36], pat: 3 },
    { base: [0.95, 0.78, 0.26], coat: [0.99, 0.95, 0.72], detail: [0.62, 0.36, 0.10], pat: 2 },
  ];
  function surfaceAt(sk, tx, ty, tz, dx, dy, dz) {
    const l = Math.hypot(dx, dy, dz) || 1; dx /= l; dy /= l; dz /= l;
    const D = 4;
    return raySkin(sk, tx + dx * D, ty + dy * D, tz + dz * D, -dx, -dy, -dz, D * 2);
  }
  // Skin covering per plan: 0 smooth, 1 scales, 2 feathers, 3 fur, 4 armour plates.
  const PLAN_SKIN = [1, 3, 1, 1, 3, 4, 1, 2, 4, 0];
  // opt (all optional): body {len,girth,neck,tail}; eye / mouth / tip(id)->id overrides.
  function defaultDesign(planIdx, opt) {
    opt = opt || {};
    const pi = clamp(planIdx | 0, 0, PLANS.length - 1);
    const pc = PLAN_COLORS[pi];
    const bd = Object.assign({ len: 1, girth: 1, neck: 1, tail: 1 }, opt.body || {});
    const d = { v: 1, plan: pi, body: bd,
                col: { base: pc.base.slice(), coat: pc.coat.slice(), detail: pc.detail.slice(), pat: pc.pat, skin: PLAN_SKIN[pi] },
                parts: [], limbs: [] };
    const sk = buildDesignSkeleton(d);
    const P = sk.plan, B = sk.balls;
    const head = B[sk.headIdx], snout = B[sk.headIdx + 1];
    let mkey = 1;
    const put = (id, tx, ty, tz, nx, ny, nz, s, mirror) => {
      if (opt.map) { id = opt.map(id); if (!id) return null; }
      const h = surfaceAt(sk, tx, ty, tz, nx, ny, nz);
      if (!h) return null;
      const pt = { id, b: 0, o: [0, 0, 0], n: [0, 1, 0], spin: 0, s: s || 1, c: null, m: 0 };
      setAnchor(sk, pt, h.p, h.n, h.b);
      d.parts.push(pt);
      if (mirror && Math.abs(h.p[2]) > 0.08) {
        const key = mkey++;
        pt.m = key;
        const tw = JSON.parse(JSON.stringify(pt));
        const hp = [h.p[0], h.p[1], -h.p[2]], hn = [h.n[0], h.n[1], -h.n[2]];
        setAnchor(sk, tw, hp, hn, nearestBall(sk, hp[0], hp[1], hp[2], true));
        tw.m = key;
        d.parts.push(tw);
      }
      return pt;
    };
    const tailPut = (id, s) => {
      if (sk.tailLen <= 0.05) return;
      const bi = sk.tailStart + P.ts - 1, k = B[bi];
      const pt = { id, b: bi, o: [-1, 0, 0], n: [-1, 0, 0], spin: 0, s: s || 1, c: null, m: 0 };
      d.parts.push(pt);
    };
    // limbs: foot given in body space; knee bend given as an offset from the
    // straight hip-to-foot midpoint
    const limb = (id, tx, ty, tz, fx, fy, fz, kx, ky, kz, tip, th) => {
      if (opt.mapLimb) { const nid = opt.mapLimb(id); if (nid === 'l_spring' && id !== nid) { kx -= 0.5; } id = nid; }
      const h = surfaceAt(sk, tx, ty, tz, 0, -0.55, Math.sign(tz) || 0);
      if (!h) return;
      const root = h.p;
      const f = [fx - root[0], fy - root[1], fz - root[2]];
      const k = [f[0] * 0.5 + kx, f[1] * 0.5 + ky, f[2] * 0.5 + kz];
      const key = mkey++;
      const tipId = tip && opt.map ? opt.map(tip) : tip;
      const mk = (sgn) => {
        const lb = { id, b: 0, o: [0, 0, 0], n: [0, -1, 0], k: [k[0], k[1], k[2] * sgn], f: [f[0], f[1], f[2] * sgn],
                     th: th || 1, c: null, tip: tipId ? { id: tipId, c: null, s: 1 } : null, m: key };
        const rp = [root[0], root[1], root[2] * sgn], rn = [h.n[0], h.n[1], h.n[2] * sgn];
        setAnchor(sk, lb, rp, rn, nearestBall(sk, rp[0], rp[1], rp[2], false));
        d.limbs.push(lb);
      };
      mk(1); mk(-1);
    };
    const hr = head.r;
    const eyeAt = (id, s, up, fwd, side) => put(id, head.x + hr * fwd, head.y + hr * up, hr * side, fwd * 0.6, up, side, s, true);
    const mouthAt = (id, s) => put(id, snout.x + snout.r * 0.9, snout.y - snout.r * 0.25, 0, 1, -0.35, 0, s, false);
    const a = sk.a, b = sk.b, st = P.stand;
    switch (pi) {
      case 0: // four-legged runner
        eyeAt('e_round', 1, 0.45, 0.35, 0.62); mouthAt('m_beak', 1);
        limb('l_leg',  a * 0.52, -b * 0.3,  b * 0.45,  a * 0.58, -st,  b * 0.62, 0.18, 0, 0.04, 't_paw');
        limb('l_leg', -a * 0.55, -b * 0.3,  b * 0.45, -a * 0.52, -st,  b * 0.62, -0.18, 0, 0.04, 't_paw');
        break;
      case 1: // long neck
        eyeAt('e_round', 0.9, 0.45, 0.3, 0.62); mouthAt('m_grazer', 0.9);
        put('h_straight', head.x - hr * 0.1, head.y + hr, hr * 0.3, -0.2, 1, 0.3, 0.55, true);
        limb('l_leg',  a * 0.50, -b * 0.3,  b * 0.40,  a * 0.55, -st,  b * 0.55, 0.2, 0, 0.04, 't_hoof', 0.9);
        limb('l_leg', -a * 0.52, -b * 0.3,  b * 0.40, -a * 0.50, -st,  b * 0.55, -0.2, 0, 0.04, 't_hoof', 0.9);
        break;
      case 2: // upright hunter with arms
        eyeAt('e_round', 1.1, 0.5, 0.35, 0.6); mouthAt('m_jaws', 1);
        limb('l_leg', -a * 0.25, -b * 0.35, b * 0.5, -a * 0.12, -st, b * 0.6, 0.3, 0.05, 0.05, 't_paw', 1.15);
        limb('l_leg', a * 0.62, 0, b * 0.62, a * 1.05, -b * 0.62, b * 0.55, 0.05, -0.22, 0.12, 't_claw', 0.8);
        break;
      case 3: // serpent
        eyeAt('e_slit', 1, 0.5, 0.3, 0.62); mouthAt('m_jaws', 1);
        break;
      case 4: // eight legs
        eyeAt('e_round', 0.8, 0.55, 0.55, 0.45); eyeAt('e_round', 0.6, 0.75, 0.3, 0.25); mouthAt('m_jaws', 0.9);
        for (const u of [0.55, 0.2, -0.2, -0.55]) {
          const h = surfaceAt(sk, a * u, 0, b * 0.9, 0, 0.1, 1);
          if (!h) continue;
          const key = mkey++;
          const spread = u * 1.1;
          for (const sg of [1, -1]) {
            const lb = { id: 'l_thin', b: 0, o: [0, 0, 0], n: [0, 0, sg], k: [spread * 0.35, 0.75, 0.95 * sg],
                         f: [spread * 0.8, -st - h.p[1], 1.85 * sg], th: 0.85, c: null, tip: null, m: key };
            const rp = [h.p[0], h.p[1], h.p[2] * sg], rn = [h.n[0], h.n[1], h.n[2] * sg];
            setAnchor(sk, lb, rp, rn, nearestBall(sk, rp[0], rp[1], rp[2], false));
            d.limbs.push(lb);
          }
        }
        break;
      case 5: // six legs
        eyeAt('e_bug', 0.9, 0.35, 0.45, 0.62); mouthAt('m_beak', 0.8);
        put('d_antenna', head.x + hr * 0.2, head.y + hr, hr * 0.3, 0.3, 1, 0.3, 1, true);
        for (const u of [0.45, 0.02, -0.4]) {
          const h = surfaceAt(sk, a * u, -b * 0.1, b * 0.6, 0, -0.3, 1);
          if (!h) continue;
          const key = mkey++;
          for (const sg of [1, -1]) {
            const lb = { id: 'l_thin', b: 0, o: [0, 0, 0], n: [0, 0, sg], k: [u * 0.5, 0.45, 0.8 * sg],
                         f: [u * 1.1, -st - h.p[1], 1.25 * sg], th: 0.9, c: null, tip: null, m: key };
            const rp = [h.p[0], h.p[1], h.p[2] * sg], rn = [h.n[0], h.n[1], h.n[2] * sg];
            setAnchor(sk, lb, rp, rn, nearestBall(sk, rp[0], rp[1], rp[2], false));
            d.limbs.push(lb);
          }
        }
        break;
      case 6: // swimmer
        eyeAt('e_round', 1, 0.35, 0.3, 0.65); mouthAt('m_beak', 0.9);
        put('f_fin', a * 0.35, -b * 0.3, b, 0, -0.35, 1, 1, true);
        put('f_dorsal', -a * 0.05, b * 1.2, 0, 0, 1, 0, 1.1, false);
        tailPut('f_fluke', 1.1);
        break;
      case 7: // flier
        eyeAt('e_round', 1, 0.45, 0.35, 0.6); mouthAt('m_beak', 1);
        put('w_feather', a * 0.1, b * 0.55, b * 0.55, 0, 0.7, 0.7, 1, true);
        limb('l_leg', -a * 0.12, -b * 0.4, b * 0.35, -a * 0.02, -st, b * 0.45, 0.22, 0, 0.03, 't_talon', 0.8);
        break;
      case 8: // heavy
        eyeAt('e_round', 0.8, 0.45, 0.35, 0.62); mouthAt('m_grazer', 1.1);
        put('h_rhino', snout.x + snout.r * 0.2, snout.y + snout.r, 0, 0.35, 1, 0, 1, false);
        limb('l_thick',  a * 0.52, -b * 0.3,  b * 0.55,  a * 0.55, -st,  b * 0.72, 0.1, 0, 0.03, 't_hoof', 1.3);
        limb('l_thick', -a * 0.52, -b * 0.3,  b * 0.55, -a * 0.55, -st,  b * 0.72, -0.1, 0, 0.03, 't_hoof', 1.3);
        break;
      case 9: // blob
        eyeAt('e_stalk', 1, 0.7, 0.2, 0.4); mouthAt('m_grazer', 1);
        put('s_knob', -a * 0.2, b * 1.3, 0, 0, 1, 0, 1, false);
        break;
    }
    return d;
  }
  // ---------------------------------------------------------- random designs
  // Every animal on the island is a designed body: founders are drawn from the
  // same ten plans and part vocabulary the editor uses, with random proportions,
  // eyes, mouths, feet, ornaments, colours and skin, so wild animals and your
  // own creature are built, rendered and animated the same way.
  function hsv(h, sat, v) {
    h = ((h % 1) + 1) % 1;
    const i = Math.floor(h * 6), f = h * 6 - i, p = v * (1 - sat), q = v * (1 - f * sat), t = v * (1 - (1 - f) * sat);
    return [[v, t, p], [q, v, p], [p, v, t], [p, q, v], [t, p, v], [v, p, q]][i % 6];
  }
  function pickW(rng, list) {
    let tot = 0; for (const e of list) tot += e[1];
    let r = rng() * tot;
    for (const e of list) { r -= e[1]; if (r <= 0) return e[0]; }
    return list[list.length - 1][0];
  }
  const FOUNDER_PLANS = [[0, 3], [1, 1.5], [2, 1.5], [3, 1.5], [4, 1], [5, 1.2], [7, 1.2], [8, 1.5], [9, 1.2]];
  function randomColours(rng, pi) {
    // mostly earthy and natural, now and then something vivid
    const vivid = rng() < 0.22;
    const h = vivid ? rng() : pickW(rng, [[0.07, 3], [0.1, 2], [0.13, 2], [0.25, 2], [0.33, 1.5], [0.02, 1], [0.55, 1], [0.6, 0.7], [0.8, 0.5]]) + (rng() - 0.5) * 0.06;
    const sat = vivid ? 0.55 + rng() * 0.35 : 0.3 + rng() * 0.35;
    const val = 0.42 + rng() * 0.4;
    const base = hsv(h, sat, val);
    const coat = hsv(h + (rng() - 0.5) * 0.08, sat * (0.25 + rng() * 0.3), Math.min(0.97, val + 0.25 + rng() * 0.15));
    const dh = rng() < 0.3 ? h + 0.5 : h + (rng() - 0.5) * 0.1;
    const detail = hsv(dh, Math.min(1, sat * (0.8 + rng() * 0.5)), val * (0.35 + rng() * 0.35));
    const pat = pickW(rng, [[0, 1.4], [1, 1.2], [2, 1.2], [3, 0.8], [4, 1], [5, 0.7]]);
    const skin = rng() < 0.7 ? PLAN_SKIN[pi] : pickW(rng, [[0, 0.6], [1, 1.2], [2, 0.6], [3, 1], [4, 0.6]]);
    return { base, coat, detail, pat, skin };
  }
  // ornaments a wild animal may carry
  function addOrnaments(d, rng, n) {
    const sk = buildDesignSkeleton(d);
    const B = sk.balls, head = B[sk.headIdx], snout = B[sk.headIdx + 1];
    const a = sk.a, b = sk.b, hr = head.r;
    let mkey = 1000 + ((rng() * 1e6) | 0);
    const put = (id, tx, ty, tz, nx, ny, nz, s, mirror) => {
      const h = surfaceAt(sk, tx, ty, tz, nx, ny, nz);
      if (!h) return;
      const pt = { id, b: 0, o: [0, 0, 0], n: [0, 1, 0], spin: 0, s: s || 1, c: null, m: 0 };
      setAnchor(sk, pt, h.p, h.n, h.b);
      d.parts.push(pt);
      if (mirror && Math.abs(h.p[2]) > 0.08) {
        const key = mkey++; pt.m = key;
        const tw = JSON.parse(JSON.stringify(pt));
        const hp = [h.p[0], h.p[1], -h.p[2]], hn = [h.n[0], h.n[1], -h.n[2]];
        setAnchor(sk, tw, hp, hn, nearestBall(sk, hp[0], hp[1], hp[2], true));
        tw.m = key; d.parts.push(tw);
      }
    };
    const has = (t) => d.parts.some(p => ITEM_SIM[p.id] && ITEM_SIM[p.id].t === t);
    for (let i = 0; i < n; i++) {
      const kind = pickW(rng, [['dorsal', 3], ['horns', 2.2], ['nose', 0.8], ['crest', 1], ['frill', 0.7], ['tailclub', 0.5], ['fin', 0.6], ['knobs', 0.8], ['antenna', 0.5]]);
      const sz = 0.75 + rng() * 0.5;
      if (kind === 'dorsal') {
        const id = pickW(rng, [['s_spike', 3], ['s_plate', 2], ['s_quills', 1.2]]);
        const cnt = 2 + ((rng() * 3) | 0);
        for (let j = 0; j < cnt; j++) {
          const u = 0.45 - j * (0.9 / Math.max(1, cnt - 1)) * (0.7 + rng() * 0.2);
          put(id, a * u, b * 1.4, 0, 0, 1, 0, sz * (1 - Math.abs(u) * 0.4), false);
        }
      } else if (kind === 'horns' && !has('HORN')) {
        const id = pickW(rng, [['h_straight', 2], ['h_curved', 2], ['h_ram', 1], ['h_antler', 1], ['h_tusk', 0.6]]);
        if (id === 'h_tusk') put(id, snout.x + snout.r * 0.4, snout.y - snout.r * 0.4, snout.r * 0.6, 0.5, -0.4, 0.8, sz * 0.8, true);
        else put(id, head.x - hr * 0.1, head.y + hr, hr * 0.35, -0.25, 1, 0.35, sz * 0.7, true);
      } else if (kind === 'nose' && !has('HORN')) {
        put('h_rhino', snout.x + snout.r * 0.2, snout.y + snout.r, 0, 0.35, 1, 0, sz * 0.8, false);
      } else if (kind === 'crest') {
        put('d_crest', head.x - hr * 0.2, head.y + hr * 1.2, 0, -0.2, 1, 0, sz, false);
      } else if (kind === 'frill') {
        put('d_frill', head.x - hr * 0.9, head.y + hr * 0.4, 0, -1, 0.5, 0, sz, false);
      } else if (kind === 'tailclub') {
        if (sk.tailLen > 0.05) { const bi = sk.tailStart + sk.plan.ts - 1; d.parts.push({ id: 's_club', b: bi, o: [-1, 0, 0], n: [-1, 0, 0], spin: 0, s: sz * 0.8, c: null, m: 0 }); }
      } else if (kind === 'fin') {
        put('f_dorsal', -a * 0.05, b * 1.3, 0, 0, 1, 0, sz * 0.8, false);
      } else if (kind === 'knobs') {
        put('s_knob', a * (rng() - 0.5) * 0.8, b * 0.6, b * 0.8, 0, 0.6, 0.8, sz * 0.8, true);
      } else if (kind === 'antenna' && !d.parts.some(p => p.id === 'd_antenna')) {
        put('d_antenna', head.x + hr * 0.2, head.y + hr, hr * 0.3, 0.3, 1, 0.3, sz * 0.8, true);
      }
    }
  }
  function randomDesign(rng, opt) {
    opt = opt || {};
    const div = clamp(numOr(opt.diversity, 0.5), 0, 1);
    const pi = opt.plan != null ? opt.plan : pickW(rng, opt.water ? FOUNDER_PLANS.concat([[6, 2]]) : FOUNDER_PLANS);
    const R = BODY_RANGE, span = 0.25 + div * 0.55;
    const pick = (k, c) => clamp(c + (rng() - 0.5) * span * (R[k][1] - R[k][0]) * 0.7, R[k][0], R[k][1]);
    const body = { len: pick('len', 1), girth: pick('girth', 1), neck: pick('neck', 1), tail: pick('tail', 1) };
    const carn = opt.diet === 'carn';
    const eye = pi === 4 || pi === 5 ? pickW(rng, [['e_bug', 2], ['e_round', 1], ['e_cluster', 1]])
              : pi === 9 ? pickW(rng, [['e_stalk', 2], ['e_round', 1], ['e_big', 0.5]])
              : pickW(rng, [['e_round', 3], ['e_slit', 2.2], ['e_big', 0.8], ['e_stalk', 0.25]]);
    const mouth = carn ? pickW(rng, [['m_jaws', 3], ['m_maw', 1]]) : pickW(rng, [['m_beak', 2], ['m_grazer', 3], ['m_trunk', 0.35]]);
    const tipFor = (id) => {
      if (id === 't_paw' || id === 't_hoof') return carn ? pickW(rng, [['t_paw', 2], ['t_claw', 1.5], ['t_talon', 1]]) : pickW(rng, [['t_paw', 2], ['t_hoof', 2], ['t_pad', 1]]);
      if (id === 't_claw') return carn ? pickW(rng, [['t_claw', 2], ['t_pincer', 1], ['t_hand', 1]]) : pickW(rng, [['t_hand', 2], ['t_paw', 1], ['t_claw', 0.5]]);
      if (id === 't_talon') return pickW(rng, [['t_talon', 2], ['t_paw', 1]]);
      return id;
    };
    const map = (id) => {
      const s = ITEM_SIM[id];
      if (!s) return id;
      if (s.t === 'EYE' && id !== 'd_antenna') return eye;
      if (s.t === 'MOUTH') return mouth;
      if (s.t === 'TIP') return tipFor(id);
      if (s.t === 'HORN' && rng() < 0.4) return null;
      return id;
    };
    const spring = (pi === 0 || pi === 2 || pi === 7) && rng() < 0.14;
    const d = defaultDesign(pi, { body, map, mapLimb: (id) => (spring && id === 'l_leg' ? 'l_spring' : id) });
    reseatDesign(d);
    d.col = randomColours(rng, pi);
    const nOrn = Math.floor(rng() * (1 + div * 3.2));
    if (nOrn) addOrnaments(d, rng, nOrn);
    // limb proportions
    for (const lb of d.limbs) { const k = 0.9 + rng() * 0.25 * (0.5 + div); lb.k = lb.k.map(v => v * k); lb.f = lb.f.map(v => v * k); lb.th = clamp(numOr(lb.th, 1) * (0.85 + rng() * 0.35), 0.5, 2); }
    for (const pt of d.parts) if (ITEM_SIM[pt.id] && ITEM_SIM[pt.id].t === 'EYE') pt.s = clamp(numOr(pt.s, 1) * (0.8 + rng() * 0.35), 0.3, 3);
    return d;
  }
  // mouth swap used by mutation, so diets can still evolve in designed lineages
  function swapMouth(d, rng) {
    const pt = (d.parts || []).find(p => ITEM_SIM[p.id] && ITEM_SIM[p.id].t === 'MOUTH');
    if (!pt) return false;
    const mode = ITEM_SIM[pt.id].mode;
    pt.id = mode === 'carn' ? pickW(rng, [['m_grazer', 2], ['m_beak', 1], ['m_hook', 1]]) : pickW(rng, [['m_jaws', 3], ['m_maw', 1], ['m_hook', 0.6]]);
    return true;
  }
  DESIGN_API.randomDesign = randomDesign;
  DESIGN_API.addOrnaments = addOrnaments;
  DESIGN_API.swapMouth = swapMouth;
  DESIGN_API.PLAN_SKIN = PLAN_SKIN;
  DESIGN_API.defaultDesign = defaultDesign;
  DESIGN_API.PLAN_COLORS = PLAN_COLORS;
  DESIGN_API.surfaceAt = surfaceAt;
