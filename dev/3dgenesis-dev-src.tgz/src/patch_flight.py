# Flight rebuilt (glide, flap, swoop, bank, thermals, stall, landing) and
# rearing up on the hind legs to reach high food. See src/flight.js.
def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
p='g3.html'; s=open(p,encoding='utf-8').read()
s=sub1(s,"function stepSim(dt) {\n", open('src/flight.js',encoding='utf-8').read()+"\nfunction stepSim(dt) {\n")
# replace the old lift-style flight
i=s.index("function updateFlight(dt) {")
j=s.index("function updateJump(dt) {")
s=s[:i]+"function updateFlight(dt) { flightTick(dt); rearTick(dt); }\n\n"+s[j:]
# movement while flying: the glider carries you; on the ground, rearing slows you
s=sub1(s,"""  const inWater = terrain.isWater(c.x, c.y);
  const airborne = p.canFly && player.fly > 0.5;""","""  const inWater = terrain.isWater(c.x, c.y);
  const airborne = flightAirborne();
  if (airborne) {
    // in the air you go where you are pointed, at the speed the wing is making
    const gs = flightGroundSpeed();
    c.vx = Math.cos(player.yaw) * gs; c.vy = Math.sin(player.yaw) * gs;
    const ts0 = world.params.timeScale != null ? world.params.timeScale : 0.12;
    const md = dt * clamp(ts0 / 0.12, 1, 8);
    c.x = clamp(c.x + c.vx * md, 1, WORLD_W - 1); c.y = clamp(c.y + c.vy * md, 1, WORLD_H - 1);
    return;
  }""")
s=sub1(s,"  sp *= PLAYER_SPEED * (dodgeV ? 1 : fightSpeedMul());","  sp *= PLAYER_SPEED * (dodgeV ? 1 : fightSpeedMul()) * (1 - 0.75 * (player.rear || 0));")
# reach: rearing up nearly doubles it
s=sub1(s,"""function interactRange(p) {
  return p.radius + p.reach * 1.6 + 34;
}""","""function interactRange(p) {
  return (p.radius + p.reach * 1.6 + 34) * (typeof rearReach === 'function' ? rearReach(p) : 1);
}""")
# HUD: altitude, airspeed and the flight keys replace the old climb/dive line
s=sub1(s,"""      (p.canFly ? `<br><span class="k">altitude</span> <span class="v">${player.fly.toFixed(0)}</span>` +
                  ` <span class="k">(space climb, ctrl dive)</span>` : '');""","""      (p.canFly ? flightHud() : '') +
      ((player.rear || 0) > 0.05 ? `<br><span style="color:#7ee787">reared up: reach x${rearReach(p).toFixed(2)}</span>` : '');""")
# the wing beat is driven by the flight model for the player
s=sub1(s,"    flap: Math.sin(t * (airborne ? 6.5 : 3.4) + c.id) * (airborne ? 0.62 : (p.canFly ? 0.18 : 0.08)),",
         "    flap: (isPlayer && c._flapDrive != null && (p.canFly || false)) ? c._flapDrive\n        : Math.sin(t * (airborne ? 6.5 : 3.4) + c.id) * (airborne ? 0.62 : (p.canFly ? 0.18 : 0.08)),")
# rearing: the body pitches up onto its hind legs and rides higher
s=sub1(s,"  c._tiltP = c._tiltP == null ? tP : c._tiltP + (tP - c._tiltP) * ke;",
         "  if (c._rear > 0.01) tP -= 0.95 * c._rear;      // up on the hind legs\n  c._tiltP = c._tiltP == null ? tP : c._tiltP + (tP - c._tiltP) * ke;")
s=sub1(s,"  const bodyY = groundY + stand + bob;","  const bodyY = groundY + stand * (1 + 0.55 * (c._rear || 0)) + bob;")
# controls help
s=sub1(s,"  get FIGHT() { return FIGHT; },","  get FL() { return FL; }, thermalAt: (x, z) => thermalAt(x, z),\n  get FIGHT() { return FIGHT; },")
open(p,'w',encoding='utf-8').write(s)
print('flight ok')
