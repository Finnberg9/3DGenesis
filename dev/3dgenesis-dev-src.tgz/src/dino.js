// =====================================================================
// DINOSAUR JAWS: a real skull mouth instead of a lump. An upper jaw that is
// part of the muzzle, a lower jaw hinged at the back that swings open, teeth
// that vary along the jaw line and interlock when shut, a tongue, gums and a
// dark throat. One builder drives every mouth: a deep crushing jaw, a long
// fish-catching jaw, a short deep muzzle, a duck bill, and the older ones.
//
// Local frame: x forward (snout), y up, z across. The part is scaled by its
// VIS size, so these numbers are relative to the head.
// =====================================================================
// S: len (snout length), deep (jaw depth), wide (half width), teeth (pairs),
// tooth (tooth length), fang (front fang multiplier), beak (bony beak tip),
// grind (flat grinding rows), gape (extra opening), curve (snout downturn)
function jawShape(id) {
  switch (id) {
    case 'm_rex':    return { len: 1.55, deep: 0.62, wide: 0.55, teeth: 7, tooth: 0.34, fang: 1.7, gape: 0.95, curve: 0.05, brow: 1 };
    case 'm_spino':  return { len: 2.25, deep: 0.40, wide: 0.36, teeth: 10, tooth: 0.26, fang: 1.5, gape: 0.8, curve: 0.12, croc: 1 };
    case 'm_short':  return { len: 1.05, deep: 0.70, wide: 0.58, teeth: 6, tooth: 0.2, fang: 1.2, gape: 1.0, curve: 0.02, brow: 1 };
    case 'm_duck':   return { len: 1.5, deep: 0.42, wide: 0.6, teeth: 8, tooth: 0.08, fang: 1, gape: 0.6, curve: 0.18, beak: 1, grind: 1 };
    case 'm_maw':    return { len: 1.25, deep: 0.58, wide: 0.6, teeth: 7, tooth: 0.3, fang: 1.8, gape: 1.0, curve: 0.04 };
    default:         return { len: 1.05, deep: 0.46, wide: 0.46, teeth: 6, tooth: 0.22, fang: 1.3, gape: 0.85, curve: 0.04 };
  }
}
// half width and depth of the muzzle at u = 0 (hinge) .. 1 (tip)
function jawProfile(S, u) {
  const taper = S.croc ? 0.85 - 0.35 * u * u : S.beak ? 0.9 - 0.15 * u + 0.5 * Math.pow(u, 6) : 1 - 0.55 * u * u;
  return { w: S.wide * taper, d: S.deep * (S.croc ? 0.9 - 0.3 * u : 1 - 0.45 * u * u) };
}
// the skin/flesh half of a jaw: the muzzle above, the mandible below (F.jaw()
// marks the pieces that ride the jaw bone, so they swing when it opens)
function dinoJawFlesh(F, S) {
  const N = 5;
  for (let i = 0; i <= N; i++) {
    const u = i / N, x = -0.35 + u * (S.len + 0.35);
    const p = jawProfile(S, u);
    const y = 0.42 - S.curve * u * u * 1.4;
    F.e(x, y + p.d * 0.30, 0, 0.12, 1, 0, 1, 0, 0, p.w * 1.02, p.d * 0.62, p.w, 0.22);   // upper muzzle
  }
  if (S.brow) for (const s of [1, -1]) F.e(-0.15, 0.95, s * S.wide * 0.8, 0, 1, 0, 1, 0, 0, 0.36, 0.2, 0.28, 0.16);
  F.jaw();
  for (let i = 0; i <= N; i++) {
    const u = i / N, x = -0.35 + u * (S.len + 0.3);
    const p = jawProfile(S, u);
    const y = 0.30 - S.curve * u * u * 1.2;
    F.e(x, y - p.d * 0.34, 0, 0.1, 1, 0, 1, 0, 0, p.w * 0.9, p.d * 0.5, p.w * 0.88, 0.18);  // mandible
  }
  F.e(-0.42, 0.06, 0, 0, 1, 0, 1, 0, 0, 0.5, 0.3, 0.42, 0.2);                               // throat pouch under the chin
  F.main();
}
// the hard half: teeth, gums, tongue, throat, beak and horn ridges
function dinoJawHard(g, c, e, S) {
  const open = (e.jaw || 0) * (S.gape || 1);
  const j = g.rotated(0, 0, 1, open);                  // the mandible swings about the hinge
  const gum = colMul(c, 0.55), bone = colMul(c, 0.9);
  // palette icon: in game the muzzle flesh comes from the mesh builder, so the
  // icon has to grow its own or it reads as a floating set of teeth
  if (e.thumb) {
    const N = 5, low = colMul(c, 0.92);
    for (let i = 0; i <= N; i++) {
      const u = i / N, p = jawProfile(S, u);
      g.sp(-0.35 + u * (S.len + 0.35), 0.42 - S.curve * u * u * 1.4 + p.d * 0.30, 0, 0.12, 1, 0, p.w * 1.02, p.d * 0.62, p.w, c);
      j.sp(-0.35 + u * (S.len + 0.3), 0.30 - S.curve * u * u * 1.2 - p.d * 0.34, 0, 0.1, 1, 0, p.w * 0.9, p.d * 0.5, p.w * 0.88, low);
    }
    g.sp(-0.42, 0.06, 0, 0, 1, 0, 0.5, 0.3, 0.42, low);
    if (S.brow) for (const s of [1, -1]) g.sp(-0.15, 0.95, s * S.wide * 0.8, 0, 1, 0, 0.36, 0.2, 0.28, c);
  }
  // dark throat behind the teeth, so an open mouth reads as a hole
  g.sp(-0.12, 0.30, 0, 0, 1, 0, 0.34, 0.42 + open * 0.5, S.wide * 0.85, MAW);
  // tooth rows: front fangs longest, tapering back; the lower row interlocks
  const n = S.teeth;
  for (let i = 0; i < n; i++) {
    const u = 0.12 + (i / Math.max(1, n - 1)) * 0.84;          // along the jaw
    const p = jawProfile(S, u);
    const x = -0.3 + u * (S.len + 0.3);
    const front = Math.pow(1 - u, 0.8);
    const size = S.tooth * (0.55 + 0.9 * front) * (i === 0 || i === 1 ? S.fang : 1);
    const yU = 0.42 - S.curve * u * u * 1.4 - p.d * 0.1;
    const yL = 0.30 - S.curve * u * u * 1.2 - p.d * 0.05;
    for (const s of [1, -1]) {
      const z = s * p.w * (S.beak ? 0.82 : 0.92);
      if (S.beak && u < 0.55) continue;                        // a duck bill is toothless in front
      if (S.grind) {
        g.sp(x, yU - 0.04, z, 0, 1, 0, 0.1, 0.06, 0.08, IVORY);
        j.sp(x - 0.06, yL + 0.04, z * 0.95, 0, 1, 0, 0.1, 0.06, 0.08, IVORY);
        continue;
      }
      // upper teeth point down and rake backward; lower teeth point up
      g.cn(x, yU, z, -0.18, -1, 0, size * 0.34, size, IVORY);
      j.cn(x - 0.05, yL, z * 0.95, -0.12, 1, 0, size * 0.3, size * 0.85, IVORY);
      if (!e.lod) {
        g.sp(x, yU + 0.03, z, 0, 1, 0, size * 0.4, 0.05, size * 0.3, gum);
        j.sp(x - 0.05, yL - 0.03, z * 0.95, 0, 1, 0, size * 0.36, 0.05, size * 0.28, gum);
      }
    }
  }
  // tongue along the floor of the mouth
  j.sp(0.1, 0.24, 0, 0.1, 1, 0, 0.16, 0.5, S.wide * 0.5, TONGUE);
  // beak tip (duck bill) or a bony snout tip
  if (S.beak) {
    const p = jawProfile(S, 1);
    g.sp(S.len * 0.95, 0.34 - S.curve * 1.4, 0, 0.2, 1, 0, p.w * 1.35, 0.12, p.w * 1.5, bone);
    j.sp(S.len * 0.9, 0.2 - S.curve * 1.2, 0, 0.2, 1, 0, p.w * 1.2, 0.1, p.w * 1.3, colMul(bone, 0.9));
  } else {
    g.sp(S.len * 0.98, 0.42 - S.curve * 1.4, 0, 1, 0.1, 0, 0.14, 0.18, jawProfile(S, 1).w * 0.9, bone);
  }
  // nostrils on top of the snout, and brow knobs over the eyes
  if (!e.lod) {
    for (const s of [1, -1]) g.ball(S.len * (S.croc ? 0.72 : 0.78), 0.68 - S.curve, s * jawProfile(S, 0.8).w * 0.45, 0.055, BLACKP);
    if (S.brow) for (const s of [1, -1]) g.sp(-0.1, 0.96, s * S.wide * 0.8, 0.2, 1, 0, 0.3, 0.16, 0.2, bone);
    if (S.croc) for (let i = 0; i < 4; i++) g.sp(-0.1 + i * S.len * 0.24, 0.72 - S.curve * 0.6, 0, 0, 1, 0, 0.1, 0.07, jawProfile(S, i / 4).w * 0.7, bone);
  }
}
