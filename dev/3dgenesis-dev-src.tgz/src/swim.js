// =====================================================================
// SWIMMING: the surface is not a ceiling. A swimmer in deep water goes where
// it looks, so pitching down and holding forward takes you under; space rises,
// ctrl (or C) sinks. An air breather is buoyant and drifts back up when you
// stop working at it, and starts drowning once its head is under. A gill
// breather is neutral: it stays wherever you leave it, all the way to the
// sea floor.
// =====================================================================
const SWIM = { msg: 0 };
function swimSurfaceY() { return (terrain && terrain.LV ? terrain.LV.water : 0.42) * HEIGHT_SCALE; }
// how much water there is under the surface here, in world units
function swimRoom(c) {
  return Math.max(0, swimSurfaceY() - groundAt(c.x, c.y));
}
function swimmingNow() {
  const c = player.c;
  if (!c || !c.alive || player.spectator) return false;
  if (!c.ph.canSwim) return false;
  if (c.ph.canFly && player.fly > 0.6) return false;
  return terrain.isWater(c.x, c.y) && swimRoom(c) > c.ph.radius * BODY_SCALE * 1.2;
}
function swimTick(dt) {
  const c = player.c;
  if (!c || !c.alive) { player.dive = 0; return; }
  if (!swimmingNow()) {
    // surfacing is quick when you leave the deep, so you never pop out inland
    player.dive = Math.max(0, (player.dive || 0) - 260 * dt);
    if (c) c._sub = false;
    return;
  }
  const p = c.ph, S = BODY_SCALE;
  const body = p.radius * S;
  const maxDive = Math.max(0, swimRoom(c) - body * 1.15);
  const speed = Math.max(40, p.speedWater * PLAYER_SPEED);
  let d = player.dive || 0;
  // swim where you look: forward with the nose down takes you under
  const fwd = (keys['w'] ? 1 : 0) - (keys['s'] ? 1 : 0);
  if (fwd) d += -Math.sin(player.pitch) * speed * fwd * dt;
  // and the explicit controls
  if (keys[' ']) d -= speed * 0.75 * dt;
  if (keys['control'] || keys['c']) d += speed * 0.75 * dt;
  // an air breather floats: let go and it rises. gills are neutral.
  if (p.airBreath && !p.waterBreath) d -= Math.min(26, 8 + body * 0.5) * dt;
  player.dive = clamp(d, 0, maxDive);
  c._sub = player.dive > body * 0.8;          // the core reads this to decide if your head is under
  // the body noses down as you descend
  c._swimPitch = clamp((player.dive - (c._diveWas || 0)) / Math.max(1e-3, dt) / Math.max(60, speed), -0.8, 0.8);
  c._diveWas = player.dive;
  SWIM.msg -= dt;
  if (c._sub && !p.waterBreath && SWIM.msg <= 0) { SWIM.msg = 3; toast('Holding your breath. Space to surface.', 1600); }
}
function swimHud() {
  const c = player.c;
  if (!c || !c.alive || !c.ph.canSwim || !terrain.isWater(c.x, c.y)) return '';
  const d = player.dive || 0;
  const air = c.ph.waterBreath ? '' : ' <span style="color:#ffc98a">breath</span>';
  return `<br><span class="k">depth</span> <span class="v">${d.toFixed(0)}</span>${air}` +
         `<br><span class="k">look down + W</span> dive · <span class="k">space</span> rise · <span class="k">ctrl</span> sink`;
}
