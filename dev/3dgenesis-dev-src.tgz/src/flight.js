// =====================================================================
// FLIGHT: a real glider, not a lift. You fly where you look. Diving trades
// height for speed, pulling up trades speed back for height, so you can swoop.
// Flapping costs stamina and buys thrust and lift; big wings beat slowly and
// carry more. Turning banks the body, and the turn rate comes from the bank
// and your speed. Thermals rise over open sunlit ground and cliff faces, so a
// big flier can circle up without a wingbeat. Too slow and you stall.
// Heavy bodies need a flap or a drop to get off the ground.
// =====================================================================
const FL = { spd: 0, vy: 0, roll: 0, rollT: 0, beat: 0, phase: 0, thrust: 0, stall: 0, lastG: null, msg: 0, glide: 0 };
const FLIGHT_G = 140;      // the gravity a wing fights: far gentler than the walking one, so gliding is possible at these speeds
function flightWing(p) { return clamp((p.wingEff || 0) * 1.2 + 0.25, 0.25, 2.2); }
function flightCruise(p) { return Math.max(230, (p.speedAir || 110) * 2.1); }
// rising air: over open sunlit ground (no canopy) and along steep slopes,
// in slowly drifting columns
function thermalAt(x, z) {
  if (!world) return 0;
  const day = world.light != null ? world.light : 1;
  if (day < 0.25) return 0;
  const drift = (world.bt || 0) * 6;
  const cx = x + drift, cz = z - drift * 0.4;
  let h = (Math.imul(Math.floor(cx / 620) * 73856093, 1) ^ Math.imul(Math.floor(cz / 620), 19349663)) >>> 0;
  h = Math.imul(h ^ (h >>> 13), 2246822519) >>> 0;
  const cell = ((h ^ (h >>> 15)) >>> 0) / 4294967296;
  if (cell > 0.42) return 0;                                  // only some cells hold a thermal
  const fx = ((cx % 620) + 620) % 620 - 310, fz = ((cz % 620) + 620) % 620 - 310;
  const r = Math.hypot(fx, fz);
  const core = 1 - clamp(r / 230, 0, 1);
  if (core <= 0) return 0;
  const open = 1 - clamp(forestCanopyAt(x, z), 0, 1);
  // slope lift: air pushed up the windward face of a hill
  const h0 = groundAt(x, z), slope = clamp((Math.abs(groundAt(x + 40, z) - h0) + Math.abs(groundAt(x, z + 40) - h0)) / 40, 0, 1.4);
  return (60 + 120 * open + 90 * slope) * core * core * day;
}
function flightAirborne() { return !!(player.c && player.c.ph.canFly && player.fly > 0.6); }
function flightTick(dt) {
  const c = player.c;
  if (!c || !c.alive || player.spectator || !c.ph.canFly) {
    if (player.fly > 0) player.fly = Math.max(0, player.fly - 180 * dt);
    FL.spd = 0; FL.vy = 0; FL.roll = 0; FL.lastG = null;
    return;
  }
  const p = c.ph;
  const wing = flightWing(p), cruise = flightCruise(p);
  const stallSpd = cruise * 0.5, maxSpd = cruise * 2.8;
  const mass = clamp((p.mass || 5) / 8, 0.35, 4);
  // walking off a drop puts you in the air without a flap
  const gy = groundAt(c.x, c.y);
  if (FL.lastG != null && player.fly <= 0.6 && gy < FL.lastG - 0.5) player.fly += (FL.lastG - gy);
  FL.lastG = gy;
  const airborne = player.fly > 0.6;
  const pitch = clamp(player.pitch, -1.25, 1.05);
  // ---- flapping
  FL.beat -= dt;
  FL.thrust = Math.max(0, FL.thrust - dt * 3);
  const period = 0.9 - 0.3 * clamp(wing, 0, 1.4);
  if (keys[' '] && FL.beat <= 0 && !FIGHT.exhausted && FIGHT.stam > 3) {
    FL.beat = period;
    fightSpend(4 + 3 * mass);
    FL.thrust = 1;
    FL.vy += (120 + 110 * wing) / Math.sqrt(mass) * (airborne ? 1 : 1.5);
    FL.spd += 42 * wing / Math.sqrt(mass);
    if (SND.ctx && SND.on) sndWingbeat(0, p.mass || 5, 0.22);
  }
  FL.phase += dt * (6.5 - 3 * clamp(wing - 0.5, 0, 1)) * (0.45 + 0.85 * FL.thrust + (airborne ? 0.35 : 0));
  if (!airborne) {
    // on the ground: run, and only leave it when a beat lifts you
    FL.spd = Math.max(FL.spd * (1 - dt * 2), Math.hypot(c.vx || 0, c.vy || 0));
    if (player.fly > 0.6) FL.vy = Math.max(FL.vy, 0);
    else { FL.vy = Math.max(0, FL.vy - GRAV * dt * 0.5); FL.roll = 0; }
    player.fly = Math.max(0, player.fly + FL.vy * dt);
    if (player.fly <= 0) FL.vy = 0;
    return;
  }
  // ---- glide: gravity along the flight path, drag, and the wing's sink rate
  const tuck = keys['w'] ? 1 : 0, brake = keys['s'] ? 1 : 0;
  const drag = (0.30 - 0.12 * tuck + 0.75 * brake) * FLIGHT_G * (FL.spd * FL.spd) / (cruise * cruise);
  FL.spd += (-Math.sin(pitch) * FLIGHT_G - drag) * dt;
  FL.spd = clamp(FL.spd, 0, maxSpd);
  // vertical: you go where you point, minus the sink of the wing, which grows
  // sharply as you slow toward the stall
  const slow = clamp(stallSpd / Math.max(20, FL.spd), 0.4, 3);
  const sink = clamp(FLIGHT_G * 0.22 * slow * slow / (0.6 + wing), 8, 300);
  let vy = Math.sin(pitch) * FL.spd - sink;
  FL.stall = FL.spd < stallSpd ? Math.min(1, FL.stall + dt * 2) : Math.max(0, FL.stall - dt * 2);
  if (FL.stall > 0.5) { vy -= 180 * FL.stall; FL.spd += FLIGHT_G * 0.9 * dt; }   // the nose drops and speed builds back
  vy += thermalAt(c.x, c.y) * (0.5 + 0.5 * wing) * dt * 8;
  FL.vy += (vy - FL.vy) * Math.min(1, dt * 6);                                   // ease, so it never snaps
  player.fly = clamp(player.fly + FL.vy * dt, 0, FLY_CEIL);
  // ---- banking turns: roll with A/D, and the bank is what turns you
  const want = (keys['a'] ? -1 : 0) + (keys['d'] ? 1 : 0);
  FL.roll += (want * 0.85 - FL.roll) * Math.min(1, dt * 4);
  if (Math.abs(FL.roll) > 0.02) player.yaw += (FLIGHT_G * Math.tan(FL.roll * 0.9) / Math.max(150, FL.spd)) * dt;
  c._tiltQ = -FL.roll * 0.9;                                                     // the body leans into the turn
  c._flapDrive = Math.sin(FL.phase) * (0.35 + 0.65 * FL.thrust) * (0.8 + 0.4 * wing);
  // ---- landing
  if (player.fly <= 0.8 && FL.vy <= 0) {
    player.fly = 0; FL.vy = 0; FL.roll = 0; c._tiltQ = 0;
    if (FL.spd > cruise * 1.6) { FIGHT.stagger = Math.max(FIGHT.stagger, 0.5); toast('Hard landing.', 1200); }
    FL.spd *= 0.4;
  }
  // ---- warnings
  FL.msg -= dt;
  if (FL.stall > 0.6 && FL.msg <= 0) { FL.msg = 2.5; toast('STALL: point the nose down or flap.', 1400); }
  if (FIGHT.exhausted && FL.msg <= 0 && FL.spd < cruise) { FL.msg = 3; toast('Too tired to flap: find a thermal or glide down.', 1600); }
}
// speed the body actually travels over the ground while flying
function flightGroundSpeed() {
  const pitch = clamp(player.pitch, -1.25, 1.05);
  return Math.max(0, Math.cos(pitch)) * FL.spd;
}
function flightHud() {
  const c = player.c;
  if (!c || !c.alive || !c.ph.canFly) return '';
  const st = FL.stall > 0.5 ? ' <span style="color:#ff6b5e">STALL</span>' : '';
  const th = thermalAt(c.x, c.y) > 40 ? ' <span style="color:#7ee787">lift</span>' : '';
  return `<br><span class="k">altitude</span> <span class="v">${player.fly.toFixed(0)}</span> · ` +
         `<span class="k">airspeed</span> <span class="v">${FL.spd.toFixed(0)}</span>${st}${th}` +
         `<br><span class="k">space</span> flap · <span class="k">look</span> to dive and climb · <span class="k">A D</span> bank · <span class="k">W</span> tuck · <span class="k">S</span> flare`;
}

// =====================================================================
// REARING UP: hold G to rise onto the hind legs, which nearly doubles your
// reach so you can strip the canopy, and makes you taller in a fight. It
// costs stamina to hold and you can barely move while you are up there.
// =====================================================================
function rearTick(dt) {
  const c = player.c;
  if (!c || !c.alive) { player.rear = 0; return; }
  const p = c.ph;
  const able = !c.ph.canFly && (p.dLegs || 0) >= 2 && !flightAirborne() && FIGHT.stagger <= 0 && FIGHT.dodgeT <= 0;
  const want = able && !!keys['g'] && !FIGHT.exhausted;
  player.rear = clamp((player.rear || 0) + (want ? dt * 2.2 : -dt * 3), 0, 1);
  if (player.rear > 0.05 && want) fightSpend(6 * dt);
  c._rear = player.rear;
}
function rearReach(p) { return 1 + 0.85 * (player.rear || 0); }
