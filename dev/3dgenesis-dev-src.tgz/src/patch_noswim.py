# =====================================================================
# A MATCH BODY HAS TO BE ABLE TO WALK
#
# You could take a fish into a battle royale. It cannot leave the water, the
# safe zone closes onto dry land, and the whole match for that player is
# drowning slowly in a shrinking sea. There is no version of that which is a
# fight.
#
# The rule is anatomical rather than a list of banned shapes, because a list
# goes stale the moment a plan is added: A MATCH BODY MUST HAVE LEGS. It is
# checked by building the body and asking classifyLimbs how many legs came
# out, which is the same function the game uses to decide whether you can
# walk at all, so the entry rule and the physics cannot disagree.
#
# A legless shape is swapped for a land one, keeping your colours and your
# proportions, and you are told plainly rather than finding out in the cage.
# The same check runs on the bots, and the body picker hides the water shapes
# for as long as a match is being armed.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, ('ANCHOR %d/%d' % (n, cnt), a[:110]); return s.replace(a, b)

p = 'g3.html'; s = open(p, encoding='utf-8').read()

s = sub1(s, "const BR_BARE_TIP = { LIMB: 't_paw' };",
r"""const BR_BARE_TIP = { LIMB: 't_paw' };
// Which body plans walk, worked out from the plans themselves rather than
// written down: build each one's default body and count the legs the game's
// own limb classifier finds on it. Computed once, on first use.
let BR_WALKERS = null;
function brWalkingPlans() {
  if (BR_WALKERS) return BR_WALKERS;
  const out = [];
  for (let pi = 0; pi < C.PLANS.length; pi++) {
    try {
      const d = C.defaultDesign(pi);
      if (C.classifyLimbs(d, C.buildDesignSkeleton(d)).legs > 0) out.push(pi);
    } catch (e) { /* a plan that will not build is not one to offer */ }
  }
  BR_WALKERS = out.length ? out : [1];
  return BR_WALKERS;
}
function brCanWalk(des) {
  if (!des) return false;
  try { return C.classifyLimbs(des, C.buildDesignSkeleton(des)).legs > 0; }
  catch (e) { return false; }
}
// The land shape nearest the one you picked: same list, closest index, so a
// serpent becomes something serpentine rather than something arbitrary.
function brNearestWalker(plan) {
  const w = brWalkingPlans();
  let best = w[0], bd = Infinity;
  for (const pi of w) { const d = Math.abs(pi - (plan | 0)); if (d < bd) { bd = d; best = pi; } }
  return best;
}""")

# the swap happens inside the one function every match body already goes
# through, so nothing can enter a match by a route that skips it
s = sub1(s, """function brBareDesign(des) {
  const src = des && des.plan != null ? des : C.defaultDesign(0);
  const d = C.cloneDesign(src);""",
"""function brBareDesign(des) {
  let src = des && des.plan != null ? des : C.defaultDesign(0);
  // No fish in a deathmatch. The zone closes onto dry land, so a body that
  // cannot leave the water is not a competitor, it is a slow drowning.
  if (!brCanWalk(src)) {
    const pi = brNearestWalker(src.plan);
    const swap = C.defaultDesign(pi);
    if (src.col) swap.col = JSON.parse(JSON.stringify(src.col));
    if (src.body) swap.body = Object.assign({}, swap.body, src.body);
    C.reseatDesign(swap);
    swap.stem = src.stem;
    BR._swapped = { from: src.plan, to: pi };
    src = swap;
  } else BR._swapped = null;
  const d = C.cloneDesign(src);""")
# and you are told, once, in the cage
s = sub1(s, "  brSay('BAY ' + bay.n + '. The gate opens in ' + BR_CAGE_SECS + ' seconds.', 5000);",
"""  if (BR._swapped) {
    brSay('A body with no legs cannot fight a match on dry land. You have been given the nearest shape that walks.', 8000);
    BR._swapped = null;
  } else brSay('BAY ' + bay.n + '. The gate opens in ' + BR_CAGE_SECS + ' seconds.', 5000);""")

# bots roll from the walking plans only
s = sub1(s, """      g.design = brBareDesign(C.randomDesign(rng, { diversity: 0.85, diet: rng() < 0.55 ? 'carn' : 'herb', rarityCap: world.rarityCap }));""",
"""      let rd = C.randomDesign(rng, { diversity: 0.85, diet: rng() < 0.55 ? 'carn' : 'herb', rarityCap: world.rarityCap });
      // Roll again rather than swapping, so a lobby is a spread of real land
      // shapes instead of everything collapsing onto the same substitute.
      for (let tries = 0; tries < 8 && !brCanWalk(rd); tries++) {
        rd = C.randomDesign(rng, { diversity: 0.85, diet: rng() < 0.55 ? 'carn' : 'herb', rarityCap: world.rarityCap });
      }
      g.design = brBareDesign(rd);""")

# the picker hides what a match will not accept, rather than letting you pick
# it and quietly taking it away
s = sub1(s, """    for (const grp of PLAN_GROUPS) {
      const list = grp.plans.filter(p => p < C.PLANS.length);""",
"""    for (const grp of PLAN_GROUPS) {
      let list = grp.plans.filter(p => p < C.PLANS.length);
      // A match will not take a body that cannot walk, so it is not offered.
      if (brLocked()) list = list.filter(p => brWalkingPlans().indexOf(p) >= 0);
      if (!list.length) continue;""")

# test surface
s = sub1(s, "    get gateY() { return BR.gateY; },",
"""    get gateY() { return BR.gateY; },
    walkers: () => brWalkingPlans().slice(),
    canWalk: (d) => brCanWalk(d),
    bareOf: (d) => brBareDesign(d),
    legsOf: (d) => { try { return C.classifyLimbs(d, C.buildDesignSkeleton(d)).legs; } catch (e) { return -1; } },""")

open(p, 'w', encoding='utf-8').write(s)
print('noswim ok')
