# =====================================================================
# THE SKELETON LEARNS THREE THINGS
#
# Every body in the game was one smooth sausage with a neck on top, because
# that is all the skeleton could describe. No amount of tuning the numbers was
# going to produce the reference creatures, and tuning them is what I kept
# doing.
#
# What the references have that the table could not say:
#
#   HUMP    The back peaks over the SHOULDERS and the hips sit low behind it.
#           `arch` is a symmetric sine, so the high point was always the
#           middle of the animal. Skewing the sine moves the peak forward and
#           drops the rump away behind it, which is the hunched silhouette
#           every one of those sculpts is built on.
#
#   WAIST   One girth curve means one mass. A thorax and an abdomen with a
#           pinch between them -- most of the reference sheet -- could not be
#           expressed at all. A gaussian notch in the profile gives the body
#           two lobes and a waist.
#
#   HEADSET The head was always ABOVE the body: `ny` is positive in all
#           thirty plans, because I never once wrote a negative one. Nothing
#           in the code required that. A negative `ny` hangs the skull low and
#           forward off the shoulder mass, which is the difference between a
#           grazing animal and something that hunts you.
#
# Only the first two need code. The third was always possible and is the
# single biggest reason the creatures read as farm animals.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, ('ANCHOR %d/%d' % (n, cnt), a[:110]); return s.replace(a, b)

p = 'g3.html'; s = open(p, encoding='utf-8').read()

s = sub1(s, """    const balls = [];
    for (let i = 0; i < P.seg; i++) {
      const u = i / (P.seg - 1);
      balls.push({ x: -a + 2 * a * u, y: (P.arch * Math.sin(Math.PI * u) - P.droop * (1 - u)) * b, z: 0,
                   r: b * planProfile(P.prof, u), g: 'body' });
    }""",
"""    const balls = [];
    // ---- hump: where along the back the high point sits ---------------------
    // 0 leaves the arch exactly where it was, in the middle. 1 pushes the peak
    // right over the shoulders and lets the hips fall away behind it. Skewing
    // the parameter rather than adding a second term means a plan with no hump
    // is byte-identical to what it was.
    const hump = P.hump || 0;
    const humpK = 1 + 2.4 * hump;
    const spineY = (u) => (P.arch * Math.sin(Math.PI * Math.pow(u, humpK)) - P.droop * (1 - u)) * b;
    // ---- waist: a pinch that turns one mass into two ------------------------
    const waist = P.waist || 0, waistAt = P.waistAt == null ? 0.5 : P.waistAt, waistW = P.waistW || 0.13;
    const girth = (u) => {
      let g = planProfile(P.prof, u);
      if (waist > 0) {
        const d = (u - waistAt) / waistW;
        g *= 1 - waist * Math.exp(-d * d);
      }
      return g;
    };
    for (let i = 0; i < P.seg; i++) {
      const u = i / (P.seg - 1);
      balls.push({ x: -a + 2 * a * u, y: spineY(u), z: 0, r: b * girth(u), g: 'body' });
    }""")
s = sub1(s, """    for (const u of [0.28, 0.5, 0.72]) {
      const w = P.wide || 0;
      const r = w > 0 ? b * planProfile(P.prof, u) * 0.72 : 0.0001;
      const x = -a + 2 * a * u, y = (P.arch * Math.sin(Math.PI * u) - P.droop * (1 - u)) * b - b * 0.12;""",
"""    for (const u of [0.28, 0.5, 0.72]) {
      const w = P.wide || 0;
      const r = w > 0 ? b * girth(u) * 0.72 : 0.0001;
      const x = -a + 2 * a * u, y = spineY(u) - b * 0.12;""")
# the neck now leaves from the top of the shoulder, wherever the hump put it,
# rather than from a fixed height that assumed a level back
s = sub1(s, """    const hx = a * 0.78 + neckLen * P.nx, hy = b * 0.30 + neckLen * P.ny;
    const nx0 = a * 0.70, ny0 = b * 0.22;""",
"""    // The neck leaves the SHOULDER, so on a hunched body it starts high, and
    // a negative ny then carries the skull down and forward from there.
    const shoulderY = spineY(0.86);
    const hx = a * 0.78 + neckLen * P.nx, hy = shoulderY + b * 0.30 + neckLen * P.ny;
    const nx0 = a * 0.70, ny0 = shoulderY + b * 0.22;""")

open(p, 'w', encoding='utf-8').write(s)
print('anatomy: hump, waist, hanging head ok')
