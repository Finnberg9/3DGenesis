# ---------------------------------------------------------------- 2026-09-25c
# Finn: "art ultra ghraphics, it only loads at 2 frames/sec but it says 30fps"
# and "its basically unplayable at ultra graphics."
#
# Both are the same bug, and the lie is the cause of the unplayability.
#
# The frame clock measured the gap between the STARTS of two renderFrame calls.
# That is the rate JavaScript is pacing at, not the rate the screen is being
# painted at. WebGPU's queue.submit is asynchronous: the CPU can build and
# submit frame after frame at very nearly vsync while the GPU falls minutes
# behind, and every one of those queued frames is latency between your mouse and
# the picture. The HUD read ~32, the GPU was delivering ~2, and everything that
# reads the frame clock believed the 32:
#
#   - the automatic quality stepper never stepped down, because by its numbers
#     the machine was coping;
#   - the resolution trim sat at 97% for the same reason;
#   - so the one system whose entire job is to rescue a machine that cannot keep
#     up was blind exactly when it was needed.
#
# Fixed by timing the GPU instead of the CPU, and by refusing to run more than
# two frames ahead of it.
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, (a[:110], n); return s.replace(a, b)
p = 'g3.html'; s = open(p, encoding='utf-8').read()

# ---- the honest clock
s = sub1(s, "function r2AutoRes() {\n  const now = performance.now();",
"""// How many frames have been handed to the GPU that it has not finished yet,
// and when it last finished one. onSubmittedWorkDone resolves when the queue
// has actually drained, which is the only moment in the whole pipeline that
// corresponds to something a person can see.
const GPUQ = { inFlight: 0, lastDone: 0, ftGpu: 16.7, peak: 0, skipped: 0, subs: 0, dones: 0, api: 0 };
function gpuFrameSubmitted() {
  GPUQ.inFlight++;
  GPUQ.subs++;
  try {
    if (!dev.queue.onSubmittedWorkDone) { GPUQ.api = -1; GPUQ.inFlight = 0; return; }
    GPUQ.api = 1;
    dev.queue.onSubmittedWorkDone().then(() => {
      const now = performance.now();
      GPUQ.dones++;
      GPUQ.inFlight = Math.max(0, GPUQ.inFlight - 1);
      if (GPUQ.lastDone) {
        // the interval between two finished frames IS the frame rate
        const d = Math.min(2000, now - GPUQ.lastDone);
        GPUQ.ftGpu += (d - GPUQ.ftGpu) * 0.12;
        GPUQ.peak = Math.max(GPUQ.peak * 0.97, d);
      }
      GPUQ.lastDone = now;
    }, () => { GPUQ.inFlight = Math.max(0, GPUQ.inFlight - 1); });
  } catch (e) { GPUQ.inFlight = Math.max(0, GPUQ.inFlight - 1); }
}
// Running more than a couple of frames ahead of the GPU buys nothing: the
// frames sit in a queue getting staler, and every one of them is input lag.
// The simulation still steps on a skipped frame, so the world does not slow
// down with the picture.
function gpuBackedUp() { return GPUQ.inFlight >= 2; }
function r2AutoRes() {
  const now = performance.now();""")
# feed the real number in, and keep the CPU number beside it for diagnosis
s = sub1(s, """    R2.ftAvg += (ft - R2.ftAvg) * 0.05;
    R2.ftSlow += (ft - R2.ftSlow) * 0.012;
    R2.fps = 1000 / Math.max(1, R2.ftAvg);""",
"""    R2.ftCpu = (R2.ftCpu || ft) + (ft - (R2.ftCpu || ft)) * 0.05;
    // The frame time everything acts on is whichever is WORSE: the CPU pacing
    // or the GPU's actual delivery. Taking the CPU number alone is what let a
    // 2 fps machine report 32 and never get helped.
    const real = Math.max(ft, GPUQ.ftGpu);
    // ASYMMETRIC: quick to believe bad news, slow to believe good. A safety
    // system that takes ten seconds to notice a machine is drowning is not a
    // safety system, and one that climbs back the moment a single frame is
    // fast oscillates forever. Frames are also being SKIPPED while the GPU is
    // behind, so there are fewer samples to converge with exactly when it
    // matters most.
    R2.ftAvg += (real - R2.ftAvg) * (real > R2.ftAvg ? 0.34 : 0.05);
    R2.ftSlow += (real - R2.ftSlow) * (real > R2.ftSlow ? 0.16 : 0.012);
    R2.fps = 1000 / Math.max(1, R2.ftAvg);""")
open(p, 'w', encoding='utf-8').write(s)
print('gpuclock: the frame clock is honest ok')

s = open(p, encoding='utf-8').read()
# ---- count every submit, and let the queue drain
s = sub1(s, """  if (R2on) r2PostPass(enc, fog);
  dev.queue.submit([enc.finish()]);
  try { brDrawNames(); }""",
"""  if (R2on) r2PostPass(enc, fog);
  dev.queue.submit([enc.finish()]);
  gpuFrameSubmitted();
  try { brDrawNames(); }""")
open(p, 'w', encoding='utf-8').write(s)
print('gpuclock: submits counted ok')

s = open(p, encoding='utf-8').read()
# ---- skip the DRAW, never the simulation, when the GPU is behind
s = sub1(s, """  updateCamera(dt);
  if (skipRender) return null;
  const r = renderFrame(simT);""",
"""  updateCamera(dt);
  if (skipRender) return null;
  // The GPU is two frames behind: building a third would only add latency.
  // The world has already been stepped above, so nothing slows down but the
  // picture, and the picture was not arriving anyway.
  if (gpuBackedUp()) { GPUQ.skipped++; drawMinimap(); return null; }
  const r = renderFrame(simT);""")
open(p, 'w', encoding='utf-8').write(s)
print('gpuclock: no running ahead of the GPU ok')

s = open(p, encoding='utf-8').read()
# ---- the auto stepper has to react faster when it is THIS bad, and the HUD
# should say what is actually happening
s = sub1(s, "  const el = document.getElementById('gfxfps');\n  if (el) el.textContent = Math.round(R2.fps) + ' fps · ' + GFX.name + ' · ' + Math.round(r2SceneScale() * 100) + '%';",
"""  const el = document.getElementById('gfxfps');
  if (!el) return;
  const gpu = Math.round(1000 / Math.max(1, GPUQ.ftGpu));
  const cpu = Math.round(1000 / Math.max(1, R2.ftCpu || R2.ftAvg));
  // When the two disagree the GPU is the one you are looking at, and seeing
  // both is how you tell a heavy scene from a heavy simulation.
  el.textContent = Math.round(R2.fps) + ' fps · ' + GFX.name + ' · ' +
    Math.round(r2SceneScale() * 100) + '%' + (cpu - gpu > 8 ? ' · gpu bound' : '');""")
open(p, 'w', encoding='utf-8').write(s)
print('gpuclock: the hud tells the truth ok')

s = open(p, encoding='utf-8').read()
# ---- harness surface
s = sub1(s, "    fallRule: () => ({ safeH: FALL_SAFE_H, fatalH: FALL_FATAL_H, slopeTan: FALL_SLOPE_TAN,",
"""    perf: () => ({ fps: +R2.fps.toFixed(1), ftAvg: +R2.ftAvg.toFixed(1),
                   ftCpu: +(R2.ftCpu || 0).toFixed(1), ftGpu: +GPUQ.ftGpu.toFixed(1),
                   inFlight: GPUQ.inFlight, skipped: GPUQ.skipped, dyn: +R2.dyn.toFixed(3),
                   scale: +r2SceneScale().toFixed(3), gfx: GFX.name,
                   drops: (typeof rainN === 'number' ? rainN : 0), plants: plantCount | 0,
                   subs: GPUQ.subs, dones: GPUQ.dones, api: GPUQ.api }),
    // start a clean measurement window: the averages carry the last scene
    perfReset: () => { GPUQ.ftGpu = 16.7; GPUQ.lastDone = 0; GPUQ.skipped = 0; GPUQ.subs = 0; GPUQ.dones = 0;
                       R2.ftAvg = 16.7; R2.ftSlow = 16.7; R2.ftCpu = 16.7; },
    fallRule: () => ({ safeH: FALL_SAFE_H, fatalH: FALL_FATAL_H, slopeTan: FALL_SLOPE_TAN,""")
open(p, 'w', encoding='utf-8').write(s)
print('gpuclock: harness ok')

s = open(p, encoding='utf-8').read()
# Individual cost knobs, so where a frame goes can be MEASURED one line item at
# a time instead of guessed at.
s = sub1(s, "    order: () => GFX_ORDER.slice(),",
"""    order: () => GFX_ORDER.slice(),
    setRes: (v) => { GFX.res = clamp(+v || 1, 0.45, 1.5); R2.sceneRes = null; return GFX.res; },
    setPlants: (k) => { GFX.plant = Math.round((GFX_PRESETS[GFX.name].plant || 8000) * (+k || 1));
                        GFX.folMax = Math.round((GFX_PRESETS[GFX.name].folMax || 140000) * (+k || 1)); return GFX.plant; },
    setShadow: (n) => { GFX.shadow = Math.max(0, n | 0); return GFX.shadow; },
    setCrit: (k) => { GFX.crit = (GFX_PRESETS[GFX.name].crit || 1.5) * (+k || 1); return GFX.crit; },""")
open(p, 'w', encoding='utf-8').write(s)
print('gpuclock: cost knobs ok')

s = open(p, encoding='utf-8').read()
# ULTRA was rendering at 1.15x the display size and then scaling down. That is
# supersampling on top of MSAA: it costs 32% of every pixel in the frame and is
# very nearly invisible next to the MSAA that is already running. Ultra keeps
# its draw distance, its shadow cascades, its foliage and its effects -- the
# things you can actually see -- and renders at native.
s = sub1(s, "  ultra:  { res: 1.15,", "  ultra:  { res: 1.00,")
open(p, 'w', encoding='utf-8').write(s)
print('gpuclock: ultra renders at native ok')

s = open(p, encoding='utf-8').read()
# If you PICKED a level, the game does not overrule you -- that rule is tested
# and it stays. But it should say so when the level you picked is not arriving,
# instead of leaving you to wonder whether the game is broken.
s = sub1(s, "function r2Hud() {",
"""// Said once, quietly, when a hand-picked level is being delivered at a rate
// nobody would call playable. Not a nag: it names the number and the way out.
let AQ_SAID_SLOW = 0;
function r2WarnIfDrowning() {
  if (!GFX.userSet || !R2.ftSlow) return;
  const now = performance.now() / 1000;
  if (R2.ftSlow < 90 || now - AQ_SAID_SLOW < 45) return;      // under ~11 fps
  AQ_SAID_SLOW = now;
  toast(GFX.name + ' is arriving at ' + Math.round(1000 / R2.ftSlow) +
        ' fps on this machine. Press the auto button to let it pick for you.', 5000);
}
function r2Hud() {
  try { r2WarnIfDrowning(); } catch (e) {}""")
open(p, 'w', encoding='utf-8').write(s)
print('gpuclock: it says when a chosen level is not arriving ok')
