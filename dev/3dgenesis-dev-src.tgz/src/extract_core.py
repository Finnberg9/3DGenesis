import re,sys
s=open(sys.argv[1],encoding='utf-8').read()
i=s.index("(function (root) {")
j=s.index("})(typeof window !== 'undefined' ? window : globalThis);",i)
open(sys.argv[2],'w').write(s[i:j]+"})(globalThis);\n")
