// =====================================================================
// FUSED CREATURE MESH (CPU side)
// A designed creature is one continuous skin: body, neck, head, tail, limbs,
// feet, hands, lips, eye sockets and every other fleshy part are primitives
// of a single signed-distance field joined with smooth minimums, then meshed
// with surface nets. Each vertex records the two bones that move it (so legs
// bend at the knee and the tail swings), a baked ambient-occlusion term (so
// creases under the jaw and in the armpits darken like real skin) and a
// colour for parts painted their own colour.
// Everything is in body-local rest space, in units of the body radius R.
// =====================================================================
const MESH_V_FLOATS = 14;   // pos3 nrm3 ao1 bone0 bone1 w0 col3 paint1
// Flat, monomorphic copy of the primitives for the hot loops.
const PS = 22;
function packPrims(prims) {
  const T = new Float64Array(prims.length * PS);
  prims.forEach((q, i) => {
    const o = i * PS;
    T[o + 1] = q.ax; T[o + 2] = q.ay; T[o + 3] = q.az; T[o + 10] = q.k || 0;
    if (q.t === 's') { T[o] = 0; T[o + 7] = q.ra; }
    else if (q.t === 'c') {
      const bax = q.bx - q.ax, bay = q.by - q.ay, baz = q.bz - q.az, l2 = bax * bax + bay * bay + baz * baz;
      if (l2 < 1e-10) { T[o] = 0; T[o + 7] = Math.max(q.ra, q.rb); return; }
      T[o] = 1; T[o + 4] = bax; T[o + 5] = bay; T[o + 6] = baz; T[o + 7] = q.ra; T[o + 8] = q.rb;
      const rr = q.ra - q.rb; T[o + 9] = l2; T[o + 11] = rr; T[o + 12] = l2 - rr * rr; T[o + 13] = 1 / l2;
    } else {
      T[o] = 2;
      T[o + 4] = q.ex[0] / q.rx; T[o + 5] = q.ex[1] / q.rx; T[o + 6] = q.ex[2] / q.rx;
      T[o + 7] = q.ey[0] / q.ry; T[o + 8] = q.ey[1] / q.ry; T[o + 9] = q.ey[2] / q.ry;
      T[o + 11] = q.ez[0] / q.rz; T[o + 12] = q.ez[1] / q.rz; T[o + 13] = q.ez[2] / q.rz;
      T[o + 14] = 1 / q.rx; T[o + 15] = 1 / q.ry; T[o + 16] = 1 / q.rz; T[o + 17] = Math.min(q.rx, q.ry, q.rz);
    }
  });
  return T;
}
function sdPacked(T, o, x, y, z) {
  const px = x - T[o + 1], py = y - T[o + 2], pz = z - T[o + 3];
  const ty = T[o];
  if (ty === 0) return Math.sqrt(px * px + py * py + pz * pz) - T[o + 7];
  if (ty === 1) {
    const bax = T[o + 4], bay = T[o + 5], baz = T[o + 6], l2 = T[o + 9], rr = T[o + 11], a2 = T[o + 12], il2 = T[o + 13];
    const yy = px * bax + py * bay + pz * baz, zz = yy - l2;
    const xx = px * l2 - bax * yy, xy = py * l2 - bay * yy, xz = pz * l2 - baz * yy;
    const x2 = xx * xx + xy * xy + xz * xz, y2 = yy * yy * l2, z2 = zz * zz * l2;
    const k = (rr > 0 ? 1 : rr < 0 ? -1 : 0) * rr * rr * x2;
    if ((zz > 0 ? a2 * z2 : zz < 0 ? -a2 * z2 : 0) > k) return Math.sqrt(x2 + z2) * il2 - T[o + 8];
    if ((yy > 0 ? a2 * y2 : yy < 0 ? -a2 * y2 : 0) < k) return Math.sqrt(x2 + y2) * il2 - T[o + 7];
    return (Math.sqrt(x2 * a2 * il2) + yy * rr) * il2 - T[o + 7];
  }
  const u = px * T[o + 4] + py * T[o + 5] + pz * T[o + 6];
  const v = px * T[o + 7] + py * T[o + 8] + pz * T[o + 9];
  const w = px * T[o + 11] + py * T[o + 12] + pz * T[o + 13];
  const k0 = Math.sqrt(u * u + v * v + w * w);
  const u2 = u * T[o + 14], v2 = v * T[o + 15], w2 = w * T[o + 16];
  const k1 = Math.sqrt(u2 * u2 + v2 * v2 + w2 * w2);
  return k1 > 1e-9 ? k0 * (k0 - 1) / k1 : -T[o + 17];
}
function primBounds(q) {
  const m = q.k * 0.5;
  if (q.t === 's') return [q.ax - q.ra - m, q.ay - q.ra - m, q.az - q.ra - m, q.ax + q.ra + m, q.ay + q.ra + m, q.az + q.ra + m];
  if (q.t === 'c') {
    const r = Math.max(q.ra, q.rb) + m;
    return [Math.min(q.ax, q.bx) - r, Math.min(q.ay, q.by) - r, Math.min(q.az, q.bz) - r,
            Math.max(q.ax, q.bx) + r, Math.max(q.ay, q.by) + r, Math.max(q.az, q.bz) + r];
  }
  const r = Math.max(q.rx, q.ry, q.rz) + m;
  return [q.ax - r, q.ay - r, q.az - r, q.ax + r, q.ay + r, q.az + r];
}
function primMinR(q) { return q.t === 's' ? q.ra : q.t === 'c' ? Math.min(q.ra, q.rb) : Math.min(q.rx, q.ry, q.rz); }

// Mesh a list of primitives. quality: 1 = editor / your own body, 0 = distant AI.
function meshPrims(prims, quality) {
  if (!prims.length) return null;
  const bb = [Infinity, Infinity, Infinity, -Infinity, -Infinity, -Infinity];
  let minR = Infinity;
  const pb = prims.map((q) => {
    const b = primBounds(q);
    for (let i = 0; i < 3; i++) { bb[i] = Math.min(bb[i], b[i]); bb[i + 3] = Math.max(bb[i + 3], b[i + 3]); }
    const r = primMinR(q); if (r > 0.02) minR = Math.min(minR, r);
    return b;
  });
  if (!isFinite(minR)) minR = 0.1;
  const span = Math.max(bb[3] - bb[0], bb[4] - bb[1], bb[5] - bb[2]);
  // a grid fine enough for the thinnest limb, bounded both ways
  // quality 2: editor and your own body, 1: animals near you, 0: distant animals
  const maxCells = [64, 96, 124][clamp(quality | 0, 0, 2)], minCells = [36, 48, 56][clamp(quality | 0, 0, 2)];
  let step = minR * (quality >= 2 ? 0.5 : quality ? 0.6 : 0.8);
  step = Math.min(Math.max(step, span / maxCells), span / minCells);
  const pad = step * 2;
  const ox = bb[0] - pad, oy = bb[1] - pad, oz = bb[2] - pad;
  let nx = Math.ceil((bb[3] - bb[0] + 2 * pad) / step) + 1;
  let ny = Math.ceil((bb[4] - bb[1] + 2 * pad) / step) + 1;
  let nz = Math.ceil((bb[5] - bb[2] + 2 * pad) / step) + 1;
  const N = nx * ny * nz;
  const FAR = 1e3;
  const F = new Float32Array(N).fill(FAR);
  const B1 = new Int16Array(N).fill(-1), B2 = new Int16Array(N).fill(-1);
  const D1 = new Float32Array(N).fill(FAR), D2 = new Float32Array(N).fill(FAR);
  const at = (i, j, k) => (k * ny + j) * nx + i;
  // Two-level evaluation. The field is first evaluated on a coarse lattice (one
  // point per 4x4x4 block corner). Only blocks the surface can pass through, or
  // close enough that normals and creases sample them, are then evaluated exactly
  // per cell, and only against the primitives that can reach that block. Every
  // other cell takes the trilinear coarse value, which has the right sign and a
  // smooth magnitude for the occlusion samples.
  const BS = 4, cs = BS * step;
  const cx = Math.ceil((nx - 1) / BS) + 1, cy = Math.ceil((ny - 1) / BS) + 1, cz = Math.ceil((nz - 1) / BS) + 1;
  const CF = new Float32Array(cx * cy * cz).fill(FAR);
  const cat = (I, J, K) => (K * cy + J) * cx + I;
  const smoothInto = (f, d, kk) => {
    if (kk > 0) { const h = kk - Math.abs(f - d); if (h > 0) { const hh = h / kk; return Math.min(f, d) - hh * hh * kk * 0.25; } }
    return d < f ? d : f;
  };
  const TP = packPrims(prims);
  const cRange = (b) => [
    Math.max(0, Math.floor((b[0] - ox) / cs) - 1), Math.min(cx - 1, Math.ceil((b[3] - ox) / cs) + 1),
    Math.max(0, Math.floor((b[1] - oy) / cs) - 1), Math.min(cy - 1, Math.ceil((b[4] - oy) / cs) + 1),
    Math.max(0, Math.floor((b[2] - oz) / cs) - 1), Math.min(cz - 1, Math.ceil((b[5] - oz) / cs) + 1)];
  const pr = pb.map(cRange);
  for (let pi = 0; pi < prims.length; pi++) {
    const q = prims[pi], r = pr[pi];
    for (let K = r[4]; K <= r[5]; K++) for (let J = r[2]; J <= r[3]; J++) {
      let idx = cat(r[0], J, K);
      for (let I = r[0]; I <= r[1]; I++, idx++) CF[idx] = smoothInto(CF[idx], sdPacked(TP, pi * PS, ox + I * cs, oy + J * cs, oz + K * cs), q.k);
    }
  }
  // blocks to refine
  const bx = cx - 1, by = cy - 1, bz = cz - 1;
  const HDb = 0.5 * Math.sqrt(3) * cs, margin = HDb * 1.15 + step;
  const lists = new Array(bx * by * bz);
  const bid = (I, J, K) => (K * by + J) * bx + I;
  for (let K = 0; K < bz; K++) for (let J = 0; J < by; J++) for (let I = 0; I < bx; I++) {
    let lo = FAR;
    for (let c = 0; c < 8; c++) { const v = Math.abs(CF[cat(I + (c & 1), J + ((c >> 1) & 1), K + ((c >> 2) & 1))]); if (v < lo) lo = v; }
    if (lo < margin) lists[bid(I, J, K)] = [];
  }
  for (let pi = 0; pi < prims.length; pi++) {
    const r = pr[pi];
    for (let K = Math.max(0, r[4] - 1); K <= Math.min(bz - 1, r[5]); K++)
      for (let J = Math.max(0, r[2] - 1); J <= Math.min(by - 1, r[3]); J++)
        for (let I = Math.max(0, r[0] - 1); I <= Math.min(bx - 1, r[1]); I++) {
          const L = lists[bid(I, J, K)]; if (L) L.push(pi);
        }
  }
  const dcs = new Float32Array(prims.length);
  for (let K = 0; K < bz; K++) for (let J = 0; J < by; J++) for (let I = 0; I < bx; I++) {
    const i0 = I * BS, j0 = J * BS, k0 = K * BS;
    const iE = Math.min(nx - 1, i0 + BS), jE = Math.min(ny - 1, j0 + BS), kE = Math.min(nz - 1, k0 + BS);
    const L = lists[bid(I, J, K)];
    if (!L) {
      // trilinear fill from the 8 coarse corners
      const c000 = CF[cat(I, J, K)], c100 = CF[cat(I + 1, J, K)], c010 = CF[cat(I, J + 1, K)], c110 = CF[cat(I + 1, J + 1, K)];
      const c001 = CF[cat(I, J, K + 1)], c101 = CF[cat(I + 1, J, K + 1)], c011 = CF[cat(I, J + 1, K + 1)], c111 = CF[cat(I + 1, J + 1, K + 1)];
      for (let k = k0; k <= kE; k++) {
        const tz = (k - k0) / BS;
        for (let j = j0; j <= jE; j++) {
          const ty = (j - j0) / BS;
          const a0 = c000 + (c010 - c000) * ty, a1 = c100 + (c110 - c100) * ty;
          const b0 = c001 + (c011 - c001) * ty, b1 = c101 + (c111 - c101) * ty;
          const e0 = a0 + (b0 - a0) * tz, e1 = a1 + (b1 - a1) * tz;
          let idx = at(i0, j, k);
          for (let i = i0; i <= iE; i++, idx++) { if (D1[idx] < FAR) continue; F[idx] = e0 + (e1 - e0) * ((i - i0) / BS); }
        }
      }
      continue;
    }
    if (!L.length) continue;
    // which primitives can reach this block
    const mx = ox + (i0 + BS * 0.5) * step, my = oy + (j0 + BS * 0.5) * step, mz = oz + (k0 + BS * 0.5) * step;
    let up = FAR;
    for (let n = 0; n < L.length; n++) { const d = sdPacked(TP, L[n] * PS, mx, my, mz); dcs[n] = d; if (d + HDb < up) up = d + HDb; }
    let m = 0;
    for (let n = 0; n < L.length; n++) if (dcs[n] - HDb < up + TP[L[n] * PS + 10] + 2 * step) L[m++] = L[n];
    L.length = m;
    for (let k = k0; k <= kE; k++) {
      const z = oz + k * step;
      for (let j = j0; j <= jE; j++) {
        const y = oy + j * step;
        let idx = at(i0, j, k);
        for (let i = i0; i <= iE; i++, idx++) {
          if (D1[idx] < FAR) continue;           // shared face already done exactly
          const x = ox + i * step;
          let f = FAR, d1 = FAR, d2 = FAR, b1 = -1, b2 = -1;
          for (let n = 0; n < m; n++) {
            const pi = L[n], d = sdPacked(TP, pi * PS, x, y, z), kk = TP[pi * PS + 10];
            if (kk > 0) { const h = kk - Math.abs(f - d); if (h > 0) { const hh = h / kk; f = Math.min(f, d) - hh * hh * kk * 0.25; } else if (d < f) f = d; }
            else if (d < f) f = d;
            if (d < d1) { d2 = d1; b2 = b1; d1 = d; b1 = pi; } else if (d < d2) { d2 = d; b2 = pi; }
          }
          F[idx] = f; D1[idx] = d1 < FAR ? d1 : FAR * 0.999; D2[idx] = d2; B1[idx] = b1; B2[idx] = b2;
        }
      }
    }
  }
  // ---- surface nets ---------------------------------------------------------
  const CORN = [[0,0,0],[1,0,0],[0,1,0],[1,1,0],[0,0,1],[1,0,1],[0,1,1],[1,1,1]];
  const EDG = [[0,1],[2,3],[4,5],[6,7],[0,2],[1,3],[4,6],[5,7],[0,4],[1,5],[2,6],[3,7]];
  const cnx = nx - 1, cny = ny - 1;
  const vid = new Int32Array(cnx * cny * (nz - 1)).fill(-1);
  const cid = (i, j, k) => (k * cny + j) * cnx + i;
  const pos = [];
  const cv = new Float32Array(8);
  // only refined blocks can hold surface cells
  const RB = [];
  for (let K = 0; K < bz; K++) for (let J = 0; J < by; J++) for (let I = 0; I < bx; I++) if (lists[bid(I, J, K)]) RB.push(I, J, K);
  for (let r = 0; r < RB.length; r += 3) {
  const I0 = RB[r] * BS, J0 = RB[r + 1] * BS, K0 = RB[r + 2] * BS;
  const IE = Math.min(nx - 1, I0 + BS), JE = Math.min(ny - 1, J0 + BS), KE = Math.min(nz - 1, K0 + BS);
  for (let k = K0; k < KE; k++) for (let j = J0; j < JE; j++) for (let i = I0; i < IE; i++) {
    let neg = 0;
    for (let c = 0; c < 8; c++) { const o = CORN[c]; const v = F[at(i + o[0], j + o[1], k + o[2])]; cv[c] = v; if (v < 0) neg++; }
    if (neg === 0 || neg === 8) continue;
    let sx = 0, sy = 0, sz = 0, n = 0;
    for (let e = 0; e < 12; e++) {
      const a = EDG[e][0], b = EDG[e][1], va = cv[a], vb = cv[b];
      if ((va < 0) === (vb < 0)) continue;
      const t = va / (va - vb);
      const A = CORN[a], Bc = CORN[b];
      sx += A[0] + (Bc[0] - A[0]) * t; sy += A[1] + (Bc[1] - A[1]) * t; sz += A[2] + (Bc[2] - A[2]) * t; n++;
    }
    vid[cid(i, j, k)] = pos.length / 3;
    pos.push(i + sx / n, j + sy / n, k + sz / n);   // grid units for now
  }
  }
  const nv = pos.length / 3;
  if (!nv) return null;
  const idxArr = [];
  const quad = (a, b, c, d, flip) => {
    if (a < 0 || b < 0 || c < 0 || d < 0) return;
    if (flip) idxArr.push(a, b, c, a, c, d); else idxArr.push(a, d, c, a, c, b);
  };
  for (let r = 0; r < RB.length; r += 3) {
  const I0 = Math.max(1, RB[r] * BS), J0 = Math.max(1, RB[r + 1] * BS), K0 = Math.max(1, RB[r + 2] * BS);
  const IE = Math.min(nx - 1, RB[r] * BS + BS), JE = Math.min(ny - 1, RB[r + 1] * BS + BS), KE = Math.min(nz - 1, RB[r + 2] * BS + BS);
  for (let k = K0; k < KE; k++) for (let j = J0; j < JE; j++) for (let i = I0; i < IE; i++) {
    const v0 = F[at(i, j, k)] < 0;
    if ((F[at(i + 1, j, k)] < 0) !== v0) quad(vid[cid(i, j - 1, k - 1)], vid[cid(i, j, k - 1)], vid[cid(i, j, k)], vid[cid(i, j - 1, k)], !v0);
    if ((F[at(i, j + 1, k)] < 0) !== v0) quad(vid[cid(i - 1, j, k - 1)], vid[cid(i, j, k - 1)], vid[cid(i, j, k)], vid[cid(i - 1, j, k)], v0);
    if ((F[at(i, j, k + 1)] < 0) !== v0) quad(vid[cid(i - 1, j - 1, k)], vid[cid(i, j - 1, k)], vid[cid(i, j, k)], vid[cid(i - 1, j, k)], !v0);
  }
  }
  if (!idxArr.length) return null;
  // trilinear field sample and gradient in grid units
  const clampi = (v, hi) => (v < 0 ? 0 : v > hi ? hi : v);
  const Fg = (i, j, k) => F[at(clampi(i, nx - 1), clampi(j, ny - 1), clampi(k, nz - 1))];
  const sample = (gx, gy, gz) => {
    const i = Math.floor(gx), j = Math.floor(gy), k = Math.floor(gz);
    const tx = gx - i, ty = gy - j, tz = gz - k;
    const c00 = Fg(i, j, k) * (1 - tx) + Fg(i + 1, j, k) * tx, c10 = Fg(i, j + 1, k) * (1 - tx) + Fg(i + 1, j + 1, k) * tx;
    const c01 = Fg(i, j, k + 1) * (1 - tx) + Fg(i + 1, j, k + 1) * tx, c11 = Fg(i, j + 1, k + 1) * (1 - tx) + Fg(i + 1, j + 1, k + 1) * tx;
    return (c00 * (1 - ty) + c10 * ty) * (1 - tz) + (c01 * (1 - ty) + c11 * ty) * tz;
  };
  const out = new Float32Array(nv * MESH_V_FLOATS);
  const aoH = [1.2, 2.4, 4.0, 6.5];
  for (let v = 0; v < nv; v++) {
    const gx = pos[v * 3], gy = pos[v * 3 + 1], gz = pos[v * 3 + 2];
    // gradient by central differences of the trilinear field
    const e = 0.5;
    let nxv = sample(gx + e, gy, gz) - sample(gx - e, gy, gz);
    let nyv = sample(gx, gy + e, gz) - sample(gx, gy - e, gz);
    let nzv = sample(gx, gy, gz + e) - sample(gx, gy, gz - e);
    const nl = Math.hypot(nxv, nyv, nzv) || 1; nxv /= nl; nyv /= nl; nzv /= nl;
    // ambient occlusion: how far the field falls short along the normal
    let occ = 0, wsum = 0;
    for (let s2 = 0; s2 < aoH.length; s2++) {
      const h = aoH[s2] * (quality ? 1 : 0.7);
      const f = sample(gx + nxv * h, gy + nyv * h, gz + nzv * h) / step;
      const wgt = 1 / (s2 + 1);
      occ += Math.max(0, h - f) / h * wgt; wsum += wgt;
    }
    const ao = clamp(1 - (occ / wsum) * 1.6, 0.32, 1);
    // bones and colour from the nearest grid corner's two closest primitives
    const ci = clampi(Math.round(gx), nx - 1), cj = clampi(Math.round(gy), ny - 1), ck = clampi(Math.round(gz), nz - 1);
    const ix = at(ci, cj, ck);
    const p1 = B1[ix] >= 0 ? prims[B1[ix]] : prims[0];
    const p2 = B2[ix] >= 0 ? prims[B2[ix]] : p1;
    const dd = D2[ix] - D1[ix];
    const blend = Math.max(0.04, Math.max(p1.k, p2.k) * 0.8);
    const u = clamp(dd / blend, 0, 1);
    const w1 = 0.5 + 0.5 * u * u * (3 - 2 * u);
    const o = v * MESH_V_FLOATS;
    out[o] = ox + gx * step; out[o + 1] = oy + gy * step; out[o + 2] = oz + gz * step;
    out[o + 3] = nxv; out[o + 4] = nyv; out[o + 5] = nzv;
    out[o + 6] = ao;
    let b1 = p1.bone | 0, b2 = p2.bone | 0, ww = w1;
    if (b1 === b2) { ww = 1; }
    out[o + 7] = b1; out[o + 8] = b2; out[o + 9] = ww;
    const c1 = p1.col, c2 = p2.col;
    const pa1 = c1 ? 0 : 1, pa2 = c2 ? 0 : 1;
    const cc1 = c1 || [1, 1, 1], cc2 = c2 || [1, 1, 1];
    // colour boundaries are sharper than bone blends
    const cu = clamp(dd / Math.max(0.02, blend * 0.35), 0, 1);
    const cw = 0.5 + 0.5 * cu * cu * (3 - 2 * cu);
    out[o + 10] = cc1[0] * cw + cc2[0] * (1 - cw);
    out[o + 11] = cc1[1] * cw + cc2[1] * (1 - cw);
    out[o + 12] = cc1[2] * cw + cc2[2] * (1 - cw);
    out[o + 13] = pa1 * cw + pa2 * (1 - cw);
  }
  return { vertData: out, idx: new Uint32Array(idxArr), verts: nv, tris: idxArr.length / 3 };
}
