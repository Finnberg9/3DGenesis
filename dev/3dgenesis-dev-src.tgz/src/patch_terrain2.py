# Terrain 2 (rocks, boulders, pebbles, driftwood, shallow water with shore
# waves, frozen lakes, terrain surface detail), lower exposure, first person
# body view, ultra draw distance. See src/terrain2.js.
def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
p='g3.html'; s=open(p,encoding='utf-8').read()
# ---- core: boulders in the static forest (kind 9, solid like a trunk)
s=sub1(s,"  const TREE_R = [16, 7.5, 3, 3, 5, 4, 4, 4, 2.2];","  const TREE_R = [16, 7.5, 3, 3, 5, 4, 4, 4, 2.2, 8.5];")
s=sub1(s,"""    const grid = makeGrid(w, h, 110);
    for (const t of trees) grid.insert(t);
    return { trees, grid };""","""    // boulders: scattered everywhere, thick on rock and scree, in clusters
    const BOULDER = { rock: 0.55, scree: 0.7, tundra: 0.25, snow: 0.12, beach: 0.12, desert: 0.14, savanna: 0.1, plains: 0.07, forest: 0.08, taiga: 0.14, marsh: 0.03 };
    const BC = 96, bnx = Math.ceil(w / BC), bny = Math.ceil(h / BC);
    for (let j = 0; j < bny; j++) for (let i = 0; i < bnx; i++) {
      const x = (i + 0.1 + hsh(i, j, 11) * 0.8) * BC, y = (j + 0.1 + hsh(i, j, 12) * 0.8) * BC;
      if (x < 8 || y < 8 || x > w - 8 || y > h - 8) continue;
      const b = terrain.biomeAt(x, y);
      if (b === 'deep' || b === 'shallow') continue;
      if (terrain.height(x, y) < terrain.LV.water + 0.002) continue;
      const clump = 0.5 + 0.9 * hsh(Math.floor(i / 4), Math.floor(j / 4), 13);      // regional clusters
      if (hsh(i, j, 14) > (BOULDER[b] || 0) * clump) continue;
      const sc = 0.35 + Math.pow(hsh(i, j, 15), 2.2) * 1.9;                          // mostly small, a few huge
      trees.push({ x, y, kind: 9, s: sc, rot: hsh(i, j, 16) * 6.2832, v: (hsh(i, j, 17) * 3) | 0, trunkR: TREE_R[9] * sc, isTree: true, forest: true, boulder: true });
    }
    const grid = makeGrid(w, h, 110);
    for (const t of trees) grid.insert(t);
    return { trees, grid };""")
# ---- meshes
s=sub1(s,"function folInit() {\n", open('src/terrain2.js',encoding='utf-8').read()+"\nfunction folInit() {\n")
s=sub1(s,"""  for (let k = 0; k < 9; k++) {
    FOL.tree[k] = [];
    for (let v = 0; v < TREE_VARIANTS; v++) {
      FOL.tree[k][v] = [];
      for (let l = 0; l < 3; l++) { const { m, H } = buildTreeMesh(k, v, l);""","""  for (let k = 0; k < 10; k++) {
    FOL.tree[k] = [];
    for (let v = 0; v < TREE_VARIANTS; v++) {
      FOL.tree[k][v] = [];
      for (let l = 0; l < 3; l++) { const { m, H } = k === 9 ? buildBoulderMesh(v, l) : buildTreeMesh(k, v, l);""")
s=sub1(s,"  for (let k = 0; k < COVER_KINDS; k++) { FOL.cover[k] = []; for (let v = 0; v < COVER_VARIANTS; v++) FOL.cover[k][v] = folUpload(buildCoverMesh(k, v)); }",
         "  for (let k = 0; k < COVER_KINDS; k++) { FOL.cover[k] = []; for (let v = 0; v < COVER_VARIANTS; v++) FOL.cover[k][v] = folUpload(k >= 6 ? buildRockCover(k, v) : buildCoverMesh(k, v)); }")
s=sub1(s,"const TREE_VARIANTS = 3, COVER_KINDS = 6, COVER_VARIANTS = 2;","const TREE_VARIANTS = 3, COVER_KINDS = 9, COVER_VARIANTS = 2;")
s=sub1(s,"""  forest: [[2, 0.55], [5, 0.3], [0, 0.35], [4, 0.2]], plains: [[0, 0.8], [4, 0.08]], savanna: [[1, 0.8], [4, 0.05]],
  marsh: [[3, 0.8], [0, 0.3]], taiga: [[2, 0.3], [4, 0.2], [0, 0.2]], beach: [[1, 0.12]], tundra: [[0, 0.1]], shallow: [[3, 0.4]],""",
"""  forest: [[2, 0.55], [5, 0.3], [0, 0.35], [4, 0.2], [7, 0.03], [8, 0.015]], plains: [[0, 0.8], [4, 0.08], [6, 0.04], [7, 0.015]],
  savanna: [[1, 0.8], [4, 0.05], [6, 0.06], [7, 0.02]], marsh: [[3, 0.8], [0, 0.3], [8, 0.02]],
  taiga: [[2, 0.3], [4, 0.2], [0, 0.2], [6, 0.08], [7, 0.04]], beach: [[1, 0.12], [6, 0.22], [8, 0.025], [7, 0.02]],
  tundra: [[0, 0.1], [6, 0.3], [7, 0.1]], shallow: [[3, 0.4], [6, 0.15]], rock: [[6, 0.45], [7, 0.22]],
  scree: [[6, 0.6], [7, 0.2]], snow: [[6, 0.08], [7, 0.04]], desert: [[6, 0.15], [7, 0.05]],""")
# rock material in the foliage shader (leaf = -1)
s=sub1(s,"""  var col = i.col;
  if (i.leaf < 0.5) {""","""  var col = i.col;
  if (i.leaf < -0.5) {
    // rock: layered strata, lichen speckle, cracks, a bumped normal
    let det = 1.0 - smoothstep(200.0, 900.0, d);
    let q = i.wpos * 0.18;
    let n1 = fnoise(q.xz + q.yy * 0.7);
    let strata = fnoise(vec2<f32>(i.wpos.y * 0.9 + n1 * 2.0, (i.wpos.x + i.wpos.z) * 0.02));
    let crack = smoothstep(0.47, 0.5, abs(fnoise(q.xy * 1.7 + q.zz) - 0.5) + 0.46);
    let speck = smoothstep(0.78, 0.86, fnoise(i.wpos.xz * 0.9 + i.wpos.yy * 0.4));
    var rc = col * (0.78 + 0.34 * strata) * (1.0 - 0.35 * (1.0 - crack));
    rc = mix(rc, vec3<f32>(0.62, 0.64, 0.52), speck * 0.35);
    col = mix(col, rc, det);
    let b1 = fnoise(q.xz * 2.0 + q.yy);
    let b2 = fnoise(q.zy * 2.0 + q.xx);
    N = normalize(N + (vec3<f32>(b1 - 0.5, 0.0, b2 - 0.5) * 0.6) * det);
  } else if (i.leaf < 0.5) {""")
s=sub1(s,"const CR = [85, 55, 22, 18, 28, 36, 0, 30, 12];","const CR = [85, 55, 22, 18, 28, 36, 0, 30, 12, 0];")
# ---- terrain surface detail: albedo variation, rock on slopes, wet sand, snow caps
s=sub1(s,"""  var o: VO; o.pos = g.viewProj * vec4<f32>(p, 1.0); o.nrm = n; o.col = c; o.wpos = p; return o;
}
@fragment fn fs(i: VO) -> @location(0) vec4<f32> {
  return vec4<f32>(shade(i.col, i.nrm, i.wpos), 1.0);
}`;""","""  var o: VO; o.pos = g.viewProj * vec4<f32>(p, 1.0); o.nrm = n; o.col = c; o.wpos = p; return o;
}
fn th(p: vec2<f32>) -> f32 { var p3 = fract(vec3<f32>(p.x, p.y, p.x) * 0.1031); p3 += dot(p3, p3.yzx + vec3<f32>(33.33)); return fract((p3.x + p3.y) * p3.z); }
fn tn(p: vec2<f32>) -> f32 {
  let i = floor(p); let f = fract(p); let u = f * f * (3.0 - 2.0 * f);
  return mix(mix(th(i), th(i + vec2<f32>(1.0, 0.0)), u.x), mix(th(i + vec2<f32>(0.0, 1.0)), th(i + vec2<f32>(1.0, 1.0)), u.x), u.y);
}
fn fbm(p: vec2<f32>) -> f32 { return tn(p) * 0.5 + tn(p * 2.03 + vec2<f32>(5.2, 1.3)) * 0.3 + tn(p * 4.1 + vec2<f32>(2.7, 9.1)) * 0.2; }
@fragment fn fs(i: VO) -> @location(0) vec4<f32> {
  var N = normalize(i.nrm);
  let d = distance(i.wpos, g.camPos.xyz);
  let det = 1.0 - smoothstep(600.0, 3000.0, d);
  let xz = i.wpos.xz;
  var col = i.col;
  // large patches and fine grain break up the flat vertex colours
  let mcr = fbm(xz * 0.004);
  let fine = mix(0.5, fbm(xz * 0.09), det);
  col *= 0.80 + 0.28 * mcr + 0.16 * (fine - 0.5);
  // steep ground is bare layered rock
  let slope = 1.0 - N.y;
  let rockK = smoothstep(0.22, 0.42, slope + (mcr - 0.5) * 0.12);
  let strata = tn(vec2<f32>(i.wpos.y * 0.22 + mcr * 3.0, (xz.x + xz.y) * 0.01));
  let rock = vec3<f32>(0.40, 0.38, 0.34) * (0.72 + 0.45 * strata) * (0.85 + 0.3 * fine);
  col = mix(col, rock, rockK);
  // sand darkens where waves wet it
  let sea = g.params.w;
  let wet = (1.0 - smoothstep(sea + 0.5, sea + 5.0, i.wpos.y)) * step(sea - 30.0, i.wpos.y);
  col *= 1.0 - 0.3 * wet;
  // bump from the fine noise so the sun rakes across the ground
  let e = 1.5;
  let h0 = fbm(xz * 0.09); let hx = fbm((xz + vec2<f32>(e, 0.0)) * 0.09); let hz = fbm((xz + vec2<f32>(0.0, e)) * 0.09);
  N = normalize(N + vec3<f32>(h0 - hx, 0.0, h0 - hz) * 2.2 * det * (0.4 + 0.6 * rockK));
  var lit = shade(col, N, i.wpos);
  let V = normalize(g.camPos.xyz - i.wpos);
  lit += vec3<f32>(0.5) * pow(max(dot(reflect(-normalize(g.lightDir.xyz), N), V), 0.0), 40.0) * wet * 0.25 * g.params.z;
  return vec4<f32>(lit, 1.0);
}`;""")
# softer, less neon ground palette
s=sub1(s,"""  deep: [23, 56, 95], shallow: [47, 119, 158], beach: [226, 203, 140], marsh: [84, 120, 76],
  plains: [126, 178, 84], forest: [56, 116, 52], taiga: [43, 84, 67], savanna: [186, 174, 96],
  desert: [222, 194, 128],""","""  deep: [23, 56, 95], shallow: [120, 118, 96], beach: [196, 178, 132], marsh: [78, 104, 68],
  plains: [100, 138, 70], forest: [52, 96, 46], taiga: [43, 78, 62], savanna: [160, 150, 92],
  desert: [196, 170, 118],""")
# ---- water: depth-aware shallows, shore waves and foam, frozen lakes
s=sub1(s,"""const WGSL_WATER = WGSL_COMMON + `
struct VO { @builtin(position) pos: vec4<f32>, @location(0) wpos: vec3<f32> };
@vertex fn vs(@location(0) p: vec3<f32>) -> VO {
  var o: VO; o.pos = g.viewProj * vec4<f32>(p, 1.0); o.wpos = p; return o;
}""","""const WGSL_WATER = WGSL_COMMON + `
struct VO { @builtin(position) pos: vec4<f32>, @location(0) wpos: vec3<f32> };
@group(0) @binding(3) var hTex: texture_2d<f32>;
fn wh(p: vec2<f32>) -> vec2<f32> {
  let dim = vec2<i32>(textureDimensions(hTex));
  let f = p / ${GRID_STEP}.0;
  let i0 = vec2<i32>(floor(f)); let t = fract(f);
  let c = dim - vec2<i32>(1);
  let a = textureLoad(hTex, clamp(i0, vec2<i32>(0), c), 0).rg;
  let b = textureLoad(hTex, clamp(i0 + vec2<i32>(1, 0), vec2<i32>(0), c), 0).rg;
  let cc = textureLoad(hTex, clamp(i0 + vec2<i32>(0, 1), vec2<i32>(0), c), 0).rg;
  let dd = textureLoad(hTex, clamp(i0 + vec2<i32>(1, 1), vec2<i32>(0), c), 0).rg;
  var r = mix(mix(a, b, t.x), mix(cc, dd, t.x), t.y);
  if (p.x < 0.0 || p.y < 0.0 || i0.x >= c.x || i0.y >= c.y) { r = vec2<f32>(-2000.0, 0.0); }
  return r;
}
fn wn(p: vec2<f32>) -> f32 { var p3 = fract(vec3<f32>(p.x, p.y, p.x) * 0.1031); p3 += dot(p3, p3.yzx + vec3<f32>(33.33)); return fract((p3.x + p3.y) * p3.z); }
fn wnoise(p: vec2<f32>) -> f32 {
  let i = floor(p); let f = fract(p); let u = f * f * (3.0 - 2.0 * f);
  return mix(mix(wn(i), wn(i + vec2<f32>(1.0, 0.0)), u.x), mix(wn(i + vec2<f32>(0.0, 1.0)), wn(i + vec2<f32>(1.0, 1.0)), u.x), u.y);
}
@vertex fn vs(@location(0) p: vec3<f32>) -> VO {
  var o: VO; o.pos = g.viewProj * vec4<f32>(p, 1.0); o.wpos = p; return o;
}
@fragment fn fs2(i: VO) -> @location(0) vec4<f32> {
  let t = g.params.x;
  let sea = g.params.w;
  let hc = wh(i.wpos.xz);
  let depth = max(0.0, sea - hc.x);
  let V = normalize(g.camPos.xyz - i.wpos);
  let dist = distance(i.wpos, g.camPos.xyz);
  let fogf = clamp(1.0 - exp(-(dist * g.params.y) * (dist * g.params.y)), 0.0, 1.0);
  let L = normalize(g.lightDir.xyz);
  let day = g.params.z;
  // frozen: lakes in cold country are ice
  if (hc.y > 0.5) {
    let n = wnoise(i.wpos.xz * 0.05) * 0.6 + wnoise(i.wpos.xz * 0.2) * 0.4;
    let crack = smoothstep(0.02, 0.0, abs(wnoise(i.wpos.xz * 0.03 + vec2<f32>(n)) - 0.5));
    var ice = mix(vec3<f32>(0.62, 0.76, 0.84), vec3<f32>(0.86, 0.92, 0.96), n);
    ice = mix(ice, vec3<f32>(0.40, 0.55, 0.66), crack * 0.6);
    let Ni = normalize(vec3<f32>((n - 0.5) * 0.08, 1.0, (wnoise(i.wpos.zx * 0.2) - 0.5) * 0.08));
    let sh = shadowAt(i.wpos, Ni);
    var lit = ice * (mix(vec3<f32>(0.2, 0.24, 0.32), vec3<f32>(0.62, 0.70, 0.80), day) + vec3<f32>(0.9, 0.88, 0.82) * max(dot(Ni, L), 0.0) * 0.55 * sh * day);
    lit += vec3<f32>(1.0) * pow(max(dot(reflect(-L, Ni), V), 0.0), 60.0) * 0.5 * day * sh;
    return vec4<f32>(mix(lit, g.fogCol.rgb, fogf), 0.97);
  }
  // waves: several travelling ripples, calmer in the shallows
  let calm = clamp(depth / 25.0, 0.25, 1.0);
  let w1 = sin(i.wpos.x * 0.021 + i.wpos.z * 0.013 + t * 1.3);
  let w2 = sin(i.wpos.x * -0.017 + i.wpos.z * 0.029 + t * 1.7);
  let w3 = wnoise(i.wpos.xz * 0.08 + vec2<f32>(t * 0.4, t * 0.3)) - 0.5;
  let n = normalize(vec3<f32>((w1 * 0.10 + w3 * 0.25) * calm, 1.0, (w2 * 0.10 + w3 * 0.2) * calm));
  let fres = 0.03 + 0.97 * pow(1.0 - clamp(dot(n, V), 0.0, 1.0), 5.0);
  // colour by depth: clear turquoise over sand, deep blue further out
  let shal = vec3<f32>(0.20, 0.52, 0.52);
  let mid = vec3<f32>(0.07, 0.30, 0.40);
  let deep = vec3<f32>(0.03, 0.12, 0.22);
  var col = mix(shal, mid, smoothstep(2.0, 18.0, depth));
  col = mix(col, deep, smoothstep(18.0, 90.0, depth));
  let sh = shadowAt(i.wpos, n);
  let sky = mix(vec3<f32>(0.08, 0.10, 0.14), vec3<f32>(0.55, 0.66, 0.76), day);
  var lit = col * (0.3 + 0.7 * day) * (0.75 + 0.25 * sh) + sky * fres * 0.8;
  lit += vec3<f32>(1.0, 0.95, 0.85) * pow(max(dot(reflect(-L, n), V), 0.0), 120.0) * 1.4 * day * sh;
  // waves rolling in: bands that travel toward the shore and break as foam
  var foam = 0.0;
  if (depth < 14.0) {
    let band = sin(depth * 0.55 - t * 1.8 + wnoise(i.wpos.xz * 0.02) * 4.0);
    let crest = smoothstep(0.90, 0.99, band) * (1.0 - smoothstep(1.0, 5.0, depth)) * smoothstep(0.35, 0.6, wnoise(i.wpos.xz * 0.05));
    let edge = 1.0 - smoothstep(0.0, 1.6 + 0.8 * sin(t * 1.1 + i.wpos.x * 0.01), depth);
    foam = max(crest * 0.6, edge * 0.85) * (0.55 + 0.45 * wnoise(i.wpos.xz * 0.35 + vec2<f32>(t * 0.5, 0.0)));
  }
  lit = mix(lit, vec3<f32>(0.88, 0.92, 0.92) * (0.35 + 0.65 * day), clamp(foam, 0.0, 1.0));
  // the shallows are see-through: you see the sand and pebbles under them
  let alpha = clamp(mix(0.25, 0.94, 1.0 - exp(-depth / 9.0)) + fres * 0.3 + foam * 0.6, 0.0, 0.98);
  return vec4<f32>(mix(lit, g.fogCol.rgb, fogf), mix(alpha, 1.0, fogf));
}""")
# use the new fragment entry for the world water
s=sub1(s,"""    fragment: { module: wm, entryPoint: 'fs', targets: [{ format: fmt, blend: {""","""    fragment: { module: wm, entryPoint: 'fs2', targets: [{ format: fmt, blend: {""")
s=sub1(s,"    water:   dev.createBindGroup({ layout: waterPipe.getBindGroupLayout(0),   entries: [{ binding: 0, resource: { buffer: gBuf } }] }),",
         "    water:   dev.createBindGroup({ layout: waterPipe.getBindGroupLayout(0),   entries: [{ binding: 0, resource: { buffer: gBuf } }, { binding: 3, resource: waterHeightTex().createView() }].concat(SE) }),")
s=sub1(s,"  buildTerrain(); buildWater(); buildMinimap();","  buildTerrain(); buildWater(); waterHeightUpload(); buildMinimap();")
s=sub1(s,"  const info = buildTerrain();\n  buildWater();","  const info = buildTerrain();\n  buildWater();\n  waterHeightUpload();")
open(p,'w',encoding='utf-8').write(s)
print('terrain2 ok')
