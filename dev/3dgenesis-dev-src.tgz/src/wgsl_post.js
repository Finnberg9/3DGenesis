// Post-processing shaders: half-res ambient occlusion + sun shafts, a bright
// pass and separable blur for bloom, and the final composite that upscales
// the scene with contrast-adaptive sharpening and grades it.
const WGSL_POST_COMMON = `
struct PP { a: vec4<f32>, b: vec4<f32>, c: vec4<f32>, d: vec4<f32> };
// a: sunUV.xy, sun visible, ray strength
// b: ao strength, bloom strength, sharpen, time
// c: near, far, daylight, vignette
// d: sun colour rgb, grade strength
@group(0) @binding(0) var<uniform> P: PP;
struct VO { @builtin(position) pos: vec4<f32>, @location(0) uv: vec2<f32> };
@vertex fn vs(@builtin(vertex_index) i: u32) -> VO {
  var p = array<vec2<f32>, 3>(vec2<f32>(-1.0, -1.0), vec2<f32>(3.0, -1.0), vec2<f32>(-1.0, 3.0));
  var o: VO;
  o.pos = vec4<f32>(p[i], 0.0, 1.0);
  o.uv = vec2<f32>(p[i].x * 0.5 + 0.5, 0.5 - p[i].y * 0.5);
  return o;
}
fn phash(p: vec2<f32>) -> f32 { return fract(sin(dot(p, vec2<f32>(12.9898, 78.233))) * 43758.5453); }
`;
const WGSL_POST_FX = WGSL_POST_COMMON + `
@group(0) @binding(1) var depthTex: texture_depth_multisampled_2d;
fn depthAt(uv: vec2<f32>) -> f32 {
  let dim = vec2<f32>(textureDimensions(depthTex));
  let ip = vec2<i32>(clamp(uv * dim, vec2<f32>(0.0), dim - vec2<f32>(1.0)));
  return textureLoad(depthTex, ip, 0);
}
fn linZ(d: f32) -> f32 { return P.c.x * P.c.y / max(1e-4, P.c.y - d * (P.c.y - P.c.x)); }
@fragment fn fs(i: VO) -> @location(0) vec4<f32> {
  let d0 = depthAt(i.uv);
  var ao = 0.0;
  if (P.b.x > 0.0 && d0 < 0.99999) {
    let z0 = linZ(d0);
    // about 9 world units of search radius, shrinking on screen with distance
    let rad = clamp(9.0 / z0 * 1.1, 0.002, 0.045);
    let rot = phash(i.pos.xy) * 6.2831;
    var occ = 0.0;
    for (var k = 0; k < 8; k = k + 1) {
      let a = rot + f32(k) * 0.7853982;
      let dir = vec2<f32>(cos(a), sin(a) * 1.6);
      for (var s = 1; s <= 2; s = s + 1) {
        let z = linZ(depthAt(i.uv + dir * rad * (f32(s) * 0.5)));
        let diff = z0 - z;
        if (diff > 0.35 && diff < 30.0) { occ += 1.0 - diff / 30.0; }
      }
    }
    ao = clamp(occ / 16.0 * 1.6, 0.0, 1.0) * (1.0 - smoothstep(600.0, 1400.0, z0));
  }
  var ray = 0.0;
  if (P.a.z > 0.0 && P.a.w > 0.0) {
    let N = 28;
    let delta = (P.a.xy - i.uv) / f32(N);
    var uv = i.uv + delta * phash(i.pos.xy + vec2<f32>(7.0, 3.0));
    var decay = 1.0;
    for (var s = 0; s < N; s = s + 1) {
      uv += delta;
      if (depthAt(uv) >= 0.99999) { ray += decay; }
      decay *= 0.95;
    }
    let toSun = distance(i.uv, P.a.xy);
    ray = ray / f32(N) * P.a.w * P.a.z * (1.0 - smoothstep(0.1, 0.9, toSun));
  }
  return vec4<f32>(ao, ray, 0.0, 1.0);
}`;
const WGSL_POST_BLOOM = WGSL_POST_COMMON + `
@group(0) @binding(1) var src: texture_2d<f32>;
@group(0) @binding(2) var smp: sampler;
@fragment fn fs_bright(i: VO) -> @location(0) vec4<f32> {
  let ts = 1.0 / vec2<f32>(textureDimensions(src));
  var c = textureSampleLevel(src, smp, i.uv + ts * vec2<f32>(-1.0, -1.0), 0.0).rgb;
  c += textureSampleLevel(src, smp, i.uv + ts * vec2<f32>(1.0, -1.0), 0.0).rgb;
  c += textureSampleLevel(src, smp, i.uv + ts * vec2<f32>(-1.0, 1.0), 0.0).rgb;
  c += textureSampleLevel(src, smp, i.uv + ts * vec2<f32>(1.0, 1.0), 0.0).rgb;
  c *= 0.25;
  let l = max(c.r, max(c.g, c.b));
  let thr = 0.66 + 0.0 * P.b.w;   // P referenced so every post pass shares one bind layout
  return vec4<f32>(c * smoothstep(thr, 0.97, l), 1.0);
}
fn blur(uv: vec2<f32>, dir: vec2<f32>) -> vec4<f32> {
  let ts = (1.0 + 0.0 * P.b.w) / vec2<f32>(textureDimensions(src));
  var w = array<f32, 5>(0.227027, 0.1945946, 0.1216216, 0.054054, 0.016216);
  var c = textureSampleLevel(src, smp, uv, 0.0).rgb * w[0];
  for (var k = 1; k < 5; k = k + 1) {
    let o = dir * ts * f32(k) * 1.5;
    c += textureSampleLevel(src, smp, uv + o, 0.0).rgb * w[k];
    c += textureSampleLevel(src, smp, uv - o, 0.0).rgb * w[k];
  }
  return vec4<f32>(c, 1.0);
}
@fragment fn fs_blurH(i: VO) -> @location(0) vec4<f32> { return blur(i.uv, vec2<f32>(1.0, 0.0)); }
@fragment fn fs_blurV(i: VO) -> @location(0) vec4<f32> { return blur(i.uv, vec2<f32>(0.0, 1.0)); }`;
const WGSL_POST_FINAL = WGSL_POST_COMMON + `
@group(0) @binding(1) var scene: texture_2d<f32>;
@group(0) @binding(2) var fxT: texture_2d<f32>;
@group(0) @binding(3) var bloomT: texture_2d<f32>;
@group(0) @binding(4) var smp: sampler;
@fragment fn fs(i: VO) -> @location(0) vec4<f32> {
  let ts = 1.0 / vec2<f32>(textureDimensions(scene));
  let c = textureSampleLevel(scene, smp, i.uv, 0.0).rgb;
  // contrast-adaptive sharpening: restores detail lost to the lower render
  // scale without ringing on edges that are already sharp
  let n0 = textureSampleLevel(scene, smp, i.uv + vec2<f32>(ts.x, 0.0), 0.0).rgb;
  let n1 = textureSampleLevel(scene, smp, i.uv - vec2<f32>(ts.x, 0.0), 0.0).rgb;
  let n2 = textureSampleLevel(scene, smp, i.uv + vec2<f32>(0.0, ts.y), 0.0).rgb;
  let n3 = textureSampleLevel(scene, smp, i.uv - vec2<f32>(0.0, ts.y), 0.0).rgb;
  let mn = min(c, min(min(n0, n1), min(n2, n3)));
  let mx = max(c, max(max(n0, n1), max(n2, n3)));
  let amp = sqrt(clamp(min(mn, vec3<f32>(1.0) - mx) / max(mx, vec3<f32>(1e-4)), vec3<f32>(0.0), vec3<f32>(1.0)));
  let w = -amp * mix(0.08, 0.2, P.b.z);
  var col = (c + (n0 + n1 + n2 + n3) * w) / (vec3<f32>(1.0) + 4.0 * w);
  let f = textureSampleLevel(fxT, smp, i.uv, 0.0);
  col *= 1.0 - f.r * P.b.x;
  col += P.d.rgb * f.g;
  col += textureSampleLevel(bloomT, smp, i.uv, 0.0).rgb * P.b.y;
  // grade: gentle highlight roll-off, filmic contrast, a little saturation,
  // cool shadows and warm highlights
  col = max(col, vec3<f32>(0.0));
  let g = P.d.w;
  col = col * (1.0 + 0.18 * g) / (vec3<f32>(1.0) + col * 0.18 * g);
  col = mix(col, col * col * (vec3<f32>(3.0) - 2.0 * clamp(col, vec3<f32>(0.0), vec3<f32>(1.0))), 0.22 * g);
  let lum = dot(col, vec3<f32>(0.2126, 0.7152, 0.0722));
  col = mix(vec3<f32>(lum), col, 1.0 + 0.12 * g);
  col += (vec3<f32>(-0.012, 0.0, 0.018) * (1.0 - lum) + vec3<f32>(0.022, 0.010, -0.016) * lum) * g;
  let vq = (i.uv - vec2<f32>(0.5)) * vec2<f32>(1.15, 1.0);
  col *= mix(1.0, smoothstep(0.98, 0.32, length(vq)), P.c.w);
  col += vec3<f32>((phash(i.pos.xy + vec2<f32>(P.b.w)) - 0.5) / 255.0);
  return vec4<f32>(col, 1.0);
}`;
