# ---------------------------------------------------------------- walking down
# Finn: "everytime i go downhills it just glitch jumps down it. You should only
# fall if the slope is like 80 degrees or steeper. Otherwise you walk down it."
# and "increase initial fall damage height like triple".
#
# The bug was in what counted as the ground falling away. It compared the drop
# under your feet against SPEED * tan(60) * dt -- your top speed, not the
# distance you actually covered -- with a floor of two world units. So a slow
# animal, or any animal in a long frame, cleared the bar on ordinary ground and
# was put in the air, and the hop you saw was gravity bringing it back down.
#
# The honest test is the slope you just walked: the ground dropped `drop` over
# the `dh` you actually moved. That is a fall only if drop/dh is steeper than
# tan 80. Everything shallower is a hill, and you walk down hills.
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, (a[:100], n); return s.replace(a, b)
p = 'g3.html'; s = open(p, encoding='utf-8').read()

s = sub1(s, "const PAGE_SLOPE_TAN = 1.7321;   // tan 60, the walking limit, page-side copy",
"""const PAGE_SLOPE_TAN = 1.7321;   // tan 60, the walking limit, page-side copy
// tan 80. Steeper than this under your feet and there is nothing to walk on;
// anything shallower is a hill, however fast it drops away.
const FALL_SLOPE_TAN = 5.6713;
// And a lip you can step off without it being a fall, as a fraction of your
// own standing height. Without it, terrain noise under a stationary animal
// reads as a cliff.
const FALL_STEP_FRAC = 0.35;""")
s = sub1(s, "const FALL_SAFE_H = 2.5;",
"""// Tripled on 2026-09-25: a fall had to be under two and a half body heights
// to be free, which on this terrain meant almost every hill hurt.
const FALL_SAFE_H = 7.5;""")

# ---- the player. Measure the slope actually walked, not the top speed.
s = sub1(s, """  if (player._gWas != null && player.grounded) {
    // A walk down a slope drops the ground under you too, and with a 60 degree
    // limit that is a lot per frame. Only count a drop that no walk could have
    // produced in the time available.
    const walkDrop = Math.max(2, (c.ph.speedLand || 40) * PAGE_SLOPE_TAN * dt * 1.6);
    const drop = player._gWas - gNow;
    if (isFinite(drop) && drop > walkDrop) { player.jumpY += drop; player.grounded = false; }
  }""",
"""  if (player._gWas != null && player.grounded) {
    // THE SLOPE YOU JUST WALKED, not the speed you could have walked it at.
    // The ground fell `drop` over the `dh` you actually covered: steeper than
    // 80 degrees and your feet had nothing under them, and anything shallower
    // is a hill, which you walk down. The old test used top speed and a two
    // unit floor, so ordinary ground threw you into the air and gravity
    // dropped you back onto it -- the hop Finn was seeing on every descent.
    const dh = player._gAt ? Math.hypot(c.x - player._gAt[0], c.y - player._gAt[1]) : 0;
    const drop = player._gWas - gNow;
    const walkable = dh * FALL_SLOPE_TAN + Math.max(1.5, (c.ph.standH || 6) * BODY_SCALE * FALL_STEP_FRAC);
    if (isFinite(drop) && drop > walkable) { player.jumpY += drop; player.grounded = false; }
  }""")
open(p, 'w', encoding='utf-8').write(s)
print('fall: you walk down hills now ok')

s = open(p, encoding='utf-8').read()
# ---- and the same rule for every other animal on the island
s = sub1(s, """      if (!p.canFly && !terrain.isWater(nx, ny)) {
        const HS2 = terrain.heightScale || 420;
        const fell = (terrain.height(c.x, c.y) - terrain.height(nx, ny)) * HS2;
        const safe = Math.max(6, (p.standH || p.radius || 6) * FALL_SAFE_H_SIM);
        if (fell > safe) {""",
"""      if (!p.canFly && !terrain.isWater(nx, ny)) {
        const HS2 = terrain.heightScale || 420;
        const fell = (terrain.height(c.x, c.y) - terrain.height(nx, ny)) * HS2;
        const safe = Math.max(6, (p.standH || p.radius || 6) * FALL_SAFE_H_SIM);
        // the same 80 degree rule the player gets: a step down a hill is a
        // step down a hill, whatever the height difference adds up to
        const stepH = Math.hypot(nx - c.x, ny - c.y);
        if (fell > Math.max(safe, stepH * FALL_SLOPE_TAN_SIM)) {""")
s = sub1(s, "const FALL_SAFE_H_SIM = 2.5, FALL_FATAL_H_SIM = 7;",
         "const FALL_SAFE_H_SIM = 7.5, FALL_FATAL_H_SIM = 7;\nconst FALL_SLOPE_TAN_SIM = 5.6713;   // tan 80")
open(p, 'w', encoding='utf-8').write(s)
print('fall: the animals walk down hills too ok')

s = open(p, encoding='utf-8').read()
# ---- the harness has to be able to ask both questions directly
s = sub1(s, "    resetFall: () => fallResetGround(),",
"""    resetFall: () => fallResetGround(),
    fallRule: () => ({ safeH: FALL_SAFE_H, fatalH: FALL_FATAL_H, slopeTan: FALL_SLOPE_TAN,
                       stepFrac: FALL_STEP_FRAC,
                       safe: player.c ? Math.round(fallSafeFor(player.c.ph)) : null,
                       grounded: !!player.grounded, jumpY: +(player.jumpY || 0).toFixed(2) }),
    fallDamage: (h2) => (player.c ? applyFallDamage(player.c, h2) : null),""")
open(p, 'w', encoding='utf-8').write(s)
print('fall: harness ok')
