# Sky dome with sun, moon and clouds; seasonal sun path; exposure, defaults.
def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
p='g3.html'; s=open(p,encoding='utf-8').read()
s=sub1(s,"""  const sunA = (world.bt || 0) * 0.4;
  gArr[20] = Math.cos(sunA) * 0.45; gArr[21] = 0.72 + 0.28 * lt; gArr[22] = Math.sin(sunA) * 0.45; gArr[23] = 0;""","""  r2SunMoon();""")
i=s.index("function renderFrame(t) {")
j=s.index("  pass.setPipeline(terrainPipe); pass.setBindGroup(0, bindG.terrain);", i)
s=s[:j]+"  if (R2on) r2DrawSky(pass, fog, aspect);\n"+s[j:]
s=sub1(s,"const FAR = 14000;","const FAR = 26000;")
# ultra reaches much further; the rest unchanged
s=sub1(s,"  ultra:  { res: 1.15, cover: 1250, plant: 11000, lod0: 1500, lod1: 6000, crit: 1.9, fog: 0.42, folMax: 200000,",
         "  ultra:  { res: 1.15, cover: 1700, plant: 18000, lod0: 2300, lod1: 9500, crit: 2.8, fog: 0.26, folMax: 200000,")
s=sub1(s,"  high:   { res: 0.90, cover: 900,  plant: 6500,  lod0: 1000, lod1: 3800, crit: 1.3, fog: 0.60,","  high:   { res: 0.90, cover: 1000, plant: 8000,  lod0: 1200, lod1: 4800, crit: 1.5, fog: 0.50,")
open(p,'w',encoding='utf-8').write(s)
print('sky ok')
s=open(p,encoding='utf-8').read()
# detached camera: your body is left to itself, ambling and grazing slowly
s=sub1(s,"""    c.x = px; c.y = py;
    movePlayer(c, dt);
  }""","""    if (player.spectator) { c.x = px + (c.x - px) * 0.35; c.y = py + (c.y - py) * 0.35; }
    else { c.x = px; c.y = py; movePlayer(c, dt); }
  }""")
open(p,'w',encoding='utf-8').write(s)
