# FOOD ECOLOGY
# patch_food.py made a plant a thing with a standing crop. This makes the rest
# of the world act like that is true.
#
#   grazing   a mouthful is taken, the plant lives. Plants are never deleted by
#             eating any more, so world.plants saturates at maxPlants and the
#             food supply is regrowth, not respawn. That is the whole point:
#             pressure now shows up as a thinned crop in place instead of as a
#             hole in the map that refills somewhere else.
#   movement  a patch grazed below a bar stops being perceived as food, so a
#             herd drifts off it. Starving animals drop the bar to near-bare,
#             because a behaviour rule must never become a new way to die with
#             food underfoot.
#   toxins    eating poison costs energy, resisted by gut mass and by a
#             carrion-tuned mouth (the same machinery that handles rot).
#   rot       a corpse has a freshness clock of its own. Fresh meat is the
#             generalist's prize, putrid meat is the scavenger's, and each is
#             a real loss to the wrong mouth -- a trade, not a free bonus.
#
# Nothing here loops over all plants per tick: crop is resolved on read, rot is
# resolved on read, and both are pure arithmetic on fields the object already
# carries.
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, (a[:90], n); return s.replace(a, b)

p = 'g3.html'; s = open(p, encoding='utf-8').read()

# ------------------------------------------------------- gut on the phenotype
# stat.gut already drives storage/digest/carrionDigest but was never exposed,
# so nothing outside develop() could ask "how much gut is this animal". Toxin
# resistance needs exactly that, and it is the honest place for it to come
# from: the organ that processes what you swallow.
s = sub1(s, """      carrionDigest: clamp(0.65 + stat.mouthScav * 0.55 + stat.gut * 0.12, 0.65, 1.8),""",
            """      carrionDigest: clamp(0.65 + stat.mouthScav * 0.55 + stat.gut * 0.12, 0.65, 1.8),
      gut: stat.gut,""")

# ------------------------------------------------------------ rot & toxin math
s = sub1(s, """  function plantReachOK(ph, pl, mul) {
    const high = pl.high || 0;
    if (high <= 0.05) return true;
    const rr = (ph.reach || 0) + (ph.radius || 0) * 0.5 + (ph.neck || 0) * 20;
    return rr * (mul || 1) >= high * 34;
  }""", """  function plantReachOK(ph, pl, mul) {
    const high = pl.high || 0;
    if (high <= 0.05) return true;
    const rr = (ph.reach || 0) + (ph.radius || 0) * 0.5 + (ph.neck || 0) * 20;
    return rr * (mul || 1) >= high * 34;
  }
  // How far gone a corpse is, 0 fresh .. 1 putrid. Read off the decay counter
  // the carcass already ticks down, so rot costs nothing and cannot drift out
  // of step with when the body disappears. Bodies made before this existed, or
  // by a caller that skipped life, fall back to the world's carrionLife rather
  // than dividing by zero.
  function carrionRot(world, cz) {
    if (!cz) return 1;
    let life = cz.life;
    if (!(life > 0)) {
      const P = world && world.params;
      life = (P && P.carrionLife > 0) ? P.carrionLife : 12;
    }
    const left = cz.decay != null ? cz.decay : life;
    const v = 1 - left / life;
    return v < 0 ? 0 : v > 1 ? 1 : v;
  }
  // 0..1: how scavenger-tuned a mouth is. Both halves matter -- the mouth mode
  // says what it is for, the carrion gut says whether it can actually hold the
  // meal down -- so a scav mouth bolted onto no gut is only half a scavenger.
  function scavTune(ph) {
    if (!ph) return 0;
    const cd = Math.max(0, (ph.carrionDigest || 0.65) - 0.65) / 1.15;
    const v = (ph.scavenger || 0) * 0.5 + cd * 0.5;
    return v < 0 ? 0 : v > 1 ? 1 : v;
  }
  // Energy a mouthful of poison costs. Resistance rides gut mass and the
  // carrion mouth, since clearing rot and clearing plant toxins are the same
  // problem. Capped well short of 1: nothing is ever immune, so a fungus field
  // stays a gamble rather than becoming free food for one lineage.
  function plantToxinCost(ph, tox) {
    if (!(tox > 0) || !ph) return 0;
    const cd = Math.max(0, (ph.carrionDigest || 0.65) - 0.65);
    let res = 0.25 + (ph.gut || 0) * 0.30 + (ph.scavenger || 0) * 0.35 + cd * 0.25;
    if (res > 0.95) res = 0.95;
    return tox * 18 * (1 - res);
  }
  // What a body is worth to this mouth right now, plus what it costs to keep
  // down. rotMul is 1.0 for a generalist on a fresh kill -- exactly the old
  // flat behaviour -- and falls to a quarter of that when the body is putrid;
  // a scavenger starts at 0.30 and climbs past 1.4, so on a fresh corpse the
  // generalist wins outright even after carrionDigest and on a rotten one the
  // scavenger wins by a mile. Both directions are a loss for the wrong animal,
  // which is what makes the niche worth specializing into.
  function carrionYield(world, cz, ph) {
    const e = (cz && cz.e > 0) ? cz.e : 0;
    if (e <= 0) return { gain: 0, ill: 0, rot: cz ? carrionRot(world, cz) : 1 };
    const rot = carrionRot(world, cz);
    const sv = scavTune(ph);
    const rotMul = Math.max(0.05, (1 - 0.70 * sv) + rot * (1.90 * sv - 0.75));
    const gain = e * (ph && ph.carrionDigest > 0 ? ph.carrionDigest : 0.9) * rotMul;
    // Illness only past the halfway mark, which is roughly where a body stops
    // being meat. Scaled on carcass size so a rotten whale is not a free meal
    // with a token cost attached.
    const ill = Math.max(0, rot - 0.5) * 2 * Math.max(0, 1 - sv * 1.8) * (10 + e * 0.10);
    return { gain, ill, rot };
  }""")

# --------------------------------------------------- perception: grazed-out
s = sub1(s, """        if (d2 >= senseSq || d2 >= bestFoodD) return;
        if (!reachable(pl.x, pl.y)) return;  // visible up a cliff is not food
        bestFoodD = d2; bestFood = pl; bestFoodCarrion = false;""",
            """        if (d2 >= senseSq || d2 >= bestFoodD) return;
        // A cropped patch stops advertising itself, so a herd that has grazed
        // a bush down walks off it instead of standing there taking crumbs.
        // A starving animal drops the bar to near-bare: this is a rule about
        // where herds go, and it must never become a way to starve on top of
        // food. Plants made before pl.c0 existed read as full, so old saves
        // and hand-built test worlds behave as they always did.
        if (plantCrop(world, pl) < (c.hunger > 0.6 ? 0.03 : 0.15)) return;
        if (!reachable(pl.x, pl.y)) return;  // visible up a cliff is not food
        bestFoodD = d2; bestFood = pl; bestFoodCarrion = false;""")

# ------------------------------------------------------------ forage consume
s = sub1(s, """          if (bestFoodCarrion) { if (!bestFood.dead) { bestFood.dead = true; c.energy = Math.min(p.storage, c.energy + bestFood.e * p.carrionDigest); } }
          else if (!eaten.has(bestFood)) { eaten.add(bestFood); c.energy = Math.min(p.storage, c.energy + bestFood.e * p.digest); }""",
            """          if (bestFoodCarrion) {
            if (!bestFood.dead) {
              bestFood.dead = true;
              const cy = carrionYield(world, bestFood, p);
              c.energy = Math.min(p.storage, c.energy + cy.gain);
              // Rot sickness is a poison effect, so it answers to the same
              // switch the rest of the toxin model does.
              if (flags.toxins && cy.ill > 0) {
                c.energy -= cy.ill;
                if (c.energy <= 0) c.deathCause = 'toxin';
              }
            }
          } else if (!eaten.has(bestFood)) {
            // One mouthful per plant per tick. The plant is NOT removed: a
            // herd crops it down over several ticks and it regrows in place,
            // which is the whole grazing loop. The set is per-tick only, so it
            // is a herd-rate limiter, not a claim on the plant.
            eaten.add(bestFood);
            const bite = plantBite(world, bestFood);
            if (bite > 0) c.energy = Math.min(p.storage, c.energy + bite * p.digest);
            const tox = bestFood.toxic || 0;
            if (flags.toxins && tox > 0 && bite > 0) {
              c.energy -= plantToxinCost(p, tox);
              // the death sweep below reads this back; it is set only on the
              // tick the animal actually dies, so it cannot go stale.
              if (c.energy <= 0) c.deathCause = 'toxin';
            }
          }""")

# ------------------------------------------------ death cause: poisoned, not starved
s = sub1(s, """        c.deathCause = c.age >= c.maxAge ? 'oldage' : c._drown === 1 ? 'drowned' : c._drown === 2 ? 'suffocated' : (inHazard ? 'toxin' : 'starvation');""",
            """        c.deathCause = c.age >= c.maxAge ? 'oldage' : c._drown === 1 ? 'drowned' : c._drown === 2 ? 'suffocated' : ((inHazard || c.deathCause === 'toxin') ? 'toxin' : 'starvation');""")

# --------------------------------------------------- plants survive being eaten
s = sub1(s, """    if (eaten.size) {
      for (const pl of eaten) { pl.gone = true; if (pl.deep) world.deepPlants--; }
      world.plants = world.plants.filter(pl => !pl.gone);
      world._pgDirty = true;
    }""",
            """    // Eating no longer removes anything. `eaten` was a kill list; it is now
    // only a per-tick one-bite-each limiter, built above and dropped here, so
    // there is nothing to sweep, the plant grid stays valid, and the deep
    // stock is untouched by grazing (the plant is still standing there).""")

# ---------------------------------------------------------------- core export
s = sub1(s, "    plantCrop, plantBite, plantReachOK, FOOD_KIND, FOOD_BY_BIOME,",
            "    plantCrop, plantBite, plantReachOK, FOOD_KIND, FOOD_BY_BIOME,\n    carrionRot, carrionYield, scavTune, plantToxinCost,")

open(p, 'w', encoding='utf-8').write(s)
print('food ecology ok')
