# =====================================================================
# DEV TOOLING: reach the palette's rendered thumbnails from the harness
#
# Everything in the editor lives inside the page's single IIFE, so `ED` is not
# reachable from page.evaluate(). The thumbnail contact sheet -- the only
# instrument that can tell us whether a body plan actually LOOKS different from
# the one next to it -- needs those data URLs out of the running page.
#
# Two accessors on the existing automation surface. They read, never write.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, ('ANCHOR %d/%d' % (n, cnt), a[:110]); return s.replace(a, b)

p = 'g3.html'; s = open(p, encoding='utf-8').read()

s = sub1(s, "    refresh: () => edRefreshUI(),\n  },",
"""    refresh: () => edRefreshUI(),
    // ---- thumbnail dump -------------------------------------------------
    // ED.thumbs is keyed 'plan<N>' for body plans and by part id otherwise.
    // Kept out of the game loop: these are only read by tools/thumbs.js.
    // The offered set, as the picker actually builds it. test_nomerge_steps had
    // that list PASTED INTO IT, which is how a guard quietly stops guarding:
    // the picker changes and the test carries on proving something about a set
    // nobody can pick any more.
    offeredPlans: () => PLAN_GROUPS.reduce((a, g) => a.concat(g.plans), []),
    thumbsReady: () => !!ED.thumbsReady,
    thumbKeys: () => Object.keys(ED.thumbs || {}),
    thumb: (k) => (ED.thumbs || {})[k] || null,
  },""")

open(p, 'w', encoding='utf-8').write(s)
print('tools: thumbnail dump reachable from the harness ok')
