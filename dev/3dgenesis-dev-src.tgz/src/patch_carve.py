# CARVING THE HEIGHTMAP
# The terrain is generated once and the render mesh is built from it, so
# anything that wants to change the shape of the ground has to do it in between.
# This exposes that seam: terrain.carveFlat() levels a disc, which is what a
# cage pad needs, and it is the same hook rivers will cut their channels with.
def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
p='g3.html'; s=open(p,encoding='utf-8').read()
s=sub1(s,"""    const terrain = {
      w, h, LV, island: isle, mountain: mt, lakes, islandMask,""",
"""    const terrain = {
      w, h, LV, island: isle, mountain: mt, lakes, islandMask,
      hg, HX, HY, CELL,
      // Level a disc of ground to one height, blending out over an apron so it
      // does not leave a step around the edge. Returns the height it settled
      // on. Anything built on the ground calls this BEFORE the render mesh is
      // made; after that the mesh is already baked and this does nothing
      // visible.
      carveFlat(x, y, radius, apron, targetY) {
        const R = Math.max(1, radius), A = Math.max(1, apron || R * 0.9);
        const ci = Math.round(x / CELL), cj = Math.round(y / CELL);
        const span = Math.ceil((R + A) / CELL) + 1;
        // the height to settle on: the median of the disc, so a pad sits in
        // the slope rather than on top of it or buried in it
        const samples = [];
        for (let j = -span; j <= span; j++) for (let i = -span; i <= span; i++) {
          const gi = ci + i, gj = cj + j;
          if (gi < 0 || gj < 0 || gi > HX - 1 || gj > HY - 1) continue;
          if (Math.hypot(i * CELL, j * CELL) > R) continue;
          samples.push(hg[gj * HX + gi]);
        }
        if (!samples.length) return null;
        samples.sort((a, b) => a - b);
        const tgt = targetY != null ? targetY : samples[samples.length >> 1];
        for (let j = -span; j <= span; j++) for (let i = -span; i <= span; i++) {
          const gi = ci + i, gj = cj + j;
          if (gi < 0 || gj < 0 || gi > HX - 1 || gj > HY - 1) continue;
          const d = Math.hypot(i * CELL, j * CELL);
          if (d > R + A) continue;
          const k = d <= R ? 1 : 1 - (d - R) / A;
          const kk = k * k * (3 - 2 * k);                 // smoothstep apron
          const o = gj * HX + gi;
          hg[o] = hg[o] + (tgt - hg[o]) * kk;
        }
        return tgt;
      },""")
open(p,'w',encoding='utf-8').write(s)
print('carve hook ok')
