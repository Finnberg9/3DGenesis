# The closing zone as real weather: a wall of cloud puffs standing on the ring,
# drawn with their own alpha-blended pipeline, plus the ring on the minimap so
# you can see it coming before it is on top of you. See src/brcloud.js.
def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
p='g3.html'; s=open(p,encoding='utf-8').read()

s=sub1(s,"function brRenderHud() {", open('src/brcloud.js',encoding='utf-8').read()+"\nfunction brRenderHud() {")
# build the pipeline alongside the others, and the bind group with them
s=sub1(s,"function makeBindGroups() {\n  const SE = r2ShadowEntries();","function makeBindGroups() {\n  const SE = r2ShadowEntries();\n  try { cloudInit(); } catch (e) { console.warn('cloud pipeline', e); }")
# feed it every frame and draw it last, over the world but under the water line
s=sub1(s,"""  pass.setPipeline(waterPipe); pass.setBindGroup(0, bindG.water);
  pass.setVertexBuffer(0, waterVB); pass.draw(6);
  pass.end();""","""  pass.setPipeline(waterPipe); pass.setBindGroup(0, bindG.water);
  pass.setVertexBuffer(0, waterVB); pass.draw(6);
  try { cloudDraw(pass); } catch (e) { console.warn('cloud draw', e); }
  pass.end();""")
s=sub1(s,"""  const nPlant = buildPlantInstances(player.camX, player.camZ, t);""",
         """  const nPlant = buildPlantInstances(player.camX, player.camZ, t);
  try { if (BR.on) cloudBuild(t); else cloudCount = 0; } catch (e) { console.warn('cloud build', e); }""")
# the global fog inside the wall: gentler, and tinted to match the cloud
s=sub1(s,"""      gArr[29] = gArr[29] + bf * bf * 0.055;
      const fogMix = clamp(bf * 1.1, 0, 1);
      gArr[24] = gArr[24] * (1 - fogMix) + 0.30 * fogMix;
      gArr[25] = gArr[25] * (1 - fogMix) + 0.34 * fogMix;
      gArr[26] = gArr[26] * (1 - fogMix) + 0.30 * fogMix;
      gArr[30] = gArr[30] * (1 - 0.5 * fogMix);""",
"""      // Inside the cloud you cannot see, and that is the whole danger of it.
      // Outside it you should see the WALL, not a grey pane over the world,
      // so this only bites once you are actually in the band.
      gArr[29] = gArr[29] + bf * bf * 0.075;
      const fogMix = clamp(bf * 1.25, 0, 1);
      gArr[24] = gArr[24] * (1 - fogMix) + 0.42 * fogMix;
      gArr[25] = gArr[25] * (1 - fogMix) + 0.45 * fogMix;
      gArr[26] = gArr[26] * (1 - fogMix) + 0.43 * fogMix;
      gArr[30] = gArr[30] * (1 - 0.45 * fogMix);""")
open(p,'w',encoding='utf-8').write(s)
print('cloud wired ok')
s=open(p,encoding='utf-8').read()

# ---- the ring on the minimap
s=sub1(s,"""  miniCtx.fillStyle = 'rgba(255,64,48,0.92)';""",
"""  // The cloud, so you can see it coming rather than discovering it.
  if (BR.on && BR.zone && BR.zone.r > 0) {
    const zx = BR.zone.cx * sx, zy = BR.zone.cz * sz, zr = BR.zone.r * sx;
    miniCtx.save();
    // everything outside the ring is under cloud
    miniCtx.beginPath();
    miniCtx.rect(0, 0, MW, MH);
    miniCtx.arc(zx, zy, Math.max(1, zr), 0, Math.PI * 2, true);
    miniCtx.fillStyle = 'rgba(150,158,150,0.50)';
    miniCtx.fill('evenodd');
    // the band that kills, and the edge itself
    miniCtx.beginPath(); miniCtx.arc(zx, zy, Math.max(1, zr), 0, Math.PI * 2);
    miniCtx.strokeStyle = 'rgba(226,232,224,0.95)'; miniCtx.lineWidth = 2 * k; miniCtx.stroke();
    // where it is heading, so the shrink is legible
    const rNext = brZoneRadiusAt(BR.t + 45) * sx;
    if (rNext < zr - 1) {
      miniCtx.beginPath(); miniCtx.arc(zx, zy, Math.max(1, rNext), 0, Math.PI * 2);
      miniCtx.strokeStyle = 'rgba(255,150,120,0.7)'; miniCtx.lineWidth = 1.2 * k;
      miniCtx.setLineDash([4 * k, 4 * k]); miniCtx.stroke(); miniCtx.setLineDash([]);
    }
    miniCtx.restore();
  }
  miniCtx.fillStyle = 'rgba(255,64,48,0.92)';""")
open(p,'w',encoding='utf-8').write(s)
s=sub1(s,"  rebuild: () => rebuildWorld(),","  rebuild: () => rebuildWorld(),\n  get cloudCount() { return cloudCount; },")
open(p,'w',encoding='utf-8').write(s)
print('minimap ring ok')
