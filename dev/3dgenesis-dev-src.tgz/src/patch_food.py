# FOOD FOUNDATION
# Until now a plant was a number: you walked into it, the whole thing vanished,
# and an identical one respawned somewhere else. That is not food, it is a
# pickup. This lays the data model every other food change reads.
#
#   pl.kind    'grass' | 'bush' | 'fungus' | 'tuber' | 'cactus' | 'kelp'
#              decided once, from the position hash and the biome, exactly the
#              way isTree is, so what you see, what you can eat and what it
#              does to you are one decision and cannot drift apart.
#   pl.toxic   0..1. Fungus mostly, a rare berry. Eating it makes you ill.
#   pl.bites   how many mouthfuls the full crop is. A berry bush is not one
#              swallow.
#   pl.high    0..1, how far off the ground the food sits. Needs body reach.
#   pl.c0/gt   the crop left at the last bite, and the world-clock time of it.
#              Crop is NOT stored live: it is computed from these two on read,
#              so regrowth costs nothing per tick no matter how many plants.
#   pl.regrow  crop per bt-unit, before the season multiplier.
#
# Calibration: with plants no longer deleted when eaten, the spawn loop
# saturates at maxPlants and regrowth becomes the whole food influx. Old
# influx was plantRate * areaScale * plantArea plants (of e each) per bt;
# new influx is maxPlants * regrow * e. maxPlants is CAPS.PLANTS * areaScale *
# plantArea, so regrow = plantRate / CAPS.PLANTS keeps the energy budget of
# the ecosystem where it was, independent of map size.
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, (a[:90], n); return s.replace(a, b)

p = 'g3.html'; s = open(p, encoding='utf-8').read()

# ---------------------------------------------------------------- plant kinds
s = sub1(s, """  function makePlant(world, x, y, biome) {""", """  // What grows where. Weights per biome; the first entry that the hash roll
  // falls into wins, so this is deterministic per position.
  const FOOD_BY_BIOME = {
    forest:  [['bush', 0.34], ['fungus', 0.22], ['tuber', 0.16], ['grass', 0.28]],
    plains:  [['grass', 0.58], ['tuber', 0.24], ['bush', 0.18]],
    savanna: [['grass', 0.62], ['bush', 0.24], ['tuber', 0.14]],
    taiga:   [['fungus', 0.30], ['bush', 0.26], ['grass', 0.44]],
    tundra:  [['grass', 0.52], ['fungus', 0.18], ['tuber', 0.30]],
    marsh:   [['kelp', 0.34], ['fungus', 0.26], ['grass', 0.40]],
    shallow: [['kelp', 0.82], ['grass', 0.18]],
    deep:    [['kelp', 1.0]],
    beach:   [['grass', 0.62], ['bush', 0.38]],
    desert:  [['cactus', 0.68], ['grass', 0.32]],
    scree:   [['grass', 0.58], ['fungus', 0.42]],
    rock:    [['grass', 0.54], ['fungus', 0.46]],
    snow:    [['grass', 0.70], ['fungus', 0.30]],
  };
  // bites, how high the food sits, and how fast the crop comes back. A berry
  // bush is several mouthfuls held up off the ground and slow to refill; grass
  // is one quick crop at your feet that grows back fast.
  const FOOD_KIND = {
    grass:  { bites: 2, high: 0.02, regrow: 2.2, toxOdds: 0 },
    bush:   { bites: 4, high: 0.55, regrow: 1.0, toxOdds: 6 },
    fungus: { bites: 3, high: 0.06, regrow: 1.6, toxOdds: 46 },
    tuber:  { bites: 3, high: 0.00, regrow: 1.4, toxOdds: 0 },
    cactus: { bites: 3, high: 0.42, regrow: 0.7, toxOdds: 0 },
    kelp:   { bites: 3, high: 0.30, regrow: 1.2, toxOdds: 0 },
  };
  // The crop standing on a plant right now, 0..1. Regrowth is resolved on
  // read from the time of the last bite, so no per-tick loop over plants
  // exists and a map with 2400 of them costs the same as one with 20.
  function plantCrop(world, pl) {
    if (!pl || pl.gone) return 0;
    if (pl.c0 == null) return 1;
    if (pl.c0 >= 1) return 1;
    const season = (world.flags && world.flags.seasons === false) ? 1 : (world.season != null ? world.season : 1);
    const mul = 0.30 + 1.4 * season;            // winter growth is slow, not stopped
    const el = Math.max(0, (world.bt || 0) - (pl.gt || 0));
    const v = pl.c0 + el * (pl.regrow || 0) * mul;
    return v < 0 ? 0 : v > 1 ? 1 : v;
  }
  // Take one mouthful. Returns the energy in it (0 if the plant is bare).
  // Bites are a fraction of the whole crop, so a full plant is worth exactly
  // what it always was -- just not in one swallow.
  function plantBite(world, pl) {
    const crop = plantCrop(world, pl);
    if (crop <= 0.02) { pl.c0 = crop; pl.gt = world.bt || 0; return 0; }
    const frac = Math.min(crop, 1 / Math.max(1, pl.bites || 1));
    pl.c0 = crop - frac;
    pl.gt = world.bt || 0;
    if (pl.deep && pl.c0 <= 0.02) { /* deep stock stays counted: the plant lives */ }
    return (pl.e || 0) * frac;
  }
  // Can this body get at it? Food held up in a bush or a cactus needs height
  // or reach; anything on the ground does not. rear/flight multipliers are
  // applied by the caller (the player rears with G).
  function plantReachOK(ph, pl, mul) {
    const high = pl.high || 0;
    if (high <= 0.05) return true;
    const rr = (ph.reach || 0) + (ph.radius || 0) * 0.5 + (ph.neck || 0) * 20;
    return rr * (mul || 1) >= high * 34;
  }

  function makePlant(world, x, y, biome) {""")

# assign the fields
s = sub1(s, """      trunkR: isTree ? (2.2 + j * 2.0) * clamp(eScale, 0.7, 1.6) : 0,
    };
  }""", """      trunkR: isTree ? (2.2 + j * 2.0) * clamp(eScale, 0.7, 1.6) : 0,
      kind, toxic, bites: K.bites, high: K.high,
      // full when it grows, and regrowing from the moment anything bites it
      c0: 1, gt: world.bt || 0,
      // PLAY_MUL: strict energy parity (PLAY_MUL 1) makes a grazed plant take
      // about twenty minutes of wall time to come back, which reads to a
      // player as "the food is gone for good" rather than as grazing. 3x puts
      // recovery inside a play session at the cost of a richer island, and is
      // the balance knob to turn if the ecosystem runs hot.
      regrow: (world.params.plantRate || 20) / CAPS.PLANTS * K.regrow * 3,
    };
  }""")
s = sub1(s, """    const eScale = clamp(e / Math.max(1, world.params.plantEnergy), 0.6, 3.2);
    return {
      x, y, deep,""", """    const eScale = clamp(e / Math.max(1, world.params.plantEnergy), 0.6, 3.2);
    // kind, and whether this one is poisonous, from the same position hash the
    // tree roll came out of -- different bits, so they do not correlate.
    // hs's top bits are not random at world coordinates (x*7919 ^ y*104729 is
    // about 1e8 for any point on the map, so bits 27+ never move). Mix it
    // properly before taking new fields out of it, or every fungus on the
    // island comes out poisonous.
    let hm = Math.imul(hs ^ 0x9e3779b9, 2246822519) >>> 0; hm = (hm ^ (hm >>> 15)) >>> 0;
    hm = Math.imul(hm, 3266489917) >>> 0; hm = (hm ^ (hm >>> 16)) >>> 0;
    const opts = FOOD_BY_BIOME[biome] || FOOD_BY_BIOME.plains;
    let r = (hm % 1000) / 1000, kind = opts[opts.length - 1][0];
    for (const [k, wgt] of opts) { if (r < wgt) { kind = k; break; } r -= wgt; }
    const K = FOOD_KIND[kind] || FOOD_KIND.grass;
    const toxic = ((((hm >>> 10) % 100)) < K.toxOdds) ? (0.45 + ((hm >>> 17) % 100) / 180) : 0;
    return {
      x, y, deep,""")

# ---------------------------------------------------------------- core export
s = sub1(s, "    makeWorld, makeCreature, makeTerrain,",
            "    plantCrop, plantBite, plantReachOK, FOOD_KIND, FOOD_BY_BIOME,\n    makeWorld, makeCreature, makeTerrain,")
open(p, 'w', encoding='utf-8').write(s)
print('food foundation ok')
