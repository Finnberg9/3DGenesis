# Main menu: Continue / New game / Load creature / Controls / Options / About,
# with a torn brush mark on the highlighted line. See src/menu.js.
def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
p='g3.html'; s=open(p,encoding='utf-8').read()
s=sub1(s,"function stepSim(dt) {\n", open('src/menu.js',encoding='utf-8').read()+"\nfunction stepSim(dt) {\n")
# ---- markup: keep the animated jungle, replace the wall of text with a menu
i=s.index('<div id="start"><canvas id="startbg"></canvas><div class="flow">')
j=s.index('<div id="err">')
old=s[i:j]
k0=old.index('<div class="keysg">'); k1=old.index('</div>\n  <p class="fl moves">')
keys=old[k0:k1+6]
moves=old[old.index('<p class="fl moves">'):old.index('</p>\n  <div class="go fl">')+4]
html='''<div id="start"><canvas id="startbg"></canvas>
  <div class="mm">
    <div class="mmhead">
    <svg id="mmLogo" viewBox="0 0 1200 250" role="img" aria-label="Genesis">
      <defs>
        <!-- rough cast concrete: fractal noise lit from the upper left, with grit over it -->
        <filter id="mmRock" x="-6%" y="-14%" width="112%" height="128%">
          <feTurbulence type="fractalNoise" baseFrequency="0.055 0.075" numOctaves="5" seed="17" result="n"/>
          <feDiffuseLighting in="n" lighting-color="#cdc7b8" surfaceScale="2.6" diffuseConstant="1.05" result="lit">
            <feDistantLight azimuth="228" elevation="46"/>
          </feDiffuseLighting>
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed="4" result="grit"/>
          <feColorMatrix in="grit" type="matrix" values="0 0 0 0 .62 0 0 0 0 .61 0 0 0 0 .58 0 0 0 .55 0" result="gritA"/>
          <feBlend in="lit" in2="gritA" mode="multiply" result="rough"/>
          <feTurbulence type="turbulence" baseFrequency="0.012" numOctaves="3" seed="21" result="warp"/>
          <feDisplacementMap in="rough" in2="warp" scale="5" xChannelSelector="R" yChannelSelector="G" result="face"/>
          <feComposite in="face" in2="SourceAlpha" operator="in"/>
        </filter>
        <!-- three claw gouges raked across the face -->
        <mask id="mmClaw">
          <rect x="-60" y="-60" width="1340" height="380" fill="#fff"/>
          <g fill="#000">
            <path d="M 144 -146 L 165 -136 L 186 -127 L 207 -119 L 229 -110 L 250 -102 L 272 -94 L 294 -86 L 316 -77 L 338 -69 L 360 -61 L 383 -54 L 405 -45 L 428 -38 L 451 -29 L 474 -21 L 497 -15 L 520 -6 L 543 2 L 566 11 L 590 18 L 614 25 L 638 34 L 662 41 L 686 50 L 710 57 L 735 65 L 758 74 L 783 81 L 808 89 L 832 99 L 857 107 L 883 115 L 908 124 L 933 132 L 959 141 L 984 150 L 1010 160 L 1036 168 L 1062 178 L 1088 187 L 1114 196 L 1141 205 L 1167 215 L 1194 224 L 1194 224 L 1168 213 L 1142 203 L 1115 192 L 1090 182 L 1064 172 L 1038 163 L 1012 153 L 986 145 L 961 135 L 935 126 L 910 116 L 885 109 L 860 99 L 835 90 L 810 83 L 785 75 L 761 65 L 736 59 L 712 51 L 688 41 L 664 34 L 640 25 L 616 19 L 593 9 L 570 1 L 546 -5 L 522 -13 L 499 -20 L 476 -29 L 453 -37 L 430 -44 L 408 -52 L 385 -59 L 363 -68 L 340 -76 L 318 -84 L 296 -91 L 274 -98 L 252 -107 L 230 -115 L 209 -123 L 187 -131 L 166 -139 L 144 -146 Z"/>
            <path d="M 120 -70 L 141 -60 L 162 -51 L 183 -43 L 205 -35 L 226 -25 L 248 -17 L 270 -8 L 292 -1 L 314 8 L 336 15 L 358 24 L 381 32 L 404 40 L 426 48 L 449 56 L 473 63 L 496 71 L 519 80 L 542 86 L 566 96 L 589 103 L 613 112 L 637 118 L 662 126 L 685 135 L 709 144 L 734 151 L 759 158 L 784 166 L 808 176 L 833 183 L 858 193 L 883 201 L 909 209 L 934 218 L 960 227 L 985 237 L 1011 245 L 1037 254 L 1064 263 L 1090 273 L 1116 282 L 1143 292 L 1170 300 L 1170 300 L 1144 288 L 1118 278 L 1092 267 L 1066 257 L 1040 248 L 1014 238 L 988 228 L 962 220 L 937 210 L 912 202 L 887 192 L 862 182 L 836 175 L 812 166 L 786 158 L 762 150 L 737 141 L 713 132 L 689 124 L 664 118 L 640 109 L 617 100 L 593 92 L 569 84 L 545 78 L 522 68 L 499 61 L 475 54 L 453 45 L 430 38 L 407 31 L 384 22 L 362 14 L 339 8 L 317 -1 L 294 -8 L 272 -16 L 250 -24 L 228 -32 L 206 -39 L 185 -47 L 163 -55 L 142 -63 L 120 -70 Z"/>
            <path d="M 94 4 L 115 13 L 136 22 L 157 30 L 179 39 L 201 47 L 222 55 L 244 64 L 266 72 L 288 80 L 311 88 L 333 96 L 356 104 L 378 113 L 401 120 L 424 128 L 447 136 L 470 145 L 493 152 L 517 159 L 540 168 L 564 174 L 588 184 L 612 191 L 636 198 L 660 206 L 684 215 L 709 224 L 733 231 L 758 240 L 783 248 L 808 256 L 833 265 L 858 273 L 884 281 L 909 290 L 934 300 L 960 309 L 986 318 L 1012 327 L 1038 336 L 1064 345 L 1091 355 L 1117 365 L 1144 374 L 1144 374 L 1118 363 L 1092 352 L 1065 343 L 1039 333 L 1013 323 L 987 313 L 962 304 L 936 294 L 911 286 L 885 277 L 860 268 L 835 259 L 810 250 L 785 241 L 760 233 L 735 225 L 711 216 L 686 209 L 662 201 L 638 193 L 614 184 L 590 175 L 566 169 L 543 160 L 519 153 L 496 145 L 473 136 L 449 129 L 426 122 L 403 114 L 380 105 L 358 98 L 335 91 L 312 83 L 290 75 L 268 68 L 246 59 L 224 52 L 202 44 L 180 36 L 158 28 L 137 19 L 115 12 L 94 4 Z"/>
          </g>
        </mask>
        <clipPath id="mmClip"><use href="#mmT"/></clipPath>
        <text id="mmT" x="8" y="186" textLength="1184" lengthAdjust="spacingAndGlyphs"
              font-family="'IBM Plex Mono', ui-monospace, monospace" font-weight="700" font-size="200"
              letter-spacing="8">GENESIS</text>
      </defs>
      <!-- dark stone inside the gouges, showing through the cuts -->
      <use href="#mmT" fill="#0b0d0d"/>
      <g mask="url(#mmClaw)">
      <use href="#mmT" x="10.5" y="13.3" fill="#060606"/>
      <use href="#mmT" x="9.0" y="11.4" fill="#060606"/>
      <use href="#mmT" x="7.5" y="9.5" fill="#0a0806"/>
      <use href="#mmT" x="6.0" y="7.6" fill="#100e0b"/>
      <use href="#mmT" x="4.5" y="5.7" fill="#161411"/>
      <use href="#mmT" x="3.0" y="3.8" fill="#1c1a17"/>
      <use href="#mmT" x="1.5" y="1.9" fill="#22201d"/>
        <use href="#mmT" filter="url(#mmRock)"/>
        <use href="#mmT" fill="none" stroke="#efe9da" stroke-width="1.5" opacity=".2" x="-1" y="-1.4"/>
        <use href="#mmT" fill="none" stroke="#000" stroke-width="2" opacity=".45" x="1.4" y="1.9"/>
      </g>
      <!-- torn stone along the cuts -->
      <g clip-path="url(#mmClip)">
        <path d="M 144 -146 L 165 -136 L 186 -127 L 207 -119 L 229 -110 L 250 -102 L 272 -94 L 294 -86 L 316 -77 L 338 -69 L 360 -61 L 383 -54 L 405 -45 L 428 -38 L 451 -29 L 474 -21 L 497 -15 L 520 -6 L 543 2 L 566 11 L 590 18 L 614 25 L 638 34 L 662 41 L 686 50 L 710 57 L 735 65 L 758 74 L 783 81 L 808 89 L 832 99 L 857 107 L 883 115 L 908 124 L 933 132 L 959 141 L 984 150 L 1010 160 L 1036 168 L 1062 178 L 1088 187 L 1114 196 L 1141 205 L 1167 215 L 1194 224 L 1194 224 L 1168 213 L 1142 203 L 1115 192 L 1090 182 L 1064 172 L 1038 163 L 1012 153 L 986 145 L 961 135 L 935 126 L 910 116 L 885 109 L 860 99 L 835 90 L 810 83 L 785 75 L 761 65 L 736 59 L 712 51 L 688 41 L 664 34 L 640 25 L 616 19 L 593 9 L 570 1 L 546 -5 L 522 -13 L 499 -20 L 476 -29 L 453 -37 L 430 -44 L 408 -52 L 385 -59 L 363 -68 L 340 -76 L 318 -84 L 296 -91 L 274 -98 L 252 -107 L 230 -115 L 209 -123 L 187 -131 L 166 -139 L 144 -146 Z" fill="none" stroke="#d6d0c0" stroke-width="1.1" opacity=".45" transform="translate(-1.1,-1.5)"/>
        <path d="M 120 -70 L 141 -60 L 162 -51 L 183 -43 L 205 -35 L 226 -25 L 248 -17 L 270 -8 L 292 -1 L 314 8 L 336 15 L 358 24 L 381 32 L 404 40 L 426 48 L 449 56 L 473 63 L 496 71 L 519 80 L 542 86 L 566 96 L 589 103 L 613 112 L 637 118 L 662 126 L 685 135 L 709 144 L 734 151 L 759 158 L 784 166 L 808 176 L 833 183 L 858 193 L 883 201 L 909 209 L 934 218 L 960 227 L 985 237 L 1011 245 L 1037 254 L 1064 263 L 1090 273 L 1116 282 L 1143 292 L 1170 300 L 1170 300 L 1144 288 L 1118 278 L 1092 267 L 1066 257 L 1040 248 L 1014 238 L 988 228 L 962 220 L 937 210 L 912 202 L 887 192 L 862 182 L 836 175 L 812 166 L 786 158 L 762 150 L 737 141 L 713 132 L 689 124 L 664 118 L 640 109 L 617 100 L 593 92 L 569 84 L 545 78 L 522 68 L 499 61 L 475 54 L 453 45 L 430 38 L 407 31 L 384 22 L 362 14 L 339 8 L 317 -1 L 294 -8 L 272 -16 L 250 -24 L 228 -32 L 206 -39 L 185 -47 L 163 -55 L 142 -63 L 120 -70 Z" fill="none" stroke="#d6d0c0" stroke-width="1.3" opacity=".5" transform="translate(-1.3,-1.7)"/>
        <path d="M 94 4 L 115 13 L 136 22 L 157 30 L 179 39 L 201 47 L 222 55 L 244 64 L 266 72 L 288 80 L 311 88 L 333 96 L 356 104 L 378 113 L 401 120 L 424 128 L 447 136 L 470 145 L 493 152 L 517 159 L 540 168 L 564 174 L 588 184 L 612 191 L 636 198 L 660 206 L 684 215 L 709 224 L 733 231 L 758 240 L 783 248 L 808 256 L 833 265 L 858 273 L 884 281 L 909 290 L 934 300 L 960 309 L 986 318 L 1012 327 L 1038 336 L 1064 345 L 1091 355 L 1117 365 L 1144 374 L 1144 374 L 1118 363 L 1092 352 L 1065 343 L 1039 333 L 1013 323 L 987 313 L 962 304 L 936 294 L 911 286 L 885 277 L 860 268 L 835 259 L 810 250 L 785 241 L 760 233 L 735 225 L 711 216 L 686 209 L 662 201 L 638 193 L 614 184 L 590 175 L 566 169 L 543 160 L 519 153 L 496 145 L 473 136 L 449 129 L 426 122 L 403 114 L 380 105 L 358 98 L 335 91 L 312 83 L 290 75 L 268 68 L 246 59 L 224 52 L 202 44 L 180 36 L 158 28 L 137 19 L 115 12 L 94 4 Z" fill="none" stroke="#d6d0c0" stroke-width="1" opacity=".45" transform="translate(-1.1,-1.5)"/>
        <path d="M 120 -70 L 141 -60 L 162 -51 L 183 -43 L 205 -35 L 226 -25 L 248 -17 L 270 -8 L 292 -1 L 314 8 L 336 15 L 358 24 L 381 32 L 404 40 L 426 48 L 449 56 L 473 63 L 496 71 L 519 80 L 542 86 L 566 96 L 589 103 L 613 112 L 637 118 L 662 126 L 685 135 L 709 144 L 734 151 L 759 158 L 784 166 L 808 176 L 833 183 L 858 193 L 883 201 L 909 209 L 934 218 L 960 227 L 985 237 L 1011 245 L 1037 254 L 1064 263 L 1090 273 L 1116 282 L 1143 292 L 1170 300 L 1170 300 L 1144 288 L 1118 278 L 1092 267 L 1066 257 L 1040 248 L 1014 238 L 988 228 L 962 220 L 937 210 L 912 202 L 887 192 L 862 182 L 836 175 L 812 166 L 786 158 L 762 150 L 737 141 L 713 132 L 689 124 L 664 118 L 640 109 L 617 100 L 593 92 L 569 84 L 545 78 L 522 68 L 499 61 L 475 54 L 453 45 L 430 38 L 407 31 L 384 22 L 362 14 L 339 8 L 317 -1 L 294 -8 L 272 -16 L 250 -24 L 228 -32 L 206 -39 L 185 -47 L 163 -55 L 142 -63 L 120 -70 Z" fill="none" stroke="#b3140c" stroke-width=".9" opacity=".3" transform="translate(1.8,2.2)"/>
      </g>
    </svg>
    <h1 id="mmBig">NEW GAME</h1></div>
    <nav id="mmNav"></nav>
    <audio id="mmMusic" src="menu.mp3" loop preload="auto"></audio>
  </div>
  <div id="mmFoot"><div id="mmDesc"></div><div class="mmhint">move <b>&#8593;</b> <b>&#8595;</b> &nbsp; choose <b>Enter</b> &nbsp; back <b>Esc</b></div></div>
  <div id="mmPage"></div>
  <div id="mmKeysSrc" style="display:none">'''+keys+moves+'''</div>
</div>

'''
s=s[:i]+html+s[j:]
# ---- style
i=s.index('  #start{position:fixed;inset:0;display:flex;justify-content:center;align-items:flex-start;overflow-y:auto;')
j=s.index('  #resetbtn{position:fixed;')
css='''  #start{position:fixed;inset:0;background:#05080a;z-index:20;cursor:default;overflow:hidden}
  #startbg{position:fixed;inset:0;width:100vw;height:100vh;display:block}
  #start .mm{position:absolute;left:clamp(24px,5vw,96px);top:9vh;max-width:min(880px,70vw)}
  #mmLogo{display:block;width:min(860px,68vw);height:auto;margin:0 0 6px -10px;
    filter:drop-shadow(0 10px 30px rgba(0,0,0,.75)) drop-shadow(0 2px 0 rgba(0,0,0,.6))}
  #start .mmhead h1{margin:0 0 30px;font-size:clamp(20px,2.4vw,30px);letter-spacing:.34em;color:#cfe0d8;font-weight:600;
    text-shadow:0 4px 26px #000;transition:opacity .18s}
  #mmNav{display:flex;flex-direction:column;gap:2px;align-items:flex-start}
  .mmItem{position:relative;font:inherit;font-size:clamp(15px,1.5vw,19px);letter-spacing:.2em;color:#9db3ab;background:none;border:0;
    padding:9px 18px 9px 40px;cursor:pointer;transition:transform .16s cubic-bezier(.2,.8,.2,1),color .16s}
  .mmItem .mmLabel{position:relative;z-index:2}
  .mmItem .mmBrush{position:absolute;left:8px;top:50%;translate:0 -50%;width:calc(100% - 8px);height:26px;background:#b3140c;
    clip-path:polygon(0 38%,6% 12%,16% 44%,27% 8%,38% 40%,52% 14%,66% 46%,78% 16%,90% 42%,100% 20%,97% 78%,86% 96%,72% 66%,58% 92%,44% 62%,30% 94%,18% 64%,8% 90%,2% 70%);
    transform:scaleX(0);transform-origin:left center;transition:transform .22s cubic-bezier(.2,.8,.2,1);opacity:.9}
  .mmItem:hover,.mmItem.on{color:#fff;transform:translateX(10px)}
  .mmItem.on .mmBrush{transform:scaleX(1)}
  .mmItem:hover .mmBrush{transform:scaleX(1)}
  @media (prefers-reduced-motion:reduce){.mmItem,.mmItem .mmBrush{transition:none}}
  #mmFoot{position:absolute;right:clamp(20px,4vw,70px);bottom:8vh;max-width:420px;text-align:right;color:#a9c0b8}
  #mmDesc{font-size:14px;line-height:1.6;border-right:2px solid #b3140c;padding-right:14px;min-height:44px}
  #mmFoot .mmhint{margin-top:14px;font-size:11px;letter-spacing:.18em;color:#6d8781}
  #mmFoot .mmhint b{color:#cfe3dc;background:rgba(255,255,255,.07);border:1px solid #2c4b45;border-radius:4px;padding:1px 6px}
  #mmPage{position:absolute;inset:0;display:none;overflow-y:auto;padding:7vh clamp(28px,7vw,140px);
    background:linear-gradient(90deg,rgba(3,8,8,.97),rgba(3,8,8,.82));color:#cfe3dc;z-index:3}
  #mmPage.show{display:block}
  #mmPage h2{margin:0 0 20px;font-size:26px;letter-spacing:.34em;color:#eef6f2}
  #mmPage p{max-width:720px;line-height:1.7;font-size:14px}
  #mmPage .keysg{display:grid;grid-template-columns:repeat(auto-fit,minmax(340px,1fr));gap:10px 34px;text-align:left;max-width:1100px}
  #mmPage .grp h3{margin:14px 0 6px;font-size:11px;letter-spacing:.2em;text-transform:uppercase;color:#6fb8a6}
  #mmPage .kr{display:flex;gap:12px;align-items:baseline;font-size:13.5px;line-height:1.55;margin:3px 0}
  #mmPage .kk{flex:0 0 150px;text-align:right;white-space:nowrap}
  #mmPage kbd{font-family:inherit;font-size:12px;color:#e4f4ef;background:rgba(10,30,26,.55);border:1px solid rgba(90,160,140,.35);border-radius:4px;padding:1px 6px}
  #mmPage .moves{margin-top:18px;color:#9dbdb5;font-size:13.5px}
  .mmopt{max-width:720px}
  .mmrow{display:flex;justify-content:space-between;align-items:center;gap:20px;padding:11px 0;border-bottom:1px solid #16302b;font-size:14px}
  .mmnote{color:#6d8781;font-size:12px}
  .mmb{font:inherit;font-size:13px;color:#dff3ec;background:#0a201d;border:1px solid #2c4b45;border-radius:6px;padding:5px 11px;margin-left:6px;cursor:pointer}
  .mmb:hover{border-color:#b3140c;color:#fff}
  .mmb.wide{display:block;width:100%;text-align:left;margin:6px 0}
  .mmb.back{margin-top:26px}
  .mmsaved{max-width:520px}
'''
s=s[:i]+css+s[j:]
# ---- wiring: the menu replaces the click-anywhere start
s=sub1(s,"""    startEl.style.display = 'none';
    openEditor('start');
  });""","""  });
  menuBind();
  { const m = document.getElementById('mmMusic'); if (m) {
    m.volume = 0.45;
    m.loop = true;
    m.autoplay = true;
    // Autoplay is blocked without a gesture in every current browser, so try
    // straight away, again on load, and once more on the first input event.
    const startMenuMusic = () => {
      if (started) return;
      m.play().catch(() => {});
    };
    const startOnGesture = () => {
      removeEventListener('pointerdown', startOnGesture);
      removeEventListener('keydown', startOnGesture);
      startMenuMusic();
    };
    startMenuMusic();
    addEventListener('load', startMenuMusic, { once: true });
    addEventListener('pointerdown', startOnGesture);
    addEventListener('keydown', startOnGesture);
  } }""")
open(p,'w',encoding='utf-8').write(s)
print('menu ok')
