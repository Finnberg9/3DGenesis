# Main menu: Continue / New game / Load creature / Controls / Options / About,
# with a torn brush mark on the highlighted line. See src/menu.js.
def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
p='g3.html'; s=open(p,encoding='utf-8').read()
s=sub1(s,"function stepSim(dt) {\n", open('src/menu.js',encoding='utf-8').read()+"\nfunction stepSim(dt) {\n")
# ---- markup: keep the animated jungle, replace the wall of text with a menu
i=s.index('<div id="start"><canvas id="startbg"></canvas><div class="flow">')
j=s.index('<div id="err">')
old=s[i:j]
k0=old.index('<div class="keysg">'); k1=old.index('</div>\n  <p class="fl moves">')
keys=old[k0:k1+6]
moves=old[old.index('<p class="fl moves">'):old.index('</p>\n  <div class="go fl">')+4]
html='''<div id="start"><canvas id="startbg"></canvas>
  <div class="mm">
    <div class="mmhead"><span class="mmkicker">GENESIS</span><h1 id="mmBig">NEW GAME</h1></div>
    <nav id="mmNav"></nav>
  </div>
  <div id="mmFoot"><div id="mmDesc"></div><div class="mmhint">move <b>&#8593;</b> <b>&#8595;</b> &nbsp; choose <b>Enter</b> &nbsp; back <b>Esc</b></div></div>
  <div id="mmPage"></div>
  <div id="mmKeysSrc" style="display:none">'''+keys+moves+'''</div>
</div>

'''
s=s[:i]+html+s[j:]
# ---- style
i=s.index('  #start{position:fixed;inset:0;display:flex;justify-content:center;align-items:flex-start;overflow-y:auto;')
j=s.index('  #resetbtn{position:fixed;')
css='''  #start{position:fixed;inset:0;background:#05080a;z-index:20;cursor:default;overflow:hidden}
  #startbg{position:fixed;inset:0;width:100vw;height:100vh;display:block}
  #start .mm{position:absolute;left:clamp(28px,6vw,110px);top:14vh;max-width:640px}
  #start .mmkicker{display:block;font-size:12px;letter-spacing:.55em;color:#b3140c;margin-bottom:2px}
  #start .mmhead h1{margin:0 0 34px;font-size:clamp(34px,5.6vw,64px);letter-spacing:.1em;color:#eef6f2;font-weight:700;
    text-shadow:0 4px 26px #000;transition:opacity .18s}
  #mmNav{display:flex;flex-direction:column;gap:2px;align-items:flex-start}
  .mmItem{position:relative;font:inherit;font-size:clamp(15px,1.5vw,19px);letter-spacing:.2em;color:#9db3ab;background:none;border:0;
    padding:9px 18px 9px 40px;cursor:pointer;transition:transform .16s cubic-bezier(.2,.8,.2,1),color .16s}
  .mmItem .mmLabel{position:relative;z-index:2}
  .mmItem .mmBrush{position:absolute;left:8px;top:50%;translate:0 -50%;width:calc(100% - 8px);height:26px;background:#b3140c;
    clip-path:polygon(0 38%,6% 12%,16% 44%,27% 8%,38% 40%,52% 14%,66% 46%,78% 16%,90% 42%,100% 20%,97% 78%,86% 96%,72% 66%,58% 92%,44% 62%,30% 94%,18% 64%,8% 90%,2% 70%);
    transform:scaleX(0);transform-origin:left center;transition:transform .22s cubic-bezier(.2,.8,.2,1);opacity:.9}
  .mmItem:hover,.mmItem.on{color:#fff;transform:translateX(10px)}
  .mmItem.on .mmBrush{transform:scaleX(1)}
  .mmItem:hover .mmBrush{transform:scaleX(1)}
  @media (prefers-reduced-motion:reduce){.mmItem,.mmItem .mmBrush{transition:none}}
  #mmFoot{position:absolute;right:clamp(20px,4vw,70px);bottom:8vh;max-width:420px;text-align:right;color:#a9c0b8}
  #mmDesc{font-size:14px;line-height:1.6;border-right:2px solid #b3140c;padding-right:14px;min-height:44px}
  #mmFoot .mmhint{margin-top:14px;font-size:11px;letter-spacing:.18em;color:#6d8781}
  #mmFoot .mmhint b{color:#cfe3dc;background:rgba(255,255,255,.07);border:1px solid #2c4b45;border-radius:4px;padding:1px 6px}
  #mmPage{position:absolute;inset:0;display:none;overflow-y:auto;padding:7vh clamp(28px,7vw,140px);
    background:linear-gradient(90deg,rgba(3,8,8,.97),rgba(3,8,8,.82));color:#cfe3dc;z-index:3}
  #mmPage.show{display:block}
  #mmPage h2{margin:0 0 20px;font-size:26px;letter-spacing:.34em;color:#eef6f2}
  #mmPage p{max-width:720px;line-height:1.7;font-size:14px}
  #mmPage .keysg{display:grid;grid-template-columns:repeat(auto-fit,minmax(340px,1fr));gap:10px 34px;text-align:left;max-width:1100px}
  #mmPage .grp h3{margin:14px 0 6px;font-size:11px;letter-spacing:.2em;text-transform:uppercase;color:#6fb8a6}
  #mmPage .kr{display:flex;gap:12px;align-items:baseline;font-size:13.5px;line-height:1.55;margin:3px 0}
  #mmPage .kk{flex:0 0 150px;text-align:right;white-space:nowrap}
  #mmPage kbd{font-family:inherit;font-size:12px;color:#e4f4ef;background:rgba(10,30,26,.55);border:1px solid rgba(90,160,140,.35);border-radius:4px;padding:1px 6px}
  #mmPage .moves{margin-top:18px;color:#9dbdb5;font-size:13.5px}
  .mmopt{max-width:720px}
  .mmrow{display:flex;justify-content:space-between;align-items:center;gap:20px;padding:11px 0;border-bottom:1px solid #16302b;font-size:14px}
  .mmnote{color:#6d8781;font-size:12px}
  .mmb{font:inherit;font-size:13px;color:#dff3ec;background:#0a201d;border:1px solid #2c4b45;border-radius:6px;padding:5px 11px;margin-left:6px;cursor:pointer}
  .mmb:hover{border-color:#b3140c;color:#fff}
  .mmb.wide{display:block;width:100%;text-align:left;margin:6px 0}
  .mmb.back{margin-top:26px}
  .mmsaved{max-width:520px}
'''
s=s[:i]+css+s[j:]
# ---- wiring: the menu replaces the click-anywhere start
s=sub1(s,"""    startEl.style.display = 'none';
    openEditor('start');
  });""","""  });
  menuBind();""")
open(p,'w',encoding='utf-8').write(s)
print('menu ok')
