# BATTLE ROYALE: the match mode. Cages on a ring, gates, a grace period, the
# closing fog, looting a kill's parts, packs, and the win. Opponents are bots
# because this build has no game server; every rule goes through BR_NET so a
# real one drops in without a rewrite. See src/br.js and src/brmesh.js.
def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
p='g3.html'; s=open(p,encoding='utf-8').read()

# ---------------------------------------------------------------- modules
s=sub1(s,"function folInit() {\n",
        open('src/brmesh.js',encoding='utf-8').read()+"\nfunction folInit() {\n")
s=sub1(s,"  FOL.ready = true;","  brMeshInit();\n  FOL.ready = true;")
# the cage ring goes in with the trees
s=sub1(s,"""  const fx = Math.cos(yaw), fz = Math.sin(yaw);
  const T = terrain;
  for (const tr of world.forest.trees) {""","""  const fx = Math.cos(yaw), fz = Math.sin(yaw);
  const T = terrain;
  brPutCages(put, camX, camZ);
  for (const tr of world.forest.trees) {""")
# the match itself sits with the rest of the page logic
s=sub1(s,"function becomeDesigned(des) {", open('src/br.js',encoding='utf-8').read()+"\nfunction becomeDesigned(des) {")

# ---------------------------------------------------------------- the one hit rule
s=sub1(s,"""function fightHitFilter(victim, att, dmg) {
  const c = player.c;""","""function fightHitFilter(victim, att, dmg) {
  const c = player.c;
  // In a match, who may hit whom is a match rule, not a combat rule.
  if (BR.on && !brHitAllowed(victim, att)) return null;""")

# ---------------------------------------------------------------- per-frame
s=sub1(s,"""  simT += dt;
  stepSim(dt);""","""  simT += dt;
  // The match clock advances with the simulation, not with the frame loop: a
  // dropped frame must not be a dropped second of the match.
  try { if (BR.on) brTick(dt); } catch (e) { console.warn('br tick', e); }
  stepSim(dt);""")

# the fog: the match zone drives the same fog uniforms the weather does, so
# visibility inside it collapses to a couple of body lengths
s=sub1(s,"  gArr[28] = t; gArr[29] = FOG_DENSITY * GFX.fog * (1 + 2.4 * can) * (1 + 3.2 * (1 - lt2)); gArr[30] = (0.1 + 0.9 * lt2) * (1 - 0.22 * can); gArr[31] = terrain.LV.water * HEIGHT_SCALE;",
"""  gArr[28] = t; gArr[29] = FOG_DENSITY * GFX.fog * (1 + 2.4 * can) * (1 + 3.2 * (1 - lt2)); gArr[30] = (0.1 + 0.9 * lt2) * (1 - 0.22 * can); gArr[31] = terrain.LV.water * HEIGHT_SCALE;
  // the match fog: thick enough at the centre of the band that you cannot see
  // your own tail, and it washes the world grey-green as it takes you
  if (BR.on) {
    const bf = brFogAt(player.camX, player.camZ);
    if (bf > 0) {
      gArr[29] = gArr[29] + bf * bf * 0.055;
      const fogMix = clamp(bf * 1.1, 0, 1);
      gArr[24] = gArr[24] * (1 - fogMix) + 0.30 * fogMix;
      gArr[25] = gArr[25] * (1 - fogMix) + 0.34 * fogMix;
      gArr[26] = gArr[26] * (1 - fogMix) + 0.30 * fogMix;
      gArr[30] = gArr[30] * (1 - 0.5 * fogMix);
    }
  }""")

# ---------------------------------------------------------------- HUD
s=sub1(s,"""  objReset();
  seaLifeReset();""","""  objReset();
  seaLifeReset();
  if (BR.on) brStop();""")
open(p,'w',encoding='utf-8').write(s)
print('br core ok')
s=open(p,encoding='utf-8').read()

# HUD block: the match panel and the death choice go in the objective slot area
s=sub1(s,"""  <div id="edSavedBox" class="edp"></div>""",
        """  <div id="edSavedBox" class="edp"></div>""")
s=sub1(s,"""<div id="picker"></div>""","""<div id="picker"></div>
<div id="brPanel"></div>
<div id="brChoice"></div>""")
s=sub1(s,"  #warn{position:fixed;left:50%;top:112px;","""  #brPanel{position:fixed;right:14px;top:120px;display:none;min-width:240px;padding:11px 14px;border-radius:12px;
    background:rgba(8,14,18,.82);border:1px solid #3a5a52;color:#dfeee9;font-size:13px;line-height:1.55;z-index:40}
  #brPanel .brtop b{font-size:20px;color:#fff;letter-spacing:.06em}
  #brPanel .brphase{color:#8fd8c2;font-size:11.5px;letter-spacing:.14em;text-transform:uppercase;margin-top:3px}
  #brPanel .brzone{margin-top:5px;color:#a9c0b8;font-size:12px}
  #brPanel .brzone .bad{color:#ff8f7a;font-weight:600}
  #brPanel .brk{margin-top:4px;color:#e8d9a8;font-size:12px}
  #brMsg{position:fixed;left:50%;top:150px;transform:translateX(-50%);display:none;padding:12px 24px;border-radius:12px;
    background:rgba(10,18,16,.9);border:1px solid #4a7a6c;color:#eafaf4;font-size:17px;letter-spacing:.08em;text-align:center;z-index:41}
  #brChoice{position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);display:none;padding:26px 34px;border-radius:16px;
    background:linear-gradient(180deg,rgba(14,26,24,.98),rgba(6,14,14,.98));border:1px solid #4a7a6c;color:#eafaf4;z-index:60;text-align:center;max-width:460px}
  #brChoice h3{margin:0 0 10px;font-size:19px;letter-spacing:.12em}
  #brChoice p{margin:0 0 18px;font-size:13.5px;line-height:1.6;color:#a9c0b8}
  #brChoice button{font:inherit;font-size:14px;margin:0 6px;padding:9px 20px;border-radius:9px;cursor:pointer;
    background:#0a201d;border:1px solid #3d6a5e;color:#dff3ec}
  #brChoice button:hover{border-color:#b3140c;color:#fff}
  #warn{position:fixed;left:50%;top:112px;""")
s=sub1(s,"""<div id="brPanel"></div>""","""<div id="brPanel"></div>
<div id="brMsg"></div>""")
open(p,'w',encoding='utf-8').write(s)
print('br css ok')
s=open(p,encoding='utf-8').read()

# render the panel each frame, alongside the rest of the HUD
s=sub1(s,"""  try { objTick(dt); sndTick(dt); spatTick(dt); } catch (e) { console.warn(e); }""",
"""  try { objTick(dt); sndTick(dt); spatTick(dt); } catch (e) { console.warn(e); }
  try { if (BR.on) brRenderHud(); } catch (e) { console.warn('br hud', e); }""")
s=sub1(s,"function brHudHtml() {","""function brRenderHud() {
  const el = document.getElementById('brPanel');
  if (el) { el.innerHTML = brHudHtml(); el.style.display = BR.on ? 'block' : 'none'; }
  const m = document.getElementById('brMsg');
  if (m) {
    const show = BR.msg && performance.now() < BR.msgT;
    m.textContent = show ? BR.msg : '';
    m.style.display = show ? 'block' : 'none';
  }
  brRenderChoice();
}
// The loser's choice. Shown once, when you die in a match with a killer.
function brRenderChoice() {
  const el = document.getElementById('brChoice');
  if (!el) return;
  const dc = BR.deadChoice;
  if (!dc) { if (el.style.display !== 'none') { el.style.display = 'none'; el.innerHTML = ''; } return; }
  if (el.dataset.t === String(dc.t)) return;
  el.dataset.t = String(dc.t);
  const k = dc.killer != null ? BR.players[dc.killer] : null;
  el.innerHTML = '<h3>' + (k ? k.name.toUpperCase() + ' KILLED YOU' : 'THE FOG KILLED YOU') + '</h3>' +
    '<p>' + (k ? 'Join their pack and come back as their young: you fight for them, they cannot hurt you, and if they win, you win. Or watch the rest of the match.'
               : 'Nothing to join. The fog takes no packs.') + '</p>' +
    (k ? '<button data-brjoin="1">join the pack</button>' : '') +
    '<button data-brjoin="0">spectate</button>';
  el.style.display = 'block';
  for (const b of el.querySelectorAll('[data-brjoin]')) {
    b.onclick = () => { el.style.display = 'none'; el.innerHTML = ''; el.dataset.t = ''; brChoose(b.getAttribute('data-brjoin') === '1'); };
  }
}
function brHudHtml() {""")
open(p,'w',encoding='utf-8').write(s)
print('br hud ok')
s=open(p,encoding='utf-8').read()

# ---------------------------------------------------------------- the menu entry
s=sub1(s,"""  out.push({ id: 'load', label: 'LOAD CREATURE', desc: 'Pick one of the creatures you have saved and play it.' });""",
"""  out.push({ id: 'load', label: 'LOAD CREATURE', desc: 'Pick one of the creatures you have saved and play it.' });
  out.push({ id: 'online', label: 'BATTLE ROYALE', desc: 'A fifteen-minute match. Twenty-four cages, one island, a closing fog. Last one standing wins.' });""")
s=sub1(s,"""  if (it.id === 'new') { menuFresh(() => { stopMenuMusic(true); const st = document.getElementById('start'); if (st) st.style.display = 'none'; openEditor('start'); }); return; }""",
"""  if (it.id === 'new') { menuFresh(() => { stopMenuMusic(true); const st = document.getElementById('start'); if (st) st.style.display = 'none'; openEditor('start'); }); return; }
  if (it.id === 'online') { menuPage('online'); return; }""")
s=sub1(s,"""  } else if (id === 'load') {""","""  } else if (id === 'online') {
    const wins = PROG.brWins | 0, best = PROG.brBest | 0;
    h = '<h2>BATTLE ROYALE</h2>' +
      '<p>Twenty-four creatures, one island, fifteen minutes. You start locked in a numbered cage on the ring. ' +
      'The gates go up together. For the first five minutes no player can touch another: hunt the island\\'s own ' +
      'animals and take their parts. Then it is open. A fog closes in from the edge and kills whatever it catches. ' +
      'Kill a player and you eat them, grow, take a part off their body and earn ' + BONES_PER_KILL + ' bones; they choose to watch you ' +
      'or come back as your young, and a pack that wins, wins together.</p>' +
      '<p>Nothing about the island is yours to set. The seed, the ecosystem, the weather, the clock and the ' +
      'terrain are fixed by the match and identical for everyone in it, and the world panel is dead for as long ' +
      'as the match runs. Climate drift is off: it re-classifies biomes as the match goes, and a player whose ' +
      'ground shifted under them would gain or lose cover through no choice of their own.</p>' +
      '<p class="mmnote"><b>This build has no game server.</b> The match, the zone, the grace period, the looting, the ' +
      'packs and the win are all real and run to the end, but the other twenty-three are bots on this machine. Every ' +
      'rule is settled through one transport interface, so pointing it at a real server is a swap rather than a rewrite. ' +
      'Nothing here talks to the network.</p>' +
      (wins ? '<p class="mmnote">You have won ' + wins + ' match' + (wins === 1 ? '' : 'es') + '. Best: ' + best + ' kills.</p>' : '') +
      '<div class="mmopt"><button class="mmb wide" data-brgo="1">enter a match with your last creature</button>' +
      '<button class="mmb wide" data-brgo="2">build a creature first</button></div>';
  } else if (id === 'load') {""")
s=sub1(s,"""    if (t.dataset.load != null) {""","""    if (t.dataset.brgo != null) {
      const mode = t.dataset.brgo;
      if (mode === '2') { stopMenuMusic(true); BR.pending = true; const st = document.getElementById('start'); if (st) st.style.display = 'none'; openEditor('start'); return; }
      if (!PROG.last) { menuPage('online'); brSay('You have no creature yet. Build one first.', 4000); return; }
      stopMenuMusic(true); menuStart();
      brEnterMatch(C.cloneDesign(PROG.last)); return;
    }
    if (t.dataset.load != null) {""")
open(p,'w',encoding='utf-8').write(s)
print('br menu ok')
s=open(p,encoding='utf-8').read()

# building a creature for a match drops you straight into one
s=sub1(s,"  rebuild: () => rebuildWorld(),","""  rebuild: () => rebuildWorld(),
  br: {
    get on() { return BR.on; }, get phase() { return BR.phase; }, get t() { return BR.t; },
    get zone() { return BR.zone; }, get players() { return BR.players; }, get bays() { return BR.bays; },
    get alive() { return brAliveCount(); }, get result() { return BR.result; }, get log() { return BR.log; },
    start: (net) => brStart(net), stop: () => brStop(), tick: (dt) => brTick(dt),
    skip: (secs) => { BR.t += secs; },
    hitAllowed: (v, a) => brHitAllowed(v, a),
    fogAt: (x, z) => brFogAt(x, z),
    choose: (join) => brChoose(join),
    kill: (slot, by) => brOnPlayerKilled(slot, by),
    netKind: () => (BR.net ? BR.net.kind : null),
    get locked() { return brLocked(); },
    rules: () => BR_RULES,
    ruleOpts: () => brRuleOpts(),
    enter: (d) => brEnterMatch(d || (PROG.last ? C.cloneDesign(PROG.last) : null)),
    get seed() { return BR.seed; },
    syncPanel: () => brSyncPanel(),
    panelOpts: () => panelOpts(),
    panelFlags: () => panelFlags(),
    panelWarmup: () => panelWarmup(),
    resetClick: () => resetWorldClick(),
    menuPage: (id) => menuPage(id),
    get deadChoice() { return BR.deadChoice; },
    renderHud: () => brRenderHud(),
  },""")
open(p,'w',encoding='utf-8').write(s)
print('br api ok')

# ---------------------------------------------------------------- death and kills
s=open(p,encoding='utf-8').read()
# Dying in a match is not the normal "continue as your nearest kin": it is the
# end of your run unless your killer takes you into their pack.
s=sub1(s,"""function respawn() {
  const dead = player.c;
  if (dead && dead !== player._shownDeath) { player._shownDeath = dead; showDeath(dead); }""",
"""function respawn() {
  const dead = player.c;
  if (dead && dead !== player._shownDeath) { player._shownDeath = dead; showDeath(dead); }
  // In a match your line does not continue into the wildlife. Who killed you
  // decides what happens next, and brChoose() puts you back or not.
  if (BR.on && BR.phase !== 'over') {
    const me = BR.players[BR.slot];
    if (me && me.alive) {
      const killer = dead && dead._brKiller != null ? dead._brKiller : null;
      brOnPlayerKilled(BR.slot, killer, dead && dead.deathCause ? dead.deathCause : 'the island');
    }
    player.spectator = true;
    return;
  }""")
# remember who landed the killing blow on you, so the pack offer knows the name
s=sub1(s,"""  const windup = clamp(0.40 + 0.09 * Math.sqrt(Math.max(0.1, att.ph.mass)), 0.40, 0.85);""",
"""  if (BR.on && brSlotOf(att) != null) c._brKiller = brSlotOf(att);
  const windup = clamp(0.40 + 0.09 * Math.sqrt(Math.max(0.1, att.ph.mass)), 0.40, 0.85);""")
# killing a rival in a match is a match event, not an ordinary kill
s=sub1(s,"""function edOnKill(prey) {
  PROG.kills++;
  boneEarn(BONES_PER_KILL, 'kill');""","""function edOnKill(prey) {
  // A rival in a match pays out through the match, which handles the loot, the
  // growth, the bones and the pack offer, so the ordinary kill path is skipped.
  if (BR.on && prey && prey._br != null) {
    if (prey.alive === false || prey.energy <= 0) brOnPlayerKilled(prey._br, BR.slot);
    return;
  }
  PROG.kills++;
  boneEarn(BONES_PER_KILL, 'kill');""")
open(p,'w',encoding='utf-8').write(s)
print('br death ok')
s=open(p,encoding='utf-8').read()

# ---------------------------------------------------------------- editor hand-off
# "build a creature first" sets BR.pending, so finishing the builder drops you
# straight into a match instead of into free roam.
s=sub1(s,"""  if (mode === 'start') {
    if (apply) { becomeDesigned(des); started = true; }
    else if (!started) ssShow();""","""  if (mode === 'start') {
    if (apply) {
      if (BR.pending) { BR.pending = false; started = true; brEnterMatch(des); }
      else { becomeDesigned(des); started = true; }
    } else { BR.pending = false; if (!started) ssShow(); }""")
open(p,'w',encoding='utf-8').write(s)
print('br handoff ok')

# ---------------------------------------------------------------- the lock
# A match is a fair fight or it is nothing. While one is live, nothing the
# player can reach may change the ecosystem, the clock, the terrain or the
# seed: the panel answers with the match ruleset however it has been dragged,
# the live sliders do not reach world.params, and reset will not fire.
s=open(p,encoding='utf-8').read()
s=sub1(s,"""function panelOpts() {
  const num = (id, d) => { const el = $(id); const v = el ? parseFloat(el.value) : NaN; return isFinite(v) ? v : d; };
  return {""","""function panelOpts() {
  // In a match the controls are not the source of truth; the match is.
  if (brLocked()) return brRuleOpts();
  const num = (id, d) => { const el = $(id); const v = el ? parseFloat(el.value) : NaN; return isFinite(v) ? v : d; };
  return {""")
s=sub1(s,"""function panelFlags() {
  const b = (id) => { const el = $(id); return el ? el.checked : true; };""",
"""function panelFlags() {
  if (brLocked()) return Object.assign({}, BR_RULES.flags);
  const b = (id) => { const el = $(id); return el ? el.checked : true; };""")
s=sub1(s,"""function panelWarmup() {
  const el = $('prerun');
  const v = el ? parseFloat(el.value) : 0;
  return isFinite(v) ? clamp(v, 0, 400) : 0;
}
function panelOpts() {""","""function panelWarmup() {
  if (brLocked()) return BR_RULES.prerun;
  const el = $('prerun');
  const v = el ? parseFloat(el.value) : 0;
  return isFinite(v) ? clamp(v, 0, 400) : 0;
}
function panelOpts() {""")
# live sliders: refuse, and put the control back where the match says it is
s=sub1(s,"""    const apply = () => {
      const v = +el.value;
      const o = $(out); if (o) o.textContent = fmt ? fmt(v) : v;
      if (world && key) world.params[key] = v;
    };""","""    const apply = () => {
      if (brLocked()) { brSyncPanel(); brSay('Match settings are locked. Everyone plays the same island.', 2200); return; }
      const v = +el.value;
      const o = $(out); if (o) o.textContent = fmt ? fmt(v) : v;
      if (world && key) world.params[key] = v;
    };""")
s=sub1(s,"""    const el = $(id); if (el) el.addEventListener('change', () => { if (world) world.flags = panelFlags(); });""",
"""    const el = $(id); if (el) el.addEventListener('change', () => {
      if (brLocked()) { brSyncPanel(); brSay('Match settings are locked. Everyone plays the same island.', 2200); return; }
      if (world) world.flags = panelFlags();
    });""")
s=sub1(s,"""  const rst = $('reset'); if (rst) rst.addEventListener('click', () => { rebuildWorld(); });""",
"""  const rst = $('reset'); if (rst) rst.addEventListener('click', () => {
    if (brLocked()) { brSay('You cannot rebuild the world in the middle of a match.', 2600); return; }
    rebuildWorld();
  });""")
# and the Reset World button on the HUD
s=sub1(s,"""function resetWorldClick() {""","""function resetWorldClick() {
  if (brLocked()) { brSay('You cannot rebuild the world in the middle of a match.', 2600); return; }""")
# the world build takes the match seed, not the seed box
s=sub1(s,"""  const lockEl = $('seedLock');
  if (!lockEl || !lockEl.checked) { const sd = $('seed'); if (sd) sd.value = (Math.random() * 1e9) | 0; }
  let seed = parseInt(($('seed') || {}).value, 10) >>> 0;
  if (!seed) seed = 2024;""","""  // A match names its own island. The seed box and its lock have no say.
  if (brLocked()) { const sd = $('seed'); if (sd) sd.value = String(BR.seed >>> 0); }
  else {
    const lockEl = $('seedLock');
    if (!lockEl || !lockEl.checked) { const sd = $('seed'); if (sd) sd.value = (Math.random() * 1e9) | 0; }
  }
  let seed = brLocked() ? (BR.seed >>> 0) : (parseInt(($('seed') || {}).value, 10) >>> 0);
  if (!seed) seed = 2024;""")
# a rebuild that is part of arming a match must not tear the match down
s=sub1(s,"""  if (BR.on) brStop();
  toast('New world, seed ' + seed + '. You are a newborn again.', 3600);""",
"""  if (BR.on && !BR.arming) brStop();
  brSyncPanel();
  if (BR.arming) toast('Match island built. Seed ' + seed + '. Settings are locked for everyone.', 3600);
  else toast('New world, seed ' + seed + '. You are a newborn again.', 3600);""")
# the panel, greyed out, says why
s=sub1(s,"  #brPanel{position:fixed;right:14px;top:120px;","""  #panel.brlocked{filter:saturate(.45) brightness(.78)}
  #panel.brlocked .ctl,#panel.brlocked .pop-row,#panel.brlocked .flags{pointer-events:none}
  /* ::after would land at the BOTTOM of the panel, so both lines go in ::before */
  #panel.brlocked::before{content:'MATCH SETTINGS LOCKED\\A everyone in the match plays the same island, on the same clock';
    white-space:pre-line;display:block;margin:34px 0 12px;padding:8px 10px;border-radius:8px;font-size:11px;letter-spacing:.14em;
    line-height:1.9;background:rgba(120,30,20,.38);border:1px solid #8a3a2c;color:#ffd9cf;text-align:center;pointer-events:none}
  /* free-roam furniture that has no business in a match */
  body.brmatch #objective{display:none !important}
  body.brmatch #resetbtn{display:none !important}
  #brPanel{position:fixed;right:14px;top:120px;""")
open(p,'w',encoding='utf-8').write(s)
print('br lock ok')

# ---------------------------------------------------------------- cage material
# The cages were drawing through the foliage shader's BARK path, which put tree
# furrows, moss and lichen on steel. They get their own material: dark grey
# plate, mill grain, pitting, rust blooming out of the joints with streaks
# running down below each bloom, and a tight highlight on whatever is still
# clean. The lamps and bay numerals get a lit material so they are not weathered
# with the rest of it.
s=open(p,encoding='utf-8').read()
s=sub1(s,"""  var col = i.col;
  if (i.leaf < -0.5) {
    // rock: layered strata, lichen speckle, cracks, a bumped normal""",
"""  var col = i.col;
  var metalSpec = 0.0;
  var glow = 0.0;
  if (i.leaf < -2.5) {
    // lamp glass and the bay numerals: lit from inside, so they read at night
    glow = 1.0;
  } else if (i.leaf < -1.5) {
    // Weathered steel. Rust is biased onto faces that hold water and runs
    // downward below wherever it has taken hold, which is what makes painted
    // metal read as old rather than as flat grey.
    let det = 1.0 - smoothstep(340.0, 1400.0, d);
    let grain = fnoise(i.wpos.xz * 1.9 + i.wpos.yy * 0.30);
    var mcol = col * (0.93 + 0.14 * grain);
    if (det > 0.001) {
      let b0 = fnoise(vec2<f32>(i.wpos.x * 0.10 + i.wpos.z * 0.10, i.wpos.y * 0.045));
      let b1 = fnoise(vec2<f32>(i.wpos.x * 0.34 - i.wpos.z * 0.29, i.wpos.y * 0.105));
      let bloom = b0 * 0.65 + b1 * 0.35;
      let up = clamp(N.y, 0.0, 1.0);                      // top faces puddle, so they go first
      let rust0 = smoothstep(0.58, 0.88, bloom + up * 0.12);
      // the run below a bloom: the same field stretched hard down the surface
      let run = smoothstep(0.60, 0.96, fnoise(vec2<f32>(i.wpos.x * 0.55 + i.wpos.z * 0.55, i.wpos.y * 0.009)));
      let rusty = clamp(rust0 + run * rust0 * 0.45, 0.0, 1.0);
      let rustCol = mix(vec3<f32>(0.40, 0.200, 0.095), vec3<f32>(0.62, 0.345, 0.155), b1);
      mcol = mix(mcol, rustCol * (0.86 + 0.28 * grain), rusty * 0.80);
      let pit = smoothstep(0.74, 0.92, fnoise(i.wpos.xz * 3.2 + i.wpos.yy * 0.9));
      mcol *= 1.0 - 0.16 * pit;
      let e = 0.6;
      let hx = fnoise((i.wpos.xz + vec2<f32>(e, 0.0)) * 1.9 + i.wpos.yy * 0.30);
      let hz = fnoise((i.wpos.xz + vec2<f32>(0.0, e)) * 1.9 + i.wpos.yy * 0.30);
      N = normalize(N + vec3<f32>(grain - hx, 0.0, grain - hz) * 0.45 * det);
      // bare steel takes a tight highlight; rust has none
      let Lm = normalize(g.lightDir.xyz);
      let Vm = normalize(g.camPos.xyz - i.wpos);
      metalSpec = pow(max(dot(reflect(-Lm, N), Vm), 0.0), 58.0) * (1.0 - rusty) * 0.6 * g.params.z * det;
    }
    col = mix(col, mcol, det);
  } else if (i.leaf < -0.5) {
    // rock: layered strata, lichen speckle, cracks, a bumped normal""")
s=sub1(s,"""  var lit = shade(col, N, i.wpos);
  if (i.leaf > 0.5) {""","""  var lit = shade(col, N, i.wpos);
  if (metalSpec > 0.0) { lit += vec3<f32>(0.78, 0.80, 0.84) * metalSpec * shadowAt(i.wpos, N); }
  if (glow > 0.0) {
    // bright enough to carry at night, and it does not take the fog's grade
    let flick = 0.95 + 0.05 * fnoise(vec2<f32>(g.params.x * 0.6, i.wpos.y * 0.03));
    lit = mix(lit, col * (1.55 + 0.75 * (1.0 - g.params.z)) * flick, 0.88);
  }
  if (i.leaf > 0.5) {""")
open(p,'w',encoding='utf-8').write(s)
print('cage material ok')
