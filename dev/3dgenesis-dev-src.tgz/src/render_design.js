// =====================================================================
// DESIGNED CREATURES: part art + renderer
// Every placeable part is drawn from the same two primitives the rest of the
// game uses (ellipsoid, cone), built in the part's own local frame:
//   x = tangent (body-up projected onto the skin, or body-forward on top)
//   y = out of the skin (the surface normal)
//   z = the third axis, mirrored for parts on the left, so a mirrored pair
//       is a true reflection of itself.
// One local unit = the part's size in world units.
// =====================================================================
function pushSX(px, py, pz, dx, dy, dz, xx, xy, xz, sx, sy, sz, col) {
  if (instCount >= MAX_INST) return;
  const o = instCount * INST_FLOATS;
  instData[o] = px; instData[o+1] = py; instData[o+2] = pz;
  instData[o+3] = dx; instData[o+4] = dy; instData[o+5] = dz;
  instData[o+6] = sx; instData[o+7] = sy; instData[o+8] = sz;
  instData[o+9] = col[0]; instData[o+10] = col[1]; instData[o+11] = col[2];
  instData[o+12] = xx; instData[o+13] = xy; instData[o+14] = xz;
  instCount++;
}
function pushCX(px, py, pz, dx, dy, dz, xx, xy, xz, rad, len, col, radZ) {
  if (spikeCount >= MAX_SPIKE_INST) return;
  const o = spikeCount * INST_FLOATS;
  spikeData[o] = px; spikeData[o+1] = py; spikeData[o+2] = pz;
  spikeData[o+3] = dx; spikeData[o+4] = dy; spikeData[o+5] = dz;
  spikeData[o+6] = rad; spikeData[o+7] = len; spikeData[o+8] = radZ != null ? radZ : rad;
  spikeData[o+9] = col[0]; spikeData[o+10] = col[1]; spikeData[o+11] = col[2];
  spikeData[o+12] = xx; spikeData[o+13] = xy; spikeData[o+14] = xz;
  spikeCount++;
}
// ---- small vector kit ------------------------------------------------------
const v3 = {
  add: (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]],
  sub: (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]],
  mul: (a, k) => [a[0] * k, a[1] * k, a[2] * k],
  dot: (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2],
  cross: (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]],
  len: (a) => Math.hypot(a[0], a[1], a[2]),
  norm: (a) => { const l = Math.hypot(a[0], a[1], a[2]); return l > 1e-9 ? [a[0] / l, a[1] / l, a[2] / l] : [0, 1, 0]; },
  lerp: (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t],
  // rotate v about unit axis k by angle a (Rodrigues)
  rot: (v, k, a) => {
    const c = Math.cos(a), s = Math.sin(a), d = k[0] * v[0] + k[1] * v[1] + k[2] * v[2];
    const cx = k[1] * v[2] - k[2] * v[1], cy = k[2] * v[0] - k[0] * v[2], cz = k[0] * v[1] - k[1] * v[0];
    return [v[0] * c + cx * s + k[0] * d * (1 - c), v[1] * c + cy * s + k[1] * d * (1 - c), v[2] * c + cz * s + k[2] * d * (1 - c)];
  },
};
const colMul = (c, k) => [Math.min(1, c[0] * k), Math.min(1, c[1] * k), Math.min(1, c[2] * k)];
const colMix = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
const colHi = (c) => [Math.min(1, c[0] * 1.18 + 0.16), Math.min(1, c[1] * 1.18 + 0.16), Math.min(1, c[2] * 1.18 + 0.16)];
const IVORY = [0.94, 0.91, 0.82], KERATIN = [0.30, 0.24, 0.20], BLACKP = [0.03, 0.03, 0.04], WHITE = [0.97, 0.97, 0.95];
const MAW = [0.32, 0.07, 0.09], TONGUE = [0.86, 0.42, 0.46];

// Local drawing frame. P origin (world), X/Y/Z world unit axes, S scale.
function makeG(P, X, Y, Z, S, fwL, upL) {
  const W = (x, y, z) => [P[0] + (X[0] * x + Y[0] * y + Z[0] * z) * S,
                          P[1] + (X[1] * x + Y[1] * y + Z[1] * z) * S,
                          P[2] + (X[2] * x + Y[2] * y + Z[2] * z) * S];
  const D = (x, y, z) => [X[0] * x + Y[0] * y + Z[0] * z, X[1] * x + Y[1] * y + Z[1] * z, X[2] * x + Y[2] * y + Z[2] * z];
  const g = {
    P, X, Y, Z, S, fw: fwL || [1, 0, 0], up: upL || [0, 1, 0], W, D,
    // ellipsoid centred at local (x,y,z), its own y axis along local (ax,ay,az)
    sp(x, y, z, ax, ay, az, sx, sy, sz, col, hx, hy, hz) {
      const p = W(x, y, z), d = v3.norm(D(ax, ay, az));
      const h = hx == null ? [0, 0, 0] : D(hx, hy, hz);
      pushSX(p[0], p[1], p[2], d[0], d[1], d[2], h[0], h[1], h[2], sx * S, sy * S, sz * S, col);
    },
    ball(x, y, z, r, col) { const p = W(x, y, z); pushSX(p[0], p[1], p[2], Y[0], Y[1], Y[2], X[0], X[1], X[2], r * S, r * S, r * S, col); },
    // cone with its base centred at local (x,y,z), apex along (ax,ay,az)
    cn(x, y, z, ax, ay, az, rad, len, col, hx, hy, hz, radZ) {
      const p = W(x, y, z), d = v3.norm(D(ax, ay, az));
      const h = hx == null ? [0, 0, 0] : D(hx, hy, hz);
      pushCX(p[0], p[1], p[2], d[0], d[1], d[2], h[0], h[1], h[2], rad * S, len * S, col, radZ != null ? radZ * S : null);
    },
    // capsule-ish tube between two local points, built from overlapping ellipsoids
    tube(a, b, r0, r1, col, n) {
      const d = v3.sub(b, a), L = v3.len(d);
      if (L < 1e-6) return;
      const k = n || Math.max(1, Math.min(8, Math.ceil(L / (Math.min(r0, r1) * 1.6 + 1e-6))));
      for (let i = 0; i < k; i++) {
        const u = (i + 0.5) / k, r = r0 + (r1 - r0) * u;
        const m = v3.lerp(a, b, u);
        g.sp(m[0], m[1], m[2], d[0], d[1], d[2], r, Math.max(r, L / k * 0.72), r, col);
      }
    },
    // a copy of this frame rotated about a local axis through the origin
    rotated(ax, ay, az, ang) {
      const k = v3.norm(D(ax, ay, az));
      return makeG(P, v3.rot(X, k, ang), v3.rot(Y, k, ang), v3.rot(Z, k, ang), S, g.fw, g.up);
    },
    at(x, y, z) { return makeG(W(x, y, z), X, Y, Z, S, g.fw, g.up); },
    // smooth tapered tube between two local points (radii in local units)
    tb(a, b, ra, rb, col) { const A = W(a[0], a[1], a[2]), Bw = W(b[0], b[1], b[2]); pushT(A[0], A[1], A[2], Bw[0], Bw[1], Bw[2], ra * S, col, rb * S); },
  };
  return g;
}
// Fan of stiff rays with skin between them, in the plane of local axes A (out)
// and B (spread). Thin along the plane normal.
function drawFan(g, A, B, angs, lens, skin, ray, thin, ripple, t) {
  const Nrm = v3.norm(v3.cross(A, B));
  const n = angs.length;
  const pts = [];
  for (let j = 0; j < n; j++) {
    const a = angs[j];
    const dir = v3.add(v3.mul(A, Math.cos(a)), v3.mul(B, Math.sin(a)));
    const wob = Math.sin(t * 2.4 - j * 0.8) * (ripple || 0);
    const tip = v3.add(v3.mul(dir, lens[j]), v3.mul(Nrm, wob * lens[j] * 0.25));
    pts.push(tip);
    g.tube([0, 0, 0], tip, 0.055, 0.03, ray, 3);
  }
  // membrane: flat ellipsoids spanning neighbouring rays
  for (let j = 0; j < n - 1; j++) {
    const p0 = pts[j], p1 = pts[j + 1];
    for (const u of [0.35, 0.7, 0.95]) {
      const q0 = v3.mul(p0, u), q1 = v3.mul(p1, u);
      const m = v3.lerp(q0, q1, 0.5);
      const span = v3.sub(q1, q0);
      const out = v3.norm(m);
      const w = v3.len(span) * 0.62 + 0.04;
      const h = v3.len(p0) * 0.2 + 0.05;
      // ellipsoid y along the outward direction, x across the span, z = plane normal
      g.sp(m[0] * 0.92, m[1] * 0.92, m[2] * 0.92, out[0], out[1], out[2], w, h * (1.25 - u * 0.5), thin, skin, span[0], span[1], span[2]);
    }
  }
}
// Spread direction for a wing: the skin normal flattened toward horizontal
// (plus a little dihedral), so wings spread sideways instead of straight up.
function wingAxes(g) {
  const u = g.up;
  let o = v3.sub([0, 1, 0], v3.mul(u, u[1]));
  if (v3.len(o) < 0.3) o = [0, 0, 1];
  o = v3.norm(v3.add(v3.norm(o), v3.mul(u, 0.28)));
  let B = backOf(g);
  B = v3.norm(v3.sub(B, v3.mul(o, v3.dot(B, o))));
  return { o, B };
}
// The body's forward axis expressed in the part frame, projected off the normal.
const backOf = (g) => { const f = g.fw; const b = [-f[0], 0, -f[2]]; return v3.len(b) > 0.2 ? v3.norm(b) : [0, 0, 1]; };

// ---------------------------------------------------------------- catalog
// cat: palette tab. size: base size in body radii. col: default colour, or
// 'base' | 'coat' | 'detail' to follow the body paint. kind: 'surface' (drag
// onto the skin), 'limb' (adds a jointed limb), 'tip' (snaps onto a limb end).
const VIS = {
  // ---------------------------------------------------------------- mouths
  m_beak: { name: 'beak', cat: 'mouth', size: 0.34, col: [0.93, 0.74, 0.36], draw(g, c) {
    g.sp(0, 0.05, 0, 0, 1, 0, 0.62, 0.36, 0.66, colMul(c, 0.85));
    g.cn(0.16, 0, 0, -0.34, 1, 0, 0.52, 1.45, c);
    g.cn(-0.28, 0.02, 0, 0.05, 1, 0, 0.40, 0.95, colMul(c, 0.8));
    g.ball(0.4, 0.55, 0.26, 0.07, BLACKP); g.ball(0.4, 0.55, -0.26, 0.07, BLACKP);
  } },
  m_grazer: { name: 'grazing lips', cat: 'mouth', size: 0.36, col: [0.86, 0.60, 0.58], draw(g, c, e) {
    const o = e.chomp * 0.12;
    g.sp(0.2 + o, 0.34, 0, 0, 1, 0, 0.5, 0.5, 0.82, c);
    g.sp(-0.34 - o, 0.3, 0, 0, 1, 0, 0.42, 0.44, 0.74, colMul(c, 0.92));
    g.sp(-0.06, 0.62, 0, 0, 1, 0, 0.07 + o * 0.6, 0.18, 0.62, MAW);
    g.ball(0.5, 0.66, 0.3, 0.1, colMul(c, 0.35)); g.ball(0.5, 0.66, -0.3, 0.1, colMul(c, 0.35));
  } },
  m_trunk: { name: 'trunk', cat: 'mouth', size: 0.36, col: 'base', draw(g, c, e) {
    let p = [0, 0, 0], d = [0, 1, 0];
    const sw = Math.sin(e.t * 1.3 + e.seed) * 0.12;
    for (let i = 0; i < 7; i++) {
      const r = 0.46 - i * 0.045;
      d = v3.norm(v3.add(d, [-0.23, 0, sw]));
      const q = v3.add(p, v3.mul(d, 0.42));
      g.tube(p, q, r, r - 0.04, i % 2 ? colMul(c, 0.93) : c, 1);
      p = q;
    }
    g.ball(p[0], p[1], p[2], 0.2, colMul(c, 0.5));
  } },
  m_jaws: { name: 'jaws', cat: 'mouth', size: 0.5, col: 'base', draw(g, c, e) {
    const o = 0.1 + e.chomp * 0.22;
    g.sp(-0.05, 0.3, 0, 0, 1, 0, 0.36 + o, 0.55, 0.72, MAW);
    g.sp(0.32 + o * 0.5, 0.38, 0, 0.2, 1, 0, 0.32, 0.68, 0.86, c);
    g.sp(-0.42 - o * 0.5, 0.32, 0, -0.15, 1, 0, 0.28, 0.6, 0.78, colMul(c, 0.9));
    g.sp(-0.12 - o * 0.3, 0.42, 0, 0, 1, 0, 0.12, 0.34, 0.4, TONGUE);
    for (let i = 0; i < 5; i++) {
      const z = (i - 2) * 0.26, y = 0.55 + (2 - Math.abs(i - 2)) * 0.07;
      g.cn(0.2 + o * 0.5, y, z, -1, 0.1, 0, 0.075, 0.3, IVORY);
    }
    for (let i = 0; i < 4; i++) {
      const z = (i - 1.5) * 0.28, y = 0.52 + (1.5 - Math.abs(i - 1.5)) * 0.06;
      g.cn(-0.28 - o * 0.5, y, z, 1, 0.1, 0, 0.07, 0.26, IVORY);
    }
  } },
  m_maw: { name: 'fanged maw', cat: 'mouth', size: 0.56, col: 'base', draw(g, c, e) {
    const o = 0.18 + e.chomp * 0.3;
    g.sp(-0.05, 0.32, 0, 0, 1, 0, 0.42 + o, 0.6, 0.95, MAW);
    g.sp(0.4 + o * 0.5, 0.4, 0, 0.25, 1, 0, 0.34, 0.74, 1.05, c);
    g.sp(-0.5 - o * 0.5, 0.34, 0, -0.2, 1, 0, 0.3, 0.66, 0.98, colMul(c, 0.88));
    for (const s of [1, -1]) g.cn(0.26 + o * 0.5, 0.66, s * 0.5, -1, 0.15, 0, 0.12, 0.72, IVORY);
    for (let i = 0; i < 6; i++) g.cn(0.26 + o * 0.5, 0.62, (i - 2.5) * 0.18, -1, 0.1, 0, 0.06, 0.26, IVORY);
    for (let i = 0; i < 6; i++) g.cn(-0.34 - o * 0.5, 0.6, (i - 2.5) * 0.2, 1, 0.1, 0, 0.065, 0.3, IVORY);
    for (const s of [1, -1]) g.cn(-0.34 - o * 0.5, 0.62, s * 0.62, 1, 0.2, 0, 0.1, 0.5, IVORY);
  } },
  m_rex: { name: 'crushing jaw', cat: 'mouth', size: 0.74, col: 'base', use: 'a deep bone-cracking bite: the heaviest damage of any mouth, and the most genome space', draw(g, c, e) { dinoJawHard(g, c, e, jawShape('m_rex')); } },
  m_spino: { name: 'fishing jaw', cat: 'mouth', size: 0.62, col: 'base', use: 'long crocodile jaws full of conical teeth: extra reach, good in water', draw(g, c, e) { dinoJawHard(g, c, e, jawShape('m_spino')); } },
  m_short: { name: 'short muzzle', cat: 'mouth', size: 0.6, col: 'base', use: 'a short deep bulldog muzzle: fast, strong bites at close range', draw(g, c, e) { dinoJawHard(g, c, e, jawShape('m_short')); } },
  m_duck: { name: 'duck bill', cat: 'mouth', size: 0.64, col: 'base', use: 'a broad beak with grinding rows behind it: strips plants fast and reaches further', draw(g, c, e) { dinoJawHard(g, c, e, jawShape('m_duck')); } },
  m_hook: { name: 'hooked beak', cat: 'mouth', size: 0.36, col: [0.36, 0.30, 0.26], draw(g, c) {
    g.sp(0, 0.1, 0, 0, 1, 0, 0.6, 0.4, 0.62, colMul(c, 1.2));
    let p = [0.2, 0.1, 0], d = [0, 1, 0];
    for (let i = 0; i < 4; i++) {
      d = v3.norm(v3.add(d, [-0.42, 0, 0]));
      const q = v3.add(p, v3.mul(d, 0.34));
      g.tube(p, q, 0.46 - i * 0.1, 0.36 - i * 0.1, c, 1);
      p = q;
    }
    g.cn(p[0], p[1], p[2], d[0], d[1], d[2], 0.1, 0.3, c);
    g.cn(-0.3, 0.05, 0, 0.1, 1, 0, 0.34, 0.8, colMul(c, 0.85));
  } },
  // ------------------------------------------------------------------ eyes
  e_round: { name: 'round eye', cat: 'eyes', size: 0.17, col: [0.30, 0.55, 0.25], draw(g, c, e) { drawEye(g, c, e, 1, 'round'); } },
  e_big: { name: 'goggle eye', cat: 'eyes', size: 0.21, col: [0.85, 0.45, 0.15], draw(g, c, e) { drawEye(g, c, e, 1.25, 'goggle'); } },
  e_slit: { name: 'slit eye', cat: 'eyes', size: 0.17, col: [0.95, 0.80, 0.18], draw(g, c, e) { drawEye(g, c, e, 1, 'slit'); } },
  e_stalk: { name: 'eye stalk', cat: 'eyes', size: 0.18, col: [0.25, 0.45, 0.85], draw(g, c, e) {
    const sway = Math.sin(e.t * 1.7 + e.seed) * 0.18;
    const top = [0.25 + sway, 2.5, 0.1];
    g.tube([0, 0, 0], [0.1, 1.3, 0.05], 0.36, 0.26, e.base);
    g.tube([0.1, 1.3, 0.05], top, 0.26, 0.22, e.base);
    drawEye(g.at(top[0], top[1] - 0.45, top[2]), c, e, 0.95, 'round');
  } },
  e_cluster: { name: 'eye cluster', cat: 'eyes', size: 0.2, col: [0.55, 0.05, 0.08], draw(g, c, e) {
    const pts = [[0.45, 0.3, 0.3], [0.45, 0.3, -0.3], [-0.1, 0.35, 0.55], [-0.1, 0.35, -0.55], [-0.2, 0.42, 0]];
    for (const p of pts) { g.ball(p[0], p[1], p[2], 0.34, colMul(c, 0.55)); g.ball(p[0] + 0.12, p[1] + 0.2, p[2] + 0.06, 0.09, WHITE); }
  } },
  e_bug: { name: 'compound eye', cat: 'eyes', size: 0.26, col: [0.62, 0.12, 0.10], draw(g, c) {
    g.sp(0, 0.35, 0, 0, 1, 0, 1, 0.78, 1, colMul(c, 0.8));
    for (let i = 0; i < 9; i++) {
      const a = i / 9 * Math.PI * 2, r = 0.55;
      g.ball(Math.cos(a) * r, 0.78 + 0.2 * (1 - r), Math.sin(a) * r, 0.24, i % 2 ? c : colMul(c, 0.7));
    }
    g.ball(0, 1.02, 0, 0.26, colHi(c));
  } },
  // ----------------------------------------------------------------- horns
  h_straight: { name: 'straight horn', cat: 'horns', size: 0.34, col: IVORY, draw(g, c, e) {
    g.sp(0, 0.05, 0, 0, 1, 0, 0.36, 0.18, 0.36, e.base);
    g.cn(0, 0, 0, -0.22, 1, 0, 0.3, 1.9, c);
    g.sp(-0.05, 0.3, 0, -0.22, 1, 0, 0.33, 0.1, 0.33, colMul(c, 0.8));
  } },
  h_curved: { name: 'curved horn', cat: 'horns', size: 0.34, col: IVORY, draw(g, c, e) {
    g.sp(0, 0.05, 0, 0, 1, 0, 0.36, 0.18, 0.36, e.base);
    let p = [0, 0, 0], d = [0, 1, 0];
    const n = 6;
    for (let i = 0; i < n; i++) {
      d = v3.norm(v3.add(d, [-0.28, 0, 0.05]));
      const q = v3.add(p, v3.mul(d, 0.36));
      const r0 = 0.3 * (1 - i / n), r1 = 0.3 * (1 - (i + 1) / n);
      if (i < n - 1) g.tube(p, q, Math.max(0.05, r0), Math.max(0.05, r1), i % 2 ? colMul(c, 0.94) : c, 1);
      else g.cn(p[0], p[1], p[2], d[0], d[1], d[2], Math.max(0.05, r0), 0.5, c);
      p = q;
    }
  } },
  h_ram: { name: 'ram horn', cat: 'horns', size: 0.34, col: [0.78, 0.70, 0.56], draw(g, c, e) {
    g.sp(0, 0.05, 0, 0, 1, 0, 0.4, 0.2, 0.4, e.base);
    const N = 12;
    let prev = [0, 0, 0];
    for (let i = 1; i <= N; i++) {
      const th = i / N * Math.PI * 1.7;
      const rr = 0.85 * (1 - i / N * 0.45);
      const q = [-Math.sin(th) * rr, 0.25 + (1 - Math.cos(th)) * rr * 0.85 * (th < Math.PI ? 1 : 0.8), 0.18 * i / N];
      const r = 0.36 * (1 - i / N * 0.7);
      g.tube(prev, q, r + 0.03, r, i % 2 ? colMul(c, 0.86) : c, 1);
      prev = q;
    }
  } },
  h_antler: { name: 'antler', cat: 'horns', size: 0.36, col: [0.66, 0.55, 0.40], draw(g, c, e) {
    g.sp(0, 0.05, 0, 0, 1, 0, 0.3, 0.16, 0.3, e.base);
    const beam = [[0, 0, 0], [-0.25, 0.8, 0.1], [-0.55, 1.6, 0.25], [-0.7, 2.3, 0.4]];
    for (let i = 0; i < 3; i++) g.tube(beam[i], beam[i + 1], 0.16 - i * 0.03, 0.13 - i * 0.03, c, 2);
    g.cn(beam[3][0], beam[3][1], beam[3][2], -0.3, 1, 0.3, 0.09, 0.45, c);
    for (const [i, dx, dz] of [[1, 0.9, 0.1], [2, 0.8, 0.4], [2, 0.2, -0.5]]) g.cn(beam[i][0], beam[i][1], beam[i][2], dx, 0.8, dz, 0.08, 0.7, c);
  } },
  h_rhino: { name: 'nose horn', cat: 'horns', size: 0.4, col: [0.80, 0.74, 0.62], draw(g, c, e) {
    g.sp(0, 0.05, 0, 0, 1, 0, 0.55, 0.2, 0.5, e.base);
    g.cn(0.05, 0, 0, -0.18, 1, 0, 0.5, 1.6, c);
    g.cn(-0.75, 0, 0, -0.1, 1, 0, 0.26, 0.6, colMul(c, 0.9));
  } },
  h_tusk: { name: 'tusk', cat: 'horns', size: 0.34, col: IVORY, draw(g, c) {
    let p = [0, 0, 0], d = [0, 1, 0];
    for (let i = 0; i < 5; i++) {
      d = v3.norm(v3.add(d, [0.3, 0, 0.05]));
      const q = v3.add(p, v3.mul(d, 0.42));
      if (i < 4) g.tube(p, q, 0.26 - i * 0.04, 0.22 - i * 0.04, c, 1);
      else g.cn(p[0], p[1], p[2], d[0], d[1], d[2], 0.1, 0.4, c);
      p = q;
    }
  } },
  // ---------------------------------------------------- spikes and armour
  s_spike: { name: 'spike', cat: 'armor', size: 0.3, col: [0.90, 0.86, 0.76], draw(g, c, e) {
    g.sp(0, 0.05, 0, 0, 1, 0, 0.34, 0.14, 0.34, e.base);
    g.cn(0, 0, 0, -0.18, 1, 0, 0.3, 1.5, c);
  } },
  s_quills: { name: 'quills', cat: 'armor', size: 0.3, col: [0.92, 0.90, 0.84], draw(g, c, e) {
    const dirs = [[-0.2, 1, 0], [-0.5, 1, 0.3], [-0.5, 1, -0.3], [0.1, 1, 0.45], [0.1, 1, -0.45], [-0.8, 1, 0]];
    dirs.forEach((d, i) => { g.cn(d[0] * 0.2, 0, d[2] * 0.2, d[0], d[1], d[2], 0.07, 1.5 + (i % 3) * 0.25, i % 2 ? c : e.detail); });
  } },
  s_plate: { name: 'back plate', cat: 'armor', size: 0.36, col: 'detail', draw(g, c) {
    const bk = backOf(g);
    g.cn(0, -0.1, 0, bk[0] * 0.3, 1, bk[2] * 0.3, 0.85, 1.9, c, bk[0], 0, bk[2], 0.09);
    g.cn(0, 0.15, 0, bk[0] * 0.3, 1, bk[2] * 0.3, 0.55, 1.35, colMul(c, 1.3), bk[0], 0, bk[2], 0.11);
    g.sp(0, 0.05, 0, 0, 1, 0, 0.7, 0.2, 0.3, colMul(c, 0.8), bk[0], 0, bk[2]);
  } },
  s_shell: { name: 'armour shell', cat: 'armor', size: 0.5, col: [0.56, 0.46, 0.33], draw(g, c) {
    g.sp(0, 0.1, 0, 0, 1, 0, 1.5, 0.62, 1.3, c);
    const cells = [[0, 0.62, 0], [0.7, 0.5, 0], [-0.7, 0.5, 0], [0.35, 0.52, 0.62], [-0.35, 0.52, 0.62], [0.35, 0.52, -0.62], [-0.35, 0.52, -0.62]];
    for (const q of cells) g.sp(q[0], q[1], q[2], q[0] * 0.3, 1, q[2] * 0.3, 0.42, 0.12, 0.42, colMul(c, 1.28));
  } },
  s_knob: { name: 'studded knob', cat: 'armor', size: 0.28, col: [0.62, 0.52, 0.40], draw(g, c) {
    g.ball(0, 0.35, 0, 0.62, c);
    for (let i = 0; i < 6; i++) { const a = i / 6 * 6.283; g.cn(Math.cos(a) * 0.4, 0.55, Math.sin(a) * 0.4, Math.cos(a), 1, Math.sin(a), 0.1, 0.35, IVORY); }
    g.cn(0, 0.9, 0, 0, 1, 0, 0.1, 0.4, IVORY);
  } },
  s_club: { name: 'spiked club', cat: 'armor', size: 0.34, col: [0.60, 0.50, 0.38], draw(g, c) {
    g.tube([0, 0, 0], [0, 0.8, 0], 0.3, 0.36, c, 2);
    g.ball(0, 1.3, 0, 0.72, c);
    for (let i = 0; i < 10; i++) {
      const a = i * 2.39996, y = 1 - (i + 0.5) / 10 * 2, r = Math.sqrt(1 - y * y);
      const d = [Math.cos(a) * r, y, Math.sin(a) * r];
      g.cn(d[0] * 0.6, 1.3 + d[1] * 0.6, d[2] * 0.6, d[0], d[1], d[2], 0.13, 0.5, IVORY);
    }
  } },
  // ------------------------------------------------------------------ limbs
  l_leg: { name: 'limb', cat: 'limbs', size: 1, col: 'base', kind: 'limb', thick: 1 },
  l_thick: { name: 'heavy limb', cat: 'limbs', size: 1, col: 'base', kind: 'limb', thick: 1.45 },
  l_thin: { name: 'slender limb', cat: 'limbs', size: 1, col: 'base', kind: 'limb', thick: 0.6 },
  l_spring: { name: 'springing leg', cat: 'limbs', size: 1, col: 'base', kind: 'limb', thick: 1.15 },
  // ------------------------------------------------------ feet and hands
  // frame: y = along the limb (away from the ankle), x = body forward
  t_paw: { name: 'paw', cat: 'limbs', size: 0.26, col: 'base', kind: 'tip', draw(g, c) {
    g.sp(0.1, 0.25, 0, 0, 1, 0, 0.62, 0.42, 0.62, c);
    for (let i = 0; i < 4; i++) {
      const z = (i - 1.5) * 0.3, x = 0.5 + (1.5 - Math.abs(i - 1.5)) * 0.1;
      g.ball(x, 0.5, z, 0.2, colMul(c, 0.95));
      g.cn(x + 0.12, 0.55, z, 1, 0.45, 0, 0.07, 0.22, IVORY);
    }
  } },
  t_hoof: { name: 'hoof', cat: 'limbs', size: 0.26, col: KERATIN, draw(g, c, e) {
    g.sp(0, 0.05, 0, 0, 1, 0, 0.5, 0.25, 0.5, e.limb);
    g.sp(0.08, 0.42, 0, 0, 1, 0, 0.58, 0.4, 0.56, c);
    g.sp(0.1, 0.72, 0, 0, 1, 0, 0.62, 0.08, 0.6, colMul(c, 0.7));
  }, kind: 'tip' },
  t_talon: { name: 'talons', cat: 'limbs', size: 0.28, col: [0.90, 0.74, 0.34], kind: 'tip', draw(g, c) {
    g.ball(0, 0.15, 0, 0.3, c);
    const toes = [[1, 0, 0.35], [1, 0, 0], [1, 0, -0.35], [-1, 0, 0]];
    for (const t of toes) {
      const dir = v3.norm([t[0], 0.35, t[2]]);
      const a = [0, 0.2, 0], b = v3.add(a, v3.mul(dir, t[0] > 0 ? 0.9 : 0.5));
      g.tube(a, b, 0.14, 0.1, c, 2);
      g.cn(b[0], b[1], b[2], dir[0] * 0.6, 0.8, dir[2] * 0.6, 0.08, 0.3, KERATIN);
    }
  } },
  t_hand: { name: 'grasping hand', cat: 'limbs', size: 0.26, col: 'base', kind: 'tip', draw(g, c, e) {
    const curl = 0.25 + e.grip * 0.5;
    g.sp(0, 0.35, 0, 0, 1, 0, 0.5, 0.48, 0.24, c);
    for (let i = 0; i < 4; i++) {
      const x = (i - 1.5) * 0.24;
      let p = [x, 0.72, 0], d = [0, 1, 0];
      for (let k = 0; k < 3; k++) {
        d = v3.norm(v3.add(d, [0, 0, curl * 0.6]));
        const q = v3.add(p, v3.mul(d, 0.26 - k * 0.03));
        g.tube(p, q, 0.1, 0.085, c, 1);
        p = q;
      }
      g.cn(p[0], p[1], p[2], d[0], d[1], d[2], 0.06, 0.14, IVORY);
    }
    g.tube([0.45, 0.3, 0.05], [0.7, 0.62, 0.25], 0.11, 0.09, c, 2);
  } },
  t_claw: { name: 'big claws', cat: 'limbs', size: 0.26, col: [0.88, 0.84, 0.72], kind: 'tip', draw(g, c, e) {
    g.sp(0, 0.3, 0, 0, 1, 0, 0.56, 0.42, 0.4, e.limb);
    for (let i = 0; i < 3; i++) {
      const x = (i - 1) * 0.3;
      let p = [x, 0.6, 0.15], d = [0, 1, 0.3];
      for (let k = 0; k < 3; k++) {
        d = v3.norm(v3.add(d, [0, -0.1, 0.45]));
        const q = v3.add(p, v3.mul(d, 0.34));
        g.tube(p, q, 0.13 - k * 0.035, 0.1 - k * 0.035, c, 1);
        p = q;
      }
      g.cn(p[0], p[1], p[2], d[0], d[1], d[2], 0.05, 0.2, c);
    }
  } },
  t_pincer: { name: 'pincer', cat: 'limbs', size: 0.3, col: [0.86, 0.36, 0.26], kind: 'tip', draw(g, c, e) {
    g.sp(0, 0.6, 0, 0, 1, 0, 0.5, 0.72, 0.42, c);
    const o = 0.18 + e.grip * 0.25;
    g.cn(0.18, 1.1, 0, -o, 1, 0, 0.24, 1.0, colMul(c, 1.1));
    g.cn(-0.2, 1.1, 0, o, 1, 0, 0.2, 0.85, colMul(c, 0.9));
    g.ball(0.2, 0.9, 0.2, 0.08, IVORY); g.ball(-0.2, 0.9, 0.2, 0.08, IVORY);
  } },
  t_flipper: { name: 'flipper', cat: 'limbs', size: 0.3, col: 'base', kind: 'tip', draw(g, c) {
    g.sp(0.2, 0.9, 0, 0.25, 1, 0, 0.72, 1.1, 0.12, c, 1, 0, 0);
    g.sp(0.25, 1.3, 0, 0.3, 1, 0, 0.5, 0.7, 0.14, colMul(c, 1.12), 1, 0, 0);
  } },
  t_pad: { name: 'sucker pad', cat: 'limbs', size: 0.26, col: [0.95, 0.60, 0.62], kind: 'tip', draw(g, c, e) {
    g.sp(0, 0.1, 0, 0, 1, 0, 0.4, 0.2, 0.4, e.limb);
    g.sp(0, 0.34, 0, 0, 1, 0, 0.66, 0.14, 0.66, c);
    g.sp(0, 0.44, 0, 0, 1, 0, 0.3, 0.06, 0.3, colMul(c, 0.6));
  } },
  // ------------------------------------------------------- fins and wings
  f_fin: { name: 'side fin', cat: 'fins', size: 0.55, col: [0.36, 0.66, 0.86], draw(g, c, e) {
    const B = backOf(g);
    drawFan(g, [0, 1, 0], B, [0.1, 0.35, 0.6, 0.85, 1.1], [1.25, 1.35, 1.25, 1.05, 0.8], c, colHi(c), 0.05, 0.25, e.t + e.seed);
  } },
  f_dorsal: { name: 'dorsal fin', cat: 'fins', size: 0.6, col: [0.30, 0.55, 0.80], draw(g, c, e) {
    const B = backOf(g);
    drawFan(g, [0, 1, 0], B, [-0.25, 0.05, 0.35, 0.65, 0.95, 1.2], [0.7, 1.2, 1.35, 1.25, 1.0, 0.65], c, colHi(c), 0.05, 0.12, e.t + e.seed);
  } },
  f_fluke: { name: 'tail fin', cat: 'fins', size: 0.6, col: [0.28, 0.52, 0.78], draw(g, c, e) {
    // two lobes spreading along the local x axis (body-up on a tail tip)
    const t = e.t + e.seed;
    drawFan(g, [0, 1, 0], [1, 0, 0], [-0.95, -0.7, -0.4, -0.1], [1.4, 1.1, 0.8, 0.6], c, colHi(c), 0.06, 0.1, t);
    drawFan(g, [0, 1, 0], [1, 0, 0], [0.1, 0.4, 0.7, 0.95], [0.6, 0.8, 1.1, 1.4], c, colHi(c), 0.06, 0.1, t + 1);
  } },
  w_bat: { name: 'membrane wing', cat: 'wings', size: 1.0, col: [0.55, 0.36, 0.40], draw(g0, c, e) {
    const { o: O, B } = wingAxes(g0);
    const g = g0.rotated(B[0], B[1], B[2], e.flap);
    const bone = colMul(c, 0.72), skin = c;
    const P = (y, b) => v3.add(v3.mul(O, y), v3.mul(B, b));
    const sh = P(0.05, 0), el = P(0.55, -0.05), wr = P(1.05, 0.02);
    g.tube(sh, el, 0.075, 0.06, bone, 4); g.tube(el, wr, 0.06, 0.045, bone, 4);
    const tips = [];
    for (let i = 0; i < 4; i++) {
      const a = 0.12 + i * 0.45;
      const tip = v3.add(wr, P(Math.cos(a) * (0.95 - i * 0.1), Math.sin(a) * (0.95 - i * 0.1)));
      g.tube(wr, tip, 0.04, 0.018, bone, 4);
      tips.push(tip);
    }
    { const tc = v3.add(O, v3.mul(B, -0.6)); g.cn(wr[0], wr[1], wr[2], tc[0], tc[1] + 0.3, tc[2], 0.05, 0.22, IVORY); }   // thumb claw
    const bodyEdge = P(0.0, 0.85);
    // one flat panel per triangle, lying exactly in the wing plane
    const panel = (A, B2, C2, k) => {
      const m = v3.mul(v3.add(v3.add(A, B2), C2), 1 / 3);
      const mid = v3.mul(v3.add(B2, C2), 0.5);
      const ax = v3.sub(mid, A), span = v3.sub(C2, B2);
      const L = v3.len(ax), W = v3.len(span);
      const q = v3.lerp(A, mid, 0.56);
      g.sp(q[0], q[1], q[2], ax[0], ax[1], ax[2], W * 0.52 * k, L * 0.56, 0.018, skin, span[0], span[1], span[2]);
      const q2 = v3.lerp(A, m, 0.5);
      g.sp(q2[0], q2[1], q2[2], ax[0], ax[1], ax[2], W * 0.3, L * 0.4, 0.02, colMul(skin, 0.94), span[0], span[1], span[2]);
    };
    for (let i = 0; i < tips.length - 1; i++) panel(wr, tips[i], tips[i + 1], 1);
    panel(wr, tips[tips.length - 1], bodyEdge, 1.05);
    panel(el, wr, bodyEdge, 0.9);
    panel(sh, el, bodyEdge, 0.9);
  } },
  w_feather: { name: 'feathered wing', cat: 'wings', size: 1.0, col: [0.92, 0.88, 0.82], draw(g0, c, e) {
    const { o: O, B } = wingAxes(g0);
    const g = g0.rotated(B[0], B[1], B[2], e.flap);
    const tipC = e.detail;
    const P = (y, b) => v3.add(v3.mul(O, y), v3.mul(B, b));
    const arm = [P(0.05, 0), P(0.5, -0.08), P(1.0, -0.05), P(1.45, 0.02)];
    for (let i = 0; i < 3; i++) g.tube(arm[i], arm[i + 1], 0.13 - i * 0.03, 0.1 - i * 0.03, colMul(c, 0.92), 3);
    // primaries fan from the hand, secondaries run back along the arm
    const N = 13;
    for (let i = 0; i < N; i++) {
      const u = i / (N - 1);
      const base = v3.lerp(arm[0], arm[3], 0.12 + u * 0.88);
      const d = v3.norm(v3.add(v3.mul(B, 1 - u * 0.62), v3.mul(O, u * 0.72)));
      const L = 0.62 + u * 0.8;
      const m = v3.add(base, v3.mul(d, L * 0.5));
      const across = v3.norm(v3.cross(d, v3.cross(O, B)));
      g.sp(m[0], m[1], m[2], d[0], d[1], d[2], 0.11, L * 0.54, 0.025, i % 2 ? c : colMul(c, 0.93), across[0], across[1], across[2]);
      const tp = v3.add(base, v3.mul(d, L * 0.9));
      g.sp(tp[0], tp[1], tp[2], d[0], d[1], d[2], 0.085, L * 0.13, 0.028, tipC, across[0], across[1], across[2]);
    }
    for (let i = 0; i < 7; i++) {
      const u = i / 6;
      const base = v3.lerp(arm[0], arm[2], 0.12 + u * 0.88);
      const d = v3.norm(v3.add(B, v3.mul(O, 0.15)));
      const m = v3.add(base, v3.mul(d, 0.26));
      const across = v3.norm(v3.cross(d, v3.cross(O, B)));
      g.sp(m[0], m[1], m[2], d[0], d[1], d[2], 0.15, 0.32, 0.035, colMul(c, 1.06), across[0], across[1], across[2]);
    }
  } },
  w_insect: { name: 'gossamer wings', cat: 'wings', size: 0.9, col: [0.80, 0.90, 0.96], draw(g0, c, e) {
    const { o: O, B } = wingAxes(g0);
    const g = g0.rotated(B[0], B[1], B[2], e.flap * 1.4);
    for (const [ang, L, w] of [[0.35, 1.5, 0.36], [0.85, 1.2, 0.3]]) {
      const d = v3.norm(v3.add(v3.mul(O, Math.cos(ang)), v3.mul(B, Math.sin(ang))));
      const m = v3.mul(d, L * 0.5);
      g.sp(m[0], m[1], m[2], d[0], d[1], d[2], w, L * 0.52, 0.02, c, B[0], B[1], B[2]);
      g.tube([0, 0, 0], v3.mul(d, L * 0.95), 0.03, 0.015, colMul(c, 0.55), 4);
    }
  } },
  // ---------------------------------------------------------------- details
  d_antenna: { name: 'antenna', cat: 'details', size: 0.2, col: [0.22, 0.18, 0.16], draw(g, c, e) {
    let p = [0, 0, 0], d = [0, 1, 0];
    const sw = Math.sin(e.t * 2.1 + e.seed) * 0.08;
    for (let i = 0; i < 6; i++) {
      d = v3.norm(v3.add(d, [0.16 + sw, 0, 0.05]));
      const q = v3.add(p, v3.mul(d, 0.55));
      g.tube(p, q, 0.12 - i * 0.012, 0.1 - i * 0.012, c, 1);
      p = q;
    }
    g.ball(p[0], p[1], p[2], 0.26, e.detail);
  } },
  d_crest: { name: 'feather crest', cat: 'details', size: 0.3, col: [0.90, 0.30, 0.24], draw(g, c, e) {
    const B = backOf(g);
    for (let i = 0; i < 5; i++) {
      const a = -0.2 + i * 0.28;
      const d = v3.norm(v3.add(v3.mul([0, 1, 0], Math.cos(a)), v3.mul(B, Math.sin(a))));
      const L = 1.5 - Math.abs(i - 1.5) * 0.15;
      const m = v3.mul(d, L * 0.5);
      g.sp(m[0], m[1], m[2], d[0], d[1], d[2], 0.2, L * 0.55, 0.05, i % 2 ? c : colMul(c, 0.85), B[0], B[1], B[2]);
      const tp = v3.mul(d, L * 0.95);
      g.sp(tp[0], tp[1], tp[2], d[0], d[1], d[2], 0.14, 0.16, 0.06, e.detail, B[0], B[1], B[2]);
    }
  } },
  d_frill: { name: 'neck frill', cat: 'details', size: 0.5, col: [0.80, 0.42, 0.30], draw(g, c, e) {
    const B = backOf(g);
    const S2 = v3.norm(v3.cross([0, 1, 0], B));
    const angs = [], lens = [];
    for (let i = 0; i < 9; i++) { angs.push(-1.35 + i * 0.3375); lens.push(1.1 + 0.15 * Math.cos(i * 0.8)); }
    drawFan(g, [0, 1, 0], S2, angs, lens, c, e.detail, 0.05, 0.05, e.t + e.seed);
  } },
  d_gills: { name: 'gills', cat: 'details', size: 0.26, col: [0.78, 0.30, 0.34], use: 'breathe under water: no drowning, ever', draw(g, c, e) {
    for (let i = 0; i < 3; i++) {
      const z = (i - 1) * 0.42;
      g.sp(0, 0.06, z, 0, 1, 0, 0.72, 0.12, 0.1, colMul(c, 0.45), 1, 0, 0);
      g.sp(0.05, 0.14, z - 0.1, 0.1, 1, -0.4, 0.66, 0.1, 0.16, e.base, 1, 0, 0);
    }
  } },
  d_lungs: { name: 'lungs', cat: 'details', size: 0.3, col: 'base', use: 'breathe air: a water animal can come ashore', draw(g, c, e) {
    const br = 1 + Math.sin(e.t * 1.6 + e.seed) * 0.06;          // the chest lifts as it breathes
    g.sp(0, 0.16, 0, 0, 1, 0, 0.92 * br, 0.34 * br, 0.86 * br, colMul(c, 0.95));
    g.sp(0, 0.34, 0, 0, 1, 0, 0.42, 0.22, 0.36, colMul(c, 0.8));  // the blowhole mound
    g.sp(0, 0.46, 0, 0, 1, 0, 0.2, 0.08, 0.1, BLACKP);            // the hole itself
    for (const s2 of [1, -1]) g.sp(0, 0.2, s2 * 0.52, 0, 1, 0, 0.5, 0.12, 0.12, colMul(c, 0.7));   // rib swell
  } },
  d_gland: { name: 'toxin gland', cat: 'details', size: 0.26, col: [0.62, 0.22, 0.78], draw(g, c, e) {
    const k = 1 + Math.sin(e.t * 2.5 + e.seed) * 0.05;
    g.sp(0, 0.38, 0, 0, 1, 0, 0.66 * k, 0.6 * k, 0.66 * k, c);
    g.ball(0.2, 0.78, 0.15, 0.2, colHi(c));
    for (let i = 0; i < 3; i++) { const a = i * 2.1; g.ball(Math.cos(a) * 0.5, 0.62, Math.sin(a) * 0.5, 0.13, colMul(c, 0.7)); }
    g.sp(0, 0.05, 0, 0, 1, 0, 0.6, 0.12, 0.6, e.base);
  } },
};
// Shared eye: eyeball, iris and pupil turned toward where the body looks,
// and an eyelid in the skin colour that blinks.
// An animal eye: a mostly-iris eyeball seated in the skin (the lids are flesh,
// see FLESH eyes), a domed iris, a round or slit pupil and a wet highlight.
// Only a sliver of pale sclera shows, which keeps faces from looking human.
function drawEye(g, c, e, k, style) {
  // gaze axis: out of the skin, tipped forward; 'up' is the brow direction
  const f = v3.norm(v3.add([0, 1, 0], v3.mul(g.fw, 0.8)));
  const up0 = v3.sub(g.up, v3.mul(f, v3.dot(g.up, f)));
  const up = v3.len(up0) > 1e-3 ? v3.norm(up0) : [1, 0, 0];
  const R = 0.9 * k, cy = 0.22 * k;              // raised: the eye bulges from its socket
  const C0 = [0, cy, 0];
  const at = (d, u) => v3.add(v3.add(C0, v3.mul(f, d * R)), v3.mul(up, (u || 0) * R));
  // eyeball: warm, slightly yellowed sclera (only a sliver shows between the lids)
  g.sp(0, cy, 0, 0, 1, 0, R, R, R, [0.78, 0.70, 0.52]);
  // iris in layers, each a little further out so none of them z-fight:
  // dark limbal ring, the coloured iris, a lighter inner flare round the pupil
  const irisR = style === 'goggle' ? 0.86 : 0.76;
  let q = at(0.50); g.sp(q[0], q[1], q[2], f[0], f[1], f[2], irisR * R, 0.53 * R, irisR * R, colMul(c, 0.32), up[0], up[1], up[2]);
  q = at(0.58); g.sp(q[0], q[1], q[2], f[0], f[1], f[2], irisR * R * 0.9, 0.48 * R, irisR * R * 0.9, colMul(c, 0.85), up[0], up[1], up[2]);
  q = at(0.66); g.sp(q[0], q[1], q[2], f[0], f[1], f[2], irisR * R * 0.58, 0.41 * R, irisR * R * 0.58, colHi(c), up[0], up[1], up[2]);
  // pupil: round, or a vertical slit for ambush hunters
  q = at(0.76);
  if (style === 'slit') g.sp(q[0], q[1], q[2], f[0], f[1], f[2], 0.09 * R, 0.335 * R, 0.52 * R, BLACKP, up[0], up[1], up[2]);
  else g.sp(q[0], q[1], q[2], f[0], f[1], f[2], 0.33 * R, 0.335 * R, 0.33 * R, BLACKP, up[0], up[1], up[2]);
  // wet cornea: a clear-ish dome and a sharp catch-light
  if (!e.lod) {
    const side = v3.cross(f, up);
    const hl = v3.add(at(1.04, 0.32), v3.mul(side, 0.2 * R));
    g.ball(hl[0], hl[1], hl[2], 0.1 * R, WHITE);
    const hl2 = v3.add(at(1.02, -0.22), v3.mul(side, -0.16 * R));
    g.ball(hl2[0], hl2[1], hl2[2], 0.045 * R, [0.8, 0.82, 0.84]);
  }
  // lids in the skin colour: a heavy upper lid and a lower lid leave an almond
  // opening; a blink drops the upper lid and lifts the lower one to meet it
  const lid = e.base || colMul(c, 0.6);
  const shut = e.blink > 0 ? 1 : 0;
  if ((e.lod || 0) < 2) {
    q = at(0.08, 0.98 - 0.72 * shut);
    g.sp(q[0], q[1], q[2], up[0], up[1], up[2], R * 1.12, R * 0.56, R * 1.12, lid, f[0], f[1], f[2]);
    q = at(0.02, -1.08 + 0.32 * shut);
    g.sp(q[0], q[1], q[2], up[0], up[1], up[2], R * 1.08, R * 0.5, R * 1.08, colMul(lid, 0.92), f[0], f[1], f[2]);
    // a darker lash line along the upper lid's edge
    q = at(0.62, 0.44 - 0.72 * shut);
    g.sp(q[0], q[1], q[2], up[0], up[1], up[2], R * 0.78, R * 0.07, R * 0.5, colMul(lid, 0.45), f[0], f[1], f[2]);
  } else if (shut) g.sp(0, cy, 0, f[0], f[1], f[2], R * 1.06, R * 1.06, R * 1.06, lid, up[0], up[1], up[2]);
}
const VIS_CATS = [
  { id: 'body', label: 'body shape', hint: 'the skeleton everything else hangs on' },
  { id: 'shape', label: 'proportions', hint: 'stretch the body, neck and tail' },
  { id: 'paint', label: 'colour & skin', hint: 'hide colour, pattern and covering' },
  { id: 'limbs', label: 'limbs, feet & hands', hint: 'legs carry you, arms grab and strike' },
  { id: 'eyes', label: 'eyes', hint: 'how far you see danger and food' },
  { id: 'mouth', label: 'mouths & jaws', hint: 'what you can eat and how hard you bite' },
  { id: 'horns', label: 'horns', hint: 'attack, and the gore move' },
  { id: 'armor', label: 'spikes & armour', hint: 'defence, and damage to whatever bites you' },
  { id: 'fins', label: 'fins', hint: 'swimming, and steering in water' },
  { id: 'wings', label: 'wings', hint: 'flight, once the wings beat your weight' },
  { id: 'details', label: 'details', hint: 'crests, frills and display pieces' },
];
// Nothing is unlocked at the start: every part is earned by killing an animal
// that has one. Your current body's own parts stay usable while you edit it.
const STARTER_ITEMS = [];
function itemColor(id, c, dcol) {
  if (c) return c;
  const v = VIS[id];
  const dc = v ? v.col : 'base';
  if (dc === 'base' || !dc) return dcol.base;
  if (dc === 'coat') return dcol.coat;
  if (dc === 'detail') return dcol.detail;
  return dc;
}

// ---- part frame ---------------------------------------------------------------
// n: outward normal (body space). Returns local axes in body space.
function partFrame(n, spin, side, preferFwd) {
  const N = v3.norm(n);
  const U = [0, 1, 0], F = [1, 0, 0];
  let t;
  if (preferFwd) {
    t = v3.sub(F, v3.mul(N, v3.dot(F, N)));
    if (v3.len(t) < 0.3) t = v3.sub(U, v3.mul(N, v3.dot(U, N)));
  } else {
    t = v3.sub(U, v3.mul(N, v3.dot(U, N)));
    if (v3.len(t) < 0.35) t = v3.sub(F, v3.mul(N, v3.dot(F, N)));
  }
  t = v3.norm(t);
  if (spin) t = v3.rot(t, N, spin * side);
  const z = v3.mul(v3.cross(N, t), side);
  return { x: t, y: N, z };
}
function frameLocal(fr, v) { return [v3.dot(v, fr.x), v3.dot(v, fr.y), v3.dot(v, fr.z)]; }

// ---- design geometry cache ----------------------------------------------------
// Skeleton, limb classification and per-ball skin radii are pure functions of
// the design, so they are computed once per design object.
function designGeo(des) {
  if (des._geo && des._geoRev === (des._rev || 0)) return des._geo;
  const sk = C.buildDesignSkeleton(des);
  const cls = C.classifyLimbs(des, sk);
  // extent in R units, for camera distance and interaction range
  let ext = 1;
  for (const k of sk.balls) if (!k.hide) ext = Math.max(ext, Math.hypot(k.x, k.y, k.z) + k.r);
  for (const o of cls.limbs) {
    const f = v3.add(o.root, o.lb.f);
    ext = Math.max(ext, v3.len(f) + 0.3);
  }
  des._geo = { sk, cls, ext };
  des._geoRev = des._rev || 0;
  return des._geo;
}
function designExtentOf(c) {
  const d = c.genome && c.genome.design;
  if (!d) return null;
  return designGeo(d).ext;
}

// ---- tail pose ------------------------------------------------------------------
// Rest tail balls bent by a travelling wave. Returns per-ball {p, yaw}.
function tailPose(sk, t, amp, swing, seed) {
  const B = sk.balls, out = [];
  const P = sk.plan;
  let prev = [-sk.a * 0.92, sk.b * 0.08, 0];
  let restPrev = prev.slice();
  let ang = 0;
  for (let i = 0; i < P.ts; i++) {
    const k = B[sk.tailStart + i];
    const u = (i + 1) / P.ts;
    const w = Math.sin(t * 2.2 - i * 0.75 + seed) * (0.10 + u * 0.16) * amp + swing * u * 0.55;
    ang += w * 0.5;
    const seg = [k.x - restPrev[0], k.y - restPrev[1], k.z - restPrev[2]];
    const c = Math.cos(ang), s = Math.sin(ang);
    const rs = [seg[0] * c - seg[2] * s, seg[1], seg[0] * s + seg[2] * c];
    const p = v3.add(prev, rs);
    out.push({ p, yaw: ang, r: k.r });
    prev = p; restPrev = [k.x, k.y, k.z];
  }
  return out;
}
const rotYv = (v, a) => { const c = Math.cos(a), s = Math.sin(a); return [v[0] * c - v[2] * s, v[1], v[0] * s + v[2] * c]; };

// ---- draw one designed creature ---------------------------------------------
// X: placement + animation context
//   toW(l)   body-space point (R units) -> world
//   dirW(v)  body-space direction -> world
//   R        world units per R
//   t, seed, gait {phase, amt}, arm, tail swing, chomp, grab, flap
//   ground(x,z) world ground height, or null for a rest pose (editor)
//   hl       { part, limb } highlighted objects, hide Set of dead tissue types
//   lod      0 full, 1 no fine detail
//   pushBody(mesh, colours) draws the skin
function drawDesignOld(des, X) {
  const G = designGeo(des);
  const sk = G.sk, B = sk.balls, P = sk.plan;
  const col = des.col || { base: [0.5, 0.6, 0.5], coat: [0.9, 0.9, 0.8], detail: [0.2, 0.3, 0.2], pat: 0 };
  const base = X.tint ? colMix(col.base, X.tint, X.tintK) : col.base;
  const coat = X.tint ? colMix(col.coat, X.tint, X.tintK) : col.coat;
  const detail = col.detail;
  const R = X.R, t = X.t, seed = X.seed || 0;
  const hide = X.hide;
  // animated ball positions (body space)
  const bpos = new Array(B.length);
  const byaw = new Float32Array(B.length);
  for (let i = 0; i < B.length; i++) bpos[i] = [B[i].x, B[i].y, B[i].z];
  // serpentine wave, identical to the one the body shader applies to the skin
  const wAmp = sk.flex ? (X.flexAmp != null ? X.flexAmp : 0.25) : 0;
  const wPh = (X.gaitPhase || 0) * 1.2 + seed;
  const waveZ = (x) => wAmp ? wAmp * Math.sin(wPh - x * 2.4) * (0.35 + 0.65 * clamp((sk.a - x) / (2 * sk.a), 0, 1)) : 0;
  if (wAmp) for (let i = 0; i < B.length; i++) if (B[i].g !== 'tail') bpos[i][2] += waveZ(B[i].x);
  if (sk.tailLen > 0.05) {
    const tp = tailPose(sk, X.gaitPhase != null ? X.gaitPhase : t, X.tailAmp != null ? X.tailAmp : 0.6, X.tailSwing || 0, seed);
    // flexible bodies continue their wave down the tail
    const baseZ = waveZ(-sk.a * 0.92);
    for (let i = 0; i < tp.length; i++) {
      bpos[sk.tailStart + i] = [tp[i].p[0], tp[i].p[1], tp[i].p[2] + baseZ];
      byaw[sk.tailStart + i] = tp[i].yaw;
    }
  }
  const bodyCols = { base, coat, detail, pat: col.pat | 0, wave: [wAmp, wPh, sk.a] };
  // ---- body ----------------------------------------------------------------
  {
    const mesh = X.syncSkin ? skinNow(G.skin) : getSkinMesh(G.skin);
    if (mesh) X.pushBody(mesh, bodyCols);
    else {
      for (let i = 0; i < B.length; i++) {
        const k = B[i];
        if (k.hide || k.g === 'tail') continue;
        const p = X.toW(bpos[i]), r = G.iso[i] * R;
        pushSX(p[0], p[1], p[2], 0, 1, 0, 0, 0, 0, r, r, r, base);
      }
    }
  }
  // ---- tail chain -------------------------------------------------------------
  if (sk.tailLen > 0.05) {
    let prev = X.toW([-sk.a * 0.92, sk.b * 0.08, waveZ(-sk.a * 0.92)]);
    for (let i = 0; i < P.ts; i++) {
      const bi = sk.tailStart + i;
      const q = X.toW(bpos[bi]);
      const r1 = B[bi].r * R * 1.05, r0 = (i === 0 ? B[bi].r * 1.12 : B[bi - 1].r) * R * 1.05;
      const tc = i % 3 === 1 && bodyCols.pat ? colMix(base, detail, 0.45) : base;
      pushT(prev[0], prev[1], prev[2], q[0], q[1], q[2], r0, tc, r1);
      pushSX(q[0], q[1], q[2], 0, 1, 0, 0, 0, 0, r1, r1, r1, tc);
      prev = q;
    }
  }
  if (X.far) return;
  const env = { t, seed, base, coat, detail, limb: base, flap: X.flap || 0, chomp: X.chomp || 0, grip: X.grip || 0, blink: 0, lod: X.lod || 0 };
  // ---- surface parts ------------------------------------------------------------
  const parts = des.parts || [];
  for (let pi = 0; pi < parts.length; pi++) {
    const pt = parts[pi];
    const vis = VIS[pt.id];
    if (!vis || !vis.draw) continue;
    if (X.lod >= 2 && vis.size * (pt.s || 1) < 0.24) continue;   // small details vanish at distance
    const sim = C.ITEM_SIM[pt.id];
    if (hide && sim && hide.has(sim.t)) continue;
    const bi = clamp(pt.b | 0, 0, B.length - 1), k = B[bi];
    const r = Math.max(0.05, k.r);
    let off = [pt.o[0] * r, pt.o[1] * r, pt.o[2] * r];
    let n = pt.n || [0, 1, 0];
    if (byaw[bi]) { off = rotYv(off, byaw[bi]); n = rotYv(n, byaw[bi]); }
    const lp = v3.add(bpos[bi], off);
    const side = (k.z + pt.o[2] * r) < -0.04 ? -1 : 1;
    const fr = partFrame(n, pt.spin || 0, side, false);
    const S = vis.size * clamp(pt.s || 1, 0.3, 3) * R;
    const Pw = X.toW(lp);
    const g = makeG(Pw, X.dirW(fr.x), X.dirW(fr.y), X.dirW(fr.z), S,
                    frameLocal(fr, [1, 0, 0]), frameLocal(fr, [0, 1, 0]));
    let cc = itemColor(pt.id, pt.c, bodyCols);
    if (X.hl && (X.hl.part === pt || (X.hl.mirror && X.hl.part && pt.m && X.hl.part.m === pt.m))) cc = colHi(cc);
    env.seed = seed + pi * 1.7;
    env.blink = X.blink ? X.blink(pi) : 0;
    const flapSide = (X.flap || 0) * (lp[2] < 0 ? -1 : 1);   // both wings beat together
    env.flap = flapSide;
    vis.draw(g, cc, env);
  }
  // ---- limbs ------------------------------------------------------------------
  for (let li = 0; li < G.cls.limbs.length; li++) {
    const o = G.cls.limbs[li];
    const lb = o.lb;
    if (hide && hide.has(o.leg ? 'LEG' : 'ARM')) continue;
    const bi = clamp(lb.b | 0, 0, B.length - 1), k = B[bi];
    const r = Math.max(0.05, k.r);
    const root = v3.add(bpos[bi], [lb.o[0] * r, lb.o[1] * r, lb.o[2] * r]);
    let knee = v3.add(root, lb.k), foot = v3.add(root, lb.f);
    const pose = X.limbPose ? X.limbPose(o, li, root, knee, foot) : null;
    let rootW = X.toW(root), kneeW, footW;
    if (pose) { kneeW = pose.knee; footW = pose.foot; }
    else { kneeW = X.toW(knee); footW = X.toW(foot); }
    const vis = VIS[lb.id] || VIS.l_leg;
    const th = clamp(lb.th || 1, 0.5, 2) * (vis.thick || 1);
    let lc = itemColor(lb.id, lb.c, bodyCols);
    const sel = X.hl && (X.hl.limb === lb || (X.hl.mirror && X.hl.limb && lb.m && X.hl.limb.m === lb.m));
    if (sel) lc = colHi(lc);
    drawLimbTube(rootW, kneeW, footW, th, R, lc, !X.lod);
    if (X.lod >= 2) continue;
    if (lb.tip && VIS[lb.tip.id] && !(hide && hide.has('TIP'))) {
      const tv = VIS[lb.tip.id];
      const dirW2 = v3.norm(v3.sub(footW, kneeW));
      // tip frame in world space: y along the shin, x toward body-forward
      const fwdW = X.dirW([1, 0, 0]);
      let xw = v3.sub(fwdW, v3.mul(dirW2, v3.dot(fwdW, dirW2)));
      if (v3.len(xw) < 0.3) { const upW = X.dirW([0, 1, 0]); xw = v3.sub(upW, v3.mul(dirW2, v3.dot(upW, dirW2))); }
      xw = v3.norm(xw);
      const side = root[2] < -0.04 ? -1 : 1;
      const zw = v3.mul(v3.cross(dirW2, xw), side);
      const S = tv.size * clamp(lb.tip.s || 1, 0.4, 2.5) * th * R;
      const g = makeG(footW, xw, dirW2, zw, S, [1, 0, 0], [0, -1, 0]);
      let tc = itemColor(lb.tip.id, lb.tip.c, bodyCols);
      if (sel) tc = colHi(tc);
      env.limb = lc;
      tv.draw(g, tc, env);
    } else if (!lb.tip) {
      // a bare limb ends in a small rounded point
      const d = v3.norm(v3.sub(footW, kneeW));
      const r0 = 0.1 * th * R;
      pushCX(footW[0], footW[1], footW[2], d[0], d[1], d[2], 0, 0, 0, r0, r0 * 2.4, colMul(lc, 0.8));
    }
  }
}
// Organic limb: smooth tapered tubes with rounded joints and a muscle swell on
// each segment, so it reads as one continuous limb.
function drawLimbTube(a, b, c, th, R, col, fine) {
  const r0 = 0.17 * th * R, r1 = 0.122 * th * R, r2 = 0.092 * th * R;
  const sh = r0 * 1.2;
  pushSX(a[0], a[1], a[2], 0, 1, 0, 0, 0, 0, sh, sh, sh, col);
  pushT(a[0], a[1], a[2], b[0], b[1], b[2], r0, col, r1);
  pushSX(b[0], b[1], b[2], 0, 1, 0, 0, 0, 0, r1 * 1.08, r1 * 1.08, r1 * 1.08, colMul(col, 0.98));
  pushT(b[0], b[1], b[2], c[0], c[1], c[2], r1, col, r2);
  pushSX(c[0], c[1], c[2], 0, 1, 0, 0, 0, 0, r2 * 1.05, r2 * 1.05, r2 * 1.05, col);
  if (fine) {
    const mus = (p, q, u, r, k) => {
      const d = v3.sub(q, p), L = v3.len(d); if (L < 1e-6) return;
      const m = v3.lerp(p, q, u);
      pushSX(m[0], m[1], m[2], d[0] / L, d[1] / L, d[2] / L, 0, 0, 0, r * k, L * 0.3, r * k, col);
    };
    mus(a, b, 0.36, r0, 1.1);
    mus(b, c, 0.3, r1, 1.08);
  }
}
