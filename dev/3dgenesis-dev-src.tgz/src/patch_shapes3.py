# =====================================================================
# LURKER, MAW, HOLLOW, HYDRA -- BUILT OFF THE REFERENCES
#
# All four failed for the same structural reason, which the contact sheet
# makes obvious: THE HEAD WAS INSIDE THE BODY. The skin is a smooth union of
# capsules, so a head whose centre sits within a body radius of the torso is
# not a head -- it is a bulge, and the animal reads as one lump. The lurker
# had a head 80% of its body radius parked 0.28 units past the end of a body
# 0.82 long; there was never going to be a face on it.
#
# A head reads as a head when its centre clears the torso. That means the
# neck has to be long enough to carry it out, and the skull has to be
# SMALLER than the body rather than competing with it.
#
# Rebuilt against the specific references rather than against my own names:
#
#   LURKER  <- the horned ape: a heavy hunched quadruped, thick arms, a blunt
#              head carried clear and low, and a beard of tendrils under it
#   MAW     <- the white xeno: a back that peaks hard over the shoulders, a
#              small head slung down and forward well clear of the chest,
#              long bent hind legs and a long sweeping tail
#   HOLLOW  <- the horned brute: upright, enormous shoulders, long heavy arms
#              reaching the floor, small hips, a horned head between them
#   STALKER <- the spider-xeno (was "hydra"): a low hunched thorax, the head
#              tucked forward under it, bladed forelimbs held up in front
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, ('ANCHOR %d/%d' % (n, cnt), a[:110]); return s.replace(a, b)
import re

p = 'g3.html'; s = open(p, encoding='utf-8').read()

ROWS = [
 (30, "{ a: 0.92, b: 1.10, seg: 11, prof: 'animal', arch: 0.56, droop: 0.16, wide: 0.46, neck: 0.98, nx: 0.62, ny: -0.46, ns: 3, head: 0.46, snx: 0.70, snr: 0.52, tail: 0.3, tailR: 0.18, ts: 4, stand: 1.55, hump: 0.92, waist: 0.26, waistAt: 0.28 }, // 30 lurker: the horned ape. Heavy, hunched, head carried clear and low"),
 (31, "{ a: 1.22, b: 0.70, seg: 13, prof: 'animal', arch: 0.72, droop: 0.20, wide: 0.18, neck: 1.25, nx: 0.72, ny: -0.66, ns: 4, head: 0.40, snx: 0.95, snr: 0.36, tail: 2.3, tailR: 0.24, ts: 9, stand: 1.80, hump: 0.98, waist: 0.34, waistAt: 0.30 }, // 31 maw: the white xeno. A back that peaks over the shoulders, the skull slung down and forward"),
 (32, "{ a: 0.86, b: 0.72, seg: 11, prof: 'animal', arch: 0.62, droop: 0.24, wide: 0.44, neck: 0.62, nx: 0.55, ny: -0.30, ns: 3, head: 0.46, snx: 0.62, snr: 0.50, tail: 0.5, tailR: 0.20, ts: 4, stand: 2.45, hump: 0.96, waist: 0.40, waistAt: 0.24 }, // 32 hollow: the horned brute. Shoulders far over the hips, arms to the floor"),
 (24, "{ a: 1.12, b: 0.60, seg: 11, prof: 'insect', arch: 0.50, droop: 0.10, wide: 0.34, neck: 0.80, nx: 0.74, ny: -0.58, ns: 3, head: 0.38, snx: 0.72, snr: 0.40, tail: 1.5, tailR: 0.20, ts: 7, stand: 1.45, hump: 0.88, waist: 0.44, waistAt: 0.30, waistW: 0.11 }, // 24 stalker: the spider-xeno. A hunched thorax with the head tucked under its front"),
]
for idx, row in ROWS:
    m = re.search(r"^    \{ a:[^\n]*\},\s*// %d\b[^\n]*$" % idx, s, re.M)
    assert m, 'no row for plan %d' % idx
    s = s[:m.start()] + '    ' + row + s[m.end():]

# ---- what they are born wearing ---------------------------------------------
# lurker: thick arms, a tendril beard under the jaw
s = sub1(s, """      case 30: // lurker: a face across the whole front of one enormous body
        eyeAt('e_big', 1.45, 0.22, 0.62, 0.30); eyeAt('e_round', 0.75, 0.55, 0.40, 0.55);
        mouthAt('m_maw', 1.65);
        put('d_frill', -a * 0.30, b * 1.15, b * 0.30, -0.2, 1, 0.3, 1.1, true);""",
"""      case 30: // lurker: the horned ape, with a beard of tendrils under the jaw
        eyeAt('e_round', 0.70, 0.55, 0.42, 0.52); mouthAt('m_maw', 1.25);
        put('h_curved', head.x - hr * 0.25, head.y + hr * 0.85, hr * 0.42, -0.35, 1, 0.42, 1.35, true);
        for (const u of [0.15, 0.45, 0.75]) put('d_antenna', snout.x - snout.r * u, snout.y - snout.r * 0.85, snout.r * (0.18 + u * 0.35), -0.1, -0.8, 0.5, 0.85, true);
        put('s_plate', -a * 0.10, b * 1.05, b * 0.42, 0, 1, 0.35, 1.2, true);""")
# maw: a long sweeping tail and long bent hind legs
s = sub1(s, """        put('s_plate', -a * 0.30, b * 0.95, b * 0.35, -0.2, 1, 0.4, 0.95, true);
        // short, heavy and planted under the body, not splayed beside it
        limb('l_thick',  a * 0.22, -b * 0.34, b * 0.66,  a * 0.30, -st, b * 0.78, 0.16, 0.04, 0.02, 't_pad', 1.55);
        limb('l_thick', -a * 0.40, -b * 0.34, b * 0.66, -a * 0.46, -st, b * 0.78, -0.16, 0.04, 0.02, 't_pad', 1.45);
        tailPut('s_knob', 0.9);""",
"""        for (const u of [0.55, 0.30, 0.05]) put('s_spike', a * u, b * 1.02, b * 0.12, 0, 1, 0.2, 1.05 - u * 0.4, true);
        // long hind legs, knee well above the hip, and short arms up in front
        limb('l_thick', -a * 0.14, -b * 0.22, b * 0.56,  a * 0.02, -st, b * 0.62, 0.34, 0.62, 0.04, 't_talon', 1.35);
        limb('l_thin',   a * 0.52,  b * 0.22, b * 0.46,  a * 0.86, -b * 0.42, b * 0.66, 0.16, 0.30, 0.10, 't_claw', 0.68);
        tailPut('s_spike', 1.3);""")
# hollow: the long heavy arms are the whole point
s = sub1(s, """        put('s_spike', -a * 0.05, b * 1.15, b * 0.25, 0, 1, 0.3, 0.8, true);
        limb('l_thin', -a * 0.20, -b * 0.30, b * 0.42, -a * 0.10, -st, b * 0.40, 0.30, 0.10, 0.02, 't_pad', 0.62);""",
"""        put('h_tusk', head.x - hr * 0.2, head.y + hr * 0.8, hr * 0.45, -0.4, 1, 0.45, 1.3, true);
        put('s_spike', -a * 0.05, b * 1.15, b * 0.40, 0, 1, 0.35, 1.0, true);
        // short hips, and arms that come down past the feet
        limb('l_thick', -a * 0.34, -b * 0.34, b * 0.52, -a * 0.28, -st, b * 0.58, 0.22, 0.14, 0.02, 't_pad', 1.5);""")
s = sub1(s, "        limb('l_thin',  a * 0.35,  b * 0.55,  b * 0.52,  a * 0.55, -st * 0.42, b * 0.78, 0.18, -0.34, 0.10, 't_claw', 0.55);",
            "        limb('l_thick',  a * 0.42,  b * 0.52,  b * 0.70,  a * 0.62, -st * 0.55, b * 0.98, 0.10, -0.30, 0.16, 't_claw', 1.45);")
# stalker: bladed forelimbs held up, four walking legs under a hunched thorax
s = sub1(s, """        limb('l_leg',  a * 0.48, -b * 0.30,  b * 0.52,  a * 0.55, -st,  b * 0.70, 0.15, 0, 0.04, 't_paw', 1.05);
        limb('l_leg', -a * 0.50, -b * 0.30,  b * 0.52, -a * 0.55, -st,  b * 0.70, -0.15, 0, 0.04, 't_paw', 1.05);
        break;""",
"""        legRow('l_leg', [0.20, -0.30], { out: 0.80, rake: 0.85, reach: 1.35, knee: 0.95, th: 1.25, tip: 't_talon' });
        limb('l_thick', a * 0.58, b * 0.30, b * 0.50, a * 1.05, -b * 0.30, b * 0.80, 0.26, 0.52, 0.12, 't_claw', 1.05);
        break;""")

# the picker and the names follow
s = sub1(s, "'lurker', 'maw', 'hollow', 'centipede'", "'lurker', 'maw', 'hollow', 'centipede'")
s = sub1(s, "'scorpion', 'stilt-walker', 'hydra', 'mantis'", "'scorpion', 'stilt-walker', 'stalker', 'mantis'")

open(p, 'w', encoding='utf-8').write(s)
print('shapes3: four rebuilt off the references ok')
