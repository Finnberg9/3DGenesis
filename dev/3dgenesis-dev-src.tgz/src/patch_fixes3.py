# =====================================================================
# THREE THINGS FROM PLAYING IT
#
# 1. BODIES ON THE GROUND ARE TOO SMALL AND TOO BURIED. A carcass is meant to
#    be a landmark you cross a valley for: a ribcage standing out of the soil.
#    It was a flattened thing sinking into the ground almost as soon as it
#    appeared, at the size of the animal rather than the size of a thing worth
#    walking to.
#
# 2. ONE BODY, TWO LOOTS. Killing something opened the part picker, AND left a
#    body you could then search for a second pair. Two rewards for one kill,
#    through two different code paths, which is also why they could disagree.
#    The kill no longer pays out parts at all: it leaves a body, and the body
#    is searched like any other. One loot, one path, one rule.
#
# 3. THINGS HIT YOU WITHOUT LOOKING AT YOU. Heading is eased toward the
#    direction of TRAVEL, and only while moving, so an animal that stopped to
#    attack kept whatever way it happened to be pointing and bit you over its
#    own shoulder. An attacker must now turn to face you before it may commit
#    to a strike, and must still be facing you when the strike lands.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, ('ANCHOR %d/%d' % (n, cnt), a[:110]); return s.replace(a, b)

p = 'g3.html'; s = open(p, encoding='utf-8').read()

# =====================================================================
# 1. A carcass is a ribcage, not a stain
# =====================================================================
# Field bodies are drawn larger than the animal they came from on purpose:
# they are the loot landmarks of the island, and they have to read as
# something to walk to from a long way off.
s = sub1(s, """    ent.R = (G.cls && G.cls.radius ? G.cls.radius : 4) * BODY_SCALE;
    if (!(ent.R > 0.5)) ent.R = 4 * BODY_SCALE;""",
"""    ent.R = (G.cls && G.cls.radius ? G.cls.radius : 4) * BODY_SCALE * CARC_SCALE;
    if (!(ent.R > 0.5)) ent.R = 4 * BODY_SCALE * CARC_SCALE;""")
s = sub1(s, "const CARC_CELL = 1150;          // one candidate per cell this wide",
"""// Old bodies are drawn bigger than the animal that made them. They are the
// loot landmarks of the island, and a ribcage you can pick out across a
// valley is worth more to the player than an accurate one you walk past.
const CARC_SCALE = 1.8;
const CARC_CELL = 1150;          // one candidate per cell this wide""")

# the spine stands higher, the ribs arc up rather than splaying flat, and the
# soil takes them much later and much less
s = sub1(s, """  const sinkK = clamp((k - 0.25) / 0.75, 0, 1);""",
"""  // The soil takes them late and takes them slowly. Sinking early was what
  // made a body read as a stain on the ground instead of a thing standing in
  // it, and it is the ribs you want above the grass.
  const sinkK = clamp((k - 0.55) / 0.45, 0, 1);""")
s = sub1(s, """  const hs = maxR * 0.62;
  const sinkBy = (hs + 0.35) * S * sinkK * 1.15;""",
"""  // A collapsed carcass, but one that still has a ribcage standing on it.
  const hs = maxR * 1.05;
  const sinkBy = (hs + 0.35) * S * sinkK * 0.70;""")
# ribs: a tighter arc keeps them vertical instead of laying them out flat
s = sub1(s, """      const splay = 0.10 + 0.25 * remRand(r, i * 7 + side);   // collapsed outward
      let prev = top;
      for (let q = 1; q <= ribN; q++) {
        const th = (q / ribN) * 1.85;""",
"""      const splay = 0.06 + 0.16 * remRand(r, i * 7 + side);   // collapsed outward, but only a little
      let prev = top;
      for (let q = 1; q <= ribN; q++) {
        // A tighter sweep keeps the rib standing up out of the ground rather
        // than folding it flat along the soil.
        const th = (q / ribN) * 1.42;""")
s = sub1(s, """        const p = [b.x + side * 0 - 0.06 * q / ribN, Math.max(0.04, top[1] * Math.cos(th) * (1 - splay * 0.5)),""",
             """        const p = [b.x + side * 0 - 0.06 * q / ribN, Math.max(0.10, top[1] * Math.cos(th * 0.82) * (1 - splay * 0.4)),""")
# and thicker bone, so a big ribcage does not read as wire at distance
s = sub1(s, "  const vr = 0.055 + maxR * 0.035;",
            "  const vr = 0.075 + maxR * 0.048;")

# =====================================================================
# 2. One body, one loot
# =====================================================================
s = sub1(s, """  const opts = preyItems(prey);
  if (!opts.length) { toast('Killed it. +' + KILL_SPACE + ' genome space, +' + BONES_PER_KILL + ' bones.', 2600); return; }
  player.picker = { opts, label: 'You killed it: +' + KILL_SPACE + ' genome space, +' + BONES_PER_KILL + ' bones. Take a pair of one of its parts', t0: performance.now(), items: true };
  renderPicker();""",
"""  // A kill pays genome space and bones. It does NOT hand you parts: it leaves
  // a body, and the body is searched with E like every other body on the
  // island. Two payouts through two different code paths is how they came to
  // disagree with each other in the first place.
  const opts = preyItems(prey);
  toast('Killed it. +' + KILL_SPACE + ' genome space, +' + BONES_PER_KILL + ' bones.' +
        (opts.length ? ' Search the body with E: ' + opts.length + ' parts on it.' : ''), 3000);""")

# =====================================================================
# 3. Nothing hits you without looking at you
# =====================================================================
s = sub1(s, "  const windup = clamp(0.40 + 0.09 * Math.sqrt(Math.max(0.1, att.ph.mass)), 0.40, 0.85);",
r"""  // It has to be looking at you before it may commit. Refusing the strike
  // rather than letting it fly is what turns "it bit me over its shoulder"
  // into "it turned, then bit me": the refusal costs it the tick, it spends
  // that tick turning, and it tries again.
  att._faceT = simT + 1.2;                         // keep turning toward the player
  if (!fightFacing(att, c, FACE_COMMIT)) return null;
  const windup = clamp(0.40 + 0.09 * Math.sqrt(Math.max(0.1, att.ph.mass)), 0.40, 0.85);""")
s = sub1(s, "function fightResolveStrike(s) {",
r"""// How far off straight-ahead an attacker may be. It has to be roughly facing
// you to start a strike, and still facing you when it lands -- the second is
// tighter, so turning away mid-swing throws it.
const FACE_COMMIT = Math.cos(1.92);    // ~110 degrees: may begin the wind-up
const FACE_LAND = Math.cos(1.31);      // ~75 degrees: may actually connect
// Is `att` looking at `tgt`? Read off the same heading the body is drawn with,
// so what the player SEES is what the rule uses.
function fightFacing(att, tgt, cosNeed) {
  if (!att || !tgt) return true;
  const yaw = att._yaw3;
  if (yaw == null) return true;                     // never drawn: do not punish it
  const dx = tgt.x - att.x, dz = tgt.y - att.y;
  const d = Math.hypot(dx, dz);
  if (d < 1e-4) return true;
  return (Math.cos(yaw) * dx + Math.sin(yaw) * dz) / d >= cosNeed;
}
// Turn whatever is trying to hit you toward you, every frame, whether or not
// it is being drawn. This is behaviour, not rendering: a rule that only runs
// inside the renderer is a rule that stops when the creature goes off screen.
function fightFaceTick(dt) {
  const c = player.c;
  if (!c || !c.alive || !world) return;
  for (const q of FIGHT.pending) if (q.att) q.att._faceT = Math.max(q.att._faceT || 0, simT + 0.35);
  const list = world.creatures;
  for (let i = 0; i < list.length; i++) {
    const a = list[i];
    if (!a.alive || a === c || !(a._faceT > simT)) continue;
    const dx = c.x - a.x, dz = c.y - a.y;
    if (Math.hypot(dx, dz) < 1e-4) continue;
    const want = Math.atan2(dz, dx);
    if (a._yaw3 == null) { a._yaw3 = want; continue; }
    let e = want - a._yaw3;
    while (e > Math.PI) e -= Math.PI * 2;
    while (e < -Math.PI) e += Math.PI * 2;
    // heavy bodies swing round slowly, which is what makes flanking one work
    const rate = clamp(4.2 - 0.05 * (a.ph ? a.ph.mass : 8), 1.3, 4.2);
    const step = rate * dt;
    a._yaw3 += Math.abs(e) <= step ? e : Math.sign(e) * step;
  }
}
function fightResolveStrike(s) {""")
s = sub1(s, """  if (d > reach) { fightMsg('Out of reach: it missed.', 700); return; }""",
"""  if (d > reach) { fightMsg('Out of reach: it missed.', 700); return; }
  if (!fightFacing(att, c, FACE_LAND)) { fightMsg('It swung wide: it is not facing you.', 900); return; }""")
# the renderer stops fighting the turn while a creature is committed to facing you
s = sub1(s, """  if (sp > 1) {
    const target = Math.atan2(c.vy, c.vx);""",
"""  // While something is turning to face the player it owns its own heading:
  // easing toward the direction of travel as well would drag it back off
  // target every frame it stepped sideways.
  if (sp > 1 && !(c._faceT > simT)) {
    const target = Math.atan2(c.vy, c.vx);""")
s = sub1(s, "function fightTick(dt) {\n  world.hitFilter = fightHitFilter;\n  spellTick(dt);",
            "function fightTick(dt) {\n  world.hitFilter = fightHitFilter;\n  fightFaceTick(dt);\n  spellTick(dt);")

# test surface
s = sub1(s, "    resetFall: () => fallResetGround(),",
"""    resetFall: () => fallResetGround(),
    facing: (a, t, need) => fightFacing(a, t, need == null ? FACE_LAND : need),
    faceTick: (dt) => fightFaceTick(dt),
    FACE_COMMIT, FACE_LAND,""")

open(p, 'w', encoding='utf-8').write(s)
print('fixes3 ok')

# The same rule for a player kill: it leaves a body, and the body is searched.
# Two payouts for one kill is two payouts however the victim is labelled.
s = open(p, encoding='utf-8').read()
s = sub1(s, """  const opts = [...ids];
  if (!opts.length) { brSay('You ate ' + from + '. There was nothing on it to take.', 2600); return; }
  player.picker = { opts: opts.slice(0, 6), label: 'You killed ' + from + '. Take a pair of one of their parts', t0: performance.now(), items: true };
  renderPicker();""",
"""  const opts = [...ids];
  if (!opts.length) { brSay('You killed ' + from + '. There was nothing on them worth taking.', 2600); return; }
  brSay('You killed ' + from + '. Their body is at your feet: press E to search it \\u00b7 ' + opts.length + ' parts', 4200);""")

open(p, 'w', encoding='utf-8').write(s)
print('fixes3: one loot for a player kill too ok')

# ---------------------------------------------------------------- test surface
s = open(p, encoding='utf-8').read()
s = sub1(s, "    walkTo: (i) => { const e = CARC.live.filter(q => q.G && !q.looted)[i || 0]; if (!e) return null;",
"""    get scale() { return CARC_SCALE; },
    radii: () => CARC.live.filter(e => e.G).map(e => +e.R.toFixed(2)),
    // how much of its height the soil has taken, at a given fraction of life
    sinkAt: (ks) => (ks || []).map((k) => +clamp((k - 0.55) / 0.45, 0, 1).toFixed(3)),
    walkTo: (i) => { const e = CARC.live.filter(q => q.G && !q.looted)[i || 0]; if (!e) return null;""")
s = sub1(s, "  inv: {\n    granted: (id) => (ED.grantCount && ED.grantCount[id]) || 0,",
"""  inspectTargetDbg: () => inspectTarget(),
  // put a creature next to the player and kill it the way a swing would, so
  // the loot rules can be driven end to end
  spawnFoe: (x, z) => {
    const g = C.seedHerbivore(world, world.rng);
    g.design = C.randomDesign(world.rng, { diversity: 0.85, rarityCap: 'ultra' });
    C.compileDesign(g);
    const f = C.makeCreature(g, x, z, 400);
    for (const q of f.cellState) q.grow = 1;
    f.ph = C.develop(g, f.cellState);
    C.hpOf(f);
    world.creatures.push(f);
    return f;
  },
  killNearest: () => {
    const c = player.c;
    if (!c) return { ok: false, why: 'nobody' };
    const f = window.__G3D.spawnFoe(c.x + 12, c.y + 4);
    f.alive = false; f.deathCause = 'predation'; f._creditedKill = true;
    remainsAdd(f);
    edOnKill(f);
    return { ok: true, parts: (f.genome.design ? designItems(f.genome.design) : []).length };
  },
  inv: {
    granted: (id) => (ED.grantCount && ED.grantCount[id]) || 0,""")
open(p, 'w', encoding='utf-8').write(s)
print('fixes3: test surface ok')
