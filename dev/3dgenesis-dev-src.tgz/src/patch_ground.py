# GROUND RULES
#  - a real slope limit: nothing walks up anything steeper than 60 degrees, and
#    a body built to scramble (hooves or claws, and not too heavy) gets to 80
#  - fall damage over 20 feet, scaling with the drop, none of it if you land in
#    water deep enough to take you
# One world unit is one foot. A grown animal stands 8 to 15 of them.
def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
p='g3.html'; s=open(p,encoding='utf-8').read()

# ---------------------------------------------------------------- climb stat
# How well a body grips rock: what its legs end in, and how heavy it is. A
# hoofed or clawed light body scrambles; a flat-footed heavy one does not.
s=sub1(s,"""  function jitterDesign(d, rng, rate) {""","""  // What each foot is worth on rock. Hooves and claws grip; flippers do not.
  const GRIP_TIP = { t_claw: 1.0, t_talon: 0.80, t_hoof: 0.65, t_hand: 0.50,
                     t_pincer: 0.35, t_paw: 0.20, t_pad: 0.12, t_flipper: 0 };
  // 0 = walks on flat ground only, 1 = mountain goat.
  function designClimb(d, mass) {
    if (!d || !d.limbs || !d.limbs.length) return 0;
    let n = 0, grip = 0;
    for (const lb of d.limbs) {
      const tip = lb.tip && lb.tip.id;
      const g = tip != null && GRIP_TIP[tip] != null ? GRIP_TIP[tip] : 0.2;
      n++; grip += g;
    }
    if (!n) return 0;
    // The square-cube law: holding yourself on a wall costs strength that goes
    // as area while the weight goes as volume, so this falls away fast with
    // size. A hoofed grazer is not a goat; a small clawed thing is.
    const light = clamp(1.25 - (mass || 1) / 14, 0.05, 1);
    return clamp((grip / n) * light, 0, 1);
  }
  function jitterDesign(d, rng, rate) {""")
s=sub1(s,"      ph.dLegs = X.legs || 0; ph.dArms = X.arms || 0; ph.dSpring = X.spring || 0;",
"""      ph.dLegs = X.legs || 0; ph.dArms = X.arms || 0; ph.dSpring = X.spring || 0;
      ph.climb = designClimb(genome.design, ph.mass);""")
s=sub1(s,"    ITEM_SIM, ITEM_SINGLE, PLANS, BODY_RANGE, planProfile, buildDesignSkeleton, skinField, raySkin, snapToSkin, rarityCap: 'ultra',",
         "    ITEM_SIM, ITEM_SINGLE, PLANS, BODY_RANGE, planProfile, buildDesignSkeleton, skinField, raySkin, snapToSkin, rarityCap: 'ultra', designClimb, GRIP_TIP,")
open(p,'w',encoding='utf-8').write(s)
print('climb stat ok')
s=open(p,encoding='utf-8').read()

# ---------------------------------------------------------------- slope limit
s=sub1(s,"""      if (!p.canFly) {
        const lv0 = terrain.level(c.x, c.y);""","""      if (!p.canFly) {
        const lv0 = terrain.level(c.x, c.y);
        // Slope, measured in the direction of travel over a fixed baseline
        // rather than over the tick's own step, which is far too short to read
        // a gradient from. 60 degrees for anything that walks; a scrambler
        // earns its way up to 80.
        const HSC = terrain.heightScale || 420;
        const climbLim = SLOPE_TAN_WALK + (SLOPE_TAN_CLIMB - SLOPE_TAN_WALK) * Math.pow(clamp(p.climb || 0, 0, 1), 2.5);
        const tooSteep = (bx, by) => {
          const dxm = bx - c.x, dym = by - c.y;
          const L = Math.hypot(dxm, dym);
          if (L < 1e-6) return false;
          const B = SLOPE_BASE;
          const h0 = terrain.height(c.x, c.y);
          const h1 = terrain.height(c.x + dxm / L * B, c.y + dym / L * B);
          const tan = (h1 - h0) * HSC / B;
          // airborne you clear more than you could walk up
          return tan > climbLim + (c.jumpLv || 0) * 0.9;
        };""")
s=sub1(s,"          return terrain.level(bx, by) - lv0 > terrain.maxStep + (c.jumpLv || 0);",
         "          return tooSteep(bx, by);")
# These live in the CORE, beside the other simulation constants: the slope test
# runs inside stepWorld, which is a separate scope from the page.
s=sub1(s,"const HURT_TIME = 5;","""const HURT_TIME = 5;
// 60 degrees is the limit for anything that walks. A body built to scramble
// earns its way to 80. Measured over this baseline, in world units.
const SLOPE_TAN_WALK = 1.7321;    // tan 60
const SLOPE_TAN_CLIMB = 5.6713;   // tan 80
const SLOPE_BASE = 9;""")
open(p,'w',encoding='utf-8').write(s)
print('slope limit ok')

# ---------------------------------------------------------------- fall damage
# Walking off a cliff used to snap you to the ground below with no consequence.
# Now the ground falling away under you puts you in the air, gravity takes over,
# and what you hit at the bottom costs you. Water takes the fall instead.
s=open(p,encoding='utf-8').read()
s=sub1(s,"const GRAV = 520;","""// One world unit is one foot. You can drop this far for free; past it the
// damage goes as the height, so about ninety feet kills most bodies outright.
const FALL_SAFE = 20;
const FALL_FATAL = 70;        // feet of drop BEYOND the safe distance that costs a full body
const GRAV = 520;""")
s=sub1(s,"""function updateJump(dt) {
  if (!player.c || !player.c.alive) { player.jumpY = 0; player.jumpV = 0; player.grounded = true; return; }
  if (player.c.ph.canFly) { player.jumpY = 0; player.jumpV = 0; player.grounded = true; return; }
  if (player.jumpY > 0 || player.jumpV > 0) {
    player.jumpV -= GRAV * dt;
    player.jumpY += player.jumpV * dt;
    // terrain steps you can clear while in the air
    const blockH = terrain.hMax * HEIGHT_SCALE / Math.max(1, terrain.ELEV);
    player.c.jumpLv = Math.max(0, Math.floor(player.jumpY / Math.max(1, blockH)));
    if (player.jumpY <= 0) { player.jumpY = 0; player.jumpV = 0; player.grounded = true; player.c.jumpLv = 0; }
    else player.grounded = false;
  } else player.grounded = true;
}""","""function updateJump(dt) {
  if (!player.c || !player.c.alive) { player.jumpY = 0; player.jumpV = 0; player.grounded = true; player._gWas = null; return; }
  if (player.c.ph.canFly && player.fly > 0.05) { player.jumpY = 0; player.jumpV = 0; player.grounded = true; player._gWas = null; player._fallTop = null; return; }
  const c = player.c;
  const gNow = groundAt(c.x, c.y);
  // The ground dropping away under you is a fall, not a teleport. Whatever it
  // dropped becomes height you are now standing on nothing above.
  if (player._gWas != null) {
    const drop = player._gWas - gNow;
    if (drop > 1.2) { player.jumpY += drop; player.grounded = false; }
  }
  player._gWas = gNow;
  if (player.jumpY > 0 || player.jumpV > 0) {
    player.jumpV -= GRAV * dt;
    player.jumpY += player.jumpV * dt;
    // the highest point of this flight, in world units, is what the landing is measured from
    const topNow = gNow + player.jumpY;
    player._fallTop = player._fallTop == null ? topNow : Math.max(player._fallTop, topNow);
    // terrain steps you can clear while in the air
    const blockH = terrain.hMax * HEIGHT_SCALE / Math.max(1, terrain.ELEV);
    player.c.jumpLv = Math.max(0, Math.floor(player.jumpY / Math.max(1, blockH)));
    if (player.jumpY <= 0) {
      const fell = player._fallTop != null ? player._fallTop - gNow : 0;
      player.jumpY = 0; player.jumpV = 0; player.grounded = true; player.c.jumpLv = 0; player._fallTop = null;
      applyFallDamage(c, fell);
    } else player.grounded = false;
  } else { player.grounded = true; player._fallTop = null; }
}
// Water you fall into takes the impact, as long as it is deep enough to take
// the animal rather than just wet its feet.
function fallBrokenByWater(c) {
  if (!terrain.isWater(c.x, c.y)) return false;
  const deep = waterDepth(terrain, c.x, c.y);
  return deep > Math.max(4, (c.ph.radius || 4) * BODY_SCALE * 1.1);
}
function applyFallDamage(c, fell) {
  if (!c || !c.alive || !isFinite(fell)) return 0;
  const over = fell - FALL_SAFE;
  if (over <= 0) return 0;
  if (fallBrokenByWater(c)) {
    if (fell > FALL_SAFE * 1.6) toast('You hit the water hard. The water took it.', 2000);
    return 0;
  }
  // energy of a fall goes as its height, and a bigger body fares worse for it
  const sizeK = clamp(0.8 + (c.ph.mass || 1) / 40, 0.8, 1.7);
  const frac = Math.pow(over / FALL_FATAL, 1.6) * sizeK;
  const dmg = frac * Math.max(1, c.ph.storage);
  c.energy -= dmg;
  FIGHT.hurtFx = Math.min(1, (FIGHT.hurtFx || 0) + Math.min(0.9, frac * 1.2));
  if (SND.ctx && SND.on) sndThump(Math.min(0.9, 0.25 + frac));
  if (c.energy <= 0) {
    c.alive = false; c.deathCause = 'fall';
    toast('You fell ' + Math.round(fell) + ' feet. It killed you.', 4200);
  } else {
    toast('You fell ' + Math.round(fell) + ' feet. ' + Math.round(frac * 100) + '% of you is gone.', 2600);
  }
  return dmg;
}""")
# the death screen should name it
s=sub1(s,"""  const why = cause === 'drowned' ? 'You drowned.' :""",
         """  const why = cause === 'fall' ? 'You fell.' : cause === 'drowned' ? 'You drowned.' :""")
open(p,'w',encoding='utf-8').write(s)
print('fall damage ok')

# ---- the same rule for everything else in the world (core side) -------------
s=open(p,encoding='utf-8').read()
s=sub1(s,"""      // Tree trunks are solid. Fliers pass over them (sam""","""      // Ground that falls away costs an animal the same as it costs the
      // player. Wild animals carry no flight arc of their own, so the drop
      // they take in a single step IS the fall.
      if (!p.canFly && !terrain.isWater(nx, ny)) {
        const HS2 = terrain.heightScale || 420;
        const fell = (terrain.height(c.x, c.y) - terrain.height(nx, ny)) * HS2;
        if (fell > FALL_SAFE_SIM) {
          const over = fell - FALL_SAFE_SIM;
          const sizeK = clamp(0.8 + (p.mass || 1) / 40, 0.8, 1.7);
          c.energy -= Math.pow(over / FALL_FATAL_SIM, 1.6) * sizeK * Math.max(1, p.storage);
          if (c.energy <= 0) { c.alive = false; c.deathCause = 'fall'; }
        }
      }
      // Tree trunks are solid. Fliers pass over them (sam""")
s=sub1(s,"const HURT_TIME = 5;","const HURT_TIME = 5;\n// The same numbers the player falls by. One world unit is one foot.\nconst FALL_SAFE_SIM = 20, FALL_FATAL_SIM = 70;")
open(p,'w',encoding='utf-8').write(s)
print('sim fall ok')
