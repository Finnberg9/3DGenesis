# GROUND RULES
#  - a real slope limit: nothing walks up anything steeper than 60 degrees, and
#    a body built to scramble (hooves or claws, and not too heavy) gets to 80
#  - fall damage over 20 feet, scaling with the drop, none of it if you land in
#    water deep enough to take you
# One world unit is one foot. A grown animal stands 8 to 15 of them.
def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
p='g3.html'; s=open(p,encoding='utf-8').read()

# ---------------------------------------------------------------- climb stat
# How well a body grips rock: what its legs end in, and how heavy it is. A
# hoofed or clawed light body scrambles; a flat-footed heavy one does not.
s=sub1(s,"""  function jitterDesign(d, rng, rate) {""","""  // What each foot is worth on rock. Hooves and claws grip; flippers do not.
  const GRIP_TIP = { t_claw: 1.0, t_talon: 0.80, t_hoof: 0.65, t_hand: 0.50,
                     t_pincer: 0.35, t_paw: 0.20, t_pad: 0.12, t_flipper: 0 };
  // 0 = walks on flat ground only, 1 = mountain goat.
  function designClimb(d, mass) {
    if (!d || !d.limbs || !d.limbs.length) return 0;
    let n = 0, grip = 0;
    for (const lb of d.limbs) {
      const tip = lb.tip && lb.tip.id;
      const g = tip != null && GRIP_TIP[tip] != null ? GRIP_TIP[tip] : 0.2;
      n++; grip += g;
    }
    if (!n) return 0;
    // The square-cube law: holding yourself on a wall costs strength that goes
    // as area while the weight goes as volume, so this falls away fast with
    // size. A hoofed grazer is not a goat; a small clawed thing is.
    const light = clamp(1.25 - (mass || 1) / 14, 0.05, 1);
    return clamp((grip / n) * light, 0, 1);
  }
  function jitterDesign(d, rng, rate) {""")
s=sub1(s,"      ph.dLegs = X.legs || 0; ph.dArms = X.arms || 0; ph.dSpring = X.spring || 0;",
"""      ph.dLegs = X.legs || 0; ph.dArms = X.arms || 0; ph.dSpring = X.spring || 0;
      ph.climb = designClimb(genome.design, ph.mass);""")
s=sub1(s,"    ITEM_SIM, ITEM_SINGLE, PLANS, BODY_RANGE, planProfile, buildDesignSkeleton, skinField, raySkin, snapToSkin, rarityCap: 'ultra',",
         "    ITEM_SIM, ITEM_SINGLE, PLANS, BODY_RANGE, planProfile, buildDesignSkeleton, skinField, raySkin, snapToSkin, rarityCap: 'ultra', designClimb, GRIP_TIP,")
open(p,'w',encoding='utf-8').write(s)
print('climb stat ok')
s=open(p,encoding='utf-8').read()

# ---------------------------------------------------------------- slope limit
s=sub1(s,"""      if (!p.canFly) {
        const lv0 = terrain.level(c.x, c.y);""","""      if (!p.canFly) {
        const lv0 = terrain.level(c.x, c.y);
        // Slope, measured in the direction of travel over a fixed baseline
        // rather than over the tick's own step, which is far too short to read
        // a gradient from. 60 degrees for anything that walks; a scrambler
        // earns its way up to 80.
        const HSC = terrain.heightScale || 420;
        const climbLim = SLOPE_TAN_WALK + (SLOPE_TAN_CLIMB - SLOPE_TAN_WALK) * Math.pow(clamp(p.climb || 0, 0, 1), 2.5);
        const tooSteep = (bx, by) => {
          const dxm = bx - c.x, dym = by - c.y;
          const L = Math.hypot(dxm, dym);
          if (L < 1e-6) return false;
          const B = SLOPE_BASE;
          const h0 = terrain.height(c.x, c.y);
          const h1 = terrain.height(c.x + dxm / L * B, c.y + dym / L * B);
          const tan = (h1 - h0) * HSC / B;
          // airborne you clear more than you could walk up
          return tan > climbLim + (c.jumpLv || 0) * 0.9;
        };""")
s=sub1(s,"          return terrain.level(bx, by) - lv0 > terrain.maxStep + (c.jumpLv || 0);",
         "          return tooSteep(bx, by);")
# These live in the CORE, beside the other simulation constants: the slope test
# runs inside stepWorld, which is a separate scope from the page.
s=sub1(s,"const HURT_TIME = 5;","""const HURT_TIME = 5;
// 60 degrees is the limit for anything that walks. A body built to scramble
// earns its way to 80. Measured over this baseline, in world units.
const SLOPE_TAN_WALK = 1.7321;    // tan 60
const SLOPE_TAN_CLIMB = 5.6713;   // tan 80
const SLOPE_BASE = 9;""")
open(p,'w',encoding='utf-8').write(s)
print('slope limit ok')

# ---------------------------------------------------------------- fall damage
# Walking off a cliff used to snap you to the ground below with no consequence.
# Now the ground falling away under you puts you in the air, gravity takes over,
# and what you hit at the bottom costs you. Water takes the fall instead.
s=open(p,encoding='utf-8').read()
s=sub1(s,"const GRAV = 520;","""// Falls are measured in the animal's own height, which is the only scale that
// means anything here: bodies run from a lizard to a sauropod and a drop that
// is nothing to one is fatal to the other. A fall under about two and a half
// times your standing height costs nothing; seven heights past that is a full
// body. (The square-cube term in applyFallDamage tilts it further against
// heavy animals, which is how it works in life.)
const PAGE_SLOPE_TAN = 1.7321;   // tan 60, the walking limit, page-side copy
const FALL_SAFE_H = 2.5;
const FALL_FATAL_H = 7;
function fallSafeFor(p) { return Math.max(6, (p && (p.standH || p.radius) || 6) * FALL_SAFE_H); }
function fallFatalFor(p) { return Math.max(14, (p && (p.standH || p.radius) || 6) * FALL_FATAL_H); }
const GRAV = 520;""")
s=sub1(s,"""function updateJump(dt) {
  if (!player.c || !player.c.alive) { player.jumpY = 0; player.jumpV = 0; player.grounded = true; return; }
  if (player.c.ph.canFly) { player.jumpY = 0; player.jumpV = 0; player.grounded = true; return; }
  if (player.jumpY > 0 || player.jumpV > 0) {
    player.jumpV -= GRAV * dt;
    player.jumpY += player.jumpV * dt;
    // terrain steps you can clear while in the air
    const blockH = terrain.hMax * HEIGHT_SCALE / Math.max(1, terrain.ELEV);
    player.c.jumpLv = Math.max(0, Math.floor(player.jumpY / Math.max(1, blockH)));
    if (player.jumpY <= 0) { player.jumpY = 0; player.jumpV = 0; player.grounded = true; player.c.jumpLv = 0; }
    else player.grounded = false;
  } else player.grounded = true;
}""","""function updateJump(dt) {
  if (!player.c || !player.c.alive) { player.jumpY = 0; player.jumpV = 0; player.grounded = true; player._gWas = null; return; }
  if (player.c.ph.canFly && player.fly > 0.05) { player.jumpY = 0; player.jumpV = 0; player.grounded = true; player._gWas = null; player._fallTop = null; return; }
  const c = player.c;
  const gNow = groundAt(c.x, c.y);
  // The ground dropping away under you is a fall, not a teleport. Whatever it
  // dropped becomes height you are now standing on nothing above.
  if (player._gWas != null && player.grounded) {
    // A walk down a slope drops the ground under you too, and with a 60 degree
    // limit that is a lot per frame. Only count a drop that no walk could have
    // produced in the time available.
    const walkDrop = Math.max(2, (c.ph.speedLand || 40) * PAGE_SLOPE_TAN * dt * 1.6);
    const drop = player._gWas - gNow;
    if (drop > walkDrop) { player.jumpY += drop; player.grounded = false; }
  }
  player._gWas = gNow;
  if (player.jumpY > 0 || player.jumpV > 0) {
    player.jumpV -= GRAV * dt;
    player.jumpY += player.jumpV * dt;
    // the highest point of this flight, in world units, is what the landing is measured from
    const topNow = gNow + player.jumpY;
    player._fallTop = player._fallTop == null ? topNow : Math.max(player._fallTop, topNow);
    // terrain steps you can clear while in the air
    const blockH = terrain.hMax * HEIGHT_SCALE / Math.max(1, terrain.ELEV);
    player.c.jumpLv = Math.max(0, Math.floor(player.jumpY / Math.max(1, blockH)));
    if (player.jumpY <= 0) {
      const fell = player._fallTop != null ? player._fallTop - gNow : 0;
      player.jumpY = 0; player.jumpV = 0; player.grounded = true; player.c.jumpLv = 0; player._fallTop = null;
      applyFallDamage(c, fell);
    } else player.grounded = false;
  } else { player.grounded = true; player._fallTop = null; }
}
// Water you fall into takes the impact, as long as it is deep enough to take
// the animal rather than just wet its feet.
function fallBrokenByWater(c) {
  if (!terrain.isWater(c.x, c.y)) return false;
  const deep = waterDepth(terrain, c.x, c.y);
  return deep > Math.max(4, (c.ph.radius || 4) * BODY_SCALE * 1.1);
}
// No message. You felt the ground, you saw the screen flash, and your health
// bar moved: a toast telling you what just happened to you is noise.
function applyFallDamage(c, fell) {
  if (!c || !c.alive || !isFinite(fell)) return 0;
  const over = fell - fallSafeFor(c.ph);
  if (over <= 0) return 0;
  if (fallBrokenByWater(c)) return 0;
  // energy of a fall goes as its height, and a bigger body fares worse for it
  const sizeK = clamp(0.8 + (c.ph.mass || 1) / 40, 0.8, 1.7);
  const frac = Math.pow(over / fallFatalFor(c.ph), 1.6) * sizeK;
  const dmg = frac * Math.max(1, c.ph.storage);
  c.energy -= dmg;
  FIGHT.hurtFx = Math.min(1, (FIGHT.hurtFx || 0) + Math.min(0.9, frac * 1.2));
  if (SND.ctx && SND.on) sndThump(Math.min(0.9, 0.25 + frac));
  if (c.energy <= 0) { c.alive = false; c.deathCause = 'fall'; }
  return dmg;
}""")
# the death screen should name it
s=sub1(s,"""  const why = cause === 'drowned' ? 'You drowned.' :""",
         """  const why = cause === 'fall' ? 'You fell.' : cause === 'drowned' ? 'You drowned.' :""")
open(p,'w',encoding='utf-8').write(s)
print('fall damage ok')

# ---- the same rule for everything else in the world (core side) -------------
s=open(p,encoding='utf-8').read()
s=sub1(s,"""      // Tree trunks are solid. Fliers pass over them (sam""","""      // Ground that falls away costs an animal the same as it costs the
      // player. Wild animals carry no flight arc of their own, so the drop
      // they take in a single step IS the fall.
      if (!p.canFly && !terrain.isWater(nx, ny)) {
        const HS2 = terrain.heightScale || 420;
        const fell = (terrain.height(c.x, c.y) - terrain.height(nx, ny)) * HS2;
        const safe = Math.max(6, (p.standH || p.radius || 6) * FALL_SAFE_H_SIM);
        if (fell > safe) {
          const over = fell - safe;
          const sizeK = clamp(0.8 + (p.mass || 1) / 40, 0.8, 1.7);
          c.energy -= Math.pow(over / Math.max(14, (p.standH || p.radius || 6) * FALL_FATAL_H_SIM), 1.6) * sizeK * Math.max(1, p.storage);
          if (c.energy <= 0) { c.alive = false; c.deathCause = 'fall'; }
        }
      }
      // Tree trunks are solid. Fliers pass over them (sam""")
s=sub1(s,"const HURT_TIME = 5;","const HURT_TIME = 5;\n// The same numbers the player falls by, in body heights.\nconst FALL_SAFE_H_SIM = 2.5, FALL_FATAL_H_SIM = 7;")
open(p,'w',encoding='utf-8').write(s)
print('sim fall ok')

# ---- test surface
s=open(p,encoding='utf-8').read()
s=sub1(s,"  rebuild: () => rebuildWorld(),","""  rebuild: () => rebuildWorld(),
  fall: {
    safeFor: (ph) => fallSafeFor(ph), fatalFor: (ph) => fallFatalFor(ph),
    apply: (c, d) => applyFallDamage(c, d),
    get jumpY() { return player.jumpY; }, get grounded() { return player.grounded; },
  },""")
open(p,'w',encoding='utf-8').write(s)
print('fall api ok')
