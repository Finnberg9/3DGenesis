# Larger, taller world: bigger terrain features, extra massifs, a slope limit
# of 45 degrees everywhere except defined rock cliffs, and a static forest that
# is generated from the terrain and is solid to walkers.
def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
p='g3.html'; s=open(p,encoding='utf-8').read()

s=sub1(s,"    const sx = w / BASE_W, sy = h / BASE_H;",
"""    // featureScale > 1 makes every landform proportionally wider (a bigger map
    // with bigger mountains rather than more of the same small hills)
    const FS = clamp(numOr(terrainOpts.featureScale, 1), 0.5, 4);
    const HS = Math.max(1, numOr(terrainOpts.heightScale, 420));        // elevation 0..1 -> world units
    const MAX_TAN = clamp(numOr(terrainOpts.maxSlope, 1), 0.2, 4);      // walkable slope limit (1 = 45 deg)
    const CLIFF_TAN = clamp(numOr(terrainOpts.cliffSlope, 4.5), MAX_TAN, 12);
    const sx = w / (BASE_W * FS), sy = h / (BASE_H * FS);""")

# extra massifs, inserted before the lakes
s=sub1(s,"""    // inland lakes (small, with a divable centre) kept clear of the massif""","""    // a range of lesser mountains and big hills scattered over the interior
    const hills = [];
    const nHills = 4 + ((rng() * 4) | 0);
    for (let i = 0; i < nHills; i++) {
      for (let k = 0; k < 40; k++) {
        const ha = rng() * TAU, hr = 0.15 + rng() * 0.6;
        const hx = isle.cx + Math.cos(ha) * isle.rx * hr, hy = isle.cy + Math.sin(ha) * isle.ry * hr;
        if (islandMask(hx, hy) < 0.9) continue;
        hills.push({ x: hx, y: hy, r: D * (0.035 + rng() * 0.05), up: 0.12 + rng() * 0.26, p0: rng() * TAU, pw: 1.3 + rng() * 0.8 });
        break;
      }
    }
    // inland lakes (small, with a divable centre) kept clear of the massif""")
s=sub1(s,"""      // ridges (distance to a line segment)
      for (let i = 0; i < ridges.length; i++) {""","""      for (let i = 0; i < hills.length; i++) {
        const hl = hills[i], hdx = x - hl.x, hdy = y - hl.y;
        const hrug = 1 + 0.15 * Math.sin(3 * Math.atan2(hdy, hdx) + hl.p0);
        e += hl.up * reliefMul * Math.pow(fall((Math.hypot(hdx, hdy) / hl.r) * hrug), hl.pw) * m;
      }
      // ridges (distance to a line segment)
      for (let i = 0; i < ridges.length; i++) {""")

# restructure the cache fill: heights first, then slope limit, then biomes
s=sub1(s,"""    for (let j = 0; j < HY; j++) for (let i = 0; i < HX; i++) {
      const px = i * CELL, py = j * CELL, k = j * HX + i;
      const e = rawHeight(px, py);
      hg[k] = e; bg[k] = classify(px, py, e); mg[k] = moisture(px, py);
    }""","""    for (let j = 0; j < HY; j++) for (let i = 0; i < HX; i++) hg[j * HX + i] = rawHeight(i * CELL, j * CELL);
    // ---- slope limit. Any two neighbouring cells may differ by at most
    // tan(limit) * distance. Peaks are cut down and pits filled (two chamfer
    // sweeps each, which is exact for this 8-neighbour metric) so nothing a
    // walker meets is steeper than 45 degrees -- except CLIFF cells: bands of
    // exposed rock on ridgelines and high ground, where the limit is much
    // steeper and the terrain renders as bare rock faces.
    const cliff = new Uint8Array(HX * HY);
    for (let j = 0; j < HY; j++) for (let i = 0; i < HX; i++) {
      const k = j * HX + i, px = i * CELL, py = j * CELL, e = hg[k];
      if (e > LV.sand + 0.06 && ridgedAt(rdgA, px, py) > 0.82 && ridgedAt(valA, px, py) < 0.5) cliff[k] = 1;
    }
    {
      const dA = CELL * MAX_TAN / HS, dC = CELL * CLIFF_TAN / HS;
      const lim = (a, b, diag) => ((cliff[a] && cliff[b]) ? dC : dA) * (diag ? 1.4142 : 1);
      const N8 = [[-1, 0, 0], [0, -1, 0], [-1, -1, 1], [1, -1, 1]];
      for (let pass = 0; pass < 2; pass++) {
        // cut peaks: h <= min(neighbour + limit)
        for (let j = 0; j < HY; j++) for (let i = 0; i < HX; i++) {
          const k = j * HX + i; let v = hg[k];
          for (const [di, dj, dg] of N8) { const ii = i + di, jj = j + dj; if (ii < 0 || jj < 0 || ii >= HX) continue; const q = jj * HX + ii; const c = hg[q] + lim(k, q, dg); if (c < v) v = c; }
          hg[k] = v;
        }
        for (let j = HY - 1; j >= 0; j--) for (let i = HX - 1; i >= 0; i--) {
          const k = j * HX + i; let v = hg[k];
          for (const [di, dj, dg] of N8) { const ii = i - di, jj = j - dj; if (ii < 0 || jj >= HY || ii >= HX) continue; const q = jj * HX + ii; const c = hg[q] + lim(k, q, dg); if (c < v) v = c; }
          hg[k] = v;
        }
        // fill pits: h >= max(neighbour - limit)
        for (let j = 0; j < HY; j++) for (let i = 0; i < HX; i++) {
          const k = j * HX + i; let v = hg[k];
          for (const [di, dj, dg] of N8) { const ii = i + di, jj = j + dj; if (ii < 0 || jj < 0 || ii >= HX) continue; const q = jj * HX + ii; const c = hg[q] - lim(k, q, dg); if (c > v) v = c; }
          hg[k] = v;
        }
        for (let j = HY - 1; j >= 0; j--) for (let i = HX - 1; i >= 0; i--) {
          const k = j * HX + i; let v = hg[k];
          for (const [di, dj, dg] of N8) { const ii = i - di, jj = j - dj; if (ii < 0 || jj >= HY || ii >= HX) continue; const q = jj * HX + ii; const c = hg[q] - lim(k, q, dg); if (c > v) v = c; }
          hg[k] = v;
        }
      }
    }
    for (let j = 0; j < HY; j++) for (let i = 0; i < HX; i++) {
      const px = i * CELL, py = j * CELL, k = j * HX + i;
      bg[k] = classify(px, py, hg[k]); mg[k] = moisture(px, py);
    }""")
s=sub1(s,"""      ELEV, hMax, levelOf, tileSize: TS, LTX, LTY, maxStep: MAXSTEP,""","""      ELEV, hMax, levelOf, tileSize: TS, LTX, LTY, maxStep: MAXSTEP,
      heightScale: HS, cliffAt(x, y) { return cliff[cellIdx(x, y)]; },""")

# world options
s=sub1(s,"""      reliefMul: opts.terrainRelief, waterDepthMul: opts.waterDepthMul, regionDensityMul: opts.regionDensity,
    });""","""      reliefMul: opts.terrainRelief, waterDepthMul: opts.waterDepthMul, regionDensityMul: opts.regionDensity,
      featureScale: opts.featureScale, heightScale: opts.heightScale, maxSlope: opts.maxSlope,
    });""")

# no tree plants any more: trees are the static forest
s=sub1(s,"""    const isTree = roll < (TREE_ODDS[biome] || 6) * (world.params.treeDensity || 1);
    const eScale""","""    const isTree = world.forest ? false : roll < (TREE_ODDS[biome] || 6) * (world.params.treeDensity || 1);
    const eScale""")

# static forest + collision
s=sub1(s,"""  function pushOutOfTrees(pGrid, x, y, cr) {
    if (!pGrid) return null;
    let hit = null, hitD2 = Infinity, hitMinD = 0;""","""  // ---- static forest ------------------------------------------------------
  // Trees are part of the land, generated once from the terrain: a jittered
  // grid, thinned by biome density, moisture and slope, with the species chosen
  // by biome. Kinds: 0 emergent giant, 1 canopy broadleaf, 2 palm, 3 understory
  // tree, 4 conifer, 5 acacia, 6 cactus, 7 mangrove, 8 tree fern.
  const FOREST_DENS = { forest: 0.8, marsh: 0.5, taiga: 0.6, plains: 0.09, savanna: 0.08, beach: 0.14,
                        desert: 0.03, tundra: 0.04, rock: 0.02, scree: 0, snow: 0, shallow: 0.05, deep: 0 };
  const FOREST_CELL = 64;
  const TREE_R = [16, 7.5, 3, 3, 5, 4, 4, 4, 2.2];     // trunk collision radius at scale 1 (bark plus root flare)
  function buildForest(terrain, w, h, density) {
    const trees = [];
    const hsh = (i, j, s) => { let v = ((i * 73856093) ^ (j * 19349663) ^ (s * 83492791)) >>> 0; v = Math.imul(v ^ (v >>> 15), 2246822519) >>> 0; v = Math.imul(v ^ (v >>> 13), 3266489917) >>> 0; return ((v ^ (v >>> 16)) >>> 0) / 4294967296; };
    const HS = terrain.heightScale || 420;
    const nx = Math.ceil(w / FOREST_CELL), ny = Math.ceil(h / FOREST_CELL);
    for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) {
      const x = (i + 0.15 + hsh(i, j, 1) * 0.7) * FOREST_CELL, y = (j + 0.15 + hsh(i, j, 2) * 0.7) * FOREST_CELL;
      if (x < 8 || y < 8 || x > w - 8 || y > h - 8) continue;
      const b = terrain.biomeAt(x, y);
      let dens = (FOREST_DENS[b] || 0) * density;
      if (!dens) continue;
      const m = terrain.moistureAt(x, y);
      dens *= 0.55 + 0.9 * m;
      // no trees on steep ground or cliffs
      const e0 = terrain.height(x, y), ex = terrain.height(x + 16, y), ez = terrain.height(x, y + 16);
      const slope = Math.hypot(ex - e0, ez - e0) * HS / 16;
      if (slope > 0.8 || terrain.cliffAt(x, y)) continue;
      if (hsh(i, j, 3) > dens) continue;
      const r = hsh(i, j, 4), sc = 0.75 + hsh(i, j, 5) * 0.6;
      let kind;
      if (b === 'forest') kind = r < 0.07 ? 0 : r < 0.62 ? 1 : r < 0.78 ? 2 : r < 0.9 ? 3 : 8;
      else if (b === 'marsh' || b === 'shallow') kind = r < 0.6 ? 7 : r < 0.8 ? 2 : 1;
      else if (b === 'taiga' || b === 'tundra') kind = 4;
      else if (b === 'beach') kind = 2;
      else if (b === 'savanna') kind = r < 0.8 ? 5 : 3;
      else if (b === 'desert') kind = 6;
      else if (b === 'rock') kind = r < 0.5 ? 4 : 3;
      else kind = r < 0.45 ? 1 : r < 0.75 ? 3 : 5;
      trees.push({ x, y, kind, s: sc, rot: hsh(i, j, 6) * 6.2832, v: (hsh(i, j, 7) * 3) | 0, trunkR: TREE_R[kind] * sc, isTree: true, forest: true });
    }
    const grid = makeGrid(w, h, 110);
    for (const t of trees) grid.insert(t);
    return { trees, grid };
  }
  function pushOutOfTrees(pGrid, x, y, cr) {
    if (!pGrid) return null;
    let hit = null, hitD2 = Infinity, hitMinD = 0;
    const F = pGrid._forest;
    if (F) F.grid.around(x, y, (pl) => {
      const dx = x - pl.x, dy = y - pl.y, d2 = dx * dx + dy * dy;
      const minD = cr + pl.trunkR;
      if (d2 < minD * minD && d2 < hitD2) { hitD2 = d2; hit = pl; hitMinD = minD; }
    });""")
open(p,'w',encoding='utf-8').write(s)
print('world core ok')
s=open(p,encoding='utf-8').read()
s=sub1(s,"""    // Seed the flora to a real starting density (attempt-capped): the biome""","""    world.forest = buildForest(terrain, w, h, world.params.treeDensity || 1);
    world.pGrid._forest = world.forest;
    // Seed the flora to a real starting density (attempt-capped): the biome""")
open(p,'w',encoding='utf-8').write(s)
print('forest hook ok')
s=open(p,encoding='utf-8').read()
s=sub1(s,"      let e = 0.300 + base * 0.560 * reliefMul;  // land-biased base band",
"      let e = 0.300 + base * 0.560 * reliefMul * BASE_REL;  // land-biased base band")
s=sub1(s,"    const sx = w / (BASE_W * FS), sy = h / (BASE_H * FS);","""    const sx = w / (BASE_W * FS), sy = h / (BASE_H * FS);
    // general lowland roughness, relative to the mountains (1 = original)
    const BASE_REL = clamp(numOr(terrainOpts.baseRelief, 1), 0.1, 2);""")
s=sub1(s,"      featureScale: opts.featureScale, heightScale: opts.heightScale, maxSlope: opts.maxSlope,",
"      featureScale: opts.featureScale, heightScale: opts.heightScale, maxSlope: opts.maxSlope, baseRelief: opts.baseRelief,")
open(p,'w',encoding='utf-8').write(s)
print('base relief ok')
s=open(p,encoding='utf-8').read()
# trees only stop what actually touches them: the collision circle is the body's
# visible half-width, not its half-length (a long snake used to be a huge disc)
s=sub1(s,"const pushed = pushOutOfTrees(pGrid, nx, ny, p.bodyRX || p.radius || 3);",
       "const pushed = pushOutOfTrees(pGrid, nx, ny, trunkClearance(p));")
s=sub1(s,"const pushed = pushOutOfTrees(pGrid, c.x, c.y, c.ph.bodyRX || c.ph.radius || 3);",
       "const pushed = pushOutOfTrees(pGrid, c.x, c.y, trunkClearance(c.ph));")
s=sub1(s,"  function pushOutOfTrees(pGrid, x, y, cr) {","""  function trunkClearance(p) {
    const r = Math.min(p.bodyRX || p.radius || 3, p.bodyRY || p.radius || 3, p.radius || 3);
    return Math.max(0.8, r * 0.5);    // 0.55 is the drawn body scale; a little give on top
  }
  function pushOutOfTrees(pGrid, x, y, cr) {""")
# plant density: the bigger map keeps the old per-area food density on half of it
s=sub1(s,"      maxPlants: Math.max(200, Math.round(CAPS.PLANTS * areaScale)),","      maxPlants: Math.max(200, Math.round(CAPS.PLANTS * areaScale * PLANT_AREA)),")
s=sub1(s,"      maxDeepPlants: Math.max(60, Math.round(CAPS.PLANTS * areaScale * 0.16)),","      maxDeepPlants: Math.max(60, Math.round(CAPS.PLANTS * areaScale * PLANT_AREA * 0.16)),")
s=sub1(s,"    const want = params.plantRate * plantMul * bdt * world.areaScale; // per-area rate","    const want = params.plantRate * plantMul * bdt * world.areaScale * (world.plantArea || 1); // per-area rate")
s=sub1(s,"    const areaScale = (w * h) / (BASE_W * BASE_H);","""    const areaScale = (w * h) / (BASE_W * BASE_H);
    const PLANT_AREA = clamp(numOr(opts.plantArea, 1), 0.1, 1);""")
s=sub1(s,"      w, h, seed, rng, terrain, t: 0, areaScale,","      w, h, seed, rng, terrain, t: 0, areaScale, plantArea: PLANT_AREA,")
open(p,'w',encoding='utf-8').write(s)
print('clearance ok')
s=open(p,encoding='utf-8').read()
s=sub1(s,"""      e = OF + (e - OF) * m;
      return clamp(e, 0, 1);""","""      e = OF + (e - OF) * m;
      // soft ceiling: summits taper toward 1 instead of being sliced into flat mesas
      if (e > 0.78) e = 1 - 0.22 * Math.exp(-(e - 0.78) / 0.22);
      return clamp(e, 0, 1);""")
open(p,'w',encoding='utf-8').write(s)
s=open(p,encoding='utf-8').read()
s=sub1(s,"""  const API = {
    ...DESIGN_API,""","""  const API = {
    ...DESIGN_API,
    pushOutOfTrees, trunkClearance,""")
# the player's own movement uses the same trunk test as every other animal
old=s[s.index("  // Same tree-trunk solidity NPC creatures get in stepWorld (core.js) --"):s.index("  c.x = nx; c.y = ny;\n  // sprint is charged")]
s=s.replace(old,"""  // Same tree-trunk solidity every other animal gets in stepWorld: the static
  // forest plus any tree plants, with the body's visible half-width as clearance.
  // Two passes so squeezing between two close trunks cannot push you into either.
  if (!p.canFly && world.pGrid) {
    for (let it = 0; it < 2; it++) {
      const pushed = C.pushOutOfTrees(world.pGrid, nx, ny, C.trunkClearance(p));
      if (!pushed) break;
      nx = clamp(pushed[0], 1, WORLD_W - 1); ny = clamp(pushed[1], 1, WORLD_H - 1);
    }
  }
""",1)
open(p,'w',encoding='utf-8').write(s)
print('player trees ok')
