# Every creature is a designed body: founders and the "random creature" start
# are drawn from the design vocabulary instead of the legacy node genome.
p='g3.html'; s=open(p,encoding='utf-8').read()
old="""    for (let i = 0; i < world.params.startPop; i++) {
      let g = seedHerbivore(world, rng);
      for (let m = 0; m < _frounds; m++) g = mutate(world, g, rng, _fdiv);"""
new="""    for (let i = 0; i < world.params.startPop; i++) {
      let g = seedHerbivore(world, rng);
      g.design = DESIGN_API.randomDesign(rng, { diversity: Math.max(0.25, _fdiv), diet: rng() < 0.12 ? 'carn' : 'herb' });
      DESIGN_API.compileDesign(g);
      for (let m = 0; m < _frounds; m++) g = mutate(world, g, rng, _fdiv);"""
assert old in s; s=s.replace(old,new)
old="""  const draw = () => {
    let g = C.seedHerbivore(world, rng);
    const rounds = 2 + ((rng() * 6) | 0);"""
new="""  const draw = () => {
    let g = C.seedHerbivore(world, rng);
    g.design = C.randomDesign(rng, { diversity: 0.7, diet: kind === 'hunter' ? 'carn' : 'herb' });
    C.compileDesign(g);
    const rounds = 2 + ((rng() * 6) | 0);"""
assert old in s; s=s.replace(old,new)
open(p,'w',encoding='utf-8').write(s)
print('designall ok')
