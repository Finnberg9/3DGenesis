# Prehistoric pass: dinosaur jaws with teeth (src/dino.js), grey body-shape
# thumbnails, and the editor clearing kept free of trees in front of you.
def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
p='g3.html'; s=open(p,encoding='utf-8').read()
s=sub1(s,"// Shared eye: eyeball, iris and pupil turned toward where the body looks,", open('src/dino.js',encoding='utf-8').read()+"\n// Shared eye: eyeball, iris and pupil turned toward where the body looks,")
# body-shape thumbnails: plain grey silhouettes, no eyes, mouths or ornaments
s=sub1(s,"""    } else if (j.plan != null) {
      const d = C.defaultDesign(j.plan);""","""    } else if (j.plan != null) {
      const d = C.defaultDesign(j.plan);
      d.parts = (d.parts || []).filter(q => { const sim = C.ITEM_SIM[q.id]; return sim && (sim.t === 'FIN' || sim.t === 'WING'); });
      d.col = { base: [0.62, 0.63, 0.64], coat: [0.78, 0.79, 0.80], detail: [0.45, 0.46, 0.48], pat: 0, skin: 0 };""")
# the editor clearing: no trunks close enough to stand between you and your creature
s=sub1(s,"    const a = rnd() * Math.PI * 2, r = 14 + Math.pow(rnd(), 0.7) * 70;","    const a = rnd() * Math.PI * 2, r = 34 + Math.pow(rnd(), 0.7) * 60;")
s=sub1(s,"    const a = rnd() * Math.PI * 2, r = ED_POD_R + 0.4 + Math.pow(rnd(), 0.8) * 40;","    const a = rnd() * Math.PI * 2, r = ED_POD_R + 3.5 + Math.pow(rnd(), 0.8) * 40;")
open(p,'w',encoding='utf-8').write(s)
print('dino ok')
