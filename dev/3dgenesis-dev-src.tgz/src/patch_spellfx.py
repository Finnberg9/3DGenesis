# =====================================================================
# THE MUSHROOMS, MADE READABLE
#
# Three things, all from playing it:
#
#   TOO BIG, TOO MANY. The cap was wider than the animal picking it up and
#   there was one every 760 units. Both cut hard: the cap is roughly a third
#   the size, and the field is about a ninth as dense, so finding one is an
#   event instead of scenery.
#
#   YOU CANNOT TELL WHAT IS RUNNING. Two spells at once has always been
#   allowed -- the multipliers compose -- but the only sign of it was a small
#   line of text in the corner and a tint on the hide you are looking at from
#   behind. The whole screen now carries the colour of everything running:
#   yellow, green, purple or red, breathing, and flashing faster in the last
#   few seconds. Two at once reads as two colours, because each one gets its
#   own layer rather than being averaged into a third colour that means
#   nothing.
#
#   YOU CANNOT TELL WHAT YOU ARE HOLDING. The pouch only listed a slot once
#   you had one. All four are always shown now, dark and struck through when
#   empty, so "press 2" failing is something you can see coming instead of a
#   toast you missed.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, ('ANCHOR %d/%d' % (n, cnt), a[:110]); return s.replace(a, b)

p = 'g3.html'; s = open(p, encoding='utf-8').read()

# ---------------------------------------------------------------- 1. smaller, and rarer
s = sub1(s, "const SHROOM_CELL = 760;        // one candidate per cell",
            "const SHROOM_CELL = 1900;       // one candidate per cell")
s = sub1(s, "const SHROOM_ODDS = 0.42;       // ...and this many cells actually hold one",
            "const SHROOM_ODDS = 0.30;       // ...and this many cells actually hold one. Together: about a ninth of the first cut.")
s = sub1(s, "  const H = 15, CAP = 13;",
"""  // Sized against the animal that picks it up, not against the terrain: the
  // first cut had a cap wider than the creature standing next to it.
  const H = 5.6, CAP = 4.6;""")
s = sub1(s, "      ent = { x, z, id, y: 0, taken: 0, rot: r() * 6.283, s: 0.85 + r() * 0.45, built: false };",
            "      ent = { x, z, id, y: 0, taken: 0, rot: r() * 6.283, s: 0.88 + r() * 0.40, built: false };")
# the reach has to come down with the cap, or you pick one up from a body length away
s = sub1(s, "  const rr = Math.max(26, interactRange(c.ph) * 0.9);",
            "  const rr = Math.max(14, interactRange(c.ph) * 0.65);")

# ---------------------------------------------------------------- 2. the screen carries the colour
s = sub1(s, """<div id="sickfx"></div>""", """<div id="sickfx"></div><div id="spellfx"></div>""")
s = sub1(s, """  #sickfx{position:fixed;inset:0;z-index:4;pointer-events:none;opacity:0;""",
"""  /* One layer per running spell, so two at once reads as two colours rather
     than as a third colour that means nothing. */
  #spellfx{position:fixed;inset:0;z-index:5;pointer-events:none}
  #spellfx i{position:absolute;inset:0;display:block;opacity:0;mix-blend-mode:screen;
    transition:opacity .18s linear}
  #sickfx{position:fixed;inset:0;z-index:4;pointer-events:none;opacity:0;""")
s = sub1(s, """// Push the buffs that live on the creature itself onto the creature.""",
r"""// The whole screen takes the colour of everything running. One <i> per spell,
// created once and then only ever changed in opacity, so this costs nothing
// per frame and cannot leak elements.
function spellFxTick() {
  const host = document.getElementById('spellfx');
  if (!host) return;
  if (!host.childElementCount) {
    for (const k of SPELL_IDS) {
      const el = document.createElement('i');
      const c = SPELL_DEF[k].col;
      const rgb = (a) => 'rgba(' + Math.round(c[0] * 255) + ',' + Math.round(c[1] * 255) + ',' + Math.round(c[2] * 255) + ',' + a + ')';
      // an edge wash, heaviest in the corners, so the middle of the screen
      // stays readable while the colour is unmistakable
      el.style.background = 'radial-gradient(ellipse 96% 88% at 50% 50%, ' +
        rgb(0) + ' 34%, ' + rgb(0.20) + ' 72%, ' + rgb(0.52) + ' 100%)';
      el.dataset.spell = k;
      host.appendChild(el);
    }
  }
  for (const el of host.children) {
    const k = el.dataset.spell, t = spellLeft(k);
    if (!(t > 0)) { if (el.style.opacity !== '0') el.style.opacity = '0'; continue; }
    // breathe slowly, then hurry as it runs out
    const urg = t < 4 ? 6.5 : 1.9;
    const pulse = 0.72 + 0.28 * (0.5 + 0.5 * Math.sin(simT * urg));
    el.style.opacity = (pulse * (t < 0.8 ? t / 0.8 : 1)).toFixed(3);
  }
}
// Push the buffs that live on the creature itself onto the creature.""")
s = sub1(s, """  if (changed) spellApply();
  else if (player.c && player.c.hpMul !== spellHpMul()) spellApply();
}""",
"""  if (changed) spellApply();
  else if (player.c && player.c.hpMul !== spellHpMul()) spellApply();
  spellFxTick();
}""")

# ---------------------------------------------------------------- 3. all four slots, always
# An empty slot is shown dark rather than hidden, so pressing a number and
# getting nothing is something you saw coming instead of a toast you missed.
s = sub1(s, "    const D = SPELL_DEF[k], t = spellLeft(k), n = SPELL.bag[k];\n    if (!n && !(t > 0)) continue;\n"
            "    const c = D.col, css = 'rgb(' + Math.round(c[0] * 255) + ',' + Math.round(c[1] * 255) + ',' + Math.round(c[2] * 255) + ')';\n"
            "    rows.push('<span class=\"sp\" style=\"border-color:' + css + ';color:' + css + '\">' +",
            "    const D = SPELL_DEF[k], t = spellLeft(k), n = SPELL.bag[k] | 0;\n"
            "    const c = D.col, css = 'rgb(' + Math.round(c[0] * 255) + ',' + Math.round(c[1] * 255) + ',' + Math.round(c[2] * 255) + ')';\n"
            "    const live = t > 0, have = n > 0;\n"
            "    const cls = 'sp' + (live ? ' live' : '') + (!have && !live ? ' off' : '');\n"
            "    rows.push('<span class=\"' + cls + '\" style=\"' + (have || live ? 'border-color:' + css + ';color:' + css : '') + '\">' +")
s = sub1(s, "      (t > 0 ? ' <i>' + Math.ceil(t) + 's</i>' : '') + '</span>');\n  }\n"
            "  return rows.length ? '<div class=\"spells\">' + rows.join('') + '</div>' : '';",
            "      (live ? ' <i>' + Math.ceil(t) + 's</i>' : '') + '</span>');\n  }\n"
            "  return '<div class=\"spells\">' + rows.join('') + '</div>';")

s = sub1(s, "  .spells .sp i{font-style:normal;opacity:.75}",
"""  .spells .sp i{font-style:normal;opacity:.75}
  .spells .sp.off{border-color:rgba(190,205,210,.16)!important;color:rgba(190,205,210,.30)!important}
  .spells .sp.live{background:rgba(255,255,255,.10);box-shadow:0 0 10px -2px currentColor}""")

open(p, 'w', encoding='utf-8').write(s)
print('spellfx: size, density and readout ok')
