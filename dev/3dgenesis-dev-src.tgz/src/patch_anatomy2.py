# =====================================================================
# THE BODY GETS A SKELETON
#
# Finn, on the ten shapes shipped earlier today: "they still look like shit,
# like cartoonish characters, with limbs literally floating not even touching
# bodies", "remove the stupid potato body shapes", "the mesh builder you made
# is fucking stupid", "there isn't wet/scary slimy scales, there isn't actual
# detail, exposed bones, curved backs etc like I told you".
#
# He is right, and the reason is structural rather than a matter of taste.
#
# THE BODY WAS ONE CHAIN OF SPHERES. The drawn skin is a smooth union of round
# cones threaded through a single spine, and a smooth union of a chain of
# spheres is a lozenge. There is nowhere in that structure to PUT a ribcage, a
# shoulder blade, a hip point, a vertebral process or a patch of skin stretched
# thin over bone -- so no amount of blend, ribs or keel tuning was ever going to
# produce them. Earlier today I added three parameters trying to get anatomy out
# of a system that has no bones in it. That was the wrong level.
#
# So the torso gets an actual armature, and the skin becomes a SHELL over it:
#
#   spine       a chain of vertebrae with dorsal processes standing up off each
#               one, so a back has a ridge of bone down it instead of being the
#               top of a curve.
#   ribcage     real arcs leaving the backbone, bowing out at the middle and
#               coming back in at the tip. THE RIBS SET THE BODY'S WIDTH. The
#               spine capsule is shrunk to a fraction of the girth and the cage
#               carries the rest, which is the whole difference between a
#               ribcage with skin on it and a sausage.
#   scapula     a flat plate over each shoulder, angled, standing proud.
#   pelvis      a flat plate at each hip, so hips are points rather than a
#               taper.
#   flesh       how much meat sits over the cage. Low and the ribs read through
#               the skin as ridges with hollows between them; high and they are
#               buried and the animal is fat.
#
# Every parameter defaults to zero or one, meaning "exactly what the old code
# did", so no plan written before this moves and no saved design changes shape.
# The ball list is untouched -- part anchors store a ball index, and these are
# emitted straight into the primitive list instead.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, ('ANCHOR %d/%d' % (n, cnt), a[:110]); return s.replace(a, b)

p = 'g3.html'; s = open(p, encoding='utf-8').read()

s = sub1(s, "    const kb = 0.26 * sk.b * (P.blend == null ? 1 : P.blend);",
r"""    const kb = 0.26 * sk.b * (P.blend == null ? 1 : P.blend);

    // ---- the armature ------------------------------------------------------
    // Emitted straight into the primitive list rather than into sk.balls: the
    // balls are the anchor coordinate system that every saved part indexes
    // into, and adding to it would move every anchor on every saved creature.
    const cage = P.ribcage || 0;         // how much of the girth the ribs carry
    const proc = P.spineRow || 0;        // dorsal processes off each vertebra
    const scap = P.scap || 0;            // shoulder blades
    const pelv = P.pelvis || 0;          // hip plates
    const flesh = P.flesh == null ? 1 : P.flesh;   // meat over the cage
    if (cage > 0 || proc > 0 || scap > 0 || pelv > 0) {
      const ax = sk.a, bb = sk.b;
      const spineAt = (u) => {
        const i = Math.min(P.seg - 1, Math.max(0, Math.round(u * (P.seg - 1))));
        return B[i];
      };
      const kBone = kb * 0.55;           // bone welds hard; flesh is what melts

      // -- ribs ---------------------------------------------------------------
      // A rib leaves the backbone, bows OUT at the middle of its arc and comes
      // back IN at the tip, so the two sides reach toward each other under the
      // belly and stop short. z = w sin(th), y = -h (1 - cos th) / 2. An arc
      // that only ever grows is a row of spokes off a stick, which is what the
      // first version of the carcass ribs looked like.
      if (cage > 0) {
        const RN = 6;                    // segments per rib: a curve, not four tubes
        const pairs = 5;
        for (let r = 0; r < pairs; r++) {
          const u = 0.26 + r * 0.13;     // over the chest, not the whole body
          const v = spineAt(u);
          if (!v || v.hide || v.r < 0.02) continue;
          const w = v.r * (1.0 + 1.25 * cage);          // how far out the cage reaches
          const h = v.r * (1.15 + 0.5 * cage);          // how far down it wraps
          const rr = Math.max(0.018 * sk.a, v.r * 0.16);
          const lean = (u - 0.5) * 0.55 * ax;           // the cage rakes back
          for (const side of [1, -1]) {
            let prev = [v.x, v.y + v.r * 0.30, 0];
            for (let q = 1; q <= RN; q++) {
              const th = (q / RN) * 2.42;               // stops short of pi
              const pt2 = [v.x - lean * (q / RN),
                           v.y + v.r * 0.30 - h * (1 - Math.cos(th)) / 2,
                           side * w * Math.sin(th)];
              body.push({ t: 'c', ax: prev[0], ay: prev[1], az: prev[2],
                          bx: pt2[0], by: pt2[1], bz: pt2[2],
                          ra: rr * (1.12 - 0.25 * q / RN), rb: rr * (1.0 - 0.28 * q / RN),
                          k: kBone, i: 0, j: 0 });
              prev = pt2;
            }
          }
        }
      }

      // -- dorsal processes ---------------------------------------------------
      // A blade of bone standing up off each vertebra. This is what gives a
      // back a RIDGE rather than a curve, and it is the single cheapest thing
      // that stops a torso reading as a tube.
      if (proc > 0) {
        for (let i = 1; i < P.seg - 1; i++) {
          const v = B[i];
          if (!v || v.hide || v.r < 0.02) continue;
          const u = i / (P.seg - 1);
          const tall = v.r * proc * (0.45 + 0.75 * Math.sin(Math.PI * Math.pow(u, 0.8)));
          const rr = Math.max(0.014 * sk.a, v.r * 0.13);
          body.push({ t: 'c', ax: v.x, ay: v.y + v.r * 0.45, az: 0,
                      bx: v.x - tall * 0.30, by: v.y + v.r * 0.45 + tall, bz: 0,
                      ra: rr * 1.25, rb: rr * 0.45, k: kBone * 0.8, i: 0, j: 0 });
        }
      }

      // -- scapulae -----------------------------------------------------------
      // Flat, angled, and standing proud of the cage: a shoulder you can see
      // the shape of under the skin.
      // The core SDF is round cones and spheres only -- primDist treats anything
      // that is not a sphere as a cone, so an ellipsoid here returns NaN and
      // poisons the whole field, which is exactly what happened the first time:
      // every part and limb on all ten failed to anchor because raySkin could
      // not find a surface. A blade is a short wide cone lying along its own
      // long axis, which reads the same from outside.
      if (scap > 0) {
        const v = spineAt(0.66);
        if (v && !v.hide) {
          const w = v.r * (0.95 + 0.5 * scap);
          const len = v.r * (0.55 + 0.55 * scap);
          for (const side of [1, -1]) {
            body.push({ t: 'c',
              ax: v.x - len * 0.55, ay: v.y + v.r * 0.55, az: side * w * 0.60,
              bx: v.x + len * 0.35, by: v.y - v.r * 0.10, bz: side * w * 0.80,
              ra: v.r * 0.30 * scap + v.r * 0.10, rb: v.r * 0.16 * scap + v.r * 0.07,
              k: kBone, i: 0, j: 0 });
          }
        }
      }

      // -- pelvis -------------------------------------------------------------
      if (pelv > 0) {
        const v = spineAt(0.26);
        if (v && !v.hide) {
          const w = v.r * (0.90 + 0.45 * pelv);
          const len = v.r * (0.50 + 0.50 * pelv);
          for (const side of [1, -1]) {
            body.push({ t: 'c',
              ax: v.x - len * 0.30, ay: v.y + v.r * 0.55, az: side * w * 0.58,
              bx: v.x + len * 0.50, by: v.y - v.r * 0.05, bz: side * w * 0.78,
              ra: v.r * 0.26 * pelv + v.r * 0.10, rb: v.r * 0.14 * pelv + v.r * 0.07,
              k: kBone, i: 0, j: 0 });
          }
        }
      }
    }""")

# ---- the spine capsule shrinks so the CAGE carries the width
# This is the line that decides sausage or ribcage. With flesh at 1 the spine
# capsule is the whole body and the ribs are buried in it; at 0.45 the spine is
# a backbone and the ribs are what the skin is stretched over.
s = sub1(s, "    for (let i = 0; i + 1 < P.seg; i++) cone(i, i + 1, body, kb);",
r"""    const fleshK = P.flesh == null ? 1 : P.flesh;
    for (let i = 0; i + 1 < P.seg; i++) {
      if (fleshK >= 0.999) { cone(i, i + 1, body, kb); continue; }
      // shrink-wrapped: the spine is a backbone, not the body
      if (!live(i) || !live(i + 1)) continue;
      body.push({ t: 'c', ax: B[i].x, ay: B[i].y, az: B[i].z, bx: B[i + 1].x, by: B[i + 1].y, bz: B[i + 1].z,
                  ra: vr(i) * fleshK, rb: vr(i + 1) * fleshK, k: kb, i, j: i + 1 });
    }""")

open(p, 'w', encoding='utf-8').write(s)
print('anatomy2: the torso has a skeleton in it')

# =====================================================================
# THE LIMB, IN THE RENDERER THE GAME ACTUALLY USES
#
# "the fucking legs are just literal cylinders now" and "remove the ugly ass
# bumps for his joints".
#
# There are TWO limb renderers. drawLimbTube is the palette icon and distant
# crowd path; creaturePrims builds the fused mesh, and THAT is what the game
# draws. This is written in the 2026-09-24 entry in this very file -- "There
# are TWO limb renderers and I had only fixed one" -- and I did it again this
# morning: the chiselled cross-section went into drawLimbTube, so the icons got
# chiselled limbs and every actual creature kept round cones with an ellipsoid
# bead at each end.
#
# The limb is rebuilt here, in the path that matters:
#
#   three bones, not two   femur, tibia, metatarsal. The old limb was thigh and
#                          shin straight to the foot, which is a human leg, and
#                          a human leg on a quadruped reads as a cartoon.
#   a real ankle           `digi` slides the hock UP the limb and kicks it
#                          backward. There is no such thing as a backwards knee
#                          in nature: the rearward joint every animal shows is
#                          the ankle, sitting high with a long metatarsal below
#                          it. That is the whole shape of a bird's or a dog's
#                          hind leg and the game had no way to say it.
#   chiselled sections     each bone is three flattened slabs whose flat face
#                          turns along its length, so rotating the animal shows
#                          a different profile. A constant circular sweep is
#                          exactly what makes a limb read as pipe.
#   no beads               joints are flat plates ACROSS the bone -- wide
#                          crossways, nearly nothing lengthways -- so a knee
#                          reads as a knee cap and a crease, not a marble
#                          threaded on a stick.
# =====================================================================
s = open(p, encoding='utf-8').read()
i0 = s.index("    const dU = v3.norm(v3.sub(knee, root)), dL = v3.norm(v3.sub(foot, knee));")
i1 = s.index("    if (lb.tip && FLESH[lb.tip.id]) {")
s = s[:i0] + r"""    // ---- three bones -------------------------------------------------------
    // The hock: up the shin and kicked back. digi 0 leaves it exactly on the
    // knee-to-foot line, which is the old two-bone limb.
    const digi = (sk.plan && sk.plan.digi) || 0;   // creaturePrims has sk, not P
    const kf = v3.sub(foot, knee);
    const fwd = [foot[0] - root[0], 0, foot[2] - root[2]];
    const fl = Math.hypot(fwd[0], fwd[2]) || 1;
    const backd = [-fwd[0] / fl, 0, -fwd[2] / fl];
    const hockT = 0.30 + 0.28 * digi;
    const hock = [knee[0] + kf[0] * hockT + backd[0] * digi * 0.30 * v3.len(kf),
                  knee[1] + kf[1] * hockT,
                  knee[2] + kf[2] * hockT + backd[2] * digi * 0.30 * v3.len(kf)];
    const rH = s1 * 0.86, rF = s2;

    const perp = (d) => { let e = v3.norm(v3.cross(d, [0, 0, 1])); if (!isFinite(e[0]) || v3.len(e) < 0.5) e = [1, 0, 0]; return e; };
    const dU = v3.norm(v3.sub(knee, root));
    const dM = v3.norm(v3.sub(hock, knee));
    const dL = v3.norm(v3.sub(foot, hock));

    // A bone: the cone is the load-bearing shaft the merge guard measures, and
    // the slabs are the visible surface. The slab's WIDE half-axis is the cone
    // radius and its thin one is 0.56 of that, so the drawn limb is chiselled
    // without the envelope growing past what the guard checks.
    const bone = (A, Bp, ra, rb, boneIdx, twist) => {
      const d = v3.sub(Bp, A), Ln = v3.len(d);
      if (Ln < 1e-5) return;
      const ey = v3.mul(d, 1 / Ln);
      const e0 = perp(ey), e1 = v3.cross(ey, e0);
      out.push({ t: 'c', ax: A[0], ay: A[1], az: A[2], bx: Bp[0], by: Bp[1], bz: Bp[2],
                 ra: ra * 0.70, rb: rb * 0.70, k: 0.03, bone: boneIdx, col });
      const N = 3;
      for (let q = 0; q < N; q++) {
        const um = (q + 0.5) / N;
        const r = ra + (rb - ra) * um;
        const m = v3.lerp(A, Bp, um);
        const ang = um * twist;
        const ca = Math.cos(ang), sa = Math.sin(ang);
        const ex = [e0[0] * ca + e1[0] * sa, e0[1] * ca + e1[1] * sa, e0[2] * ca + e1[2] * sa];
        out.push({ t: 'e', ax: m[0], ay: m[1], az: m[2],
                   ex, ey, ez: v3.cross(ex, ey),
                   rx: r, ry: Ln / N * 0.66, rz: r * 0.56,
                   k: 0.022 * th, bone: boneIdx, col });
      }
    };
    // A joint: a plate ACROSS the bone. Wide crossways, nearly flat lengthways.
    const jointPlate = (P0, dIn, dOut, r, boneIdx, wide) => {
      const ey = v3.norm(v3.add(dIn, dOut));
      const ex = perp(ey);
      out.push({ t: 'e', ax: P0[0], ay: P0[1], az: P0[2],
                 ex, ey, ez: v3.cross(ex, ey),
                 rx: r * wide, ry: r * 0.30, rz: r * wide * 0.72,
                 k: 0.03 * th, bone: boneIdx, col });
    };

    bone(root, knee, s0, s1, up, 1.7);
    bone(knee, hock, s1, rH, up, -1.4);
    bone(hock, foot, rH, rF, lo, 1.1);
    jointPlate(root, dU, dU, s0, up, HIPW * 1.06);
    jointPlate(knee, dU, dM, s1, up, KNEEW * 1.10);
    jointPlate(hock, dM, dL, rH, lo, 1.22);
    // what flesh there is sits high on the femur, and it is a flattened sheet
    // over the bone rather than a ball hung off it
    const L1 = v3.len(v3.sub(knee, root));
    if (L1 > 0.2) {
      const m = v3.lerp(root, knee, 0.28), ey = dU;
      const ex = perp(ey);
      const bulk = lb.id === 'l_spring' ? 1.55 : 1;
      out.push({ t: 'e', ax: m[0], ay: m[1], az: m[2], ex, ey, ez: v3.cross(ex, ey),
                 rx: s0 * 1.16 * bulk, ry: L1 * 0.26 * (bulk > 1 ? 1.2 : 1), rz: s0 * 0.78 * bulk,
                 k: 0.035, bone: up, col });
    }
""" + s[i1:]
open(p, 'w', encoding='utf-8').write(s)
print('anatomy2: three bones, a real ankle, chiselled sections, no beads')

# ---------------------------------------------------------------- the separation pass
# Two corrections, both found the moment the merge guard started measuring the
# slabs instead of only the thin core:
#
# 1. The pass measured the SHAFT radius, but the widest thing on a limb is the
#    joint plate at the hip, which is about a third wider again. So paired legs
#    were being parted until their shafts cleared and their hips were still
#    inside each other -- which is exactly the "ugly bumps" Finn is looking at,
#    two hip caps fused into one lump between the legs. This was true before
#    today; the old guard simply could not see it.
# 2. The drawn limb now has a third bone, and with `digi` the hock is kicked
#    backward off the knee-to-foot line. The pass has to walk the same polyline
#    the renderer draws, or it separates a leg that is not where it thinks.
s = open(p, encoding='utf-8').read()
s = sub1(s, "      let rad = Math.max(rq.r0 * 0.95, 0.030 * G._limbScale);",
r"""      // the widest drawn feature on a limb is the hip plate, not the shaft
      const thc = clamp(rq.th, 0.5, 2.2);
      const capW = 1 + (1.34 - 1) / (0.55 + 0.45 * thc);
      const s0e = Math.max(rq.r0 * 0.82, 0.030 * G._limbScale);
      let rad = Math.max(rq.r0 * 0.95, 0.030 * G._limbScale, s0e * capW * 1.06);""")
s = sub1(s, "      PP.push([hip, v3.add(rt, lb.k), v3.add(rt, lb.f)]);",
r"""      // the same three-bone polyline the renderer walks, hock included
      const kn = v3.add(rt, lb.k), ft = v3.add(rt, lb.f);
      const dg = (sk.plan && sk.plan.digi) || 0;
      const kfv = v3.sub(ft, kn);
      const fwv = [ft[0] - hip[0], 0, ft[2] - hip[2]];
      const fwl = Math.hypot(fwv[0], fwv[2]) || 1;
      const ht = 0.30 + 0.28 * dg;
      const hk = [kn[0] + kfv[0] * ht - (fwv[0] / fwl) * dg * 0.30 * v3.len(kfv),
                  kn[1] + kfv[1] * ht,
                  kn[2] + kfv[2] * ht - (fwv[2] / fwl) * dg * 0.30 * v3.len(kfv)];
      PP.push([hip, kn, hk, ft]);""")
s = sub1(s, "    const ptAt = (P, u) => (u <= 1 ? v3.lerp(P[0], P[1], u) : v3.lerp(P[1], P[2], u - 1));",
            "    const ptAt = (P, u) => (u <= 1 ? v3.lerp(P[0], P[1], u)\n"
            "                          : u <= 2 ? v3.lerp(P[1], P[2], u - 1)\n"
            "                                   : v3.lerp(P[2], P[3], u - 2));")
s = s.replace("ptAt(PP[i], (a / SN) * 2)", "ptAt(PP[i], (a / SN) * 3)")
s = s.replace("ptAt(PP[j], (b / SN) * 2)", "ptAt(PP[j], (b / SN) * 3)")
open(p, 'w', encoding='utf-8').write(s)
print('anatomy2: the separation pass measures what is actually drawn')

# =====================================================================
# THE FLOATING PARTS WERE A SCALE BUG
#
# "this guy's stinger isn't even touching him", "their mouths??? So stupid...
# its not even attached to his fucking body".
#
# Nothing is detached. A part is drawn at `vis.size * scale * R` in its own
# local units, and every part written before today reaches about 0.3 to 1.5
# local units from its anchor. Mine reach 3.6 (the metasoma walks five segments
# plus a telson plus a needle) and 1.5 (the mandible). Then I RAISED their size
# on top of that, to 0.95 and 1.05. Net effect roughly six times oversized: the
# base of the part is buried somewhere inside the torso and the part of it you
# can see is out in mid air. It looks detached because it is enormous.
#
# Sized against their real reach now, not against a guess.
# =====================================================================
s = open(p, encoding='utf-8').read()
# reach ~3.6 local * 0.32 * 1.4 = about 1.6 body radii of tail weapon
s = sub1(s, "  s_sting: { name: 'stinger tail', cat: 'armor', size: 0.95,", "  s_sting: { name: 'stinger tail', cat: 'armor', size: 0.32,")
# reach ~1.5 local * 0.44 * 1.9 = about 1.25 body radii of mouth
s = sub1(s, "  m_bloom: { name: 'split mandible', cat: 'mouth', size: 1.05,", "  m_bloom: { name: 'split mandible', cat: 'mouth', size: 0.44,")
s = sub1(s, "  s_blade: { name: 'bone blades', cat: 'armor', size: 0.52,", "  s_blade: { name: 'bone blades', cat: 'armor', size: 0.30,")
s = sub1(s, "  e_pit: { name: 'pit field', cat: 'eyes', size: 0.34,", "  e_pit: { name: 'pit field', cat: 'eyes', size: 0.26,")
# and the per-plan scales that went with the old sizes
s = sub1(s, "mouthAt('m_bloom', 2.60);", "mouthAt('m_bloom', 1.90);")
s = sub1(s, "mouthAt('m_bloom', 0.95);", "mouthAt('m_bloom', 1.35);")
s = sub1(s, "mouthAt('m_bloom', 1.05);", "mouthAt('m_bloom', 1.20);")
open(p, 'w', encoding='utf-8').write(s)
print('anatomy2: parts sized against their real reach')

# =====================================================================
# COLOUR
#
# "the colour palette is also way too bright, need more neutral/dark scary
# colours similar to what actual animals look like in nature, not RGB colour
# wheel."
#
# Two separate causes. The hides were already fairly dark, but every tooth,
# claw, spike and needle in the game is drawn in IVORY at 0.94 -- brighter than
# anything else on the animal and pure enough to read as plastic, which is what
# makes a dark creature look like a toy with white bits glued on. Real keratin
# and bone in a wet forest are dull, yellowed and dirty. And the new parts were
# carrying pale sand-coloured chitin.
# =====================================================================
s = open(p, encoding='utf-8').read()
s = sub1(s, "const IVORY = [0.94, 0.91, 0.82], KERATIN = [0.30, 0.24, 0.20], BLACKP = [0.03, 0.03, 0.04], WHITE = [0.97, 0.97, 0.95];",
            "// Bone and keratin on a living animal are dull and dirty, not enamel white.\n"
            "const IVORY = [0.58, 0.55, 0.47], KERATIN = [0.22, 0.18, 0.15], BLACKP = [0.03, 0.03, 0.04], WHITE = [0.72, 0.71, 0.67];")
s = sub1(s, "  s_sting: { name: 'stinger tail', cat: 'armor', size: 0.32, col: [0.72, 0.66, 0.54],",
            "  s_sting: { name: 'stinger tail', cat: 'armor', size: 0.32, col: [0.24, 0.21, 0.17],")
s = sub1(s, "  s_blade: { name: 'bone blades', cat: 'armor', size: 0.30, col: [0.86, 0.82, 0.72],",
            "  s_blade: { name: 'bone blades', cat: 'armor', size: 0.30, col: [0.50, 0.47, 0.41],")
s = sub1(s, "  s_spike: { name: 'spike', cat: 'armor', size: 0.3, col: [0.90, 0.86, 0.76], draw(g, c, e) {",
            "  s_spike: { name: 'spike', cat: 'armor', size: 0.3, col: [0.54, 0.50, 0.43], draw(g, c, e) {")
s = sub1(s, "  s_quills: { name: 'quills', cat: 'armor', size: 0.3, col: [0.92, 0.90, 0.84]",
            "  s_quills: { name: 'quills', cat: 'armor', size: 0.3, col: [0.48, 0.45, 0.40]")
open(p, 'w', encoding='utf-8').write(s)
print('anatomy2: bone and keratin are dull, not enamel')

# ---------------------------------------------------------------- the ten, given anatomy
# flesh    how much meat over the cage. Low = shrink-wrapped, ribs read through.
# ribcage  how much of the body's width the cage carries rather than the spine.
# spineRow dorsal processes: the ridge of bone down the back.
# scap     shoulder blades. pelvis: hip points.
# digi     how high the ankle sits and how far back it kicks.
s = open(p, encoding='utf-8').read()
ANAT = {
 38: "flesh: 0.82, ribcage: 0.55, spineRow: 0.40, scap: 0.85, pelvis: 0.65, digi: 0.25",  # armoured, meat over the cage
 39: "flesh: 0.50, ribcage: 0.95, spineRow: 0.85, scap: 0.55, pelvis: 0.35, digi: 0.80",  # starved: every rib shows
 40: "flesh: 0.54, ribcage: 0.90, spineRow: 0.98, scap: 1.00, pelvis: 0.18, digi: 0.88",  # the yoke is all scapula, the hips are gone
 41: "flesh: 0.94, ribcage: 0.22, spineRow: 0.18, scap: 0.30, pelvis: 0.55, digi: 0.92",  # the sac stays SMOOTH: it is the contrast
 42: "flesh: 0.60, ribcage: 0.72, spineRow: 0.62, scap: 0.50, pelvis: 0.50, digi: 1.00",
 43: "flesh: 0.54, ribcage: 1.00, spineRow: 0.50, scap: 0.40, pelvis: 0.40, digi: 0.90",  # a shell over a starved core
 44: "flesh: 0.72, ribcage: 0.48, spineRow: 0.78, scap: 0.20, pelvis: 0.20, digi: 0.60",
 45: "flesh: 0.62, ribcage: 0.68, spineRow: 0.58, scap: 0.60, pelvis: 0.50, digi: 0.85",
 46: "flesh: 0.66, ribcage: 0.88, spineRow: 1.00, scap: 0.92, pelvis: 0.82, digi: 0.70",  # a ridge the length of its back
 47: "flesh: 0.56, ribcage: 1.00, spineRow: 1.00, scap: 0.72, pelvis: 0.75, digi: 1.00",  # nothing to spare anywhere
}
for pi, extra in ANAT.items():
    tag = "}, // %d " % pi
    idx = s.index(tag)
    s = s[:idx] + ", " + extra + s[idx:]
open(p, 'w', encoding='utf-8').write(s)
print('anatomy2: the ten get bones')

# =====================================================================
# THE THINNING PASS COULD DELETE A LEG
#
# Plan 47 came back with no legs at all. Three causes, compounding:
#
# 1. RMIN is the floor that keeps a shaft thick enough for the mesher to
#    extract -- below about one grid cell a shaft comes out as disconnected
#    lumps or as nothing. It was written `RMIN = 0.030 * limbScale * thin`,
#    so the thinning pass scaled down the very floor that exists to stop
#    thinning from deleting the limb. A leg thinned to 0.42 got a floor 0.42
#    as high and vanished under the grid. This predates today.
# 2. The 0.42 clamp is applied per pass and there are three passes, so the
#    true floor was 0.42 cubed -- about 0.07 of the original shaft.
# 3. I then demanded ~30% more clearance (to account for the hip plate), which
#    pushed far more pairs into the thinning path in the first place.
#
# The floor no longer moves, the thinning is clamped once against the original
# thickness rather than compounding, and the hip and knee plates are much
# smaller -- which is what Finn was pointing at anyway: "remove the ugly ass
# bumps for his joints".
# =====================================================================
s = open(p, encoding='utf-8').read()
s = sub1(s, "    const SH = 0.82 * thin, RMIN = 0.030 * G._limbScale * thin;",
            "    // RMIN is the mesher's extraction floor. It must NOT be scaled by the\n"
            "    // thinning factor: that is the floor that stops thinning deleting the limb.\n"
            "    const SH = 0.82 * thin, RMIN = 0.030 * G._limbScale;")
s = sub1(s, "        const f = Math.max(0.42, best / need);\n        THIN[i] = Math.min(THIN[i], f); THIN[j] = Math.min(THIN[j], f);",
            "        // clamped against the ORIGINAL thickness, not against the running\n"
            "        // value, so three passes cannot compound 0.42 into 0.07\n"
            "        const f = Math.max(0.62, best / need);\n"
            "        THIN[i] = Math.max(0.62, Math.min(THIN[i], f));\n"
            "        THIN[j] = Math.max(0.62, Math.min(THIN[j], f));")
# a joint should read as a knuckle, not as a boulder: the plates come right down
s = sub1(s, "    const HIPW = cap(1.34), KNEEW = cap(1.42);", "    const HIPW = cap(1.13), KNEEW = cap(1.17);")
s = sub1(s, "      let rad = Math.max(rq.r0 * 0.95, 0.030 * G._limbScale, s0e * capW * 1.06);",
            "      let rad = Math.max(rq.r0 * 0.95, 0.030 * G._limbScale, s0e * capW * 1.02);")
s = sub1(s, "      const capW = 1 + (1.34 - 1) / (0.55 + 0.45 * thc);", "      const capW = 1 + (1.13 - 1) / (0.55 + 0.45 * thc);")
open(p, 'w', encoding='utf-8').write(s)
print('anatomy2: thinning can no longer delete a limb, and the beads are gone')

# =====================================================================
# A RIB THINNER THAN THE GRID IS NOT A RIB
#
# First pass put the cage in at 0.16 of the vertebra's radius. The mesher sizes
# its cells off the model's whole bounding span, so on a plan that is mostly leg
# a rib that thin is about one cell across -- and marching cubes needs roughly
# two cells to produce a ridge you can see. So the cage was built, was inside
# the skin, and came out as a smooth lozenge. Exactly the "too skinny to create"
# failure from 2026-09-24, this time on bone instead of limbs.
#
# The fix is not thinner ribs drawn more carefully. It is that the CAGE IS THE
# BODY WALL: ribs thick enough to nearly touch their neighbours, welded at a
# blend small enough that the groove between two of them survives. What you see
# then is not tubes under a skin, it is a barrel of bone with the skin drawn
# down into the gaps -- which is what a ribcage actually looks like on a starved
# animal, and what `flesh` now trades against.
# =====================================================================
s = open(p, encoding='utf-8').read()
s = sub1(s, "          const rr = Math.max(0.018 * sk.a, v.r * 0.16);",
            "          // thick enough to survive extraction AND to nearly meet its neighbour\n"
            "          const rr = Math.max(0.055 * sk.a, v.r * 0.30);")
s = sub1(s, "        const pairs = 5;", "        const pairs = 6;")
s = sub1(s, "          const u = 0.26 + r * 0.13;     // over the chest, not the whole body",
            "          const u = 0.22 + r * 0.115;    // over the chest, not the whole body")
s = sub1(s, "          const rr = Math.max(0.014 * sk.a, v.r * 0.13);",
            "          const rr = Math.max(0.045 * sk.a, v.r * 0.22);")
# and the processes need to stand clear of the back, not sit in it
s = sub1(s, "          const tall = v.r * proc * (0.45 + 0.75 * Math.sin(Math.PI * Math.pow(u, 0.8)));",
            "          const tall = v.r * proc * (0.85 + 1.15 * Math.sin(Math.PI * Math.pow(u, 0.8)));")
open(p, 'w', encoding='utf-8').write(s)
print('anatomy2: the cage is the body wall')

# =====================================================================
# EVERY PART IN THE GAME WAS ANCHORED HALF A UNIT OFF THE BODY
#
# "limbs literally floating not even touching bodies", "its not even attached
# to his fucking body". This is not the new parts. It is every part on every
# one of the 48 plans, and it has been true since the body moved from metaballs
# to signed distance fields.
#
#   skinField(sk, x, y, z) = SKIN_ISO - sdfSkin(...)     with SKIN_ISO = 0.5
#
# Parts, limb hips and everything else that asks "where is the surface" ask
# skinField, which answers "where sdfSkin equals 0.5" -- half a world unit
# OUTSIDE the primitives. But the mesher extracts the surface at sdfSkin = 0.
# So the drawn skin and the surface everything is pinned to are two different
# surfaces, a fixed 0.5 apart, and nothing scales that offset with the animal.
#
# Measured on plan 47: drawn half-width 0.168, anchoring half-width 1.081. The
# anchor surface is five and a half times the body's own radius away from the
# body. On a big animal it is a visible gap; on a small one the part is in orbit.
#
# 0.5 is a leftover from the metaball field, where the iso was a threshold on a
# sum of falloffs and 0.5 meant "about 0.8 of a ball radius". Against a true
# distance field it means half a metre of empty air. The comment above VISR even
# says the radii are already the visible radii.
#
# The iso is zero now: the surface parts are pinned to IS the surface that gets
# drawn.
# =====================================================================
s = open(p, encoding='utf-8').read()
s = sub1(s, "  const SKIN_REACH = 1.55, SKIN_ISO = 0.5;",
            "  // SKIN_ISO must be the level the mesher extracts at, which is zero. Any\n"
            "  // other value pins every part to a surface that is not the one drawn.\n"
            "  const SKIN_REACH = 1.55, SKIN_ISO = 0.0;")
open(p, 'w', encoding='utf-8').write(s)
print('anatomy2: parts are pinned to the surface that is actually drawn')

# ---- ribs have to leave a GROOVE, and the groove has a minimum width too
# Six pairs at 0.115 apart, drawn thick enough to survive the grid, overlap each
# other completely: the cage welds into a smooth barrel and the body is a
# lozenge again. Both the rib AND the gap between two ribs have to be wider than
# the mesher's cell, so the count is set by the grid, not by anatomy: fewer,
# heavier ribs with real air between them.
s = open(p, encoding='utf-8').read()
s = sub1(s, "        const pairs = 6;", "        const pairs = 4;")
s = sub1(s, "          const u = 0.22 + r * 0.115;    // over the chest, not the whole body",
            "          const u = 0.24 + r * 0.185;    // over the chest, not the whole body")
# and the editor's own body is worth a finer grid than the crowd's
s = sub1(s, "  const maxCells = [64, 96, 124][clamp(quality | 0, 0, 2)], minCells = [36, 48, 56][clamp(quality | 0, 0, 2)];",
            "  const maxCells = [64, 96, 168][clamp(quality | 0, 0, 2)], minCells = [36, 48, 56][clamp(quality | 0, 0, 2)];")
open(p, 'w', encoding='utf-8').write(s)
print('anatomy2: ribs with air between them')

# ---- the backbone still has to connect the ribs
# flesh 0.34 shrank the spine capsule below the mesher's cell, so the gaps
# between two ribs had no body in them at all and plan 47 came out with holes
# through the middle of it. The backbone gets the same extraction floor the
# limbs have: it may be a backbone rather than a body, but it may not vanish.
s = open(p, encoding='utf-8').read()
s = sub1(s, """      body.push({ t: 'c', ax: B[i].x, ay: B[i].y, az: B[i].z, bx: B[i + 1].x, by: B[i + 1].y, bz: B[i + 1].z,
                  ra: vr(i) * fleshK, rb: vr(i + 1) * fleshK, k: kb, i, j: i + 1 });""",
"""      const SPMIN = 0.045 * Math.max(sk.a, 2 * sk.b);
      body.push({ t: 'c', ax: B[i].x, ay: B[i].y, az: B[i].z, bx: B[i + 1].x, by: B[i + 1].y, bz: B[i + 1].z,
                  ra: Math.max(vr(i) * fleshK, SPMIN), rb: Math.max(vr(i + 1) * fleshK, SPMIN),
                  k: kb, i, j: i + 1 });""")
open(p, 'w', encoding='utf-8').write(s)
print('anatomy2: the backbone cannot vanish')

# ---- three of them were too thin to carry any detail at all
# The mesher sizes its grid off the model's WHOLE bounding span, so on a plan
# that is mostly leg, neck and tail, the body gets very few cells across it.
# Plans 47, 39 and 44 had body radii of 0.30, 0.28 and 0.40 against spans of
# five or six units: about six cells across the entire torso. At that
# resolution a ribcage is not a ribcage, it is a row of disconnected beads with
# holes between them, which is exactly what the numbers showed (relief above
# 100% of the body radius, and five sample points with no body at all).
#
# "Starved" has to mean the flesh is thin over the frame, not that the animal is
# a wire. The three thin ones get a torso you can actually see, and their spans
# come down so the grid is not being spent on empty air.
s = open(p, encoding='utf-8').read()
s = sub1(s, "{ a: 0.74, b: 0.30, seg: 11, prof: 'insect', arch: 0.86,", "{ a: 0.82, b: 0.54, seg: 11, prof: 'insect', arch: 0.86,")
s = sub1(s, "{ a: 0.80, b: 0.28, seg: 9,  prof: 'tube',   arch: 0.12,", "{ a: 0.86, b: 0.46, seg: 9,  prof: 'tube',   arch: 0.12,")
s = sub1(s, "{ a: 2.05, b: 0.40, seg: 19, prof: 'tube',   arch: 0.58,", "{ a: 1.70, b: 0.56, seg: 17, prof: 'tube',   arch: 0.58,")
# and the backbone floor keyed off the real span rather than off the torso
s = sub1(s, "      const SPMIN = 0.045 * Math.max(sk.a, 2 * sk.b);",
            "      // keyed off the whole animal, because that is what sets the grid\n"
            "      const SPMIN = 0.026 * Math.max(sk.a * 2, sk.b * 4, (P.stand || 1) * 2);")
open(p, 'w', encoding='utf-8').write(s)
print('anatomy2: a torso you can actually resolve')
