# =====================================================================
# WHAT A MATCH STARTS AS
#
#   NOTHING ON YOU. Everyone drops into their bay as a bare body: the shape
#   they chose, with legs and eyes and nothing else. No jaw, no horn, no
#   spike, no claw. Every weapon in the match came off the island or off
#   somebody, which is the only way "collect and equip as the game goes on"
#   can be true for all fifty players rather than for whoever shopped hardest
#   before queueing. Your pouch of parts is put aside for the duration and
#   handed back intact when the match ends.
#
#   A PILE IN YOUR CAGE. Sitting on the floor of your own bay is a small heap
#   holding a mouth and one random spike or claw. That is your opening kit,
#   it is the same size for everyone, and taking it is the first thing you do
#   with the thirty seconds before the gate.
#
#   NO WILDLIFE. Not thinned out over five minutes: none, ever. A match is
#   players. The island's old bodies are still lying around to be searched,
#   so there is still loot on the ground, but nothing breathing that is not
#   somebody.
#
#   A CAGE THAT HOLDS YOU. The confinement was applied before your movement
#   ran, so every frame you were pulled back to the wall and then walked
#   straight back out of it: you could leave through any face, including the
#   three with bars across them. It is applied after the move now, and the
#   gate face is only open once the gate is actually up.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, ('ANCHOR %d/%d' % (n, cnt), a[:110]); return s.replace(a, b)

p = 'g3.html'; s = open(p, encoding='utf-8').read()

# ---------------------------------------------------------------- 1. no wildlife, ever
s = sub1(s, "  startPop: 200,            // a living island worth hunting",
            "  startPop: 0,              // a match is players. Nothing else breathes on this island.")
s = sub1(s, "  prerun: 30,               // biological seconds run before the gates, so the island is not empty",
            "  prerun: 0,                // nothing to run forward: there is no ecosystem in a match")
# and a sweep, because a rule that depends on one number being zero is a rule
# waiting for something else to spawn one
s = sub1(s, """  // The island empties partway through, whoever is left alive. It is a clock
  // on the loot, not a truce.
  if (BR.phase === 'open' && BR.t >= BR_CAGE_SECS + BR_WILD_SECS) {
    if (!BR._wildSaid) { BR._wildSaid = true; brSay('THE ISLAND EMPTIES. Only players are left.', 7000); }
    brCullWildlife(dt);
  }""",
"""  // Nothing that is not a player is allowed to be alive in a match. The
  // ruleset builds the island empty; this is the guard that keeps it that
  // way whatever else in the page decides to spawn something.
  brNoWildlife();""")
s = sub1(s, """const BR_CULL_SECS = 30;
function brCullWildlife(dt) {""",
"""// Anything alive that is not somebody's body, gone. Cheap: in a match the
// creature list is the players and nothing else, so this walks fifty entries.
function brNoWildlife() {
  if (!world || !world.creatures) return;
  const list = world.creatures;
  for (let i = 0; i < list.length; i++) {
    const c = list[i];
    if (!c.alive || c._br != null || c === player.c) continue;
    c.alive = false;
    c.deathCause = 'oldage';
    if (world.onDeath) { try { world.onDeath(c); } catch (e) { /* remains are cosmetic */ } }
  }
}
const BR_CULL_SECS = 30;
function brCullWildlife(dt) {""")
# the HUD line about the island emptying has nothing left to count down to
s = sub1(s, "  else if (BR.phase === 'open') {\n    const wl = Math.ceil(BR_CAGE_SECS + BR_WILD_SECS - BR.t);\n    phase = wl > 0 ? 'LIVE \u00b7 island empties in ' + wl + 's' : 'LIVE \u00b7 players only';\n  }",
            "  else if (BR.phase === 'open') phase = 'LIVE \u00b7 ' + a.n + ' left';")

# ---------------------------------------------------------------- 2. a bare body
s = sub1(s, "// ---- match -----------------------------------------------------------------",
r"""// ---- what you walk in as ---------------------------------------------------
// A match body is the shape you chose and nothing else on it. Limbs stay,
// because a creature that cannot walk is not a fighter, and their tips are
// reset to a plain foot so a bought claw cannot sneak in on the end of a leg.
// Eyes stay, because being blind is not a fair start. Everything that does
// damage or soaks it comes off.
const BR_BARE_TIP = { LIMB: 't_paw' };
function brBareDesign(des) {
  const src = des && des.plan != null ? des : C.defaultDesign(0);
  const d = C.cloneDesign(src);
  // keep only the eyes: they are how you see, not how you fight
  d.parts = (d.parts || []).filter((pt) => {
    const sim = C.ITEM_SIM[pt.id];
    return sim && sim.t === 'EYE';
  });
  for (const lb of d.limbs || []) {
    if (lb.tip) lb.tip = { id: BR_BARE_TIP.LIMB, c: null, s: 1 };
  }
  return d;
}
// The opening kit, rolled per player from the match seed so everyone's bay
// holds an equivalent heap and nobody can reroll theirs.
const BR_PILE_MOUTHS = ['m_beak', 'm_grazer', 'm_jaws', 'm_hook', 'm_duck'];
const BR_PILE_ARMS = ['s_spike', 's_knob', 's_quills', 's_plate', 't_claw', 't_talon', 'h_straight', 'h_curved'];
function brPileFor(slot) {
  const r = carcRng(carcHash(slot | 0, 0x10de, BR.seed >>> 0));
  return [BR_PILE_MOUTHS[Math.floor(r() * BR_PILE_MOUTHS.length)],
          BR_PILE_ARMS[Math.floor(r() * BR_PILE_ARMS.length)]];
}

// ---- match -----------------------------------------------------------------""")

# every bot walks in bare too, and carries its own pile straight away: a bot
# has no hands to press E with, so it is given what its bay held
s = sub1(s, """      const g = C.seedHerbivore(world, rng);
      g.design = C.randomDesign(rng, { diversity: 0.85, diet: rng() < 0.55 ? 'carn' : 'herb', rarityCap: world.rarityCap });
      C.compileDesign(g);""",
"""      const g = C.seedHerbivore(world, rng);
      // Bare, exactly like you: the shape is random, the kit is not there.
      g.design = brBareDesign(C.randomDesign(rng, { diversity: 0.85, diet: rng() < 0.55 ? 'carn' : 'herb', rarityCap: world.rarityCap }));
      C.compileDesign(g);""")

# ---------------------------------------------------------------- 3. your inventory is not in the match
# Held aside rather than wiped, so a match can never cost you what you own.
s = sub1(s, "  brSpawnBots();\n  spellReset();          // nothing carries into a match",
"""  brSpawnBots();
  brStashInventory();    // what you own is yours; it is just not in this match
  spellReset();          // nothing carries into a match""")
s = sub1(s, "function brStop() {\n  try { brNamesHide(0); } catch (e) { /* the layer may not exist yet */ }",
"""function brStop() {
  try { brRestoreInventory(); } catch (e) { console.warn('br: inventory restore', e); }
  try { brNamesHide(0); } catch (e) { /* the layer may not exist yet */ }""")
s = sub1(s, "function brSay(msg, ms) {",
r"""// Your own parts are put in a drawer for the length of the match and handed
// back exactly as they were. A match must not be able to spend, lose or grant
// anything you keep between matches -- only bones, which the match pays out
// separately and deliberately.
function brStashInventory() {
  if (BR._stash) return;
  BR._stash = JSON.parse(JSON.stringify(PROG.owned || {}));
  PROG.owned = {};
  BR._pileTaken = false;
  saveProgress();
  if (typeof edRefreshUI === 'function' && ED.open) edRefreshUI();
}
function brRestoreInventory() {
  if (!BR._stash) return;
  PROG.owned = BR._stash;
  BR._stash = null;
  saveProgress();
  if (typeof edRefreshUI === 'function' && ED.open) edRefreshUI();
}
// ---- the pile on your cage floor -------------------------------------------
// Where the heap sits inside a bay: just inside the back wall, so it is the
// first thing you see when you turn away from the gate.
function brPilePos(bay) {
  if (!bay) return null;
  const ca = Math.cos(bay.yaw), sa = Math.sin(bay.yaw);
  const lx = -BR_CAGE_R * 0.52;
  return { x: bay.x + lx * ca, z: bay.z + lx * sa, y: bay.y };
}
function brPileHere() {
  if (!BR.on || BR.phase !== 'cage' || BR._pileTaken) return null;
  const bay = BR.bays[BR.slot], c = player.c;
  if (!bay || !c || !c.alive) return null;
  const q = brPilePos(bay);
  return Math.hypot(q.x - c.x, q.z - c.y) < 26 ? q : null;
}
function brTakePile() {
  if (!brPileHere()) return { ok: false, why: 'none' };
  const ids = brPileFor(BR.slot);
  for (const id of ids) ownedGain(id, 1);
  BR._pileTaken = true;
  FOL.key = '';                       // the heap comes off the floor now
  const names = ids.map((id) => (VIS[id] ? VIS[id].name : id)).join(' and a ');
  toast('You take a ' + names + '. Press B to put them on before the gate opens.', 5000);
  if (SND.ctx && SND.on) { sndThump(0.3); sndNoiseBurst(1400, 8, 0.14, 0.16, 0, 0.9); }
  return { ok: true, ids };
}
function brSay(msg, ms) {""")

open(p, 'w', encoding='utf-8').write(s)
print('brstart: rules ok')

# =====================================================================
# Part 2: walking in bare, the heap on the floor, and a cage that holds.
# =====================================================================
s = open(p, encoding='utf-8').read()

# ---------------------------------------------------------------- 4. you walk in bare
s = sub1(s, """function brEnterMatch(design, net) {
  brArm(net);
  return Promise.resolve(rebuildWorld()).then(() => {
    if (design) { try { becomeDesigned(design); } catch (e) { console.warn('br: could not take that creature in', e); } }""",
"""function brEnterMatch(design, net) {
  brArm(net);
  return Promise.resolve(rebuildWorld()).then(() => {
    // Your shape comes in. Your kit does not: everyone starts the match bare
    // and builds their beast out of what this island and these players give up.
    const bare = brBareDesign(design || (ED.des ? ED.des : null));
    try { becomeDesigned(bare); } catch (e) { console.warn('br: could not take that creature in', e); }""")

# ---------------------------------------------------------------- 5. the heap on the cage floor
s = sub1(s, "function buildShroomMesh() {",
r"""// The opening kit, as a thing on the floor: a low heap of bone and plate with
// a lit core, so it reads from the far corner of the bay.
const BR_PILE_BONE = [0.80, 0.77, 0.70];
function buildPileMesh() {
  const m = folMB();
  brBox(m, 0, 1.0, 0, 7.0, 1.0, 5.2, BR_PILE_BONE, MAT_STEEL);
  brBox(m, -1.6, 2.4, 0.8, 4.2, 1.2, 3.0, fcol(BR_PILE_BONE, 0.88), MAT_STEEL);
  brBox(m, 2.0, 2.9, -0.9, 3.0, 1.5, 2.2, fcol(BR_PILE_BONE, 0.94), MAT_STEEL);
  brBox(m, 0.2, 4.3, 0.2, 1.9, 1.2, 1.6, fcol(BR_PILE_BONE, 1.02), MAT_STEEL);
  // a few shards standing out of it, so it is obviously parts and not a rock
  for (const [dx, dz, h] of [[-4.2, 1.8, 3.4], [4.4, 1.2, 2.8], [-1.2, -3.4, 3.0], [3.0, 3.2, 2.2]]) {
    brBox(m, dx, 2.0 + h * 0.5, dz, 0.5, h * 0.5, 0.5, fcol(BR_PILE_BONE, 1.05), MAT_STEEL);
  }
  // the lit core: this is what you see across the cage
  brBox(m, 0, 2.6, 0, 2.4, 0.9, 2.0, [0.98, 0.88, 0.45], MAT_GLOW);
  return m;
}
function brPutPile(put, camX, camZ) {
  if (!BR.on || BR.phase !== 'cage' || BR._pileTaken || !BRMESH.pile) return;
  const bay = BR.bays[BR.slot];
  const q = brPilePos(bay);
  if (!q) return;
  put(BRMESH.pile, q.x, q.y, q.z, bay.yaw, 1, [1, 1, 1]);
}
function buildShroomMesh() {""")
s = sub1(s, "const BRMESH = { cage: null, gate: null, signpost: null, digits: [], shroom: null, ready: false };",
            "const BRMESH = { cage: null, gate: null, signpost: null, digits: [], shroom: null, pile: null, ready: false };")
s = sub1(s, "  BRMESH.shroom = folUpload(buildShroomMesh());",
            "  BRMESH.shroom = folUpload(buildShroomMesh());\n  BRMESH.pile = folUpload(buildPileMesh());")
s = sub1(s, "  shroomPut(put, camX, camZ);", "  shroomPut(put, camX, camZ);\n  brPutPile(put, camX, camZ);")

# E takes whatever is under your nose: the heap first, then a mushroom
s = sub1(s, "    if (k === 'e') { const r = shroomTake(); if (!r.ok && r.why === 'none') toast('Nothing to pick up here.', 900); }",
"""    if (k === 'e') {
      let r = brTakePile();
      if (!r.ok) r = shroomTake();
      if (!r.ok && r.why === 'none') toast('Nothing to pick up here.', 900);
    }""")
# and the prompt says so
s = sub1(s, """    const sh = shroomAt();
    if (sh) {""",
"""    if (brPileHere()) {
      const ids = brPileFor(BR.slot).map((id) => (VIS[id] ? VIS[id].name : id));
      act.innerHTML = '<div class="acth" style="color:#f5d98a">YOUR STARTING KIT</div>' +
        '<div class="keys"><span class="ok">E</span> take the pile &middot; a ' + ids[0] + ' and a ' + ids[1] +
        ' &middot; <span class="ok">B</span> to put them on</div>';
      act.style.display = 'block';
      return;
    }
    const sh = shroomAt();
    if (sh) {""")

# ---------------------------------------------------------------- 6. a cage that holds you
# Applied AFTER the move, which is the whole bug: clamping first and then
# letting the input run put you one step outside the bars every single frame.
s = sub1(s, """  c.x = nx; c.y = ny;
  // sprint is charged at the core's own gait rate, on biological time""",
"""  c.x = nx; c.y = ny;
  // The cage is a wall, and a wall has to be the last word on where you are.
  if (BR.on && BR.phase === 'cage') brConfineToCage(c, BR.bays[BR.slot]);
  // sprint is charged at the core's own gait rate, on biological time""")
# and the gate face opens only when the gate is actually up
s = sub1(s, """function brConfineToCage(c, bay) {
  if (!bay) return;
  const r = BR_CAGE_R - (c.ph ? c.ph.radius * BODY_SCALE : 4) - 1.5;
  if (r <= 0) { c.x = bay.x; c.y = bay.z; return; }
  const ca = Math.cos(bay.yaw), sa = Math.sin(bay.yaw);
  const dx = c.x - bay.x, dz = c.y - bay.z;
  const lx = clamp(dx * ca + dz * sa, -r, r);
  const lz = clamp(-dx * sa + dz * ca, -r, r);
  c.x = bay.x + lx * ca - lz * sa;
  c.y = bay.z + lx * sa + lz * ca;
}""",
"""function brConfineToCage(c, bay) {
  if (!bay) return;
  const r = BR_CAGE_R - (c.ph ? c.ph.radius * BODY_SCALE : 4) - 1.5;
  if (r <= 0) { c.x = bay.x; c.y = bay.z; return; }
  const ca = Math.cos(bay.yaw), sa = Math.sin(bay.yaw);
  const dx = c.x - bay.x, dz = c.y - bay.z;
  // Local axes: +x is the gate face, which is the only one that ever opens,
  // and it only opens once the gate has actually lifted.
  const gateOpen = BR.gateY > 0.5;
  const lx = clamp(dx * ca + dz * sa, -r, gateOpen ? 1e9 : r);
  const lz = clamp(-dx * sa + dz * ca, -r, r);
  c.x = bay.x + lx * ca - lz * sa;
  c.y = bay.z + lx * sa + lz * ca;
}""")

# ---------------------------------------------------------------- 7. test surface
s = sub1(s, "    wildSecs: BR_WILD_SECS,",
"""    wildSecs: BR_WILD_SECS,
    get gateY() { return BR.gateY; },
    // everything alive that is not a player: must be zero, always
    wildAlive: () => (world && world.creatures ? world.creatures.filter((c) => c.alive && c._br == null && c !== player.c).length : -1),
    bare: (slot) => {
      const q = BR.players[slot == null ? BR.slot : slot];
      const d = q && q.c && q.c.genome ? q.c.genome.design : null;
      if (!d) return null;
      const cats = {};
      for (const pt of d.parts || []) { const sim = C.ITEM_SIM[pt.id]; if (sim) cats[sim.t] = (cats[sim.t] || 0) + 1; }
      const tips = (d.limbs || []).map((l) => (l.tip ? l.tip.id : null));
      return { parts: (d.parts || []).length, limbs: (d.limbs || []).length, cats, tips,
               weapon: +(q.c.ph.weapon || 0).toFixed(4), hp: Math.round(C.hpMaxC(q.c)) };
    },
    pile: () => {
      const bay = BR.bays[BR.slot], q = brPilePos(bay);
      return { taken: !!BR._pileTaken, ids: brPileFor(BR.slot), here: !!brPileHere(), x: q ? Math.round(q.x) : null, z: q ? Math.round(q.z) : null };
    },
    goToPile: () => { const q = brPilePos(BR.bays[BR.slot]); if (!q) return null; window.__G3D.teleport(q.x, q.z); return q; },
    takePile: () => brTakePile(),
    owned: () => Object.assign({}, PROG.owned),
    stashed: () => (BR._stash ? Object.assign({}, BR._stash) : null),
    // push the body at a cage wall and report whether it stayed inside
    testWall: (lx, lz) => {
      const bay = BR.bays[BR.slot], c = player.c;
      if (!bay || !c) return null;
      const ca = Math.cos(bay.yaw), sa = Math.sin(bay.yaw);
      c.x = bay.x + lx * ca - lz * sa; c.y = bay.z + lx * sa + lz * ca;
      brConfineToCage(c, bay);
      const dx = c.x - bay.x, dz = c.y - bay.z;
      return { lx: +(dx * ca + dz * sa).toFixed(1), lz: +(-dx * sa + dz * ca).toFixed(1), R: BR_CAGE_R };
    },""")

open(p, 'w', encoding='utf-8').write(s)
print('brstart: kit and cage ok')

# health readouts, where the match checks can reach them
s = open(p, encoding='utf-8').read()
s = sub1(s, "    hitAllowed: (v, a) => brHitAllowed(v, a),",
"""    hitAllowed: (v, a) => brHitAllowed(v, a),
    hpMaxOf: (c) => C.hpMaxC(c),
    hpOf: (c) => C.hpOf(c),""")
open(p, 'w', encoding='utf-8').write(s)
print('brstart: hp readouts ok')
