// =====================================================================
// REMAINS: every animal that dies near you leaves a skeleton built from its
// own body plan. The spine follows its real vertebra chain, ribs arc over its
// real body width, the skull sits where its head was, the neck and tail are
// its own chains, and each limb it actually had lies splayed from its real
// socket. Rotting flesh clings to the bones at first and shrinks away; the
// bones then yellow and slowly sink into the soil until they are gone.
// =====================================================================
const REMAINS = [];
const REMAINS_MAX = 48;
const REMAINS_LIFE = 420;      // seconds of game time until fully buried
const REMAINS_ROT = 45;        // flesh gone after this
const REMAINS_DRAW_R = 1100;
function remainsAdd(c) {
  if (!c || c._remains || !c.ph || !c.genome || !c.genome.design) return;
  c._remains = true;
  const d = Math.hypot(c.x - player.camX, c.y - player.camZ);
  if (d > 3500) return;                                  // too far to ever be seen
  let G;
  try { G = designGeo(c.genome.design); } catch (e) { return; }
  if (!G || !G.sk) return;
  if (REMAINS.length >= REMAINS_MAX) REMAINS.shift();
  REMAINS.push({
    x: c.x, z: c.y, yaw: c._yaw3 != null ? c._yaw3 : Math.atan2(c.vy || 0, c.vx || 1),
    R: (c.ph.radius || 4) * BODY_SCALE, G, t0: simT,
    seed: (c.id * 2654435761) >>> 0,
    hide: deadTypes(c),
  });
}
// deterministic per-skeleton jitter so bones do not lie in perfect symmetry
function remRand(r, i) { let h = (r.seed ^ Math.imul(i + 1, 0x9E3779B1)) >>> 0; h = Math.imul(h ^ (h >>> 15), 2246822519) >>> 0; return ((h ^ (h >>> 13)) >>> 0) / 4294967296; }
function drawRemains(t) {
  if (!REMAINS.length) return;
  for (let ri = REMAINS.length - 1; ri >= 0; ri--) {
    const r = REMAINS[ri];
    const age = simT - r.t0;
    if (age > REMAINS_LIFE || age < -1) { REMAINS.splice(ri, 1); continue; }
    const dcam = Math.hypot(r.x - player.camX, r.z - player.camZ);
    if (dcam > REMAINS_DRAW_R) continue;
    drawSkeleton(r, age, dcam);
  }
}
function drawSkeleton(r, age, dcam) {
  const sk = r.G.sk, B = sk.balls, P = sk.plan || { seg: 0 };
  const S = r.R;
  const cy = Math.cos(r.yaw), sy = Math.sin(r.yaw);
  const gy = groundAt(r.x, r.z);
  const k = age / REMAINS_LIFE;
  // bones sink as the soil takes them: nothing for a while, then steadily
  const sinkK = clamp((k - 0.25) / 0.75, 0, 1);
  const rot = clamp(1 - age / REMAINS_ROT, 0, 1);         // 1 fresh .. 0 clean
  const fresh = [0.86, 0.80, 0.68], old = [0.58, 0.53, 0.43];
  const bone = [fresh[0] + (old[0] - fresh[0]) * k, fresh[1] + (old[1] - fresh[1]) * k, fresh[2] + (old[2] - fresh[2]) * k];
  const boneD = [bone[0] * 0.72, bone[1] * 0.70, bone[2] * 0.66];
  const flesh = [0.30, 0.05, 0.05], dark = [0.07, 0.05, 0.04];
  // spine height above ground in body units (a collapsed carcass)
  let maxR = 0.3;
  for (let i = 0; i < P.seg; i++) if (B[i] && !B[i].hide) maxR = Math.max(maxR, B[i].r);
  const hs = maxR * 0.62;
  const sinkBy = (hs + 0.35) * S * sinkK * 1.15;
  // body-local (x fwd, y up, z side) -> world, ground-relative
  const W = (x, y, z) => [r.x + (x * cy - z * sy) * S, gy + y * S - sinkBy, r.z + (x * sy + z * cy) * S];
  const lod = dcam > 500 ? 1 : 0;
  const T = (a, b, ra, rb, col) => { const A = W(a[0], a[1], a[2]), Bp = W(b[0], b[1], b[2]); pushT(A[0], A[1], A[2], Bp[0], Bp[1], Bp[2], ra * S, col, rb * S); };
  const Ball = (p, rad, col) => { const w = W(p[0], p[1], p[2]); pushS(w[0], w[1], w[2], 0, 1, 0, rad * S, rad * S, rad * S, col); };
  const El = (p, dir, sx, syy, sz, col) => { const w = W(p[0], p[1], p[2]); const dw = [dir[0] * cy - dir[2] * sy, dir[1], dir[0] * sy + dir[2] * cy]; pushS(w[0], w[1], w[2], dw[0], dw[1], dw[2], sx * S, syy * S, sz * S, col); };
  // ---- spine and ribs
  const spine = [];
  for (let i = 0; i < P.seg; i++) { const b = B[i]; if (b && !b.hide && Math.abs(b.z) < 1e-3) spine.push(b); }
  spine.sort((a, b) => a.x - b.x);
  const vr = 0.055 + maxR * 0.035;
  const sp = spine.map((b, i) => [b.x, hs * (0.55 + 0.45 * b.r / maxR) + (remRand(r, i) - 0.5) * 0.03, (remRand(r, i + 50) - 0.5) * 0.05]);
  for (let i = 0; i < sp.length; i++) {
    if (i) T(sp[i - 1], sp[i], vr, vr, bone);
    if (!lod) Ball(sp[i], vr * 1.45, bone);             // vertebra
  }
  // ribs over the widest part of the body, on both sides
  const ribN = lod ? 3 : 4;
  for (let i = 0; i < spine.length; i++) {
    const b = spine[i];
    if (b.r < maxR * 0.55) continue;
    const top = sp[i];
    for (const side of [-1, 1]) {
      // some ribs have broken or been dragged off by scavengers
      if (remRand(r, i * 3 + side + 7) < 0.12 + 0.25 * k) continue;
      const w = b.r * (0.95 + remRand(r, i * 5 + side) * 0.1);
      const splay = 0.10 + 0.25 * remRand(r, i * 7 + side);   // collapsed outward
      let prev = top;
      for (let q = 1; q <= ribN; q++) {
        const th = (q / ribN) * 1.85;
        const p = [b.x + side * 0 - 0.06 * q / ribN, Math.max(0.04, top[1] * Math.cos(th) * (1 - splay * 0.5)),
                   side * w * Math.sin(th) * (1 + splay)];
        T(prev, p, vr * 0.62, vr * 0.5, q === ribN ? boneD : bone);
        prev = p;
      }
      if (rot > 0.02 && !lod) Ball([b.x, top[1] * 0.45, side * w * 0.7], 0.16 * b.r * rot, flesh);
    }
    if (rot > 0.02) El([b.x, hs * 0.35, 0], [1, 0, 0], b.r * 0.55 * rot, b.r * 0.5 * rot, b.r * 0.45 * rot, flesh);   // guts, shrinking
  }
  // ---- neck, skull and jaw
  const head = B[sk.headIdx], neck = [];
  for (let i = P.seg; i < B.length; i++) if (B[i] && B[i].g === 'neck' && !B[i].hide) neck.push(B[i]);
  let prevN = sp.length ? sp[sp.length - 1] : [0, hs, 0];
  for (let i = 0; i < neck.length; i++) {
    const n = neck[i];
    const p = [n.x, Math.max(vr * 1.2, hs * (0.6 - 0.5 * (i + 1) / (neck.length + 1))), (i + 1) * 0.06 * (remRand(r, 90) - 0.5)];
    T(prevN, p, vr * 1.05, vr * 1.0, bone);
    if (!lod) Ball(p, vr * 1.5, bone);
    prevN = p;
  }
  if (head && !head.hide) {
    const hr = head.r;
    const hx = head.x, hz = neck.length * 0.08 * (remRand(r, 91) - 0.5);
    const hp = [hx, hr * 0.62, hz];
    T(prevN, hp, vr, vr, bone);
    // cranium, an elongated snout, dark eye sockets and a dropped jaw
    El(hp, [1, 0, 0], hr * 0.72, hr * 0.9, hr * 0.62, bone);
    const snout = B[sk.headIdx + 1] && B[sk.headIdx + 1].g === 'head' ? B[sk.headIdx + 1] : null;
    const tipX = snout ? snout.x + snout.r * 0.6 : hx + hr * 1.2;
    T([hx + hr * 0.3, hr * 0.7, hz], [tipX, hr * 0.42, hz], hr * 0.42, hr * 0.2, bone);
    if (!lod) {
      for (const s2 of [-1, 1]) Ball([hx + hr * 0.3, hr * 0.85, hz + s2 * hr * 0.42], hr * 0.2, dark);   // orbits
      Ball([tipX - hr * 0.05, hr * 0.46, hz], hr * 0.08, dark);                                              // nasal opening
      T([hx - hr * 0.1, hr * 0.14, hz + hr * 0.28], [tipX - hr * 0.1, hr * 0.08, hz + hr * 0.36], hr * 0.12, hr * 0.07, boneD);
      T([hx - hr * 0.1, hr * 0.14, hz - hr * 0.28], [tipX - hr * 0.1, hr * 0.08, hz - hr * 0.36], hr * 0.12, hr * 0.07, boneD);
    }
    if (rot > 0.02) El(hp, [1, 0, 0], hr * 0.55 * rot, hr * 0.5 * rot, hr * 0.5 * rot, flesh);
  }
  // ---- tail
  const tail = [];
  for (let i = sk.tailStart || B.length; i < B.length; i++) if (B[i] && B[i].g === 'tail' && !B[i].hide) tail.push(B[i]);
  let prevT = sp.length ? sp[0] : [0, hs, 0];
  const curl = (remRand(r, 99) - 0.5) * 1.6;
  for (let i = 0; i < tail.length; i++) {
    const tb = tail[i], u = (i + 1) / tail.length;
    const p = [tb.x, Math.max(0.05, hs * 0.5 * (1 - u)), curl * u * u * 0.6];
    const rr = Math.max(0.02, vr * (1 - 0.7 * u));
    T(prevT, p, rr, rr * 0.9, bone);
    if (!lod && i % 2 === 0) Ball(p, rr * 1.4, bone);
    prevT = p;
  }
  // ---- limbs: every limb it had, splayed flat from its real socket
  const limbs = r.G.cls ? r.G.cls.limbs : [];
  for (let li = 0; li < limbs.length; li++) {
    const o = limbs[li];
    if (r.hide && r.hide.has(o.leg ? 'LEG' : 'ARM')) continue;
    const lb = o.lb; if (!lb || !lb.k || !lb.f) continue;
    const side = o.root[2] >= 0 ? 1 : -1;
    const th = (lb.th || 1) * 0.06 + 0.02;
    const root = [o.root[0], Math.max(th, hs * 0.55), o.root[2] * 0.8];
    // lay the leg down: its drop becomes sideways reach along the ground
    const flat = (v, j) => [v[0] * (0.8 + 0.3 * remRand(r, li * 11 + j)), 0, side * (Math.abs(v[2]) + Math.abs(v[1]) * 0.9)];
    const kv = flat(lb.k, 1), fv = flat(lb.f, 2);
    const knee = [root[0] + kv[0], th * 1.2, root[2] + kv[2]];
    const foot = [root[0] + fv[0], th, root[2] + fv[2]];
    T(root, knee, th * 1.05, th * 0.85, bone);
    T(knee, foot, th * 0.85, th * 0.7, bone);
    if (!lod) {
      Ball(root, th * 1.6, bone); Ball(knee, th * 1.35, bone);
      // digits
      const dx = foot[0] - knee[0], dz = foot[2] - knee[2], dl = Math.hypot(dx, dz) || 1;
      for (let q = -1; q <= 1; q++) {
        const a = Math.atan2(dz, dx) + q * 0.35;
        T(foot, [foot[0] + Math.cos(a) * th * 3.2, th * 0.5, foot[2] + Math.sin(a) * th * 3.2], th * 0.4, th * 0.2, boneD);
      }
      void dl;
    }
  }
  // a dark stain of soil and old blood under it, fading as it is buried
  if (false) {   // stain disabled: read as a dark dome from low angles
    const len = (spine.length ? spine[spine.length - 1].x - spine[0].x : 1) + maxR;
    const w = W(0, 0.02, 0);
    pushSX(w[0], gy + 0.25, w[2], 0, 1, 0, cy, 0, sy, len * S * 0.75, 0.1, maxR * S * 1.5, [0.16 - 0.06 * k, 0.07, 0.05]);
  }
}

// Every death passes through here (world.onDeath). Something you wounded that
// bleeds out, or dies of its wounds, within 25 s still counts as your kill.
function onWorldDeath(c) {
  remainsAdd(c);
  const me = player.c;
  if (!me || !me.alive || c === me || c._creditedKill) return;
  if (c._hitByPlayerT != null && simT - c._hitByPlayerT < 25) {
    c._creditedKill = true;
    c.deathCause = 'predation';
    if (FIGHT.lock === c) FIGHT.lock = null;
    toast('Your prey bled out. The kill is yours: its body lies where it fell.', 2600);
    try { edOnKill(c); } catch (e) { console.warn(e); }
  }
}
