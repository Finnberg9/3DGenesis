// =====================================================================
// 3D AUDIO, FOOTSTEPS AND THE PROXIMITY WARNING
//
// Every positional sound goes through an HRTF PannerNode placed at the
// source's world position, with the AudioListener moved and turned with your
// head every frame. On headphones that gives full 360-degree placement: an
// animal behind you sounds behind you, not just left or right, and turning
// your head during a long roar moves it around you. Distance loudness and
// muffling stay with the existing hand-tuned curves (panner rolloff is 0), so
// the panner only decides direction.
//
// Animals near you make footsteps from their bodies: step rate from speed and
// leg length, weight from mass (big animals thud, small ones patter) and a
// surface from the ground (leaf litter, grass, sand, rock, snow, splashes).
// Meat eaters stalking you growl more often the closer they get.
//
// The proximity warning replaces the old ground rings: red arcs around the
// centre of the screen at the true bearing of every animal close to you, as
// in Fortnite's sound visualiser. Arcs brighten and widen as it closes, flash
// on each of its footsteps and turn solid for anything hunting you.
// =====================================================================
const SPAT = { lastPos: [0, 0, 0], ok: false };
const STEP_R = 650;          // footsteps audible within this
const STEP_MAX = 8;          // nearest animals that get footsteps
const PROX_R = 620;          // proximity arcs within this
const GROWL_R = 520;         // stalking meat eaters growl within this

// listener: at your eyes, facing where you look
function sndListener() {
  const ctx = SND.ctx; if (!ctx) return;
  const L = ctx.listener;
  const x = player.camX, y = player.camY, z = player.camZ;
  const fx = Math.cos(player.yaw) * Math.cos(player.pitch), fy = Math.sin(player.pitch), fz = Math.sin(player.yaw) * Math.cos(player.pitch);
  const t = ctx.currentTime;
  try {
    if (L.positionX) {
      L.positionX.setTargetAtTime(x, t, 0.02); L.positionY.setTargetAtTime(y, t, 0.02); L.positionZ.setTargetAtTime(z, t, 0.02);
      L.forwardX.setTargetAtTime(fx, t, 0.02); L.forwardY.setTargetAtTime(fy, t, 0.02); L.forwardZ.setTargetAtTime(fz, t, 0.02);
      L.upX.setValueAtTime(0, t); L.upY.setValueAtTime(1, t); L.upZ.setValueAtTime(0, t);
    } else {
      L.setPosition(x, y, z);
      L.setOrientation(fx, fy, fz, 0, 1, 0);
    }
    SPAT.lastPos = [x, y, z]; SPAT.ok = true;
  } catch (e) { SPAT.ok = false; }
}
// A world position that sndVoice / voxOut understand in place of a stereo pan.
function sndAt(x, z, y) {
  return { spatial: true, x, y: y != null ? y : groundAt(x, z) + 8, z };
}
function sndAtC(c) {
  if (!c || !c.ph) return 0;
  if (c === player.c) return 0;                       // your own body: centred
  return sndAt(c.x, c.y, groundAt(c.x, c.y) + (c.ph.standH || c.ph.radius || 4) * BODY_SCALE * 1.3);
}
// a random direction at a distance, for unseen sources (calls, distant roars)
function sndRandDir(dist) {
  const a = Math.random() * Math.PI * 2, d = dist || 1500;
  const x = player.camX + Math.cos(a) * d, z = player.camZ + Math.sin(a) * d;
  return { spatial: true, x, y: player.camY + (Math.random() * 0.3 - 0.05) * d * 0.3, z };
}
// Offset form kept for older callers: returns a world position now, not a pan.
function sndPan(dx, dz) {
  const lx = player.c ? player.c.x : player.camX, lz = player.c ? player.c.y : player.camZ;
  return sndAt(lx + dx, lz + dz, player.camY);
}
// The node a voice connects into for a given placement (number = stereo pan)
function sndPlacer(ctx, pan, dest) {
  if (pan && pan.spatial && SPAT.ok && ctx.createPanner) {
    const p = ctx.createPanner();
    p.panningModel = 'HRTF';
    p.distanceModel = 'linear'; p.rolloffFactor = 0; p.refDistance = 1; p.maxDistance = 1e7;
    const t = ctx.currentTime;
    if (p.positionX) { p.positionX.setValueAtTime(pan.x, t); p.positionY.setValueAtTime(pan.y, t); p.positionZ.setValueAtTime(pan.z, t); }
    else p.setPosition(pan.x, pan.y, pan.z);
    p.connect(dest);
    return p;
  }
  // stereo fallback (or a plain number for centred UI sounds)
  let v = 0;
  if (typeof pan === 'number') v = pan;
  else if (pan && pan.spatial) {
    const dx = pan.x - SPAT.lastPos[0], dz = pan.z - SPAT.lastPos[2], d = Math.hypot(dx, dz) || 1;
    v = clamp((-Math.sin(player.yaw) * dx + Math.cos(player.yaw) * dz) / d, -1, 1);
  }
  if (!v || !ctx.createStereoPanner) return dest;
  const s = ctx.createStereoPanner(); s.pan.value = v; s.connect(dest);
  return s;
}
function sndVoice(build, pan, when) {
  const ctx = SND.ctx; if (!ctx) return;
  build(ctx, sndPlacer(ctx, pan, SND.master), when || ctx.currentTime);
}
// distance of a placement from your ears (0 for centred)
function sndDist(pan) {
  if (!pan || !pan.spatial) return 0;
  return Math.hypot(pan.x - SPAT.lastPos[0], pan.z - SPAT.lastPos[2]);
}

// ---------------------------------------------------------------- footsteps
function stepSurface(x, z) {
  if (terrain.isWater(x, z)) return 'water';
  const b = terrain.biomeAt(x, z);
  if (b === 'forest' || b === 'marsh') return forestCanopyAt(x, z) > 0.3 || b === 'marsh' ? (b === 'marsh' ? 'mud' : 'leaf') : 'grass';
  if (b === 'rock' || b === 'tundra') return 'rock';
  if (b === 'snow') return 'snow';
  if (b === 'beach' || b === 'desert') return 'sand';
  return 'grass';
}
// one footfall: a thud scaled by weight plus a surface layer
function sndStep(pos, mass, surf, vol) {
  if (!SND.ctx || !SND.on || vol < 0.004) return;
  const heavy = clamp(Math.log2(1 + mass) / 5, 0.05, 1.3);
  sndVoice((ctx, out, t) => {
    // body: a low thump, deeper and longer for heavy animals
    if (heavy > 0.25) {
      const o = ctx.createOscillator(); o.type = 'sine';
      const f0 = 95 - 45 * Math.min(1, heavy);
      o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(f0 * 0.55, t + 0.09 + 0.12 * heavy);
      const g = ctx.createGain(); g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(vol * (0.5 + 0.9 * heavy), t + 0.008);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.12 + 0.2 * heavy);
      o.connect(g).connect(out); o.start(t); o.stop(t + 0.4 + 0.2 * heavy);
    }
    // surface: filtered noise with a material-specific colour
    const S = {
      leaf:  [2600, 0.8, 0.11, 1.0, 1.25],
      grass: [1800, 0.9, 0.08, 0.7, 1.1],
      mud:   [520, 1.4, 0.16, 0.9, 0.6],
      rock:  [3200, 2.2, 0.035, 0.55, 1.5],
      snow:  [1200, 0.7, 0.12, 0.8, 0.8],
      sand:  [2100, 0.6, 0.07, 0.6, 1.0],
      water: [900, 0.9, 0.22, 1.3, 0.7],
    }[surf] || [1800, 0.9, 0.08, 0.7, 1.0];
    const n = ctx.createBufferSource(); n.buffer = SND.noiseBuf; n.playbackRate.value = S[4] * (1.3 - 0.4 * Math.min(1, heavy));
    const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = S[0] * (1.15 - 0.35 * Math.min(1, heavy)); f.Q.value = S[1];
    const g2 = ctx.createGain(); const dur = S[2] * (0.8 + 0.8 * heavy);
    g2.gain.setValueAtTime(0.0001, t); g2.gain.exponentialRampToValueAtTime(vol * S[3] * (0.35 + 0.5 * Math.min(1, heavy)), t + 0.006);
    g2.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    n.connect(f).connect(g2).connect(out); n.start(t, Math.random() * 1.5); n.stop(t + dur + 0.05);
  }, pos);
}
function sndWingbeat(pos, mass, vol) {
  if (!SND.ctx || !SND.on || vol < 0.004) return;
  sndVoice((ctx, out, t) => {
    const n = ctx.createBufferSource(); n.buffer = SND.noiseBuf; n.playbackRate.value = 0.5;
    const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 700 - 300 * Math.min(1, mass / 20);
    const g = ctx.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + 0.05); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.22);
    n.connect(f).connect(g).connect(out); n.start(t, Math.random()); n.stop(t + 0.3);
  }, pos);
}
function stepVolume(d) { return d >= STEP_R ? 0 : 0.5 / (1 + d / 70) * (1 - d / STEP_R); }
// how often this body puts a foot down, seconds (0 = not walking)
function stepInterval(c, sp) {
  if (sp < 4) return 0;
  const p = c.ph;
  const leg = Math.max(2, (p.standH || p.radius || 4) * BODY_SCALE * 1.6);
  const feet = Math.max(2, p.dLegs || 2);
  const stride = leg * 2.2;
  // strides per second, then more footfalls for more feet (capped: a centipede patters, not buzzes)
  return clamp(stride / sp / Math.min(feet / 2, 3), 0.07, 1.1);
}
let spatNearBuf = [];
function spatTick(dt) {
  sndListener();
  const me = player.c;
  const lx = player.camX, lz = player.camZ;
  // nearest walkers
  const near = spatNearBuf; near.length = 0;
  for (const o of world.creatures) {
    if (!o.alive || !o.ph) continue;
    const d = Math.hypot(o.x - lx, o.y - lz);
    if (d > STEP_R) { o._stepFlash = 0; continue; }
    o._stepFlash = Math.max(0, (o._stepFlash || 0) - dt * 4);
    near.push({ o, d });
  }
  near.sort((a, b) => a.d - b.d);
  const audible = SND.ctx && SND.on;
  for (let i = 0; i < near.length && i < STEP_MAX; i++) {
    const { o, d } = near[i];
    const isMe = o === me;
    let sp;
    if (isMe) sp = Math.hypot(o.vx || 0, o.vy || 0) * (player.grounded ? 1 : 0);
    else sp = Math.hypot(o.vx || 0, o.vy || 0);
    const iv = stepInterval(o, sp);
    if (!iv) { o._stepT = 0; continue; }
    o._stepT = (o._stepT || 0) + dt;
    if (o._stepT < iv) continue;
    o._stepT -= iv; if (o._stepT > iv) o._stepT = 0;
    o._stepFlash = 1;
    if (!audible) continue;
    const vol = isMe ? 0.10 : stepVolume(d) * (o.ph.carnivory > 0.5 ? 1.15 : 1);
    const pos = isMe ? 0 : sndAt(o.x, o.y, groundAt(o.x, o.y) + 1);
    if (o.ph.canFly && !isMe && (o.alt || 0) > 5) sndWingbeat(pos, o.ph.mass, vol * 0.8);
    else sndStep(pos, o.ph.mass || 1, stepSurface(o.x, o.y), vol);
  }
  // stalkers growl more often as they close in
  if (audible && me && me.alive && typeof voxCall === 'function') {
    for (const { o, d } of near) {
      if (o === me || o.ph.carnivory <= 0.5 || d > GROWL_R) continue;
      const hunting = o.foe === me || o.target === me;
      if (!hunting) continue;
      o._growlT = (o._growlT == null ? 1.5 : o._growlT) - dt;
      if (o._growlT <= 0) {
        voxCall(o, 'threat');
        o._growlT = 2.2 + 5 * (d / GROWL_R) + Math.random() * 2;
      }
    }
  }
}

// ---------------------------------------------------------------- proximity warning
let proxCv = null, proxCtx = null;
function proxDraw() {
  if (!proxCv) {
    proxCv = document.getElementById('proxfx');
    if (!proxCv) return;
    proxCtx = proxCv.getContext('2d');
  }
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const W = Math.floor(proxCv.clientWidth * dpr), H = Math.floor(proxCv.clientHeight * dpr);
  if (proxCv.width !== W || proxCv.height !== H) { proxCv.width = W; proxCv.height = H; }
  const g = proxCtx;
  g.clearRect(0, 0, W, H);
  const me = player.c;
  if (!me || !me.alive || player.spectator || ED.open) return;
  const cx = W / 2, cy = H / 2, R = Math.min(W, H) * 0.36;
  const fx = Math.cos(player.yaw), fz = Math.sin(player.yaw);
  const now = performance.now() / 1000;
  let drawn = 0;
  for (const o of world.creatures) {
    if (o === me || !o.alive || !o.ph) continue;
    const dx = o.x - me.x, dz = o.y - me.y, d = Math.hypot(dx, dz);
    if (d > PROX_R || d < 1e-3) continue;
    const moving = Math.hypot(o.vx || 0, o.vy || 0) > 4;
    const hunting = o.foe === me || o.target === me || FIGHT.pending.some(s => s.att === o);
    const danger = hunting || (o.ph.carnivory > 0.5 && o.ph.attack > me.ph.defense * 0.5);
    if (!moving && !hunting) continue;                 // still animals make no sound to show
    const near = 1 - d / PROX_R;
    if (!danger && near < 0.35) continue;              // distant grazers are not worth a warning
    const fwd = dx * fx + dz * fz, side = -dx * fz + dz * fx;
    const ang = Math.atan2(side, fwd);                  // 0 = ahead, + = to your right
    const flash = o._stepFlash || 0;
    const a = clamp((danger ? 0.35 : 0.04) + near * (danger ? 0.65 : 0.40) + flash * 0.25, 0, 1) *
              (hunting ? 0.8 + 0.2 * Math.sin(now * 9) : 1);
    const span = 0.10 + 0.30 * near + (danger ? 0.06 : 0);
    const w = (danger ? 4 + 9 * near : 2 + 5 * near) * dpr;
    // screen angle: ahead is up, right is right
    const sa = ang - Math.PI / 2;
    g.beginPath();
    g.arc(cx, cy, R + (1 - near) * R * 0.25, sa - span / 2, sa + span / 2);
    g.strokeStyle = `rgba(${danger ? 255 : 235},${danger ? 38 : 70},${danger ? 30 : 55},${a.toFixed(3)})`;
    g.lineWidth = w; g.lineCap = 'round';
    g.shadowColor = 'rgba(255,30,20,0.8)'; g.shadowBlur = (6 + 14 * near) * dpr * (danger ? 1 : 0.4);
    g.stroke();
    // a chevron pointing at it for the very close and the hunting
    if (danger && near > 0.35) {
      const rr = R + (1 - near) * R * 0.25 + w * 1.6;
      const px = cx + Math.cos(sa) * rr, py = cy + Math.sin(sa) * rr;
      g.save(); g.translate(px, py); g.rotate(sa);
      g.beginPath(); g.moveTo(9 * dpr, 0); g.lineTo(-4 * dpr, -7 * dpr); g.lineTo(-4 * dpr, 7 * dpr); g.closePath();
      g.fillStyle = `rgba(255,50,35,${a.toFixed(3)})`; g.fill(); g.restore();
    }
    if (++drawn >= 24) break;
  }
  g.shadowBlur = 0;
}
