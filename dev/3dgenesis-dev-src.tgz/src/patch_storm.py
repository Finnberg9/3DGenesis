# ---------------------------------------------------------------- 2026-09-25b
# Three things Finn asked for mid-session:
#
#  1. The zone wall is a STORM, not a fog bank. A cumulonimbus tower standing
#     on the ring with a black base and a lit anvil, lightning cracking inside
#     it and thunder arriving late from the distance. Walk into it and you are
#     in heavy rain you cannot see through, with the flashes on top of you.
#  2. VEIL is real invisibility. Nothing can see you at all. It can still hear
#     you, and you can still hurt it.
#  3. RAGE costs no stamina.
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, (a[:100], n); return s.replace(a, b)
p = 'g3.html'; s = open(p, encoding='utf-8').read()

# ================================================================= 1. the storm
# A fog bank is 500 units tall and grey. A storm cell is a tower with a black
# base, a body you cannot see into and an anvil spreading downwind at the top,
# and the reason it reads as a storm rather than as smoke is that the bottom is
# DARKER than the ground and the top is brighter than the sky.
s = sub1(s, "const CLOUD_MAX = 900;", "const CLOUD_MAX = 1500;")
s = sub1(s, "const CLOUD_LAYERS = [0.10, 0.42, 0.80, 1.20];// height, as a fraction of the wall height\nconst CLOUD_WALL_H = 520;",
"""// Seven levels up a cumulonimbus: the dark shelf at the base, the body of the
// tower, and the anvil that spreads out at the top where it hits the cap.
const CLOUD_LAYERS = [0.05, 0.20, 0.40, 0.62, 0.86, 1.12, 1.40];
const CLOUD_WALL_H = 1750;
// How far each level leans OUT from the ring. The anvil overhangs: standing at
// the edge of the band you are under it, which is why the light goes first.
const CLOUD_SPREAD = [1.0, 1.05, 1.25, 1.65, 2.25, 3.0, 3.7];
// The base of a storm cell is nearly black and the anvil is white. Nothing
// else in this game has that range in one object.
const CLOUD_LUM = [0.16, 0.24, 0.42, 0.66, 0.92, 1.16, 1.30];""")
# each level is its own ring: the tower leans out as it climbs
s = sub1(s, """    for (let ri = 0; ri < CLOUD_ROWS.length; ri++) {
      const rr = (typeof brZoneEdge === 'function' ? brZoneEdge(a) : R) + CLOUD_ROWS[ri];
      const bx = Z.cx + ca * rr, bz = Z.cz + sa * rr;
      if (bx < -2000 || bz < -2000 || bx > WORLD_W + 2000 || bz > WORLD_H + 2000) continue;
      const dx = bx - camX, dz = bz - camZ;
      const d2 = dx * dx + dz * dz;
      if (d2 > SEE * SEE) continue;
      const gy = groundAt(clamp(bx, 1, WORLD_W - 1), clamp(bz, 1, WORLD_H - 1));
      for (let li = 0; li < CLOUD_LAYERS.length; li++) {""",
"""    for (let ri = 0; ri < CLOUD_ROWS.length; ri++) {
      const edgeR = (typeof brZoneEdge === 'function' ? brZoneEdge(a) : R);
      const rr = edgeR + CLOUD_ROWS[ri];
      const bx0 = Z.cx + ca * rr, bz0 = Z.cz + sa * rr;
      if (bx0 < -2000 || bz0 < -2000 || bx0 > WORLD_W + 2000 || bz0 > WORLD_H + 2000) continue;
      const dx0 = bx0 - camX, dz0 = bz0 - camZ;
      if (dx0 * dx0 + dz0 * dz0 > SEE * SEE) continue;
      const gy = groundAt(clamp(bx0, 1, WORLD_W - 1), clamp(bz0, 1, WORLD_H - 1));
      for (let li = 0; li < CLOUD_LAYERS.length; li++) {
        // the tower leans outward as it climbs, so the top overhangs the band
        const rr2 = edgeR + CLOUD_ROWS[ri] * CLOUD_SPREAD[li];
        const bx = Z.cx + ca * rr2, bz = Z.cz + sa * rr2;
        const dx = bx - camX, dz = bz - camZ;
        const d2 = dx * dx + dz * dz;""")
s = sub1(s, """        const rad = (185 + h2 * 210) * (1 + 0.10 * Math.sin(t * 0.25 + ph));""",
"""        // a tower is built of bigger puffs the higher it goes, and the anvil
        // is made of the biggest of all: that is what makes it read as scale
        const rad = (185 + h2 * 210) * (1 + 0.10 * Math.sin(t * 0.25 + ph)) * (0.78 + 0.62 * li);""")
s = sub1(s, """        const CLOUD_ROW_DENS = [0.34, 0.66, 0.95, 0.80, 0.52];
        const dens = CLOUD_ROW_DENS[ri] * (li === CLOUD_LAYERS.length - 1 ? 0.58 : li === 0 ? 0.88 : 1);
        const g1 = 0.88 + h1 * 0.16;
        list.push({ x: px, y, z: pz, r: rad, tint: [g1 * 0.93, g1, g1 * 0.90], dens,""",
"""        const CLOUD_ROW_DENS = [0.34, 0.66, 0.95, 0.80, 0.52];
        const dens = CLOUD_ROW_DENS[ri] * (li >= CLOUD_LAYERS.length - 1 ? 0.55 : li === 0 ? 0.95 : 1);
        // The tint carries the level's own light. A storm base is not grey:
        // it is darker than the ground under it, and the lightning inside is
        // the only thing that ever lights it from below.
        const g1 = (0.88 + h1 * 0.16) * CLOUD_LUM[li];
        // a flash lights the cloud it is INSIDE far harder than it lights the
        // island, and the low levels take the most of it
        const fl = (typeof WX !== 'undefined' ? WX.flash : 0) * (1.6 - 0.12 * li);
        const g2 = g1 + fl * 1.5;
        list.push({ x: px, y, z: pz, r: rad, tint: [g2 * 0.90, g2 * 0.96, g2 * 1.05], dens,""")
open(p, 'w', encoding='utf-8').write(s)
print('storm: the wall is a cumulonimbus ok')

s = open(p, encoding='utf-8').read()
# the cloud itself: a heavier, bluer body and a much darker underside, so the
# shelf at the bottom reads as weight rather than as smoke
s = sub1(s, """  var col = mix(vec3<f32>(0.085, 0.100, 0.105), vec3<f32>(0.62, 0.65, 0.64), day);
  col *= 0.44 + 0.56 * up;""",
"""  var col = mix(vec3<f32>(0.035, 0.042, 0.055), vec3<f32>(0.50, 0.53, 0.58), day);
  // the underside of a storm cell is nearly black and the shoulders are lit
  col *= 0.13 + 0.87 * pow(up, 0.75);""")
# and it should hold together as a solid mass rather than a field of balls
s = sub1(s, "  a *= smoothstep(0.34, 0.78, n * 0.72 + facing * 0.40);",
         "  a *= smoothstep(0.26, 0.72, n * 0.72 + facing * 0.44);")
open(p, 'w', encoding='utf-8').write(s)
print('storm: black base, lit shoulders ok')

s = open(p, encoding='utf-8').read()
# ---- the weather inside the band. The band IS the storm, so it drives the
# same rain, wetness, lightning and thunder the sky does. Standing in it is
# standing in a thunderstorm that happens to be killing you.
s = sub1(s, """  const w = wxAt(world.bt || 0);
  if (!WX.frozen) { WX.rain = w.rain; WX.storm = w.storm; WX.gust = w.gust; }
  WX.cell = w.cell;""",
"""  const w = wxAt(world.bt || 0);
  if (!WX.frozen) { WX.rain = w.rain; WX.storm = w.storm; WX.gust = w.gust; }
  WX.cell = w.cell;
  // The closing wall is weather, and it is the worst weather on the island.
  // Its own rain overrides the sky's: inside the band it is always a storm,
  // and the nearer the wall the more of it reaches you.
  WX.zone = 0;
  if (!WX.frozen && typeof BR !== 'undefined' && BR.on && BR.phase !== 'off') {
    try {
      const bf = brFogAt(player.camX, player.camZ);
      const gap = brEdgeGap(player.camX, player.camZ);    // >0 safe, <0 inside
      // rain reaches out ahead of the wall: you get wet before you get hurt
      const near = clamp(1 - gap / 900, 0, 1);
      WX.zone = clamp(Math.max(bf * 1.35, near * 0.55), 0, 1);
      WX.rain = Math.max(WX.rain, WX.zone);
      WX.storm = Math.max(WX.storm, clamp(WX.zone * 1.2, 0, 1));
      WX.wallGap = gap;
    } catch (e) { WX.zone = 0; }
  }""")
# thunder from the wall comes from the wall's distance, not from nowhere
s = sub1(s, """      WX.boltDist = 260 + Math.random() * Math.random() * 4200 * (1.15 - WX.storm);""",
"""      WX.boltDist = 260 + Math.random() * Math.random() * 4200 * (1.15 - WX.storm);
      // in a match the lightning is IN the wall, so the gap between the flash
      // and the crack is how far you are from the edge -- and it closes
      if (WX.zone > 0.02 && WX.wallGap != null) {
        WX.boltDist = clamp(Math.abs(WX.wallGap) + 120 + Math.random() * 700, 90, 6000);
      }""")
open(p, 'w', encoding='utf-8').write(s)
print('storm: the band rains, flashes and thunders ok')

s = open(p, encoding='utf-8').read()
# ================================================================= 2. VEIL
# It was a 0.25 multiplier on being noticed, which is a discount, not a spell.
s = sub1(s, "function spellSeenMul()   { return spellActive('veil') ? 0.25 : 1; }",
"""// 0 means NOTHING sees you. Not a smaller silhouette, not a shorter sight
// line: the island's eyes do not have you at all. What it does have is ears,
// so sprinting and swinging give you away for a second and a half at a time.
function spellSeenMul() {
  if (!spellActive('veil')) return 1;
  return SPELL.noise > 0 ? 0.55 : 0;
}
// How much of yourself you can see while veiled. Not zero: steering a body
// you cannot see at all is not stealth, it is a bug report.
function spellGhost() { return spellActive('veil') ? (SPELL.noise > 0 ? 0.66 : 0.82) : 0; }
// Anything loud. Called from the sprint and from every swing you throw.
function spellNoise(sec) { if (spellActive('veil')) SPELL.noise = Math.max(SPELL.noise || 0, sec); }""")
s = sub1(s, "const SPELL = { bag: { power: 0, ward: 0, veil: 0, rage: 0 }, on: {}, owner: null };",
         "const SPELL = { bag: { power: 0, ward: 0, veil: 0, rage: 0 }, on: {}, owner: null, noise: 0 };")
# a veiled body must not glow: a lit-up invisible animal is a contradiction
s = sub1(s, """  for (const k of SPELL_IDS) {
    const t = spellLeft(k);
    if (t > 0 && t > bestT * 0.0001 && (!best || SPELL_DEF[k].n > SPELL_DEF[best].n)) { best = k; bestT = t; }
  }""",
"""  for (const k of SPELL_IDS) {
    if (k === 'veil') continue;        // you do not glow while you are hiding
    const t = spellLeft(k);
    if (t > 0 && t > bestT * 0.0001 && (!best || SPELL_DEF[k].n > SPELL_DEF[best].n)) { best = k; bestT = t; }
  }""")
s = sub1(s, """  veil:  { n: 3, name: 'VEIL',  dur: 30, col: [0.66, 0.32, 1.00], blurb: 'small and unseen',
           hud: 'small, quiet and very hard to see' },""",
"""  veil:  { n: 3, name: 'VEIL',  dur: 30, col: [0.66, 0.32, 1.00], blurb: 'invisible',
           hud: 'nothing can see you. it can still hear you, and you can still bite' },""")
open(p, 'w', encoding='utf-8').write(s)
print('veil: it is invisibility now ok')

s = open(p, encoding='utf-8').read()
# the noise timer, ticked with the rest of the spell clocks
s = sub1(s, """function fightTick(dt) {
  world.hitFilter = fightHitFilter;
  fightFaceTick(dt);""",
"""function fightTick(dt) {
  world.hitFilter = fightHitFilter;
  fightFaceTick(dt);
  // What the island can see of each animal. One function, consulted by the
  // core's perception loop, so there is exactly one place stealth lives.
  world.seenMul = creatureSeenMul;
  SPELL.noise = Math.max(0, (SPELL.noise || 0) - dt);
  if (FIGHT.sprinting) spellNoise(0.9);
  spellTick(dt);""")
s = sub1(s, "function spellActive(k) { return (SPELL.on[k] || 0) > 0; }",
"""function spellActive(k) { return (SPELL.on[k] || 0) > 0; }
// The island's view of one animal, as a multiplier on the SQUARED sight
// range. Only the body the player is steering can be hidden; everything else
// is as visible as it has always been.
function creatureSeenMul(o) { return (o === player.c) ? spellSeenMul() : 1; }""")
# swinging is loud
s = sub1(s, "  FIGHT.swing = { mv, t: MD.dur * 0.44, weak };",
         "  FIGHT.swing = { mv, t: MD.dur * 0.44, weak };\n  spellNoise(1.5);          // a swing is loud, and loud is how you are found")
open(p, 'w', encoding='utf-8').write(s)
print('veil: seen through the ears, not the eyes ok')

s = open(p, encoding='utf-8').read()
# ---- the core actually consults it. Personal space is FELT and is evaluated
# above this line, so a hidden animal is still solid to walk into.
s = sub1(s, """        if (d2 > senseSq) return;
        near++;""",
"""        // What this animal presents to another animal's senses. 0 is not
        // "hard to see": it is not seen. Physical separation above this line
        // is untouched, so a hidden body is still a body in the way.
        const vis = world.seenMul ? world.seenMul(o) : 1;
        if (vis <= 0 || d2 > senseSq * vis) return;
        near++;""")
open(p, 'w', encoding='utf-8').write(s)
print('veil: the island cannot see you ok')

s = open(p, encoding='utf-8').read()
# ---- and you can see yourself, faintly. A dither in the skin shader rather
# than a blend: no second pipeline, no sort order, and it shimmers.
s = sub1(s, """    inst.set([q[0], q[1], q[2], X.yaw || 0, R, base[0], base[1], base[2], coat[0], coat[1], coat[2], detail[0], detail[1], detail[2], (col.pat | 0) + 16 * ((col.skin != null ? col.skin : (C.PLAN_SKIN ? C.PLAN_SKIN[des.plan | 0] : 0)) | 0), X.selBody ? 1 : 0, wAmp, wPh, sk.a, bb]);""",
"""    // pattern | skin | ghost, packed into one float. The ghost field is the
    // VEIL: 0 solid, 15 all but gone. Packed above the skin field so nothing
    // that reads pattern or covering changes.
    const ghost16 = Math.round(clamp(X.ghost || 0, 0, 1) * 15);
    const packed = (col.pat | 0) + 16 * ((col.skin != null ? col.skin : (C.PLAN_SKIN ? C.PLAN_SKIN[des.plan | 0] : 0)) | 0) + 1024 * ghost16;
    inst.set([q[0], q[1], q[2], X.yaw || 0, R, base[0], base[1], base[2], coat[0], coat[1], coat[2], detail[0], detail[1], detail[2], packed, X.selBody ? 1 : 0, wAmp, wPh, sk.a, bb]);""")
s = sub1(s, """  let p = i.opos; let n = normalize(i.onrm);
  let pk = i.misc.x;
  let skin = floor(pk / 16.0 + 0.001);
  let pat = pk - skin * 16.0;""",
"""  let p = i.opos; let n = normalize(i.onrm);
  var pk = i.misc.x;
  // ---- VEIL: stochastic transparency. A dithered discard is see-through
  // without a blend, which means no second pipeline and no sort order, and
  // the noise moving at 14 Hz is what makes it shimmer rather than screen-door.
  let gq = floor(pk / 1024.0 + 0.001);
  if (gq > 0.5) {
    let ghost = gq / 15.0;
    let px = floor(i.pos.xy);
    let hp = fract(sin(dot(px, vec2<f32>(12.9898, 78.233)) + floor(g.params.x * 14.0) * 1.7) * 43758.5453);
    if (hp < ghost) { discard; }
    pk = pk - gq * 1024.0;
  }
  let skin = floor(pk / 16.0 + 0.001);
  let pat = pk - skin * 16.0;""")
open(p, 'w', encoding='utf-8').write(s)
print('veil: you can just see yourself ok')

s = open(p, encoding='utf-8').read()
# the hard parts -- jaws, spikes, claws -- have no ghost channel, so they take
# the colour of the air instead: washed out to the fog, which at distance is
# the same answer transparency gives.
s = sub1(s, """    tint: A.flinch > 0.01 ? [1, 0.25, 0.22] : null, tintK: A.flinch * 0.55,""",
"""    ghost: isPlayer ? spellGhost() : 0,
    tint: (isPlayer && spellGhost() > 0) ? [gArr[24] * 1.25 + 0.06, gArr[25] * 1.25 + 0.06, gArr[26] * 1.25 + 0.06]
        : A.flinch > 0.01 ? [1, 0.25, 0.22] : null,
    tintK: (isPlayer && spellGhost() > 0) ? 0.82 * spellGhost() : A.flinch * 0.55,
    tintAll: isPlayer && spellGhost() > 0,""")
s = sub1(s, """  const base = X.tint ? colMix(col.base, X.tint, X.tintK) : col.base;
  const coat = X.tint ? colMix(col.coat, X.tint, X.tintK) : col.coat;
  const detail = col.detail;
  const R = X.R, t = X.t, seed = X.seed || 0;
  const hide = X.hide;""",
"""  const base = X.tint ? colMix(col.base, X.tint, X.tintK) : col.base;
  const coat = X.tint ? colMix(col.coat, X.tint, X.tintK) : col.coat;
  // a flinch reddens the hide and leaves the teeth alone; a veil takes
  // everything, teeth included, because a floating jaw is worse than no jaw
  const detail = (X.tint && X.tintAll) ? colMix(col.detail, X.tint, X.tintK) : col.detail;
  const R = X.R, t = X.t, seed = X.seed || 0;
  const hide = X.hide;""", 2)
open(p, 'w', encoding='utf-8').write(s)
print('veil: the teeth go too ok')

s = open(p, encoding='utf-8').read()
# ================================================================= 3. RAGE
# Rage was 1.5x damage, 1.5x health, bigger and faster, and it still made you
# stop and breathe. The point of it is that you do not have to.
s = sub1(s, """function fightSpend(n) {
  FIGHT.stam = Math.max(0, FIGHT.stam - n);
  FIGHT.stamDelay = STAM_DELAY;
  if (FIGHT.stam <= 0.01) FIGHT.exhausted = true;
}""",
"""function fightSpend(n) {
  // RAGE spends nothing. Sprint, swing, dodge and guard are all free while it
  // is running, and it clears an exhaustion you were already in -- otherwise
  // drinking it at zero stamina would do nothing for twenty seconds.
  if (spellActive('rage')) { FIGHT.exhausted = false; FIGHT.stamDelay = 0; return; }
  FIGHT.stam = Math.max(0, FIGHT.stam - n);
  FIGHT.stamDelay = STAM_DELAY;
  if (FIGHT.stam <= 0.01) FIGHT.exhausted = true;
}""")
s = sub1(s, "function fightCanSprint() { return !FIGHT.exhausted && FIGHT.stam > 0 && FIGHT.stagger <= 0 && !fightBlocking(); }",
         "function fightCanSprint() { return (spellActive('rage') || (!FIGHT.exhausted && FIGHT.stam > 0)) && FIGHT.stagger <= 0 && !fightBlocking(); }")
# and the bar says so rather than sitting there looking broken
s = sub1(s, """  rage:  { n: 4, name: 'RAGE',  dur: 20, col: [1.00, 0.20, 0.14], blurb: 'bigger, faster, stronger',
           hud: 'x1.5 damage and health, bigger and faster' },""",
"""  rage:  { n: 4, name: 'RAGE',  dur: 20, col: [1.00, 0.20, 0.14], blurb: 'no stamina, no limit',
           hud: 'x1.5 damage and health, bigger, faster, and nothing you do costs stamina' },""")
open(p, 'w', encoding='utf-8').write(s)
print('rage: costs nothing ok')

s = open(p, encoding='utf-8').read()
# the harness needs to be able to read the lungs to prove rage is free
s = sub1(s, "    drainStam: () => { FIGHT.stam = 0; FIGHT.exhausted = true; },",
"""    drainStam: () => { FIGHT.stam = 0; FIGHT.exhausted = true; },
    stam: () => ({ v: +FIGHT.stam.toFixed(2), ex: FIGHT.exhausted, sprint: FIGHT.sprinting }),
    veil: () => ({ seen: spellSeenMul(), ghost: spellGhost(), noise: +(SPELL.noise || 0).toFixed(2) }),
    swing: () => { fightStartSwing(); return !!FIGHT.swing; },""")
open(p, 'w', encoding='utf-8').write(s)
print('storm: harness reads the lungs ok')

s = open(p, encoding='utf-8').read()
# A seven level tower is a lot more cloud than a four level bank, and every
# puff is a big soft alpha-blended sphere. The budget follows the quality
# setting rather than being one number for every machine.
s = sub1(s, "  const n2 = Math.min(list.length, CLOUD_MAX);",
"""  const CLOUD_BUDGET = { low: 420, medium: 800, high: 1250, ultra: 1500 };
  const n2 = Math.min(list.length, CLOUD_BUDGET[GFX.name] || CLOUD_MAX);""")
open(p, 'w', encoding='utf-8').write(s)
print('storm: the tower costs what the machine can pay ok')
