# =====================================================================
# HEALTH AND DAMAGE, REBUILT
#
# The game is a fighting game now, so the numbers a fight is made of stop
# being a side effect of the ecosystem and become the thing that is designed.
#
#   HEALTH  Every body starts at 100 hp whatever shape it is -- a baby, a
#           lean runner and a squat tank all read 100 -- and only a genuinely
#           large body goes above it. Health is its own pool (`c.hp`), not the
#           food tank: energy stays what the free-roam ecosystem runs on and
#           never decides a fight again.
#
#   DAMAGE  A bare body's hit is 10. The rarest weapon in the game is 100.
#           Everything between is the part tier you are carrying, which is
#           what makes looting worth doing. Armour soaks a bounded fraction,
#           never all of it, and no hit is ever weaker than hpMax/30, so a
#           fight cannot stall: thirty clean hits ends any of them.
#
#   NO SELF-DAMAGE  Swinging cost you the target's `counter` in full, every
#           swing, silently -- which is how you could win an exchange and die
#           for it. Spikes still bite back, but only against a body-contact
#           move, capped at a tenth of what you dealt, and always announced.
#           Killing something toxic no longer poisons you at all: you are not
#           eating it any more.
#
#   ONE PATH IN  Match bots hit the player by writing to their health
#           directly, which walked straight past the wind-up, the guard, the
#           parry window and the dodge. Their strikes go through the same
#           filter every other attack does now, so the defence you are given
#           actually works against the only opponents in a match.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, ('ANCHOR %d/%d' % (n, cnt), a[:110]); return s.replace(a, b)

p = 'g3.html'; s = open(p, encoding='utf-8').read()

# ---------------------------------------------------------------- 1. the tier table moves into the core
# The page's bones table and the sim both need to know how rare a part is:
# damage reads it now, and price already did. Two copies of that table is a
# drift waiting to happen, so the core owns it and bones reads the core's.
s = sub1(s, """  // Parts that must never be duplicated: placing a second one replaces the first.
  const ITEM_SINGLE = { MOUTH: 1 };""",
"""  // Parts that must never be duplicated: placing a second one replaces the first.
  const ITEM_SINGLE = { MOUTH: 1 };

  // ---- part rarity ---------------------------------------------------------
  // The single source of truth for how rare a part is. Price, wild spawn odds
  // and now damage all read this one table, so a part cannot be cheap in the
  // shop and devastating in a fight.
  const ITEM_TIER = {
    // weak: the starting kit. Cheap, common, on half the animals you meet.
    m_beak: 'weak', m_grazer: 'weak', e_round: 'weak', e_slit: 'weak',
    s_spike: 'weak', s_knob: 'weak', l_thin: 'weak', t_paw: 'weak', t_hoof: 'weak',
    t_pad: 'weak', t_flipper: 'weak', d_crest: 'weak', d_frill: 'weak', d_antenna: 'weak',
    // solid: a working body. Real jaws, real legs, real fins.
    m_jaws: 'solid', m_hook: 'solid', m_duck: 'solid', e_big: 'solid', e_bug: 'solid',
    h_straight: 'solid', h_curved: 'solid', h_tusk: 'solid', s_quills: 'solid', s_plate: 'solid',
    l_leg: 'solid', t_talon: 'solid', t_claw: 'solid', f_fin: 'solid', f_dorsal: 'solid',
    d_gills: 'solid', d_lungs: 'solid',
    // super: specialist kit that changes how you hunt or move.
    m_maw: 'super', m_trunk: 'super', m_short: 'super', e_stalk: 'super', e_cluster: 'super',
    h_ram: 'super', h_rhino: 'super', s_club: 'super', l_thick: 'super', l_spring: 'super',
    t_hand: 'super', t_pincer: 'super', f_fluke: 'super', w_insect: 'super', d_gland: 'super',
    // ultra: flight, armour and the long killing jaws.
    m_spino: 'ultra', h_antler: 'ultra', s_shell: 'ultra', w_bat: 'ultra', w_feather: 'ultra',
    // alpha: the apex bite. Almost never born wild.
    m_rex: 'alpha',
  };
  // What a tier is worth as a weapon, 0..1. The curve is deliberately steep at
  // the top: an alpha part should feel like finding an alpha part.
  const TIER_W = { weak: 0.10, solid: 0.28, super: 0.50, ultra: 0.76, alpha: 1.00 };
  function itemTier(id) { return ITEM_TIER[id] || 'solid'; }
  function tierWeight(id) { return TIER_W[itemTier(id)] || 0.28; }
  // Every simulated part must have a tier or its damage is a guess. Checked
  // once at load rather than discovered in a fight.
  (function () {
    const miss = Object.keys(ITEM_SIM).filter((k) => !ITEM_TIER[k]);
    if (miss.length) console.warn('core: no rarity tier for', miss.join(', '), '-- weighted as solid');
  })();

  // ---- combat health -------------------------------------------------------
  // Any body you can start a match with reads 100, whatever shape it is: a
  // baby, a lean runner, a squat tank. Only a genuinely large body goes above
  // it, and it does so sub-linearly so a giant is tough, not unkillable.
  const HP_BASE = 100;          // the number on every starting creature
  // Calibrated on the HEAVIEST stock body plan, not an average one, so that
  // "whatever shape you start as, you have 100" is literally true: the squat
  // armoured plan and the lean runner both read 100, and only a body that has
  // grown past anything you can start as goes above it.
  const HP_REF_MASS = 17;
  const HP_EXP = 0.75;
  const HP_CAP_MUL = 15;        // 1500 hp is the largest health the game builds
  function hpMaxOf(ph) {
    if (!ph) return HP_BASE;
    const k = Math.pow(Math.max(0.01, ph.mass || 0) / HP_REF_MASS, HP_EXP);
    return HP_BASE * clamp(k, 1, HP_CAP_MUL);
  }

  // ---- damage --------------------------------------------------------------
  const DMG_STOCK = 10;         // a body with nothing on it
  // Damage is calibrated on a TYPICAL body, health on the largest starting
  // one. Two different reference masses on purpose: it is what makes both
  // "every starting creature has 100 hp" and "a stock hit is 10" literally
  // true at the same time, rather than approximately true of neither.
  const DMG_REF_MASS = 10;
  const DMG_MAX = 100;          // the rarest weapon in the game, fully kitted
  const TTK_CEIL = 30;          // no clean exchange ever takes more hits than this
  const ARMOUR_MAX = 0.55;      // armour never soaks more than this fraction
  const ARMOUR_HALF = 90;       // defence at which armour is at half its ceiling
  // 0..1, how armed a body is. Set once at compile time from the parts it
  // actually wears, so a fight never walks the design.
  function weaponQ(ph) {
    if (!ph) return 0;
    if (ph.weapon != null) return ph.weapon;
    // A genome with no design (a seeded founder) has no part list to read, so
    // fall back to the old aggregate with the body-size term taken back out.
    return clamp(((ph.attack || 0) - (ph.mass || 0) * 0.35) / 30, 0, 1);
  }
  // The damage one clean hit does. mul is the move's own multiplier.
  // The exponent is what keeps a starting creature on the stock 10 while the
  // top of the ladder still reaches 100: a shallow curve made every weak part
  // feel like a weapon, which flattened the whole point of looting.
  const DMG_CURVE = 2.0;
  function strikeDamage(a, d, mul) {
    const q = weaponQ(a);
    let base = DMG_STOCK + (DMG_MAX - DMG_STOCK) * Math.pow(clamp(q, 0, 1), DMG_CURVE);
    // A heavier body puts more behind the same weapon, but only modestly:
    // rarity is meant to decide a fight, not tonnage.
    base *= 0.80 + 0.20 * clamp(Math.pow(Math.max(0.01, a.mass || 1) / DMG_REF_MASS, 0.5), 0.5, 2.5);
    // The stated ceiling, applied before the move multiplier so that "the
    // rarest weapon in the game hits for 100" is a number you can check.
    base = clamp(base, DMG_STOCK * 0.5, DMG_MAX);
    let dmg = base * (mul == null ? 1 : mul);
    // Armour is a fraction, never a subtraction: it cannot take a hit to zero
    // and it cannot be out-scaled into irrelevance either.
    const def = Math.max(0, d.defense || 0);
    dmg *= 1 - ARMOUR_MAX * (def / (ARMOUR_HALF + def));
    // A fight must end. Whatever the armour, thirty clean hits kills.
    const floor = hpMaxOf(d) / TTK_CEIL;
    if (dmg < floor) dmg = floor;
    return clamp(dmg, 1, DMG_MAX * 2.5);
  }
  // Spikes bite the thing that rammed them, and only the thing that rammed
  // them: a tenth of what it dealt, never more, and never a surprise.
  const COUNTER_FRAC = 0.10;
  function counterDamage(d, dealt, contact) {
    if (!contact || !d || !(d.counter > 0)) return 0;
    return Math.min(dealt * COUNTER_FRAC, d.counter * 0.35);
  }

  // ---- the health pool -----------------------------------------------------
  // Health is its own pool. Created on first read so nothing has to remember
  // to initialise it, and carried as a FRACTION when a body grows, so getting
  // bigger mid-match heals you proportionally rather than leaving you at 4%.
  function hpOf(c) {
    if (!c) return 0;
    const max = hpMaxOf(c.ph);
    if (c.hp == null || !isFinite(c.hp)) { c.hp = max; c._hpMax = max; return c.hp; }
    // A health value written straight onto the creature (a test, a respawn, a
    // scripted wound) arrives with no record of what it was a fraction OF.
    // Adopt the current ceiling rather than rescaling against nothing --
    // treating the missing record as "full" silently healed anything that set
    // c.hp by hand, which is exactly the sort of thing that is discovered in
    // a fight rather than in a diff.
    if (!(c._hpMax > 0)) { c._hpMax = max; c.hp = clamp(c.hp, 0, max); return c.hp; }
    if (c._hpMax !== max) {
      const f = clamp(c.hp / c._hpMax, 0, 1);
      c.hp = max * f; c._hpMax = max;
    }
    return c.hp;
  }
  function hpFrac(c) { const m = hpMaxOf(c && c.ph); return m > 0 ? clamp(hpOf(c) / m, 0, 1) : 0; }
  // Take damage. Returns the health left. Never goes below zero, so a caller
  // can read it as "is it dead" without guarding for negatives.
  function hpHurt(c, dmg) {
    hpOf(c);
    c.hp -= Math.max(0, dmg || 0);
    if (!(c.hp > 0)) c.hp = 0;
    return c.hp;
  }
  function hpHeal(c, amt) {
    const max = hpMaxOf(c && c.ph);
    hpOf(c);
    c.hp = clamp(c.hp + Math.max(0, amt || 0), 0, max);
    return c.hp;
  }""")

# develop() publishes the two numbers a fight reads, so nothing recomputes them
s = sub1(s, "    if (!ph.waterBreath && !ph.airBreath) ph.airBreath = 1;",
"""    if (!ph.waterBreath && !ph.airBreath) ph.airBreath = 1;
    // What a fight reads. Both are pure functions of the body, resolved here
    // so no combat path ever has to walk a design.
    ph.weapon = (designed && genome.dx && genome.dx.wq != null)
      ? clamp(genome.dx.wq, 0, 1)
      : clamp((ph.attack - mass * 0.35) / 30, 0, 1);
    ph.hpMax = hpMaxOf(ph);""")

# compileDesign scores the weapons the body is actually wearing
s = sub1(s, "    const dx = { atk: 0, def: 0, reach: 0, sense: 0, spd: 0, fin: 0, grab: 0, sweep: 0, claw: 0, legs: 0, arms: 0, spring: 0, gill: 0, lung: 0 };",
"""    const dx = { atk: 0, def: 0, reach: 0, sense: 0, spd: 0, fin: 0, grab: 0, sweep: 0, claw: 0, legs: 0, arms: 0, spring: 0, gill: 0, lung: 0, wq: 0 };
    // How armed this body is, 0..1. The single best weapon sets three
    // quarters of it -- one alpha jaw should be the story of the creature --
    // and everything else you are carrying fills in the rest, so a body
    // bristling with solid parts can still reach the top without an alpha.
    let wqBest = 0, wqRest = 0;
    const arm = (id, scale) => {
      const sim = ITEM_SIM[id];
      // A weapon is a part that actually adds attack, or a jaw built to bite.
      if (!sim) return;
      const isWeapon = (sim.atk || 0) > 0 || (sim.t === 'MOUTH' && sim.mode === 'carn') ||
                       sim.t === 'HORN' || (sim.t === 'SPIKE' && (sim.sweep || sim.atk));
      if (!isWeapon) return;
      const w = tierWeight(id) * clamp(scale == null ? 1 : scale, 0.3, 1.6);
      if (w > wqBest) { wqRest += wqBest * 0.18; wqBest = w; }
      else wqRest += w * 0.18;
    };""")
s = sub1(s, """      if (s.t === 'MOUTH') { mouth = { s, sz }; continue; }
      add(s.t, s.w * sz);""",
"""      arm(pt.id, sz);
      if (s.t === 'MOUTH') { mouth = { s, sz }; continue; }
      add(s.t, s.w * sz);""")
s = sub1(s, """        add('TIP', ts.w * tsz);
        // weapons on the ground are worth less than weapons you swing
        extra(ts, tsz * (o.leg ? 0.45 : 1));""",
"""        add('TIP', ts.w * tsz);
        // weapons on the ground are worth less than weapons you swing
        arm(o.lb.tip.id, tsz * (o.leg ? 0.45 : 1));
        extra(ts, tsz * (o.leg ? 0.45 : 1));""")
s = sub1(s, "    if (dx.legs > 0) dx.spd = dx.spd / Math.max(1, dx.legs / 2);   // per-pair, not per-foot",
"""    dx.wq = clamp(wqBest * 0.75 + Math.min(0.25, wqRest), 0, 1);
    if (dx.legs > 0) dx.spd = dx.spd / Math.max(1, dx.legs / 2);   // per-pair, not per-foot""")

# ---------------------------------------------------------------- 2. the core's own two combat paths
s = sub1(s, """  function retaliate(world, att, foe, flags) {
    const a = att.ph, d = foe.ph;
    const ratio = clamp(a.mass / Math.max(0.01, d.mass), 0.15, 2.5);
    let dmg = Math.max(a.attack - d.defense * 0.6, d.storage * 0.03 * ratio, 1);
    dmg = filterHit(world, foe, att, dmg);
    if (dmg === null) return;
    foe.energy -= dmg;
    att.energy -= (d.counter || 0) * 0.5; if (att.energy < 0) att.energy = 0;
    onHit(foe, att, dmg);
    if (foe.energy <= 0 && foe.alive) {""",
"""  function retaliate(world, att, foe, flags) {
    const a = att.ph, d = foe.ph;
    let dmg = strikeDamage(a, d, 1);
    dmg = filterHit(world, foe, att, dmg);
    if (dmg === null) return;
    hpHurt(foe, dmg);
    // fighting back is a body slam, so spikes are in play -- capped, never fatal
    hpHurt(att, counterDamage(d, dmg, true));
    onHit(foe, att, dmg);
    if (foe.hp <= 0 && foe.alive) {""")
s = sub1(s, """  function resolveAttack(world, att, prey, flags) {
    const a = att.ph, d = prey.ph;
    let dmg = a.attack - d.defense * 0.6; if (dmg <= 0) dmg = 1;
    dmg = filterHit(world, prey, att, dmg);
    if (dmg === null) return;
    prey.energy -= dmg;
    onHit(prey, att, dmg);
    att.energy -= d.counter * 0.5; if (att.energy < 0) att.energy = 0;
    if (prey.energy <= 0) {
      prey.alive = false; prey.deathCause = 'predation'; recordDeath(world, prey);
      const gain = (d.mass * 8 + Math.max(0, prey.energy + d.mass * 2)) * 0.6;
      if (!(att.hurtT > 0)) att.energy = Math.min(a.storage, att.energy + Math.max(6, gain));
      if (flags.toxins && d.toxin > 0) att.energy -= d.toxin * 22; // poison payback
      if (att.energy < 0) att.energy = 0;
    }
  }""",
"""  function resolveAttack(world, att, prey, flags) {
    const a = att.ph, d = prey.ph;
    let dmg = strikeDamage(a, d, 1);
    dmg = filterHit(world, prey, att, dmg);
    if (dmg === null) return;
    hpHurt(prey, dmg);
    onHit(prey, att, dmg);
    hpHurt(att, counterDamage(d, dmg, true));
    if (prey.hp <= 0) {
      prey.alive = false; prey.deathCause = 'predation'; recordDeath(world, prey);
      const gain = (d.mass * 8 + d.mass * 2) * 0.6;
      if (!(att.hurtT > 0)) att.energy = Math.min(a.storage, att.energy + Math.max(6, gain));
      if (flags.toxins && d.toxin > 0) att.energy -= d.toxin * 22; // poison payback
      if (att.energy < 0) att.energy = 0;
    }
  }""")

# death by starvation still ends a wild life, but a full health bar is not a
# full stomach any more: the two pools are checked separately.
s = sub1(s, "      if (c.energy <= 0 || c.age >= c.maxAge) {",
"""      if (c.hp != null && c.hp <= 0 && c.alive) { c.alive = false; c.deathCause = c.deathCause || 'wounds'; recordDeath(world, c); continue; }
      if (c.energy <= 0 || c.age >= c.maxAge) {""")

# the fall is a wound, not a missed meal
s = sub1(s, """          c.energy -= Math.pow(over / Math.max(14, (p.standH || p.radius || 6) * FALL_FATAL_H_SIM), 1.6) * sizeK * Math.max(1, p.storage);
          if (c.energy <= 0) { c.alive = false; c.deathCause = 'fall'; }""",
"""          hpHurt(c, Math.pow(over / Math.max(14, (p.standH || p.radius || 6) * FALL_FATAL_H_SIM), 1.6) * sizeK * hpMaxOf(p));
          if (c.hp <= 0) { c.alive = false; c.deathCause = 'fall'; }""")
# drowning likewise
s = sub1(s, "      if (cantBreathe) { c.energy -= p.storage * 0.12 * dt; c._drown = underNow ? 1 : 2; }",
            "      if (cantBreathe) { hpHurt(c, hpMaxOf(p) * 0.12 * dt); c._drown = underNow ? 1 : 2; }")

# export the new surface
s = sub1(s, "    onHit, HURT_TIME,",
"""    onHit, HURT_TIME,
    ITEM_TIER, TIER_W, itemTier, tierWeight,
    HP_BASE, HP_REF_MASS, DMG_STOCK, DMG_MAX, DMG_REF_MASS, TTK_CEIL,
    hpMaxOf, hpOf, hpFrac, hpHurt, hpHeal, weaponQ, strikeDamage, counterDamage,""")

open(p, 'w', encoding='utf-8').write(s)
print('hp: core ok')

# =====================================================================
# PAGE SIDE: the player's own fight
# =====================================================================
s = open(p, encoding='utf-8').read()

# ---------------------------------------------------------------- your swing
# Damage is the part tier you are carrying, the target's armour, and nothing
# else. No toxin payback (you are not eating it), and spikes only answer a
# body-contact move.
s = sub1(s, """  let dmg = (p.attack - best.ph.defense * 0.6) * MD.dmg;
  const ratio = clamp(p.mass / Math.max(0.01, best.ph.mass), 0.12, 3);
  const floor = Math.max(1, best.ph.storage * 0.05 * ratio * MD.dmg);
  if (dmg < floor) dmg = floor;""",
"""  let dmg = C.strikeDamage(p, best.ph, MD.dmg);""")
s = sub1(s, """  best.energy -= dmg;
  C.onHit(best, c, dmg);
  c.energy -= (best.ph.counter || 0) * 0.5;
  if (c.energy < 0) c.energy = 0;
  const frac = dmg / Math.max(1, best.ph.storage);""",
"""  C.hpHurt(best, dmg);
  C.onHit(best, c, dmg);
  // Spikes answer a body slam or a headbutt, not a bite or a claw from reach,
  // and never for more than a tenth of what you just dealt. This used to fire
  // on every swing, in full, without a word about it.
  const back = C.counterDamage(best.ph, dmg, sw.mv === 'slam' || sw.mv === 'headbutt');
  if (back > 0) { C.hpHurt(c, back); toast('Its spikes cut you for ' + back.toFixed(0) + '.', 1100); }
  const frac = dmg / Math.max(1, C.hpMaxOf(best.ph));""")
s = sub1(s, """  if (best.energy > 0) {
    const hits = Math.ceil(best.energy / Math.max(0.01, dmg));
    toast(MD.label.toUpperCase() + tag + ' for ' + dmg.toFixed(0) + '. ' +
          Math.max(0, best.energy).toFixed(0) + ' left (~' + hits + ' more)' + (best.bleedT > 0 ? ', bleeding.' : '.'), 1200);
    return;
  }""",
"""  if (best.hp > 0) {
    const hits = Math.ceil(best.hp / Math.max(0.01, dmg));
    toast(MD.label.toUpperCase() + tag + ' for ' + dmg.toFixed(0) + '. ' +
          Math.max(0, best.hp).toFixed(0) + ' hp left (~' + hits + ' more)' + (best.bleedT > 0 ? ', bleeding.' : '.'), 1200);
    return;
  }""")
# a kill is a kill: no feeding, no poison, because there is no eating any more
s = sub1(s, """  const gain = (best.ph.mass * 8 + best.ph.mass * 2) * 0.6;
  if (c.hurtT > 0) toast('Killed it, but you are still under attack and cannot feed on it.', 2400);
  else { c.energy = Math.min(p.storage, c.energy + Math.max(6, gain)); feedGrowth(c, best.ph.mass, 'Ate your kill'); }
  if (world.flags.toxins && best.ph.toxin > 0) {
    c.energy -= best.ph.toxin * 22;
    if (c.energy < 0) c.energy = 0;
  }""",
"""  // A kill puts mass on you and patches you up. It does not poison you and it
  // is never refused: winning a fight is the reward.
  feedGrowth(c, best.ph.mass, 'Grew on the kill');
  C.hpHeal(c, C.hpMaxOf(p) * 0.20);""")

# ---------------------------------------------------------------- hits on you
s = sub1(s, """    const cost = 10 + 70 * dmg / Math.max(1, c.ph.storage);""",
            """    const cost = 10 + 70 * dmg / Math.max(1, C.hpMaxOf(c.ph));""")
s = sub1(s, """  c.energy -= dmg;
  if (c.energy <= 0) { c.energy = 0; c._fatalBy = att; }
  c._lastBlocked = blocked;
  C.onHit(c, att, dmg);
  att.energy -= (c.ph.counter || 0) * 0.5;       // spikes and armour still bite back on contact
  if (att.energy < 0) att.energy = 0;
  const frac = dmg / Math.max(1, c.ph.storage);""",
"""  C.hpHurt(c, dmg);
  if (c.hp <= 0) c._fatalBy = att;
  c._lastBlocked = blocked;
  C.onHit(c, att, dmg);
  // your own spikes answer whatever rammed you, capped the same way
  C.hpHurt(att, C.counterDamage(c.ph, dmg, true));
  const frac = dmg / Math.max(1, C.hpMaxOf(c.ph));""")
s = sub1(s, """  let m = (c._lastBlocked ? 'Blocked ' + diet + ': took ' + n : 'Hit by ' + diet + ' for ' + n) + '.';
  if (c.bleedT > 0) m += ' Bleeding.';
  return m + ' No eating for 5 s.';""",
"""  let m = (c._lastBlocked ? 'Blocked ' + diet + ': took ' + n : 'Hit by ' + diet + ' for ' + n) + '.';
  if (c.bleedT > 0) m += ' Bleeding.';
  return m;""")

# the player's own fall damage is a wound
s = sub1(s, """  c.energy -= dmg;""", """  C.hpHurt(c, dmg);""")
s = sub1(s, """  if (c.energy <= 0) { c.alive = false; c.deathCause = 'fall'; }""",
            """  if (c.hp <= 0) { c.alive = false; c.deathCause = 'fall'; }""")

# ---------------------------------------------------------------- every health readout
# One number, read the same way everywhere: the bar, the nameplate, the
# lock-on plate, the body's own wounded look.
for old, new in [
    ("    const ef = clamp(c.energy / Math.max(1, c.ph.storage), 0, 1);",
     "    const ef = C.hpFrac(c);"),
    ("    const f = clamp(lk.energy / Math.max(1, lk.ph.storage), 0, 1);",
     "    const f = C.hpFrac(lk);"),
    ("  const r0 = c.ph.radius, ef = c.energy / Math.max(1, c.ph.storage);",
     "  const r0 = c.ph.radius, ef = C.hpFrac(c);"),
    ("    const f = clamp(c.energy / Math.max(1, c.ph.storage), 0, 1);",
     "    const f = C.hpFrac(c);"),
]:
    s = sub1(s, old, new)
s = sub1(s, """    $('v-e').style.width = clamp(c.energy / Math.max(1, p.storage) * 100, 0, 100) + '%';""",
             """    $('v-e').style.width = (C.hpFrac(c) * 100).toFixed(1) + '%';""")

# ---------------------------------------------------------------- match bots
# A bot used to write into the player's health directly. That is why swinging
# felt like trading: the wind-up, the guard, the parry and the dodge were all
# bypassed by the only opponents in a match. Their strike goes through the
# same filter every other attack in the game does.
s = sub1(s, """    const dmg = (c.ph && c.ph.attack ? c.ph.attack : 4) * (0.8 + Math.random() * 0.5);
    best.c.energy -= dmg;
    if (best.c.energy <= 0) {
      best.c.alive = false;
      brOnPlayerKilled(best.slot, p.slot);
    }""",
"""    const dmg = C.strikeDamage(c.ph || { mass: 1 }, best.c.ph || { defense: 0, mass: 1 }, 0.9 + Math.random() * 0.5);
    // Through the filter, exactly like anything else swinging at you: against
    // the human that means a telegraphed wind-up you can guard, parry or dodge.
    const let_ = world.hitFilter ? world.hitFilter(best.c, c, dmg) : dmg;
    if (let_ === null) continue;
    C.hpHurt(best.c, let_);
    if (best.c.hp <= 0) {
      best.c.alive = false;
      brOnPlayerKilled(best.slot, p.slot);
    }""")
# the fog is damage too
s = sub1(s, """    p.c.energy -= BR_ZONE_DPS * f * dt;
    if (p.c.energy <= 0) {""",
"""    C.hpHurt(p.c, BR_ZONE_DPS * f * dt);
    if (p.c.hp <= 0) {""")

open(p, 'w', encoding='utf-8').write(s)
print('hp: page ok')

# =====================================================================
# Everything else that still read the food tank as if it were health.
# =====================================================================
s = open(p, encoding='utf-8').read()

# the action prompt's "hits to kill" has to agree with the swing that follows it
s = sub1(s, """      let dmg = mp.attack - d.defense * 0.6;
      const ratio = clamp(mp.mass / Math.max(0.01, d.mass), 0.12, 3);
      dmg = Math.max(dmg, Math.max(1, d.storage * 0.05 * ratio));
      const hits = Math.ceil(Math.max(0, tgt.energy) / Math.max(0.01, dmg));""",
"""      const dmg = C.strikeDamage(mp, d, (MOVE_DEF[player.moveSel] || { dmg: 1 }).dmg);
      const hits = Math.ceil(Math.max(0, C.hpOf(tgt)) / Math.max(0.01, dmg));""")
# the plate over a rival's head, and the tie-break when the clock runs out
s = sub1(s, "    const hp = q.c && q.c.alive ? q.c.energy : 0;",
            "    const hp = q.c && q.c.alive ? C.hpOf(q.c) : 0;")
s = sub1(s, "    if (prey.alive === false || prey.energy <= 0) brOnPlayerKilled(prey._br, BR.slot);",
            "    if (prey.alive === false || C.hpOf(prey) <= 0) brOnPlayerKilled(prey._br, BR.slot);")
# the workbench shield holds your health, not your stomach
s = sub1(s, """  if (ED.shieldE == null) ED.shieldE = c.energy;""",
            """  if (ED.shieldE == null) ED.shieldE = C.hpOf(c);""")
s = sub1(s, """  c.energy = Math.max(1, Math.min(ED.shieldE, c.ph.storage));
  c._drown = 0; c._sub = false;
  c._hurtT = 0;
  if (c.energy <= 0) c.energy = 1;""",
"""  c.hp = Math.max(1, Math.min(ED.shieldE, C.hpMaxOf(c.ph)));
  c._hpMax = C.hpMaxOf(c.ph);
  c._drown = 0; c._sub = false;
  c._hurtT = 0;""")
# growing keeps the same fraction of a bigger body (hpOf does this itself, so
# all that is needed is to stop the stomach pretending to be the health bar)
s = sub1(s, """  c.energy = Math.min(c.ph.storage, Math.max(c.energy, ef * c.ph.storage));""",
            """  C.hpOf(c);   // re-reads hpMax and carries the same fraction onto the bigger body""")

open(p, 'w', encoding='utf-8').write(s)
print('hp: readouts ok')
