# =====================================================================
# THE QUALITY SETTING DROPS ITSELF
#
# "My computer basically can't run ultra at all, it is so slow every frame
# takes like half a second."
#
# There WAS an automatic system, and it was solving the wrong problem. It
# scaled the render RESOLUTION, between 100% and 60%, and nothing else. At
# half a second a frame the cost is not pixels -- it is eighteen thousand
# plants, nine and a half thousand units of tree detail, three shadow
# cascades and a two-hundred-thousand instance budget. Rendering all of that
# at 60% of the pixels is still all of that.
#
# So the automatic system now moves the QUALITY PRESET, which is what
# actually costs the time, and keeps the resolution trim as the fine
# adjustment underneath it.
#
#   * Down fast, up slow. Two levels at once if the first seconds are dire,
#     then one at a time, with a long cooldown and a wide dead band between
#     the two thresholds so it cannot oscillate between two presets forever.
#   * It never overrules you. Touching the quality buttons yourself turns
#     automatic stepping off for the session, because a setting that undoes
#     what you just chose is worse than no setting.
#   * It says so when it moves, once, naming the level and how to stop it.
#   * A machine nobody has measured yet starts at MEDIUM rather than HIGH,
#     and is allowed to climb if it turns out to be fast. Starting high and
#     falling means the first thing a new player sees is a slideshow.
#
# The horror geometry on the mouths rides the same setting: drool, tendrils,
# tongues and inner jaws are HIGH and ULTRA only. They are the most expensive
# thing per creature in the game and the least necessary on a machine that is
# struggling. The palette icons keep them at every setting, because a still
# image costs nothing and it is the one place you look at a mouth closely.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, ('ANCHOR %d/%d' % (n, cnt), a[:110]); return s.replace(a, b)

p = 'g3.html'; s = open(p, encoding='utf-8').read()

# ---------------------------------------------------------------- 1. gore is a quality level
s = sub1(s, "  low:    { res: 0.65, cover: 380,  plant: 2600,  lod0: 420,  lod1: 1600, crit: 0.6, fog: 1.00, folMax: 50000,  shadow: 0, ao: 0, bloom: 0, rays: 0 },",
            "  low:    { res: 0.65, cover: 380,  plant: 2600,  lod0: 420,  lod1: 1600, crit: 0.6, fog: 1.00, folMax: 50000,  shadow: 0, ao: 0, bloom: 0, rays: 0, gore: 0 },")
s = sub1(s, "  medium: { res: 0.80, cover: 620,  plant: 4200,  lod0: 700,  lod1: 2600, crit: 0.9, fog: 0.80, folMax: 90000,  shadow: 1, ao: 0, bloom: 1, rays: 1 },",
            "  medium: { res: 0.80, cover: 620,  plant: 4200,  lod0: 700,  lod1: 2600, crit: 0.9, fog: 0.80, folMax: 90000,  shadow: 1, ao: 0, bloom: 1, rays: 1, gore: 0 },")
s = sub1(s, "  high:   { res: 0.90, cover: 1000, plant: 8000,  lod0: 1200, lod1: 4800, crit: 1.5, fog: 0.50, folMax: 140000, shadow: 2, ao: 1, bloom: 1, rays: 1 },",
            "  high:   { res: 0.90, cover: 1000, plant: 8000,  lod0: 1200, lod1: 4800, crit: 1.5, fog: 0.50, folMax: 140000, shadow: 2, ao: 1, bloom: 1, rays: 1, gore: 1 },")
s = sub1(s, "  ultra:  { res: 1.15, cover: 1700, plant: 18000, lod0: 2300, lod1: 9500, crit: 2.8, fog: 0.26, folMax: 200000, shadow: 3, ao: 1, bloom: 1, rays: 1 },",
            "  ultra:  { res: 1.15, cover: 1700, plant: 18000, lod0: 2300, lod1: 9500, crit: 2.8, fog: 0.26, folMax: 200000, shadow: 3, ao: 1, bloom: 1, rays: 1, gore: 1 },")

# ---------------------------------------------------------------- 2. an unmeasured machine starts at medium
s = sub1(s, """function gfxLoad() {
  let n = null;
  try { n = localStorage.getItem('g3d_gfx'); } catch (e) { n = null; }
  gfxSet(GFX_PRESETS[n] ? n : 'high', true);
}""",
"""function gfxLoad() {
  let n = null;
  try { n = localStorage.getItem('g3d_gfx'); } catch (e) { n = null; }
  // A machine nobody has measured starts in the middle and is allowed to
  // climb. Starting at high and falling means the first thing a new player
  // sees is a slideshow, and first impressions of a frame rate are permanent.
  const known = !!GFX_PRESETS[n];
  GFX.userSet = known;
  gfxSet(known ? n : 'medium', true);
}""")
# choosing a level yourself stops the automatic stepping for the session
s = sub1(s, """function gfxSet(name, silent) {
  if (!GFX_PRESETS[name]) return;""",
"""function gfxSet(name, silent) {
  if (!GFX_PRESETS[name]) return;
  // Anything the player picks is final. A setting that quietly undoes what
  // you just chose is worse than having no setting at all.
  if (!silent) { GFX.userSet = true; GFX.autoQ = false; }""")

# ---------------------------------------------------------------- 3. the automatic step
s = sub1(s, """// automatic resolution: keep frames under ~20 ms by trading render scale
function r2AutoRes() {
  const now = performance.now();
  if (R2.lastT) {
    const ft = Math.min(100, now - R2.lastT);
    R2.ftAvg += (ft - R2.ftAvg) * 0.05;
    R2.fps = 1000 / Math.max(1, R2.ftAvg);
  }
  R2.lastT = now;
  if (!R2.auto || now - R2.lastChange < 1500) return;
  if (R2.ftAvg > 21 && R2.dyn > 0.6) { R2.dyn = Math.max(0.6, R2.dyn - 0.08); R2.lastChange = now; }
  else if (R2.ftAvg < 15.5 && R2.dyn < 1) { R2.dyn = Math.min(1, R2.dyn + 0.05); R2.lastChange = now; }
}""",
r"""// Automatic quality. Resolution alone could never fix a machine that is half
// a second a frame: at that point the cost is the world, not the pixels, so
// the PRESET moves first and the resolution trim is the fine adjustment
// underneath it.
const AQ = {
  on: true,            // off the moment the player picks a level themselves
  warm: 0,             // seconds of frames seen, so a cold start is not judged
  last: 0,             // when the preset last moved
  said: 0,             // when we last told the player
  up: 0,               // how long frames have been comfortably fast
};
const AQ_BUDGET = 22;         // ms a frame we are aiming to stay under
const AQ_DIRE = 55;           // ms a frame that means drop two levels at once
const AQ_UP = 11;             // ms a frame under which climbing is safe
const AQ_COOL = 4;            // seconds between steps down
const AQ_UP_HOLD = 12;        // seconds of fast frames before stepping up
function gfxStep(d, why) {
  const i = GFX_ORDER.indexOf(GFX.name);
  const j = clamp(i + d, 0, GFX_ORDER.length - 1);
  if (j === i) return false;
  gfxSet(GFX_ORDER[j], true);          // silent: the message below is better
  AQ.last = performance.now() / 1000;
  const now = AQ.last;
  if (now - AQ.said > 6) {
    AQ.said = now;
    toast('Graphics set to ' + GFX_ORDER[j] + (why ? ' · ' + why : '') +
          '. Pick a level yourself to stop this.', 4000);
  }
  return true;
}
function r2AutoRes() {
  const now = performance.now();
  let ft = 0;
  if (R2.lastT) {
    ft = Math.min(500, now - R2.lastT);
    // A long average is what stops one stalled frame from changing anything,
    // and a short one is what makes a genuinely bad machine felt quickly.
    R2.ftAvg += (ft - R2.ftAvg) * 0.05;
    R2.ftSlow += (ft - R2.ftSlow) * 0.012;
    R2.fps = 1000 / Math.max(1, R2.ftAvg);
  }
  R2.lastT = now;
  const t = now / 1000;

  // ---- the preset -----------------------------------------------------------
  if (AQ.on && !GFX.userSet) {
    AQ.warm += Math.min(0.5, ft / 1000);
    if (AQ.warm > 1.5) {
      const cool = t - AQ.last;
      if (R2.ftSlow > AQ_DIRE && cool > 1.5) {
        // dire: do not walk down one level at a time while it is unplayable
        AQ.up = 0; gfxStep(-2, 'this machine could not keep up');
      } else if (R2.ftSlow > AQ_BUDGET && cool > AQ_COOL) {
        AQ.up = 0; gfxStep(-1, Math.round(1000 / Math.max(1, R2.ftSlow)) + ' fps');
      } else if (R2.ftSlow < AQ_UP && R2.dyn >= 0.999) {
        // Climbing needs a long stretch of genuinely fast frames AND the
        // resolution already back at full, so it can never fight the trim.
        AQ.up += Math.min(0.5, ft / 1000);
        if (AQ.up > AQ_UP_HOLD && cool > AQ_UP_HOLD) { AQ.up = 0; gfxStep(1, 'there is room for more'); }
      } else AQ.up = 0;
    }
  }

  // ---- the resolution trim underneath it ------------------------------------
  if (!R2.auto || now - R2.lastChange < 1500) return;
  if (R2.ftAvg > 21 && R2.dyn > 0.6) { R2.dyn = Math.max(0.6, R2.dyn - 0.08); R2.lastChange = now; }
  else if (R2.ftAvg < 15.5 && R2.dyn < 1) { R2.dyn = Math.min(1, R2.dyn + 0.05); R2.lastChange = now; }
}""")
s = sub1(s, "const R2 = {\n  descOf: new Map(), ok: false,",
            "const R2 = {\n  descOf: new Map(), ok: false, ftSlow: 16,")

# the readout says which level you are on, so a drop is visible rather than felt
s = sub1(s, """  if (el) el.textContent = Math.round(R2.fps) + ' fps · ' + Math.round(r2SceneScale() * 100) + '%';""",
             """  if (el) el.textContent = Math.round(R2.fps) + ' fps · ' + GFX.name + ' · ' + Math.round(r2SceneScale() * 100) + '%';""")

# ---------------------------------------------------------------- 4. the horror is a high-end feature
for fn, arg in [('function drool(g, e, x, y, halfW, n, len, seed) {', 'e'),
                ('function innerJaw(g, e, x0, y0, scale, open) {', 'e'),
                ('function lipTendrils(g, e, x0, y0, halfW, n, len, back) {', 'e')]:
    s = sub1(s, fn + "\n  if (e.lod) return;",
                fn + "\n  if (!gore(e)) return;")
s = sub1(s, "const SPIT = [0.74, 0.80, 0.72];        // saliva: pale, cold, slightly green",
"""// The wet detail is the most expensive thing per creature in the game and the
// least necessary on a machine that is struggling, so it rides the quality
// setting. Palette icons keep it at every level: a still image costs nothing
// and it is the one place anybody looks at a mouth closely.
function gore(e) { return !!e.thumb || (!e.lod && GFX.gore); }
const SPIT = [0.74, 0.80, 0.72];        // saliva: pale, cold, slightly green""")
s = sub1(s, "  if (!e.lod && open > 0.25) droolStrand(g, p[0], p[1] - wide * 0.4, p[2], 0.34 * open, e.seed * 3.1, t, 0.028);",
            "  if (gore(e) && open > 0.25) droolStrand(g, p[0], p[1] - wide * 0.4, p[2], 0.34 * open, e.seed * 3.1, t, 0.028);")

# test surface
s = sub1(s, "  get GFX() { return GFX; }, gfxSet: (n) => gfxSet(n),",
"""  get GFX() { return GFX; }, gfxSet: (n) => gfxSet(n),
  gfx: {
    name: () => GFX.name, gore: () => !!GFX.gore, userSet: () => !!GFX.userSet,
    order: () => GFX_ORDER.slice(),
    // drive the automatic stepper with a pretend frame time, so the rule can
    // be checked without needing a slow machine
    feed: (ms, secs) => {
      const n = Math.max(1, Math.round((secs || 1) * 60));
      for (let i = 0; i < n; i++) {
        R2.ftSlow += (ms - R2.ftSlow) * 0.012;
        R2.ftAvg += (ms - R2.ftAvg) * 0.05;
        AQ.warm += 1 / 60;
        AQ.last -= 1 / 60; AQ.said -= 1 / 60;
        if (ms < 11 && R2.dyn >= 0.999) AQ.up += 1 / 60; else AQ.up = 0;
        const t2 = performance.now() / 1000, cool = t2 - AQ.last;
        if (!AQ.on || GFX.userSet || AQ.warm <= 1.5) continue;
        if (R2.ftSlow > 55 && cool > 1.5) { AQ.up = 0; gfxStep(-2, 'test'); }
        else if (R2.ftSlow > 22 && cool > 4) { AQ.up = 0; gfxStep(-1, 'test'); }
        else if (R2.ftSlow < 11 && R2.dyn >= 0.999 && AQ.up > 12 && cool > 12) { AQ.up = 0; gfxStep(1, 'test'); }
      }
      return GFX.name;
    },
    reset: (n) => { GFX.userSet = false; AQ.on = true; AQ.warm = 99; AQ.up = 0; AQ.last = 0; AQ.said = -99;
                    R2.ftSlow = 16; R2.ftAvg = 16; R2.dyn = 1; gfxSet(n || 'ultra', true); return GFX.name; },
  },""")

open(p, 'w', encoding='utf-8').write(s)
print('perf: auto quality ok')

# the checks need to be able to draw one mouth and count what came out
s = open(p, encoding='utf-8').read()
s = sub1(s, "  gfx: {\n    name: () => GFX.name,",
"""  VIS,
  gfx: {
    name: () => GFX.name,""")
open(p, 'w', encoding='utf-8').write(s)
print('perf: VIS exposed ok')
