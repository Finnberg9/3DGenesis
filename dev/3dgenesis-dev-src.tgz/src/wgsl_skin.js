// Skinned creature skin: two-bone vertex blend, lateral wave for serpents,
// noise-based coat patterns in rest space (so they never swim over moving
// limbs), baked ambient occlusion, per-vertex part colour, leathery micro
// relief and a soft sheen.
const WGSL_SKIN = WGSL_COMMON + `
@group(0) @binding(1) var<storage, read> bones : array<mat4x4<f32>>;
struct VO { @builtin(position) pos: vec4<f32>, @location(0) nrm: vec3<f32>,
            @location(1) wpos: vec3<f32>, @location(2) opos: vec3<f32>, @location(3) onrm: vec3<f32>,
            @location(4) base: vec3<f32>, @location(5) coat: vec3<f32>, @location(6) detail: vec3<f32>,
            @location(7) misc: vec4<f32>, @location(8) vcol: vec3<f32>, @location(9) scl: f32 };
@vertex fn vs(@location(0) p: vec3<f32>, @location(1) n: vec3<f32>, @location(2) ao: f32,
              @location(3) bn: vec2<f32>, @location(4) bw: f32, @location(5) vc: vec3<f32>, @location(6) paint: f32,
              @location(7) iPos: vec3<f32>, @location(8) iYaw: f32, @location(9) iScl: f32,
              @location(10) iBase: vec3<f32>, @location(11) iCoat: vec3<f32>, @location(12) iDetail: vec3<f32>,
              @location(13) iPat: f32, @location(14) iWave: vec3<f32>, @location(15) iBone: f32) -> VO {
  let b0 = i32(iBone + bn.x + 0.5);
  let b1 = i32(iBone + bn.y + 0.5);
  let M0 = bones[b0]; let M1 = bones[b1];
  let q0 = M0 * vec4<f32>(p, 1.0); let q1 = M1 * vec4<f32>(p, 1.0);
  var pp = q0.xyz * bw + q1.xyz * (1.0 - bw);
  let hl = q0.w * bw + q1.w * (1.0 - bw);
  let n0 = mat3x3<f32>(M0[0].xyz, M0[1].xyz, M0[2].xyz) * n;
  let n1 = mat3x3<f32>(M1[0].xyz, M1[1].xyz, M1[2].xyz) * n;
  let nn = normalize(n0 * bw + n1 * (1.0 - bw));
  if (iWave.x > 0.0) {
    pp.z += iWave.x * sin(iWave.y - pp.x * 2.4) * (0.35 + 0.65 * clamp((iWave.z - pp.x) / (2.0 * iWave.z), 0.0, 1.0));
  }
  let s = sin(iYaw); let c = cos(iYaw);
  let q = pp * iScl;
  let w = vec3<f32>(q.x * c - q.z * s, q.y, q.x * s + q.z * c) + iPos;
  let rn = vec3<f32>(nn.x * c - nn.z * s, nn.y, nn.x * s + nn.z * c);
  var o: VO; o.pos = g.viewProj * vec4<f32>(w, 1.0);
  o.nrm = rn; o.wpos = w; o.opos = p; o.onrm = n;
  o.base = iBase; o.coat = iCoat; o.detail = iDetail; o.misc = vec4<f32>(iPat, ao, paint, hl); o.vcol = vc; o.scl = iScl;
  return o;
}
fn hash3(p: vec3<f32>) -> f32 {
  let q = fract(p * vec3<f32>(0.1031, 0.1030, 0.0973));
  let r = q + dot(q, q.yxz + 33.33);
  return fract((r.x + r.y) * r.z);
}
fn vnoise(p: vec3<f32>) -> f32 {
  let i = floor(p); let f = fract(p);
  let u = f * f * (3.0 - 2.0 * f);
  let a = mix(mix(hash3(i), hash3(i + vec3<f32>(1.0, 0.0, 0.0)), u.x),
              mix(hash3(i + vec3<f32>(0.0, 1.0, 0.0)), hash3(i + vec3<f32>(1.0, 1.0, 0.0)), u.x), u.y);
  let b = mix(mix(hash3(i + vec3<f32>(0.0, 0.0, 1.0)), hash3(i + vec3<f32>(1.0, 0.0, 1.0)), u.x),
              mix(hash3(i + vec3<f32>(0.0, 1.0, 1.0)), hash3(i + vec3<f32>(1.0, 1.0, 1.0)), u.x), u.y);
  return mix(a, b, u.z);
}
fn fbm(p: vec3<f32>) -> f32 {
  return vnoise(p) * 0.55 + vnoise(p * 2.03 + 11.7) * 0.28 + vnoise(p * 4.1 + 3.1) * 0.17;
}
// distance to the nearest and second-nearest jittered cell point
fn worley(p: vec3<f32>) -> vec2<f32> {
  let i = floor(p); let f = fract(p);
  var d1 = 9.0; var d2 = 9.0;
  for (var z = -1; z <= 1; z++) { for (var y = -1; y <= 1; y++) { for (var x = -1; x <= 1; x++) {
    let o = vec3<f32>(f32(x), f32(y), f32(z));
    let c = i + o;
    let r = o + vec3<f32>(hash3(c), hash3(c + 17.1), hash3(c + 41.7)) * 0.8 + 0.1 - f;
    let d = dot(r, r);
    if (d < d1) { d2 = d1; d1 = d; } else if (d < d2) { d2 = d; }
  } } }
  return vec2<f32>(sqrt(d1), sqrt(d2));
}
// nearest cell point: distances plus the offset to the nearest point and its id
struct Wv { d1: f32, d2: f32, off: vec3<f32>, id: f32 };
fn worleyV(p: vec3<f32>) -> Wv {
  let i = floor(p); let f = fract(p);
  var w: Wv; w.d1 = 9.0; w.d2 = 9.0; w.off = vec3<f32>(0.0); w.id = 0.0;
  for (var z = -1; z <= 1; z++) { for (var y = -1; y <= 1; y++) { for (var x = -1; x <= 1; x++) {
    let o = vec3<f32>(f32(x), f32(y), f32(z));
    let c = i + o;
    let r = o + vec3<f32>(hash3(c), hash3(c + 17.1), hash3(c + 41.7)) * 0.8 + 0.1 - f;
    let d = dot(r, r);
    if (d < w.d1) { w.d2 = w.d1; w.d1 = d; w.off = r; w.id = hash3(c + 5.3); } else if (d < w.d2) { w.d2 = d; }
  } } }
  w.d1 = sqrt(w.d1); w.d2 = sqrt(w.d2);
  return w;
}
// Overlapping shingles (scales or feathers) on a cylindrical parameterisation
// around the body axis: u runs head(+) to tail(-), v around the body. Rows nearer
// the head lie on top, so every piece overlaps the root of the one behind it.
// Returns (height, rim distance, id).
fn shingle(u: f32, v: f32, rad: f32) -> vec3<f32> {
  let r0 = floor(u);
  for (var k = 1; k >= -1; k--) {
    let r = r0 + f32(k);
    let odd = fract(r * 0.5) > 0.25;
    let off = select(0.0, 0.5, odd);
    let cv0 = floor(v - off + 0.5) + off;
    var bd = 9.0; var bc = vec2<f32>(0.0);
    for (var j = -1; j <= 1; j++) {
      let c = vec2<f32>(r + 0.5 - 0.45, cv0 + f32(j));
      let d = length(vec2<f32>(u - c.x, v - c.y)) / rad;
      if (d < bd) { bd = d; bc = c; }
    }
    if (bd < 1.0) {
      let t = clamp(0.5 - (u - bc.x) / rad * 0.5, 0.0, 1.0);    // 0 at the covered root, 1 at the free rim
      return vec3<f32>(t * 0.75 + (1.0 - bd * bd) * 0.35, 1.0 - bd, hash3(vec3<f32>(bc, 3.7)));
    }
  }
  return vec3<f32>(0.0, 0.0, 0.5);
}
@fragment fn fs(i: VO) -> @location(0) vec4<f32> {
  let p = i.opos; let n = normalize(i.onrm);
  let pk = i.misc.x;
  let skin = floor(pk / 16.0 + 0.001);
  let pat = pk - skin * 16.0;
  let edge = fbm(p * 2.2) - 0.5;
  // coat: countershaded underside with a soft, noisy boundary
  let coatW = smoothstep(-0.12, 0.42, -n.y + edge * 0.45) * 0.95;
  var m = 0.0;
  if (pat > 0.5 && pat < 1.5) {            // stripes, warped so they look grown, not drawn
    let v = sin(p.x * 6.2 + fbm(p * 1.4) * 3.2 + p.y * 1.1);
    m = smoothstep(0.25, 0.55, v);
  } else if (pat > 1.5 && pat < 2.5) {     // spots
    let wv = worley(p * 2.8 + vec3<f32>(edge * 0.6));
    m = 1.0 - smoothstep(0.26, 0.36, wv.x);
  } else if (pat > 2.5 && pat < 3.5) {     // patches separated by pale seams
    let wv = worley(p * 1.9 + vec3<f32>(edge * 0.8));
    m = smoothstep(0.05, 0.12, wv.y - wv.x);
  } else if (pat > 3.5 && pat < 4.5) {     // dark saddle along the back
    m = smoothstep(0.2, 0.5, n.y + edge * 0.7);
  } else if (pat > 4.5) {                  // speckle
    let wv = worley(p * 9.0);
    m = 1.0 - smoothstep(0.14, 0.22, wv.x);
  }
  var painted = mix(i.base, i.detail, m * (1.0 - coatW));
  painted = mix(painted, i.coat, coatW);
  painted *= 0.93 + 0.12 * fbm(p * 7.0);
  var col = mix(i.vcol, painted, clamp(i.misc.z, 0.0, 1.0));

  // ---- skin covering: a height field in rest space, turned into a normal
  // perturbation with screen-space derivatives (so it follows the posed skin)
  var h = 0.0; var tone = 1.0; var amp = 0.0; var gloss = 1.0; var fuzz = 0.0;
  let belly = clamp(-n.y, 0.0, 1.0);
  let arc = atan2(p.z, p.y) * max(0.15, length(p.yz));
  if (skin > 0.5 && skin < 1.5) {          // scales: small overlapping reptile scales, finer on the belly
    let sf = mix(10.0, 15.0, belly);
    let sh = shingle(p.x * sf, arc * sf, 0.74);
    h = sh.x;
    tone = mix(0.78, 1.0, smoothstep(0.0, 0.25, sh.y)) * (0.95 + 0.1 * sh.z);
    amp = 0.12 / sf; gloss = 1.1;
  } else if (skin > 1.5 && skin < 2.5) {   // feathers: long shingles lying toward the tail
    let sh = shingle(p.x * 4.2 + fbm(p * 2.0) * 0.4, arc * 6.5, 0.78);
    h = sh.x;
    let barbs = 0.5 + 0.5 * sin(arc * 60.0 + p.x * 8.0);
    tone = mix(0.72, 1.08, sh.x) * (0.9 + 0.2 * sh.z) * (0.95 + 0.06 * barbs);
    amp = 0.035; gloss = 0.55; fuzz = 0.25;
  } else if (skin > 2.5 && skin < 3.5) {   // fur: fine strands combed back, fuzzy silhouette
    let q = vec3<f32>(p.x * 10.0 + fbm(p * 4.0) * 1.5, p.y * 55.0, p.z * 55.0);
    h = vnoise(q) * 0.7 + vnoise(q * 2.3 + 7.0) * 0.3;
    tone = 0.9 + 0.16 * h;
    amp = 0.012; gloss = 0.25; fuzz = 0.55;
  } else if (skin > 3.5) {                 // armour plates: big flat plates with deep seams
    let w = worleyV(p * mix(5.5, 9.0, belly));
    let e = w.d2 - w.d1;
    h = smoothstep(0.0, 0.1, e) * (1.0 - 0.15 * w.d1);
    tone = mix(0.6, 1.0, smoothstep(0.0, 0.07, e)) * (0.9 + 0.2 * w.id);
    amp = 0.1; gloss = 2.2;
  } else {                                 // smooth, leathery micro relief
    h = fbm(p * 26.0) * 0.5;
    amp = 0.012; gloss = 1.0;
  }
  col *= tone;
  var N = normalize(i.nrm);
  let hh = h * amp * i.scl;
  let dpx = dpdx(i.wpos); let dpy = dpdy(i.wpos);
  let dhx = dpdx(hh); let dhy = dpdy(hh);
  let r1 = cross(dpy, N); let r2 = cross(N, dpx);
  let det = dot(dpx, r1);
  if (abs(det) > 1e-12) {
    let grad = sign(det) * (dhx * r1 + dhy * r2);
    N = normalize(abs(det) * N - grad);
  }
  let ao = pow(clamp(i.misc.y, 0.0, 1.0), 1.15) * mix(0.8, 1.0, h);
  col = col * i.misc.w;
  var lit = shade(col * (0.35 + 0.65 * ao), N, i.wpos);
  let L = normalize(g.lightDir.xyz);
  let V = normalize(g.camPos.xyz - i.wpos);
  let H = normalize(L + V);
  lit += vec3<f32>(1.0, 0.97, 0.9) * pow(max(dot(N, H), 0.0), 20.0 + 30.0 * gloss) * 0.1 * gloss * g.params.z * ao;
  let wrap = clamp(1.0 - abs(dot(N, L)), 0.0, 1.0);
  lit += col * vec3<f32>(0.22, 0.08, 0.05) * wrap * wrap * 0.3 * g.params.z;
  // fur and down catch light on the silhouette
  let rim = pow(1.0 - clamp(dot(normalize(i.nrm), V), 0.0, 1.0), 2.5);
  lit += col * rim * fuzz * (0.4 + 0.6 * g.params.z);
  return vec4<f32>(lit, 1.0);
}`;