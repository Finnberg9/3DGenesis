# =====================================================================
# A AND D ARE A LUNGE, NOT A STRAFE
#
# Sidestepping while facing forward is a shooter's movement, and it is why
# every fight turned into two animals sliding sideways past each other. An
# animal that wants to go left turns left. What it CANNOT do is walk
# sideways, and what it can do is throw itself sideways, once, hard.
#
#   W / S        walk, forward and back, along the way you are looking
#   A / D        lunge left or right: the dodge roll, given a direction
#   arrows       the same two pairs, for a pad's d-pad
#
# The lunge is the dodge that already existed, so it keeps everything that
# made the dodge worth pressing: the stamina cost, the cooldown, the
# invulnerable window at the start of the roll, and the sound. It is now the
# only way to move sideways, which makes those invulnerable frames something
# you spend rather than something you hold.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, ('ANCHOR %d/%d' % (n, cnt), a[:110]); return s.replace(a, b)

p = 'g3.html'; s = open(p, encoding='utf-8').read()

# ---------------------------------------------------------------- 1. no more strafing
s = sub1(s, """  if (keys['w']) { fx += Math.cos(player.yaw); fz += Math.sin(player.yaw); }
  if (keys['s']) { fx -= Math.cos(player.yaw); fz -= Math.sin(player.yaw); }
  if (keys['a']) { fx += Math.sin(player.yaw); fz -= Math.cos(player.yaw); }
  if (keys['d']) { fx -= Math.sin(player.yaw); fz += Math.cos(player.yaw); }""",
"""  // Forward and back only. A body walks the way it is pointed; going left
  // means turning left. Sideways is a lunge, not a gait -- see tryLunge.
  if (keys['w'] || keys['arrowup']) { fx += Math.cos(player.yaw); fz += Math.sin(player.yaw); }
  if (keys['s'] || keys['arrowdown']) { fx -= Math.cos(player.yaw); fz -= Math.sin(player.yaw); }""")

# ---------------------------------------------------------------- 2. the lunge
s = sub1(s, """function tryDodge() {
  const c = player.c;
  if (!c || !c.alive || player.spectator) return;
  if (FIGHT.dodgeCD > 0 || FIGHT.stagger > 0) return;
  if (FIGHT.exhausted || FIGHT.stam < STAM_DODGE * 0.5) { toast('Too exhausted to dodge.', 900); return; }
  let fx = 0, fz = 0;
  const cy = Math.cos(player.yaw), sy = Math.sin(player.yaw);
  if (keys['w']) { fx += cy; fz += sy; }
  if (keys['s']) { fx -= cy; fz -= sy; }
  if (keys['a']) { fx += sy; fz -= cy; }
  if (keys['d']) { fx -= sy; fz += cy; }
  let l = Math.hypot(fx, fz);
  if (l < 1e-6) { fx = -cy; fz = -sy; l = 1; }        // no direction held: hop back
  FIGHT.dodgeDX = fx / l; FIGHT.dodgeDZ = fz / l;
  FIGHT.dodgeT = DODGE_DUR; FIGHT.iframe = DODGE_IFRAME; FIGHT.dodgeCD = DODGE_CD;
  fightSpend(STAM_DODGE);
  if (typeof sndNoiseBurst === 'function' && SND.ctx && SND.on) sndNoiseBurst(700, 0.8, 0.22, 0.10, 0, 1.4);
}""",
"""// The roll, given a direction in world space. One place, so every way of
// asking for one -- A, D, Z, a tapped shift -- spends the same stamina, takes
// the same cooldown and gets the same invulnerable window.
function dodgeIn(fx, fz, why) {
  const c = player.c;
  if (!c || !c.alive || player.spectator) return false;
  if (FIGHT.dodgeCD > 0 || FIGHT.stagger > 0) return false;
  if (FIGHT.exhausted || FIGHT.stam < STAM_DODGE * 0.5) { toast('Too exhausted to ' + (why || 'dodge') + '.', 900); return false; }
  const l = Math.hypot(fx, fz) || 1;
  FIGHT.dodgeDX = fx / l; FIGHT.dodgeDZ = fz / l;
  FIGHT.dodgeT = DODGE_DUR; FIGHT.iframe = DODGE_IFRAME; FIGHT.dodgeCD = DODGE_CD;
  fightSpend(STAM_DODGE);
  if (typeof sndNoiseBurst === 'function' && SND.ctx && SND.on) sndNoiseBurst(700, 0.8, 0.22, 0.10, 0, 1.4);
  return true;
}
// A and D: throw yourself sideways. side = -1 left, +1 right.
function tryLunge(side) {
  const cy = Math.cos(player.yaw), sy = Math.sin(player.yaw);
  // +90 degrees from the facing is the player's left
  return dodgeIn(side < 0 ? sy : -sy, side < 0 ? -cy : cy, 'lunge');
}
// Z, or a tapped shift: roll whichever way you are already going, and back
// if you are standing still. Sideways is no longer held down, so this is the
// only thing left that can read a direction off the movement keys.
function tryDodge() {
  const cy = Math.cos(player.yaw), sy = Math.sin(player.yaw);
  let fx = 0, fz = 0;
  if (keys['w'] || keys['arrowup']) { fx += cy; fz += sy; }
  if (keys['s'] || keys['arrowdown']) { fx -= cy; fz -= sy; }
  if (Math.hypot(fx, fz) < 1e-6) { fx = -cy; fz = -sy; }   // nothing held: hop back
  return dodgeIn(fx, fz);
}""")

# ---------------------------------------------------------------- 3. the keys
s = sub1(s, """      if (k === 'z' && started) tryDodge();""",
"""      if (k === 'z' && started) tryDodge();
      // A and D are a lunge, and only on the press: holding one must not
      // machine-gun rolls, which is why this sits inside the !repeat guard.
      if ((k === 'a' || k === 'arrowleft') && started) tryLunge(-1);
      if ((k === 'd' || k === 'arrowright') && started) tryLunge(1);""")
s = sub1(s, "    if ([' ', 'w', 'a', 's', 'd'].includes(k)) e.preventDefault();",
            "    if ([' ', 'w', 'a', 's', 'd', 'arrowup', 'arrowdown', 'arrowleft', 'arrowright'].includes(k)) e.preventDefault();")

# ---------------------------------------------------------------- 4. say so
s = s.replace('<b>W A S D</b> move', '<b>W S</b> walk &middot; <b>A D</b> lunge')
s = s.replace('WASD move', 'W/S walk, A/D lunge')

# test surface
s = sub1(s, "    resetFall: () => fallResetGround(),",
"""    resetFall: () => fallResetGround(),
    lunge: (side) => tryLunge(side),
    dodgeVec: () => ({ x: +FIGHT.dodgeDX.toFixed(3), z: +FIGHT.dodgeDZ.toFixed(3), t: +FIGHT.dodgeT.toFixed(3) }),
    clearDodge: () => { FIGHT.dodgeT = 0; FIGHT.dodgeCD = 0; FIGHT.iframe = 0; FIGHT.stam = STAM_MAX; FIGHT.exhausted = false; },
    drainStam: () => { FIGHT.stam = 0; FIGHT.exhausted = true; },
    setKeys: (o) => { for (const k in keys) keys[k] = false; for (const k in o) keys[k] = !!o[k]; },
    moveVec: (dt) => { const c = player.c; movePlayer(c, dt || 0.016); return { vx: +c.vx.toFixed(2), vy: +c.vy.toFixed(2) }; },""")

open(p, 'w', encoding='utf-8').write(s)
print('lunge ok')
