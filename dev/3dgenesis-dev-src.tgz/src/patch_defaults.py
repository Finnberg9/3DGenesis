# Default world settings (per Finn) and the control panel hidden until opened.
def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
p='g3.html'; s=open(p,encoding='utf-8').read()
D=[('tscale','0.12','0.01','0.120','0.010'),('plant','40','20','40','20'),('pe','30','10','30','10'),
   ('dayl','18','10','18','10'),('yearl','70','10','70','10'),('clife','12','50','12','50'),
   ('cy','1','0.5','1.0','0.5'),('fp','0.7','0.5','0.70','0.50'),('fd','0.4','0.6','0.40','0.60')]
import re
for id_,old,new,lo,ln in D:
    s=sub1(s,f'<input id="{id_}" type="range"',f'<input id="{id_}" type="range"')
    s=re.sub(r'(<input id="'+id_+r'" type="range"[^>]*value=")'+re.escape(old)+'"', lambda m: m.group(1)+new+'"', s, count=1)
    assert f'id="{id_}" type="range"' in s and re.search(r'<input id="'+id_+r'" type="range"[^>]*value="'+re.escape(new)+'"', s), id_
    s=sub1(s,f'<b id="{id_}v">{lo}</b>',f'<b id="{id_}v">{ln}</b>')
    s=sub1(s,f"num('{id_}', {old})",f"num('{id_}', {new})")
s=sub1(s,'<input id="startPopR" type="range" min="2" max="500" step="1" value="50"','<input id="startPopR" type="range" min="2" max="500" step="1" value="100"')
s=sub1(s,'<input id="startPop" type="number" min="2" max="2000" value="50"','<input id="startPop" type="number" min="2" max="2000" value="100"')
s=sub1(s,'start plants <input id="startPlants" type="number" min="0" max="40000" value="500">','start plants <input id="startPlants" type="number" min="0" max="40000" value="0">')
s=sub1(s,'<div id="panel">','<div id="panel" class="hidden">')
open(p,'w',encoding='utf-8').write(s)
print('defaults ok')
s=open(p,encoding='utf-8').read()
# the predator warning sat underneath the goal box; put it below
s=sub1(s,"  #warn{position:fixed;left:50%;top:14px;","  #warn{position:fixed;left:50%;top:112px;")
open(p,'w',encoding='utf-8').write(s)
s=open(p,encoding='utf-8').read()
s=sub1(s,"  body.editing #gfxsel{display:none}","  body.editing #gfxsel{display:none}\n  body.editing #objective{display:none !important}")
open(p,'w',encoding='utf-8').write(s)
s=open(p,encoding='utf-8').read()
# energy is shown to the player as health
s=sub1(s,'<span class="k">energy</span><span class="bar"><i id="v-e"','<span class="k">health</span><span class="bar"><i id="v-e"')
s=sub1(s,"toast('Ate carrion. +' + gain.toFixed(0) + ' energy.', 1800);","toast('Ate carrion. +' + gain.toFixed(0) + ' health.', 1800);")
s=sub1(s,"toast('Ate. +' + gain.toFixed(0) + ' energy.', 1400);","toast('Ate. +' + gain.toFixed(0) + ' health.', 1400);")
open(p,'w',encoding='utf-8').write(s)
