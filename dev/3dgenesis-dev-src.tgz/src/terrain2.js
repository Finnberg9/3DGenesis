// =====================================================================
// TERRAIN 2: rocks and boulders, pebbles, driftwood, and shallow water.
//
// Boulders are real obstacles: the core places them with the static forest
// (kind 9, solid like a trunk). Pebbles, stones and driftwood are ground
// cover. Every rock is a noise-displaced icosphere, flattened and sunk into
// the ground, with moss on its top and its own rock material in the shader.
// Water now knows how deep it is (a height texture of the terrain), so
// shallows turn clear turquoise over the sand, and small waves roll in and
// break as foam on the shore.
// =====================================================================
function rkHash(x, y, z, s) {
  let h = (Math.imul(x | 0, 73856093) ^ Math.imul(y | 0, 19349663) ^ Math.imul(z | 0, 83492791) ^ Math.imul(s | 0, 2654435761)) >>> 0;
  h = Math.imul(h ^ (h >>> 15), 2246822519) >>> 0; h = Math.imul(h ^ (h >>> 13), 3266489917) >>> 0;
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}
function rkNoise(x, y, z, s) {                     // smooth 3D value noise, 0..1
  const xi = Math.floor(x), yi = Math.floor(y), zi = Math.floor(z);
  const fx = x - xi, fy = y - yi, fz = z - zi;
  const u = fx * fx * (3 - 2 * fx), v = fy * fy * (3 - 2 * fy), w = fz * fz * (3 - 2 * fz);
  const L = (a, b, t) => a + (b - a) * t;
  const c = (i, j, k) => rkHash(xi + i, yi + j, zi + k, s);
  return L(L(L(c(0, 0, 0), c(1, 0, 0), u), L(c(0, 1, 0), c(1, 1, 0), u), v),
           L(L(c(0, 0, 1), c(1, 0, 1), u), L(c(0, 1, 1), c(1, 1, 1), u), v), w);
}
// unit icosphere, subdivided n times; returns { v: [[x,y,z]], f: [[a,b,c]] }
function rkIco(n) {
  const t = (1 + Math.sqrt(5)) / 2;
  let v = [[-1, t, 0], [1, t, 0], [-1, -t, 0], [1, -t, 0], [0, -1, t], [0, 1, t], [0, -1, -t], [0, 1, -t], [t, 0, -1], [t, 0, 1], [-t, 0, -1], [-t, 0, 1]].map(fnorm);
  let f = [[0, 11, 5], [0, 5, 1], [0, 1, 7], [0, 7, 10], [0, 10, 11], [1, 5, 9], [5, 11, 4], [11, 10, 2], [10, 7, 6], [7, 1, 8],
           [3, 9, 4], [3, 4, 2], [3, 2, 6], [3, 6, 8], [3, 8, 9], [4, 9, 5], [2, 4, 11], [6, 2, 10], [8, 6, 7], [9, 8, 1]];
  for (let s = 0; s < n; s++) {
    const mid = new Map(), nf = [];
    const m = (a, b) => { const k = a < b ? a + '_' + b : b + '_' + a; let i = mid.get(k); if (i == null) { i = v.length; v.push(fnorm(fmul(fadd(v[a], v[b]), 0.5))); mid.set(k, i); } return i; };
    for (const [a, b, c] of f) { const ab = m(a, b), bc = m(b, c), ca = m(c, a); nf.push([a, ab, ca], [b, bc, ab], [c, ca, bc], [ab, bc, ca]); }
    f = nf;
  }
  return { v, f };
}
const RK_ICO = [rkIco(1), rkIco(2), rkIco(3)];
// one rock: centre c, radius R, vertical squash, colour, detail level 0..2
function folRock(m, c, R, squash, col, seed, detail, moss) {
  const ico = RK_ICO[clamp(detail, 0, 2)];
  const P = [], N = [];
  const base = c[1] - R * squash * 0.35;              // sunk: the bottom third is below ground
  const ang = seed * 1.7;
  const ca = Math.cos(ang), sa = Math.sin(ang);
  for (const u of ico.v) {
    const n1 = rkNoise(u[0] * 1.6 + seed, u[1] * 1.6, u[2] * 1.6, seed | 0);
    const n2 = rkNoise(u[0] * 3.8, u[1] * 3.8 + seed, u[2] * 3.8, (seed | 0) + 7);
    const n3 = rkNoise(u[0] * 8.5, u[1] * 8.5, u[2] * 8.5 + seed, (seed | 0) + 13);
    // chunky facets: a blocky low-frequency shape, softer detail on top
    const r = R * (0.72 + 0.55 * n1 + 0.22 * n2 + 0.06 * n3);
    let x = u[0] * r * (1.05 + 0.25 * Math.sin(seed)), y = u[1] * r * squash, z = u[2] * r;
    const xr = x * ca - z * sa, zr = x * sa + z * ca;
    let py = c[1] + y;
    if (py < base) py = base + (py - base) * 0.15;     // flatten the buried underside
    P.push([c[0] + xr, py, c[2] + zr]); N.push([0, 0, 0]);
  }
  for (const [a, b, cc] of ico.f) {
    const n = fcross(fsub(P[b], P[a]), fsub(P[cc], P[a]));
    for (const k of [a, b, cc]) N[k] = fadd(N[k], n);
  }
  const idx = P.map((p, k) => {
    const n = fnorm(N[k]);
    const h = rkNoise(p[0] * 0.3, p[1] * 0.3, p[2] * 0.3, 3);
    let cl = fcol(col, 0.78 + 0.34 * h);
    const up = n[1];
    if (moss && up > 0.45) cl = fadd(fmul(cl, 1 - moss * (up - 0.45) * 1.4), fmul([0.20, 0.30, 0.10], moss * (up - 0.45) * 1.4));
    const ao = 0.55 + 0.45 * clamp((p[1] - base) / Math.max(0.5, R * squash * 0.9), 0, 1);
    return folV(m, p, n, fcol(cl, ao), 0, -1);
  });
  for (const [a, b, cc] of ico.f) m.i.push(idx[a], idx[b], idx[cc]);
}
const RK_COLS = [[0.46, 0.44, 0.40], [0.52, 0.47, 0.40], [0.38, 0.37, 0.36], [0.56, 0.52, 0.46]];
// boulder "tree" kind 9: radius 10 at scale 1, sometimes a split pair
function buildBoulderMesh(variant, lod) {
  const m = folMB();
  const col = RK_COLS[variant % RK_COLS.length];
  const det = [2, 1, 0][lod];
  folRock(m, [0, 0, 0], 10, 0.62 + 0.12 * variant, col, 11 + variant * 5, det, 0.8);
  if (variant === 1 && lod < 2) folRock(m, [9, 0, 4], 5.5, 0.7, fcol(col, 0.95), 29, Math.max(0, det - 1), 0.8);
  if (variant === 2 && lod < 2) { folRock(m, [-8, 0, -6], 3.2, 0.8, col, 41, 0, 0.6); folRock(m, [6, 0, -8], 2.4, 0.8, col, 47, 0, 0.6); }
  return { m, H: 14 };
}
// ground-cover rocks: 6 pebble scatter, 7 medium stone, 8 driftwood
function buildRockCover(kind, variant) {
  const rnd = folRng(7100 + kind * 13 + variant * 5);
  const m = folMB();
  if (kind === 6) {
    const n = 6 + variant * 3;
    for (let k = 0; k < n; k++) {
      const a = rnd() * 6.283, r = rnd() * 7, R = 0.35 + rnd() * rnd() * 1.3;
      folRock(m, [Math.cos(a) * r, 0, Math.sin(a) * r], R, 0.55 + rnd() * 0.3, RK_COLS[(rnd() * 4) | 0], 100 + k * 3 + variant * 50, 0, 0);
    }
  } else if (kind === 7) {
    folRock(m, [0, 0, 0], 2.2 + variant * 1.2, 0.65, RK_COLS[variant + 1], 200 + variant * 9, 1, 0.5);
    folRock(m, [2.6, 0, 1.2], 0.9, 0.7, RK_COLS[0], 211 + variant, 0, 0.2);
  } else {
    // driftwood: a bleached, crooked log with a stub branch
    const col = [0.62, 0.58, 0.50];
    const pts = [], rad = [];
    const len = 16 + variant * 6;
    for (let k = 0; k <= 5; k++) { const u = k / 5; pts.push([u * len - len / 2, 0.6 + Math.sin(u * 5) * 0.3, Math.sin(u * 3 + variant) * 1.6]); rad.push(1.1 - 0.6 * u); }
    folTube(m, pts, rad, 6, col, 10, 0, 0.7);
    folLimb(m, pts[2], fadd(pts[2], [1.5, 2.5, 3.5]), 0.45, 0.2, 0.6, 5, col, 10, 0);
  }
  return m;
}

// ---------------------------------------------------------------- water depth
let WH = { tex: null, nx: 0, nz: 0 };
function waterHeightTex() {
  if (!WH.tex) {
    WH.tex = dev.createTexture({ size: [1, 1], format: 'rg32float', usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_DST });
    dev.queue.writeTexture({ texture: WH.tex }, new Float32Array([-1000, 0]), { bytesPerRow: 8 }, [1, 1]);
    WH.nx = 1; WH.nz = 1;
  }
  return WH.tex;
}
function waterHeightUpload() {
  if (!terrH || !terrNX) return;
  const nx = terrNX, nz = terrNZ;
  if (WH.tex && (WH.nx !== nx || WH.nz !== nz)) { WH.tex.destroy(); WH.tex = null; }
  if (!WH.tex) WH.tex = dev.createTexture({ size: [nx, nz], format: 'rg32float', usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_DST });
  WH.nx = nx; WH.nz = nz;
  // r: ground height (world units), g: 1 where the water is frozen (cold country)
  const data = new Float32Array(nx * nz * 2);
  const cold = { snow: 1, tundra: 1, taiga: 1, scree: 1 };
  const coldAt = (x, z) => cold[terrain.biomeAt(clamp(x, 0, WORLD_W - 1), clamp(z, 0, WORLD_H - 1))] ? 1 : 0;
  for (let j = 0; j < nz; j++) for (let i = 0; i < nx; i++) {
    const k = j * nx + i;
    data[k * 2] = terrH[k] * HEIGHT_SCALE;
    // a lake is frozen if its shore is cold: sample a ring around the point
    let c = 0;
    if (terrH[k] < terrain.LV.water && !terrain.isDeep(i * GRID_STEP, j * GRID_STEP) && (i % 2 === 0 || true)) {
      const x = i * GRID_STEP, z = j * GRID_STEP;
      c = coldAt(x, z) || coldAt(x + 160, z) || coldAt(x - 160, z) || coldAt(x, z + 160) || coldAt(x, z - 160) ? 1 : 0;
    }
    data[k * 2 + 1] = c;
  }
  dev.queue.writeTexture({ texture: WH.tex }, data, { bytesPerRow: nx * 8 }, [nx, nz]);
  if (typeof makeBindGroups === 'function' && bindG) makeBindGroups();
}
