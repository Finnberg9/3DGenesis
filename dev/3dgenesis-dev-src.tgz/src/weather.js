// =====================================================================
// WEATHER: rain, storms, and the wetness the whole renderer was waiting for.
//
// The sky is a PURE FUNCTION of (seed, world.bt), exactly like world.light.
// Nothing about it is stored, so a reloaded world gets the weather it had,
// every client of a match sees the same sky without a packet, and a
// fast-forwarded world still gets its rain in the right places.
//
// One derived quantity is NOT pure, and cannot be: surface wetness is the
// integral of rain over time with a long decay, so it is stepped in
// world.wet. It converges on its own from any starting value, which is why
// it is safe to leave it out of a save.
//
// world.wet is written into fogCol.w every frame and read by the skin,
// terrain, foliage and rock shaders as the global wetness channel.
// =====================================================================

const WX = {
  rain: 0,          // 0..1 precipitation, eased in and out across a cell
  storm: 0,         // 0..1 how much of that rain is a thunderstorm
  gust: 0,          // 0..1 wind
  wind: [1, 0],     // unit wind direction, turns slowly over the day
  flash: 0,         // lightning, decays in ~0.15 s
  nextBolt: 4,      // real seconds until the next strike is considered
  boltDist: 1200,   // metres to the last strike, for the thunder delay
  thunder: [],      // queued rumbles: {t} in real seconds
  cell: -1,         // which weather cell we are in, for the once-per-cell toast
  said: -1,
};

// A weather cell is one stretch of sky: about a seventh of a day, so a storm
// is a couple of real minutes and a clear spell is rarely longer than ten.
function wxCellLen() {
  const dl = (world && world.params && world.params.dayLen) || 10;
  return dl / 7;
}
// Deterministic per-cell value. Mixing the world seed in means two worlds with
// the same clock do not share a sky.
function wxHash(cell, salt) {
  let h = (Math.imul(cell | 0, 374761393) ^ Math.imul(salt | 0, 668265263)
           ^ Math.imul((world && world.seed) | 0, 2246822519)) >>> 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177) >>> 0;
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}
// The envelope inside a cell: the sky takes time to close over and time to
// break up. A hard edge on rain reads as a bug, not as weather.
function wxEnvelope(u) {
  return Math.min(smooth01(u / 0.20), smooth01((1 - u) / 0.26));
}
function smooth01(x) { const t = clamp(x, 0, 1); return t * t * (3 - 2 * t); }

// Pure: what the sky is doing at this moment. No side effects, no state.
function wxAt(bt) {
  if (!world) return { rain: 0, storm: 0, gust: 0 };
  const L = wxCellLen();
  const cell = Math.floor(bt / L);
  const u = bt / L - cell;
  const env = wxEnvelope(u);
  // A wet climate phase rains oftener and harder; a drought barely rains at
  // all. climate.moist is already a slow -1..1 wander on the same clock.
  const moist = (world.climate && world.climate.moist) || 0;
  const r = wxHash(cell, 1);
  // thresholds slide with the climate: at moist=+1 a bit over half of all
  // cells carry rain, at moist=-1 about one in six does
  const dry = clamp(0.62 - moist * 0.22, 0.30, 0.86);
  const wetc = clamp(0.90 - moist * 0.06, dry + 0.05, 0.97);
  let rain = 0, storm = 0;
  if (r >= dry) {
    const k = (r - dry) / Math.max(1e-3, 1 - dry);         // 0..1 through the wet band
    rain = 0.30 + 0.70 * smooth01(k * 1.15);
    if (r >= wetc) storm = smooth01((r - wetc) / Math.max(1e-3, 1 - wetc));
  }
  // gusts: always some wind, much more under a storm, breathing on its own
  const gust = clamp(0.18 + 0.55 * rain + 0.25 * Math.sin(bt * 6.1) * Math.sin(bt * 2.7), 0, 1);
  return { rain: rain * env, storm: storm * env, gust, cell };
}

// Stepped once per tick. Everything here is either an integral (wetness) or a
// real-time event (lightning), and neither belongs in the pure function.
function wxTick(dt) {
  if (!world) return;
  const w = wxAt(world.bt || 0);
  WX.rain = w.rain; WX.storm = w.storm; WX.gust = w.gust; WX.cell = w.cell;

  // ---- wind direction: a slow turn, so a squall arrives from somewhere
  const a = (world.bt || 0) * 0.35 + wxHash(Math.floor((world.bt || 0) / (wxCellLen() * 6)), 7) * 6.283;
  WX.wind = [Math.cos(a), Math.sin(a)];

  // ---- wetness: soaks in about 20 s of hard rain, dries over three minutes.
  // Night dew puts a floor under it so dawn is damp even without weather.
  const light = world.light != null ? world.light : 1;
  const dew = 0.20 * smooth01((0.34 - light) / 0.34);
  const target = Math.max(WX.rain, dew);
  const cur = world.wet || 0;
  if (target > cur) world.wet = cur + (target - cur) * (1 - Math.exp(-dt / 6.5));
  else world.wet = target + (cur - target) * Math.exp(-dt / 95);
  world.wet = clamp(world.wet, 0, 1);

  // ---- lightning. Strikes get closer and faster as the storm deepens.
  WX.flash *= Math.exp(-dt / 0.11);
  if (WX.flash < 1e-3) WX.flash = 0;
  if (WX.storm > 0.05) {
    WX.nextBolt -= dt * (0.35 + 2.4 * WX.storm);
    if (WX.nextBolt <= 0) {
      WX.nextBolt = 2.5 + Math.random() * 11;
      WX.flash = 0.75 + 0.55 * Math.random();
      WX.boltDist = 260 + Math.random() * Math.random() * 4200 * (1.15 - WX.storm);
      // sound travels; the gap between the flash and the crack is the range
      WX.thunder.push({ t: WX.boltDist / 340, d: WX.boltDist });
      // a close strike double-flickers
      if (WX.boltDist < 900) WX.thunder.push({ t: WX.boltDist / 340 + 0.9, d: WX.boltDist * 1.4 });
    }
  } else { WX.nextBolt = 3 + Math.random() * 6; }
  for (let i = WX.thunder.length - 1; i >= 0; i--) {
    WX.thunder[i].t -= dt;
    if (WX.thunder[i].t <= 0) { const b = WX.thunder[i]; WX.thunder.splice(i, 1); try { sndThunder(b.d); } catch (e) {} }
  }
  // one line when the sky turns over, and never twice for the same cell
  if (WX.cell !== WX.said) {
    const prev = WX.said; WX.said = WX.cell;
    if (prev >= 0 && typeof toast === 'function') {
      const nx = wxAt((WX.cell + 0.5) * wxCellLen());
      if (nx.storm > 0.35) toast('The sky closes over. A storm is coming in.', 2600);
      else if (nx.rain > 0.45) toast('Rain moving in off the water.', 2200);
    }
  }
}

// ---------------------------------------------------------------- rendering
// A drop is six vertices and NO buffers: position, size and fall speed all
// come out of hashes on the instance index, and the drop is wrapped into a box
// that follows the camera in world space, so it moves past you when you run
// instead of hanging on the lens.
// The box only has to cover what you can actually resolve. Rain reads from
// the streaks NEAR the eye; spreading the same budget over a bigger volume
// buys distance nobody can see and costs the density that sells it.
const RAIN_BOX = 80;             // world units on a side
const RAIN_MAX = 6000;
let rainPipe = null, rainBuf = null, rainBind = null, rainN = 0;
const rainArr = new Float32Array(8);

const WGSL_RAIN = `
struct RU { p : vec4<f32>, q : vec4<f32> };
@group(0) @binding(1) var<uniform> r : RU;
struct VO { @builtin(position) pos : vec4<f32>, @location(0) uv : vec2<f32>,
            @location(1) wpos : vec3<f32>, @location(2) a : f32 };
fn rh(n: f32) -> f32 { return fract(sin(n * 127.1 + 311.7) * 43758.5453); }
@vertex fn vs(@builtin(vertex_index) vi : u32, @builtin(instance_index) ii : u32) -> VO {
  let id = f32(ii);
  let h1 = rh(id * 1.13); let h2 = rh(id * 2.71 + 5.3); let h3 = rh(id * 3.77 + 11.1);
  let h4 = rh(id * 7.31 + 3.9);
  let BOX = r.q.x;
  let t = g.params.x;
  let fall = r.p.w * (0.78 + 0.44 * h4);
  // world-space drift, then wrapped modulo the box around the eye: continuous
  // motion, no popping, and the drop belongs to the world and not to the camera
  let drift = vec3<f32>(r.p.y, -fall, r.p.z) * t;
  let home = vec3<f32>(h1, h2, h3) * BOX + drift;
  let rel = home - g.camPos.xyz;
  let p0 = g.camPos.xyz + (rel - BOX * round(rel / BOX));
  // the streak lies along the drop's own velocity
  let vel = normalize(vec3<f32>(r.p.y, -fall, r.p.z));
  let toEye = g.camPos.xyz - p0;
  let d = length(toEye);
  var wdir = cross(vel, toEye / max(d, 1e-4));
  let wl = length(wdir);
  wdir = select(vec3<f32>(1.0, 0.0, 0.0), wdir / max(wl, 1e-4), wl > 1e-4);
  // A drop is the same size ON THE SCREEN wherever it is. Sizing a streak in
  // world units means the nearest ones subtend an enormous angle, which is
  // exactly what turned heavy rain into a picket fence of white bars across
  // the whole view. What reads as heavy rain is the NUMBER of streaks, never
  // the size of them: angular length and width, clamped at both ends.
  let len = clamp(d * r.q.y, 0.22, 4.0) * (0.70 + 0.60 * h4);
  let wid = clamp(d * r.q.z, 0.010, 0.30) * (0.75 + 0.50 * h1);
  let corner = array<vec2<f32>, 6>(vec2<f32>(-1.0, 0.0), vec2<f32>(1.0, 0.0), vec2<f32>(1.0, 1.0),
                                   vec2<f32>(-1.0, 0.0), vec2<f32>(1.0, 1.0), vec2<f32>(-1.0, 1.0));
  let c = corner[vi];
  let w = p0 + vel * (len * c.y) + wdir * (wid * c.x);
  var o : VO;
  o.pos = g.viewProj * vec4<f32>(w, 1.0);
  o.uv = c; o.wpos = w;
  // fade the far half of the box out so the volume has no wall, and fade the
  // nearest drops right out: a drop passing a hand's width from your eye is
  // travelling too fast and is too far out of focus to be anything but a smear
  o.a = r.p.x * smoothstep(BOX * 0.52, BOX * 0.28, d) * smoothstep(1.5, 7.0, d);
  return o;
}
@fragment fn fs(i : VO) -> @location(0) vec4<f32> {
  // soft along the width, tapered at the head and tail of the streak
  let across = 1.0 - i.uv.x * i.uv.x;
  let along = sin(i.uv.y * 3.14159);
  // Rain you cannot see past is not weather, it is a wall. A single drop is
  // nearly transparent; a downpour is thousands of nearly transparent drops.
  var a = i.a * across * pow(along, 0.45) * 0.38;
  if (a < 0.004) { discard; }
  // a drop is mostly the sky it carries: bright against dark ground, dim
  // against a bright sky, which is what makes rain read as water and not chalk
  let day = g.params.z;
  let col = mix(vec3<f32>(0.42, 0.48, 0.56), vec3<f32>(0.80, 0.86, 0.92), day) * (0.55 + 0.75 * day);
  let dist = distance(i.wpos, g.camPos.xyz);
  let f = clamp(1.0 - exp(-(dist * g.params.y) * (dist * g.params.y)), 0.0, 1.0);
  return vec4<f32>(mix(col, g.fogCol.rgb, f * 0.7), a);
}`;

function rainInit() {
  if (rainPipe) return;
  const m = dev.createShaderModule({ code: WGSL_COMMON + WGSL_RAIN });
  rainPipe = dev.createRenderPipeline({
    layout: 'auto',
    vertex: { module: m, entryPoint: 'vs' },
    fragment: { module: m, entryPoint: 'fs', targets: [{ format: fmt, blend: {
      color: { srcFactor: 'src-alpha', dstFactor: 'one-minus-src-alpha' },
      alpha: { srcFactor: 'one', dstFactor: 'one-minus-src-alpha' } } }] },
    primitive: { topology: 'triangle-list', cullMode: 'none' },
    depthStencil: { format: 'depth24plus', depthWriteEnabled: false, depthCompare: 'less' },
    multisample: { count: SAMPLES },
  });
  rainBuf = dev.createBuffer({ size: 32, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });
  rainBind = dev.createBindGroup({ layout: rainPipe.getBindGroupLayout(0), entries: [
    { binding: 0, resource: { buffer: gBuf } }, { binding: 1, resource: { buffer: rainBuf } }] });
}
const RAIN_BUDGET = { low: 700, medium: 1600, high: 3000, ultra: 5000 };
function rainBuild() {
  WX.builds = (WX.builds || 0) + 1; WX.sawRain = WX.rain;
  rainN = 0;
  if (!rainPipe || WX.rain <= 0.02) return 0;
  // Under a closed canopy most of it never reaches you; it lands on the leaves
  // instead, which is what the sound does.
  let canopy = 0;
  try { canopy = clamp(forestCanopyAt(player.camX, player.camZ) || 0, 0, 1); } catch (e) { canopy = 0; }
  WX.canopy = canopy;
  const budget = RAIN_BUDGET[GFX.name] || 6000;
  rainN = Math.max(0, Math.min(RAIN_MAX, Math.round(budget * WX.rain * (1 - 0.55 * canopy)) || 0));
  const spd = 120 + 130 * WX.rain;
  rainArr[0] = clamp(WX.rain * 1.15, 0, 1);          // intensity -> alpha
  rainArr[1] = WX.wind[0] * (6 + 46 * WX.gust);      // wind drift x
  rainArr[2] = WX.wind[1] * (6 + 46 * WX.gust);      // wind drift z
  rainArr[3] = spd;                                   // fall speed
  rainArr[4] = RAIN_BOX;
  // both angular, in radians of screen: about 25-40 px long and 2 px wide at
  // 1080p, whatever distance the drop happens to be at
  rainArr[5] = 0.030 + 0.022 * WX.rain;               // streak angular length
  rainArr[6] = 0.0016 + 0.0007 * WX.rain;             // streak angular half-width
  rainArr[7] = 0;
  dev.queue.writeBuffer(rainBuf, 0, rainArr);
  return rainN;
}
function rainDraw(pass) {
  if (!rainPipe || rainN <= 0) return;
  pass.setPipeline(rainPipe); pass.setBindGroup(0, rainBind);
  pass.draw(6, rainN);
}

// ---------------------------------------------------------------- sound
// Two bands, because rain on your own head and rain on the canopy above you
// are different sounds: a broad hiss that rises with how hard it is coming
// down, and a high spattering band that only exists under leaves.
function wxSoundInit() {
  if (!SND.ctx || SND.rain) return;
  const ctx = SND.ctx;
  const s1 = ctx.createBufferSource(); s1.buffer = SND.noiseBuf; s1.loop = true;
  const f1 = ctx.createBiquadFilter(); f1.type = 'bandpass'; f1.frequency.value = 1400; f1.Q.value = 0.55;
  SND.rain = ctx.createGain(); SND.rain.gain.value = 0;
  s1.connect(f1).connect(SND.rain).connect(SND.master); s1.start();
  SND.rainF = f1;
  const s2 = ctx.createBufferSource(); s2.buffer = SND.noiseBuf; s2.loop = true; s2.playbackRate.value = 1.7;
  const f2 = ctx.createBiquadFilter(); f2.type = 'bandpass'; f2.frequency.value = 5200; f2.Q.value = 1.6;
  SND.leaf = ctx.createGain(); SND.leaf.gain.value = 0;
  s2.connect(f2).connect(SND.leaf).connect(SND.master); s2.start();
}
// A long low roll for a distant strike, a crack with a tail for a near one.
function sndThunder(dist) {
  if (!SND.ctx || !SND.on) return;
  const near = clamp(1 - dist / 3000, 0, 1);
  const vol = 0.10 + 0.55 * near * near;
  const dur = 1.6 + 3.4 * (1 - near);
  sndVoice((ctx, out, t) => {
    const s = ctx.createBufferSource(); s.buffer = SND.noiseBuf; s.loop = true;
    s.playbackRate.value = 0.25 + 0.35 * near;
    const lp = ctx.createBiquadFilter(); lp.type = 'lowpass';
    lp.frequency.setValueAtTime(90 + 900 * near, t);
    lp.frequency.exponentialRampToValueAtTime(60 + 120 * near, t + dur);
    lp.Q.value = 0.8;
    const gn = ctx.createGain();
    gn.gain.setValueAtTime(0, t);
    gn.gain.linearRampToValueAtTime(vol, t + (near > 0.6 ? 0.012 : 0.35));
    gn.gain.exponentialRampToValueAtTime(0.0005, t + dur);
    s.connect(lp).connect(gn).connect(out); s.start(t, Math.random() * 1.2); s.stop(t + dur + 0.1);
  }, (Math.random() * 1.4 - 0.7));
}
function wxSound(dt) {
  if (!SND.ctx || !SND.on) return;
  wxSoundInit();
  if (!SND.rain) return;
  const t = SND.ctx.currentTime;
  let canopy = 0;
  try { canopy = forestCanopyAt(player.camX, player.camZ); } catch (e) { canopy = 0; }
  const r = WX.rain;
  SND.rain.gain.setTargetAtTime(0.30 * r * r * (1 - 0.35 * canopy), t, 0.9);
  SND.rainF.frequency.setTargetAtTime(900 + 1500 * r + 700 * WX.gust, t, 0.9);
  SND.leaf.gain.setTargetAtTime(0.055 * r * canopy, t, 0.9);
}
