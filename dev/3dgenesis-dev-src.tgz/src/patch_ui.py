# Start screen (borderless, animated jungle, auto creature builder), an always
# visible Reset World button, the You Died screen, and drowning.
def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
p='g3.html'; s=open(p,encoding='utf-8').read()
K=lambda k: '<kbd>'+k+'</kbd>'
rows=[
 ('Move', [('W A S D','walk'),('hold Shift','sprint (uses stamina)'),('Space','jump; in the air, flap'),('G','rear up on your hind legs to reach high food'),('drag / L','look around / lock the mouse')]),
 ('Fly', [('Space','flap: costs stamina, big wings beat slower'),('look','dive to gain speed, pull up to swoop and climb'),('A D','bank into a turn'),('W','tuck to dive faster'),('S','flare to slow down and land'),('thermals','rising air over open sunlit ground and hillsides')]),
 ('Fight', [('left click / F','attack with your body'),('X','switch attack'),('Q (hold)','guard: raise it as the marker over an attacker turns yellow to parry'),('Z / tap Shift','dodge roll'),('T / middle click','lock on to a target')]),
 ('Survive', [('E','eat plants, fruit or the dead'),('M','mate: you become the offspring'),('R','roar: small animals scatter, big ones answer'),('B','creature builder, any time')]),
 ('See and hear', [('C / scroll','first or third person'),('V','detach the camera'),('N','sound on or off'),('Tab','control panel'),('[ ]','simulation speed'),('Esc','release the mouse')]),
]
moves='Your attacks come from your body: a <b>head-butt</b> by default, a <b>bite</b> with jaws, a <b>gore</b> with horns, a <b>claw</b> swipe, a <b>tail sweep</b>, a <b>spike slam</b> or a <b>punch</b> with arms. Bigger bodies and bigger parts hit harder.'
kb=''.join('<div class="grp fl"><h3>'+g+'</h3>'+''.join('<div class="kr"><span class="kk">'+' '.join(K(x) for x in k.split(' / '))+'</span><span>'+d+'</span></div>' for k,d in items)+'</div>' for g,items in rows)
html='''<div id="start"><canvas id="startbg"></canvas><div class="flow">
  <h1 class="fl">GENESIS</h1>
  <p class="fl lead">You are not watching this island. You live on it.</p>
  <p class="fl">You hatch as a newborn with a real genome and a real metabolism, among animals that evolved on their own and will hunt you. Eat to grow. Kill to take their parts into your body. Mate and your line goes on in your children. When you die, you are reborn as your nearest kin.</p>
  <p class="fl">Nothing here was designed. Every animal you meet came out of mutation and natural selection, so no two islands are the same.</p>
  <p class="fl dim">Wear headphones. Footsteps, growls and roars come from where the animal really is, even behind you.</p>
  <div class="keysg">'''+kb+'''</div>
  <p class="fl moves">'''+moves+'''</p>
  <div class="go fl">click to begin</div>
  <div class="fl dim small">you will design your creature first</div>
</div></div>

'''
i=s.index('<div id="start"><div class="box">'); j=s.index('<div id="err">')
s=s[:i]+html+s[j:]
css='''  #start{position:fixed;inset:0;display:flex;justify-content:center;align-items:flex-start;overflow-y:auto;
    background:#010303;z-index:20;cursor:pointer}
  #startbg{position:fixed;inset:0;width:100vw;height:100vh;display:block}
  #start .flow{position:relative;max-width:820px;padding:9vh 28px 12vh;text-align:center;color:#b9d3cc;
    text-shadow:0 2px 12px #000,0 0 30px #000}
  #start .fl{opacity:0;transform:translateY(-18px);animation:ssdrop 1.4s cubic-bezier(.2,.7,.2,1) forwards}
  @keyframes ssdrop{to{opacity:1;transform:none}}
  @media (prefers-reduced-motion:reduce){#start .fl{animation:none;opacity:1;transform:none}}
  #start h1{margin:0 0 18px;font-size:clamp(40px,7vw,78px);letter-spacing:.34em;color:#9fe3cf;font-weight:700;
    text-shadow:0 0 40px rgba(60,200,160,.35),0 4px 18px #000}
  #start p{margin:10px auto;font-size:15px;line-height:1.75;max-width:680px}
  #start p.lead{font-size:19px;color:#d8efe8}
  #start .dim{color:#6f9088}
  #start .small{font-size:12px;margin-top:6px}
  #start .keysg{display:grid;grid-template-columns:repeat(auto-fit,minmax(340px,1fr));gap:10px 34px;margin:30px 0 8px;text-align:left}
  #start .grp h3{margin:0 0 6px;font-size:11px;letter-spacing:.2em;text-transform:uppercase;color:#6fb8a6;font-weight:600}
  #start .kr{display:flex;gap:12px;align-items:baseline;font-size:13.5px;line-height:1.55;margin:3px 0}
  #start .kk{flex:0 0 150px;text-align:right;white-space:nowrap}
  #start kbd{font-family:inherit;font-size:12px;color:#e4f4ef;background:rgba(10,30,26,.55);border:1px solid rgba(90,160,140,.35);
    border-radius:4px;padding:1px 6px}
  #start .moves{font-size:13.5px;color:#9dbdb5}
  #start .go{margin-top:30px;font-size:20px;letter-spacing:.3em;text-transform:uppercase;color:#d4f7ec;
    animation:ssdrop 1.4s cubic-bezier(.2,.7,.2,1) forwards,sspulse 2.6s ease-in-out 2.2s infinite}
  @keyframes sspulse{50%{opacity:.45}}
  #resetbtn{position:fixed;right:14px;bottom:58px;z-index:22;font:inherit;font-size:12px;color:#ffd9d2;cursor:pointer;
    background:rgba(40,8,6,.78);border:1px solid #7a2a20;border-radius:8px;padding:6px 12px;backdrop-filter:blur(6px)}
  #resetbtn:hover{border-color:#ff6b5e}
  #resetbtn.armed{background:#8a1a10;color:#fff;border-color:#ff6b5e}
  body.editing #resetbtn{display:none}
  #deathfx{position:fixed;inset:0;z-index:19;pointer-events:none;display:flex;flex-direction:column;align-items:center;justify-content:center;
    background:radial-gradient(ellipse at center,rgba(0,0,0,.72),rgba(0,0,0,.96));opacity:0;visibility:hidden}
  #deathfx .big{font-family:Georgia,'Times New Roman',serif;font-size:clamp(54px,11vw,140px);letter-spacing:.14em;color:#b3140c;
    text-shadow:0 0 30px rgba(160,10,0,.6),0 6px 24px #000;transform:scale(1.08)}
  #deathfx .sub{margin-top:14px;color:#caa;font-size:15px;letter-spacing:.06em}
  #drownfx{position:fixed;inset:0;z-index:4;pointer-events:none;opacity:0;transition:opacity .3s;
    background:radial-gradient(ellipse at center,rgba(10,60,90,.25),rgba(0,20,40,.8))}
'''
i=s.index('  #start{position:fixed;inset:0;display:flex;align-items:center;justify-content:center;')
j=s.index('  #err{position:fixed;inset:0;')
s=s[:i]+css+s[j:]
s=sub1(s,'<canvas id="gpu"></canvas>','''<canvas id="gpu"></canvas>
<div id="drownfx"></div>
<div id="deathfx"><div class="big">YOU DIED</div><div class="sub"></div></div>
<button id="resetbtn" type="button">Reset World</button>''')
s=sub1(s,"function stepSim(dt) {\n", open('src/startscreen.js',encoding='utf-8').read()+"\nfunction stepSim(dt) {\n")
# click: straight into the builder; the game starts when you finish the design
s=sub1(s,"""    const btn = e.target && e.target.closest ? e.target.closest('[data-arch]') : null;
    if (btn) { e.stopPropagation(); becomeArchetype(btn.getAttribute('data-arch')); beginPlay(); return; }
    beginPlay();
  });""","""    const btn = e.target && e.target.closest ? e.target.closest('[data-arch]') : null;
    if (btn) { e.stopPropagation(); becomeArchetype(btn.getAttribute('data-arch')); beginPlay(); return; }
    startEl.style.display = 'none';
    openEditor('start');
  });
  const rb = $('resetbtn');
  if (rb) rb.addEventListener('click', (e) => { e.stopPropagation(); resetWorldClick(); });
  ssInit();""")
s=sub1(s,"    else { const st = $('start'); if (st && !started) st.style.display = 'flex'; }","    else if (!started) ssShow();")
s=sub1(s,"function respawn() {\n  const dead = player.c;","function respawn() {\n  const dead = player.c;\n  if (dead && dead !== player._shownDeath) { player._shownDeath = dead; showDeath(dead); }")
# keep the reset button clear of the control panel too
s=sub1(s,"  el.style.right = open ? '454px' : '14px';","  el.style.right = open ? '454px' : '14px';\n  const rb = document.getElementById('resetbtn'); if (rb) rb.style.right = el.style.right;")
# ---- drowning (core): no walking under water without fins; you drown if submerged
s=sub1(s,"""          if (terrain.isDeep(bx, by)) return !p.canSwim;
          if (terrain.isWater(bx, by)) return false;        // you swim, you do not climb""","""          if (terrain.isDeep(bx, by)) return !p.canSwim;
          if (terrain.isWater(bx, by)) {
            // a non-swimmer will not wade in over its head (but may wade back out)
            if (p.canSwim) return false;
            const dB = waterDepth(terrain, bx, by);
            return dB > headHeight(world, p) * 0.9 && dB > waterDepth(terrain, c.x, c.y);
          }""")
s=sub1(s,"""      c._inHazard = inHazard ? 1 : 0;   // fed back into next step's senses""","""      c._inHazard = inHazard ? 1 : 0;   // fed back into next step's senses
      // drowning: a body without fins whose head is under water loses energy
      // fast (a full reserve lasts about eight seconds)
      if (!p.canSwim && !p.canFly && terrain.isWater(c.x, c.y) && waterDepth(terrain, c.x, c.y) > headHeight(world, p) - (c.jumpLv || 0) * 8) {
        c.energy -= p.storage * 0.12 * dt; c._drown = true;
      } else c._drown = false;""")
s=sub1(s,"""        c.deathCause = c.age >= c.maxAge ? 'oldage' : (inHazard ? 'toxin' : 'starvation');""","""        c.deathCause = c.age >= c.maxAge ? 'oldage' : c._drown ? 'drowned' : (inHazard ? 'toxin' : 'starvation');""")
s=sub1(s,"  function recordDeath(world, c) {\n","""  // metres of water over the ground here (world units), 0 on land
  function waterDepth(terrain, x, y) {
    const d = (terrain.LV.water - terrain.height(x, y)) * (terrain.heightScale || 420);
    return d > 0 ? d : 0;
  }
  // how high this body carries its head (world units); the game sets bodyScale
  function headHeight(world, p) {
    const bs = world.params.bodyScale || 0.55;
    return ((p.standH || p.radius) + (p.neck || 0) * p.radius * 1.05 + Math.max(1.5, p.radius * 0.45)) * bs;
  }
  function recordDeath(world, c) {
""")
# game side: feed bodyScale in, show drowning
s=sub1(s,"  world.hitFilter = fightHitFilter;","  world.hitFilter = fightHitFilter;\n  world.params.bodyScale = BODY_SCALE;\n  drownFx(dt);")
s=sub1(s,"function stepSim(dt) {\n","""let drownMsgT = 0;
function drownFx(dt) {
  const c = player.c, el = document.getElementById('drownfx');
  const wl = terrain && terrain.LV ? terrain.LV.water * HEIGHT_SCALE : -1e9;
  const under = player.camY < wl - 0.5;
  const drown = !!(c && c.alive && c._drown && !player.spectator);
  if (el) el.style.opacity = (under ? 0.85 : drown ? 0.5 : 0).toFixed(2);
  if (drown) {
    FIGHT.hurtFx = Math.min(1, FIGHT.hurtFx + dt * 1.6);
    drownMsgT -= dt;
    if (drownMsgT <= 0) {
      drownMsgT = 2.2; toast('Drowning! You have no fins. Get your head above water.', 2000);
      if (SND.ctx && SND.on) for (let k = 0; k < 4; k++) setTimeout(() => sndNoiseBurst(320 + Math.random() * 300, 6, 0.12, 0.12, 0, 0.6), k * 110);
    }
  } else drownMsgT = 0;
}
function stepSim(dt) {
""",1)
s=sub1(s,"  get REMAINS() { return REMAINS; },","  begin: () => { started = true; const st = document.getElementById('start'); if (st) st.style.display = 'none'; }, showDeath: (c) => showDeath(c),\n  get REMAINS() { return REMAINS; },")
open(p,'w',encoding='utf-8').write(s)
print('ui ok')
