# RIVERS: routing, carving and the running surface. See src/rivers.js.
# The carve has to happen between world generation and the terrain render mesh,
# which is the same seam the cage pads use.
def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
p='g3.html'; s=open(p,encoding='utf-8').read()

# ---- the channel cutter, beside carveFlat in the core
s=sub1(s,"""      // Level a disc of ground to one height, blending out over an apron so it""",
"""      // Cut a river channel: a flat bed of half-width halfW, then banks that
      // rise STEEPLY over bankW to bankH above the water. Steep is the point:
      // the terrain shader draws anything past about 22 degrees as layered
      // rock, so a bank cut like this is a rock cliff with no extra geometry
      // and no extra draw call. Ground already lower than the bed is left
      // alone, so a channel never builds a dam across a valley.
      carveChannel(x, y, halfW, bankW, bedE, bankH, waterE) {
        const R = Math.max(2, halfW), A = Math.max(2, bankW);
        const ci = Math.round(x / CELL), cj = Math.round(y / CELL);
        const span = Math.ceil((R + A) / CELL) + 1;
        for (let j = -span; j <= span; j++) for (let i = -span; i <= span; i++) {
          const gi = ci + i, gj = cj + j;
          if (gi < 0 || gj < 0 || gi > HX - 1 || gj > HY - 1) continue;
          const d = Math.hypot(i * CELL, j * CELL);
          if (d > R + A) continue;
          const o = gj * HX + gi;
          const cur = hg[o];
          if (d <= R) {
            // the bed itself, but never raised: a river does not dam a valley
            if (cur > bedE) hg[o] = bedE;
            continue;
          }
          // the bank. k runs 0 at the water's edge to 1 at the top.
          const k = (d - R) / A;
          // pow < 1 puts most of the rise in the first stretch, which is what
          // makes it read as a wall rather than a ramp
          const rise = Math.pow(k, 0.42);
          const want = bedE + (waterE + bankH - bedE) * rise;
          // only ever cut down to the bank profile, never build ground up
          if (cur > want) hg[o] = Math.max(want, Math.min(cur, want + (cur - want) * 0.15));
        }
      },
      // Level a disc of ground to one height, blending out over an apron so it""")
open(p,'w',encoding='utf-8').write(s)
print('carveChannel ok')
s=open(p,encoding='utf-8').read()

# ---- the module
s=sub1(s,"function brRenderHud() {", open('src/rivers.js',encoding='utf-8').read()+"\nfunction brRenderHud() {")
# routed and carved while the heightmap is still soft, before the render mesh
s=sub1(s,"""  BR.bays = BR.arming ? brCarveBays(BR.players.length) : [];
  buildCanopyMap(); FOL.key = '';""","""  BR.bays = BR.arming ? brCarveBays(BR.players.length) : [];
  try { rivBuild(seed); } catch (e) { console.warn('rivers', e); }
  buildCanopyMap(); FOL.key = '';""")
# the same at first boot
s=sub1(s,"""  terrain = world.terrain;

  buildPipelines();""","""  terrain = world.terrain;
  try { rivBuild(seed); } catch (e) { console.warn('rivers', e); }

  buildPipelines();""")
# the surface mesh, once the GPU is up and the heightmap is final
s=sub1(s,"  buildTerrain(); buildWater(); waterHeightUpload(); buildMinimap();",
         "  buildTerrain(); buildWater(); waterHeightUpload(); buildMinimap();\n  try { rivInit(); rivBuildMesh(); } catch (e) { console.warn('river mesh', e); }")
s=sub1(s,"  const info = buildTerrain();\n  buildWater();\n  waterHeightUpload();",
         "  const info = buildTerrain();\n  buildWater();\n  waterHeightUpload();\n  try { rivInit(); rivBuildMesh(); } catch (e) { console.warn('river mesh', e); }")
# drawn with the water, before the cloud wall
s=sub1(s,"""  try { cloudDraw(pass); } catch (e) { console.warn('cloud draw', e); }""",
"""  try { rivDraw(pass); } catch (e) { console.warn('river draw', e); }
  try { cloudDraw(pass); } catch (e) { console.warn('cloud draw', e); }""")
open(p,'w',encoding='utf-8').write(s)
print('rivers wired ok')
s=open(p,encoding='utf-8').read()
s=sub1(s,"  rebuild: () => rebuildWorld(),","""  rebuild: () => rebuildWorld(),
  get rivers() { return { n: RIV.paths.length, tris: RIV.count / 3,
    lens: RIV.paths.map(p => Math.round(p.pts.length * 46)),
    drops: RIV.paths.map(p => Math.round((p.pts[0].wy - p.pts[p.pts.length - 1].wy) * (terrain.heightScale || 420))) }; },
  riverAt: (x, z) => riverSurfaceAt(x, z),\n  riverPts: (i) => (RIV.paths[i] ? RIV.paths[i].pts : []),\n  groundY: (x, z) => groundAt(x, z),""")
open(p,'w',encoding='utf-8').write(s)
print('river api ok')
