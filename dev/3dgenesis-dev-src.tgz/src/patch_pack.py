# =====================================================================
# YOUR PACK IS NOT A TARGET.
#
# The rule already existed -- brHitAllowed has refused a packmate strike since
# packs were built -- but nothing in front of the player said so. You were
# shown an attack prompt, a red marker and a red dot, you swung, and nothing
# happened. A rule the interface contradicts is a rule the player does not
# believe in.
#
# One predicate, packFriend(), answers "is this one of mine", and the attack
# affordance itself is gated on the SAME filter the damage goes through, so the
# button and the hit can never disagree.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, (a[:100], n); return s.replace(a, b)
p = 'g3.html'; s = open(p, encoding='utf-8').read()

# ---------------------------------------------------------------- the predicates
s = sub1(s, """function brSay(msg, ms) { BR.msg = msg; BR.msgT = performance.now() + (ms || 3000); }""",
"""function brSay(msg, ms) { BR.msg = msg; BR.msgT = performance.now() + (ms || 3000); }

// Is this creature one of yours? Only a match has sides: in free roam nothing
// is a packmate, and the island's own wildlife never is.
function packFriend(tgt) {
  if (!BR.on || !tgt) return false;
  const vs = brSlotOf(tgt);
  if (vs == null || vs === BR.slot) return false;
  const me = BR.players[BR.slot], vp = BR.players[vs];
  if (!me || !vp) return false;
  if (vp.pack !== BR_PACK_NONE && vp.pack === me.pack) return true;   // same leader
  if (vp.pack === BR.slot) return true;                               // yours
  if (me.pack !== BR_PACK_NONE && me.pack === vs) return true;        // your leader
  return false;
}
// May you attack this at all, right now? Answered by the same filter the
// damage itself goes through, so what the interface offers and what the swing
// can do are one decision, not two that can drift apart.
function canAttackTarget(tgt) {
  const me = player.c;
  if (!me || !me.alive || !tgt || !tgt.alive || tgt === me) return false;
  if (!BR.on) return true;
  return brHitAllowed(tgt, me);
}
// Why not, in a few words, for the prompt.
function noAttackReason(tgt) {
  if (!BR.on) return '';
  if (packFriend(tgt)) return 'your pack';
  if (BR.phase === 'cage' && brSlotOf(tgt) != null) return 'caged';
  return 'protected';
}""")
open(p, 'w', encoding='utf-8').write(s)
print('pack predicates ok')

# ---------------------------------------------------------------- the prompt
# No attack key, no switch key, and no "hits to kill" on something you are not
# allowed to hit. The line says whose they are instead.
s = open(p, encoding='utf-8').read()
s = sub1(s, """      const hits = Math.ceil(Math.max(0, tgt.energy) / Math.max(0.01, dmg));
      act.innerHTML = '<b>' + diet + '</b> mass ' + d.mass.toFixed(1) +
        ' &middot; def ' + d.defense.toFixed(0) + ' &middot; ~' + hits + ' hits to kill' +
        '<div class="keys"><span class="hit">F</span> ' + MOVE_DEF[playerMove(mp)].label + ' <span>X</span> switch ' +
        '<span>Q</span> guard <span>Z</span> dodge <span>T</span> ' + (FIGHT.lock === tgt ? 'unlock ' : 'lock ') +
        (why ? '<span style="opacity:.55">M mate: ' + why + '</span>'
             : '<span class="ok">M</span> ' + (mateDistance(me, tgt) > 9 ? 'mate (hybrid)' : 'mate')) +
        ' <span>E</span> eat</div>';""",
"""      const hits = Math.ceil(Math.max(0, tgt.energy) / Math.max(0.01, dmg));
      const mayHit = canAttackTarget(tgt);
      const friend = packFriend(tgt);
      const rest = '<span>Q</span> guard <span>Z</span> dodge <span>T</span> ' + (FIGHT.lock === tgt ? 'unlock ' : 'lock ') +
        (why ? '<span style="opacity:.55">M mate: ' + why + '</span>'
             : '<span class="ok">M</span> ' + (mateDistance(me, tgt) > 9 ? 'mate (hybrid)' : 'mate')) +
        ' <span>E</span> eat</div>';
      act.innerHTML = mayHit
        ? '<b>' + diet + '</b> mass ' + d.mass.toFixed(1) +
          ' &middot; def ' + d.defense.toFixed(0) + ' &middot; ~' + hits + ' hits to kill' +
          '<div class="keys"><span class="hit">F</span> ' + MOVE_DEF[playerMove(mp)].label + ' <span>X</span> switch ' + rest
        // no attack key at all on one of your own: the prompt is the rule
        : '<b class="' + (friend ? 'pk' : '') + '">' + (friend ? 'YOUR PACK' : noAttackReason(tgt).toUpperCase()) + '</b>' +
          (friend && brNameOf(tgt) ? ' <span class="pkn">' + brNameOf(tgt) + '</span>' : '') +
          ' &middot; ' + diet + ' &middot; mass ' + d.mass.toFixed(1) +
          '<div class="keys"><span class="pkno">' + (friend ? 'you cannot hurt your own' : 'you cannot hurt this yet') + '</span> ' + rest;""")
# the name of a player creature, for that line
s = sub1(s, "function packFriend(tgt) {",
"""function brNameOf(c) {
  const sl = brSlotOf(c);
  return sl != null && BR.players[sl] ? BR.players[sl].name : '';
}
function packFriend(tgt) {""")
s = sub1(s, "  #act .keys .hit{color:#ff7a6b;border-color:#7a2c26}",
"""  #act .keys .hit{color:#ff7a6b;border-color:#7a2c26}
  #act b.pk{color:#6fe0ae;letter-spacing:.08em}
  #act .pkn{color:#bdf0d9}
  #act .keys .pkno{color:#6fe0ae;border-color:#2a6a52;background:rgba(20,70,54,.35)}""")
open(p, 'w', encoding='utf-8').write(s)
print('pack prompt ok')

# ---------------------------------------------------------------- the marker and the reticle
s = open(p, encoding='utf-8').read()
s = sub1(s, "  const col = canMate(c, tgt) ? [0.20, 0.88, 0.82] : [0.95, 0.26, 0.18];",
"""  // green over one of your own, cyan over something you could breed with, red
  // only over what you are actually allowed to attack
  const col = packFriend(tgt) ? [0.28, 0.90, 0.62]
            : canMate(c, tgt) ? [0.20, 0.88, 0.82]
            : canAttackTarget(tgt) ? [0.95, 0.26, 0.18] : [0.55, 0.78, 0.70];""")
s = sub1(s, """      pushC(x, gy + 7, z, -Math.cos(a), -0.4, -Math.sin(a), 1.6, 6, [0.95, 0.28, 0.2]);""",
"""      pushC(x, gy + 7, z, -Math.cos(a), -0.4, -Math.sin(a), 1.6, 6, lockCol);""")
s = sub1(s, """    const R = (lk.ph.radius || 4) * BODY_SCALE * 1.7 + 8;
    const gy = groundAt(lk.x, lk.y);""",
"""    const R = (lk.ph.radius || 4) * BODY_SCALE * 1.7 + 8;
    const lockCol = packFriend(lk) ? [0.28, 0.90, 0.62] : [0.95, 0.28, 0.2];
    const gy = groundAt(lk.x, lk.y);""")
open(p, 'w', encoding='utf-8').write(s)
print('pack markers ok')

# ---------------------------------------------------------------- the swing
s = open(p, encoding='utf-8').read()
s = sub1(s, """function fightStartSwing() {
  const c = player.c;
  if (!c || !c.alive || (player.atkCD || 0) > 0 || FIGHT.stagger > 0 || FIGHT.dodgeT > 0) return;""",
"""function fightStartSwing() {
  const c = player.c;
  if (!c || !c.alive || (player.atkCD || 0) > 0 || FIGHT.stagger > 0 || FIGHT.dodgeT > 0) return;
  // Pointed at one of your own: there is no attack here to make. The strike
  // could never have landed -- the filter would have eaten it -- so refusing
  // the swing outright is the honest version of that, and it costs no stamina.
  const aim = player.target;
  if (aim && aim.alive && !canAttackTarget(aim)) {
    if (packFriend(aim)) edFlashMsg('Your pack. You cannot hurt your own.');
    else if (BR.on && BR.phase === 'cage') edFlashMsg('Still caged. Nobody can touch anybody yet.');
    return;
  }""")
# a small flash that does not need the editor to be open
s = sub1(s, "function fightStartSwing() {",
"""// A one-line message on the action prompt itself, so a refusal reads where
// the player was already looking.
function edFlashMsg(msg) {
  if (typeof toast === 'function') toast(msg, 1200);
}
function fightStartSwing() {""")
open(p, 'w', encoding='utf-8').write(s)
print('pack swing ok')

# ---------------------------------------------------------------- the minimap
s = open(p, encoding='utf-8').read()
s = sub1(s, """  miniCtx.fillStyle = 'rgba(255,64,48,0.92)';
  for (const c of world.creatures) {
    if (!c.alive || c === me) continue;
    miniCtx.fillRect(c.x * sx - dotR, c.y * sz - dotR, dotR * 2.2, dotR * 2.2);
  }""",
"""  miniCtx.fillStyle = 'rgba(255,64,48,0.92)';
  for (const c of world.creatures) {
    if (!c.alive || c === me) continue;
    if (BR.on && packFriend(c)) continue;          // yours are drawn blue, below
    miniCtx.fillRect(c.x * sx - dotR, c.y * sz - dotR, dotR * 2.2, dotR * 2.2);
  }
  // Your pack, in blue and a size larger, over the top of everything else. A
  // red dot means something you can kill; yours are never that.
  if (BR.on) {
    miniCtx.fillStyle = 'rgba(96,176,255,0.96)';
    for (const q of BR.players) {
      if (!q.alive || !q.c || !q.c.alive || q.c === me) continue;
      if (!packFriend(q.c)) continue;
      miniCtx.fillRect(q.c.x * sx - dotR * 1.35, q.c.y * sz - dotR * 1.35, dotR * 2.9, dotR * 2.9);
    }
  }""")
open(p, 'w', encoding='utf-8').write(s)
print('pack minimap ok')

# ---------------------------------------------------------------- test surface
s = open(p, encoding='utf-8').read()
s = sub1(s, "    resetFall: () => fallResetGround(),",
"""    resetFall: () => fallResetGround(),
    friend: (slot) => { const q = BR.players[slot | 0]; return !!(q && q.c && packFriend(q.c)); },
    mayHit: (slot) => { const q = BR.players[slot | 0]; return !!(q && q.c && canAttackTarget(q.c)); },
    setPack: (slot, leader) => { const q = BR.players[slot | 0]; if (q) q.pack = leader; },
    aimAt: (slot) => { const q = BR.players[slot | 0]; player.target = q ? q.c : null; return !!(q && q.c); },
    actHtml: () => { updateHUD(); const el = document.getElementById('act'); return el ? el.innerHTML : ''; },
    swing: () => { const cd = player.atkCD; player.atkCD = 0; fightStartSwing(); const fired = player.atkCD > 0; player.atkCD = fired ? player.atkCD : cd; return fired; },""")
open(p, 'w', encoding='utf-8').write(s)
print('pack test surface ok')
