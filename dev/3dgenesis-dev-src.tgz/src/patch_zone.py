# =====================================================================
# THE ZONE IS NOT A CIRCLE, AND IT DOES NOT END IN THE MIDDLE.
#
# It was a perfect circle centred on the exact middle of the map, closing on
# itself, which meant every match ended in the same place and the wall was a
# geometry lesson rather than weather. Three changes:
#
#   1. A seeded wobble runs around the edge, so the wall bulges on one bearing
#      and lags on another, and it breathes as the match runs. The edge is now
#      a function of BEARING as well as time, and everything that asks where
#      the edge is -- the damage, the cloud wall, the minimap -- asks the same
#      function, so they cannot disagree.
#   2. The final ring lands somewhere else every match: a seeded point on dry
#      land, and the centre DRIFTS from where it started to where it will
#      finish as the wall closes, so the safe ground slides across the island
#      and standing still is never the answer.
#   3. The start is off-centre too, by a seeded amount, still wide enough to
#      contain every bay.
#
# BR.zone.r stays the MEAN radius, so everything that reasons about how far the
# wall has come still works on one number.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, (a[:100], n); return s.replace(a, b)
p = 'g3.html'; s = open(p, encoding='utf-8').read()

# ---------------------------------------------------------------- the edge
s = sub1(s, """// How deep into the fog a point is, 0 at the edge and 1 well inside it.
function brFogAt(x, z) {
  if (!BR.on) return 0;
  const d = Math.hypot(x - BR.zone.cx, z - BR.zone.cz);
  return clamp((d - BR.zone.r) / BR_ZONE_EDGE, 0, 1);
}""",
"""// Where the edge is on a given bearing. Three lobes of different periods,
// seeded per match, summed and normalised, so the boundary is a soft irregular
// blob rather than a circle, and each lobe turns at its own slow rate so the
// shape lives. The wobble is a fraction of the radius, so the absolute
// wander shrinks with the ring and the last arena is still a fair arena.
const BR_ZONE_WOBBLE = 0.13;
function brZoneLobes(seed) {
  let h = (seed | 0) >>> 0;
  const rnd = () => { h = Math.imul(h ^ (h >>> 15), 2246822519) >>> 0; h = Math.imul(h ^ (h >>> 13), 3266489917) >>> 0; return ((h ^ (h >>> 16)) >>> 0) / 4294967296; };
  const ks = [2, 3, 5];
  const out = [];
  let tot = 0;
  for (const k of ks) { const a = 0.45 + rnd() * 0.55; tot += a; out.push({ k, a, ph: rnd() * 6.2832, sp: (rnd() - 0.5) * 0.045 }); }
  for (const L of out) L.a /= tot;            // normalised: the sum is never past 1
  return out;
}
// The radius of the edge on bearing `ang`, in world units.
function brZoneEdge(ang, t) {
  const z = BR.zone;
  if (!z || !z.lobes) return z ? z.r : 0;
  const tt = t == null ? BR.t : t;
  let w = 0;
  for (const L of z.lobes) w += L.a * Math.sin(L.k * ang + L.ph + tt * L.sp);
  return Math.max(40, z.r * (1 + BR_ZONE_WOBBLE * w));
}
// How deep into the fog a point is, 0 at the edge and 1 well inside it.
function brFogAt(x, z) {
  if (!BR.on) return 0;
  const dx = x - BR.zone.cx, dz = z - BR.zone.cz;
  const d = Math.hypot(dx, dz);
  const edge = brZoneEdge(Math.atan2(dz, dx));
  return clamp((d - edge) / BR_ZONE_EDGE, 0, 1);
}
// How far this point is from safety, along its own bearing. The HUD reads it,
// and it is the honest number now that the edge is not one radius.
function brEdgeGap(x, z) {
  if (!BR.on) return 0;
  const dx = x - BR.zone.cx, dz = z - BR.zone.cz;
  return brZoneEdge(Math.atan2(dz, dx)) - Math.hypot(dx, dz);
}""")

# ---------------------------------------------------------------- the drift
s = sub1(s, """function brZoneSpeed() {""",
"""// Where the centre is right now: it slides from where the wall started to
// where it will finish, in step with how far it has closed, so the safe ground
// travels across the island instead of shrinking onto one fixed point.
function brZoneCentreAt(t) {
  const z = BR.zone;
  if (!z || z.fx == null) return { cx: z ? z.cx : 0, cz: z ? z.cz : 0 };
  const span = Math.max(1, z.r0 - z.r1);
  const k = clamp((z.r0 - brZoneRadiusAt(t)) / span, 0, 1);
  const e = k * k * (3 - 2 * k);                 // ease, so it does not lurch off the mark
  return { cx: z.cx0 + (z.fx - z.cx0) * e, cz: z.cz0 + (z.fz - z.cz0) * e };
}
function brZoneSpeed() {""")

# ---------------------------------------------------------------- setting it up
s = sub1(s, """  const cx0 = WORLD_W / 2, cz0 = WORLD_H / 2;
  let far = 0;
  for (const b of BR.bays) far = Math.max(far, Math.hypot(b.x - cx0, b.z - cz0));
  const r0 = Math.max(1200, far + 900);
  BR.zone = { cx: cx0, cz: cz0, r0, r1: Math.min(BR_ZONE_FINAL, r0 * 0.25), r: r0 };""",
"""  // Where the wall starts, where it finishes, and the shape of its edge are
  // all rolled from the match seed, so every player in the match gets the same
  // island AND the same weather, and no two matches close on the same ground.
  let zh = (BR.seed ^ 0x9E3779B9) >>> 0;
  const zr = () => { zh = Math.imul(zh ^ (zh >>> 15), 2246822519) >>> 0; zh = Math.imul(zh ^ (zh >>> 13), 3266489917) >>> 0; return ((zh ^ (zh >>> 16)) >>> 0) / 4294967296; };
  // start off-centre, by up to a tenth of the map on each axis
  const cx0 = WORLD_W / 2 + (zr() - 0.5) * WORLD_W * 0.20;
  const cz0 = WORLD_H / 2 + (zr() - 0.5) * WORLD_H * 0.20;
  let far = 0;
  for (const b of BR.bays) far = Math.max(far, Math.hypot(b.x - cx0, b.z - cz0));
  // The start has to clear the bays even where the wobble pulls the edge
  // inward, so the bay distance is divided out by the deepest the wobble can
  // bite, plus a margin.
  const r0 = Math.max(1200, far / (1 - BR_ZONE_WOBBLE) + 500);
  const r1 = Math.min(BR_ZONE_FINAL, r0 * 0.25);
  // The final ring: dry land, somewhere inside the opening circle but well
  // away from its middle, and not so far out that the last arena is sea.
  let fx = cx0, fz = cz0, bestScore = -1;
  for (let i = 0; i < 90; i++) {
    const a = zr() * 6.2832, rr = (0.20 + zr() * 0.55) * r0;
    const px = clamp(cx0 + Math.cos(a) * rr, r1 * 1.6, WORLD_W - r1 * 1.6);
    const pz = clamp(cz0 + Math.sin(a) * rr, r1 * 1.6, WORLD_H - r1 * 1.6);
    // count how much of the last arena would be dry
    let land = 0;
    for (let s2 = 0; s2 < 9; s2++) {
      const sa = s2 * 0.698, sr = (s2 % 3) / 3 * r1;
      if (!terrain.isWater(clamp(px + Math.cos(sa) * sr, 1, WORLD_W - 1), clamp(pz + Math.sin(sa) * sr, 1, WORLD_H - 1))) land++;
    }
    const score = land + zr() * 0.5;
    if (score > bestScore) { bestScore = score; fx = px; fz = pz; }
    if (land === 9) break;
  }
  BR.zone = { cx: cx0, cz: cz0, cx0, cz0, fx, fz, r0, r1, r: r0, lobes: brZoneLobes(BR.seed) };""")

# ---------------------------------------------------------------- tick: move the centre with it
s = sub1(s, """  // the fog
  BR.zone.r = brZoneRadiusAt(BR.t);""",
"""  // the fog: the mean radius, and the centre sliding toward where it will end
  BR.zone.r = brZoneRadiusAt(BR.t);
  { const c0 = brZoneCentreAt(BR.t); BR.zone.cx = c0.cx; BR.zone.cz = c0.cz; }""")

# ---------------------------------------------------------------- the HUD reads the bearing
s = sub1(s, """  const d = player.c ? Math.hypot(player.c.x - BR.zone.cx, player.c.y - BR.zone.cz) : 0;
  const out = Math.max(0, d - BR.zone.r);""",
"""  const gap = player.c ? brEdgeGap(player.c.x, player.c.y) : 0;
  const out = Math.max(0, -gap);""")
s = sub1(s, "' to the edge') + '</div>' +", "' to the edge') + '</div>' +")
s = sub1(s, "Math.round(BR.zone.r - d) + ' to the edge'", "Math.round(gap) + ' to the edge'")
open(p, 'w', encoding='utf-8').write(s)
print('zone shape ok')

# ---------------------------------------------------------------- the cloud wall follows the same edge
s = open(p, encoding='utf-8').read()
s = sub1(s, """      const rr = R + CLOUD_ROWS[ri];""",
            """      const rr = (typeof brZoneEdge === 'function' ? brZoneEdge(a) : R) + CLOUD_ROWS[ri];""")
# the arc bound has to allow for the wobble, or the far side of a bulge is culled
s = sub1(s, """    const cosNeed = (dCentre * dCentre + R * R - SEE * SEE) / (2 * dCentre * R);""",
            """    const Rw = R * (1 + BR_ZONE_WOBBLE);
    const cosNeed = (dCentre * dCentre + Rw * Rw - SEE * SEE) / (2 * dCentre * Rw);""")
open(p, 'w', encoding='utf-8').write(s)
print('cloud follows edge ok')

# ---------------------------------------------------------------- the minimap draws the real shape
s = open(p, encoding='utf-8').read()
s = sub1(s, """    const zx = BR.zone.cx * sx, zy = BR.zone.cz * sz, zr = BR.zone.r * sx;
    miniCtx.save();
    // everything outside the ring is under cloud
    miniCtx.beginPath();
    miniCtx.rect(0, 0, MW, MH);
    miniCtx.arc(zx, zy, Math.max(1, zr), 0, Math.PI * 2, true);
    miniCtx.fillStyle = 'rgba(150,158,150,0.50)';
    miniCtx.fill('evenodd');
    // the band that kills, and the edge itself
    miniCtx.beginPath(); miniCtx.arc(zx, zy, Math.max(1, zr), 0, Math.PI * 2);
    miniCtx.strokeStyle = 'rgba(226,232,224,0.95)'; miniCtx.lineWidth = 2 * k; miniCtx.stroke();
    // where it is heading, so the shrink is legible
    const rNext = brZoneRadiusAt(BR.t + 45) * sx;
    if (rNext < zr - 1) {
      miniCtx.beginPath(); miniCtx.arc(zx, zy, Math.max(1, rNext), 0, Math.PI * 2);
      miniCtx.strokeStyle = 'rgba(255,150,120,0.7)'; miniCtx.lineWidth = 1.2 * k;
      miniCtx.setLineDash([4 * k, 4 * k]); miniCtx.stroke(); miniCtx.setLineDash([]);
    }
    miniCtx.restore();""",
"""    // The edge is not a circle any more, so the map draws the shape itself:
    // 96 points around the real boundary, the same function the damage uses.
    const SEG = 96;
    const ringPath = (radAt, ox, oz) => {
      miniCtx.beginPath();
      for (let i = 0; i <= SEG; i++) {
        const a = (i / SEG) * Math.PI * 2;
        const rr = radAt(a);
        const px = (ox + Math.cos(a) * rr) * sx, py = (oz + Math.sin(a) * rr) * sz;
        if (i === 0) miniCtx.moveTo(px, py); else miniCtx.lineTo(px, py);
      }
      miniCtx.closePath();
    };
    const Z = BR.zone;
    miniCtx.save();
    // everything outside the edge is under cloud
    miniCtx.beginPath();
    miniCtx.rect(0, 0, MW, MH);
    for (let i = SEG; i >= 0; i--) {            // wound the other way, so evenodd cuts the hole
      const a = (i / SEG) * Math.PI * 2, rr = brZoneEdge(a);
      const px = (Z.cx + Math.cos(a) * rr) * sx, py = (Z.cz + Math.sin(a) * rr) * sz;
      if (i === SEG) miniCtx.moveTo(px, py); else miniCtx.lineTo(px, py);
    }
    miniCtx.closePath();
    miniCtx.fillStyle = 'rgba(150,158,150,0.50)';
    miniCtx.fill('evenodd');
    // the edge itself
    ringPath((a) => brZoneEdge(a), Z.cx, Z.cz);
    miniCtx.strokeStyle = 'rgba(226,232,224,0.95)'; miniCtx.lineWidth = 2 * k; miniCtx.stroke();
    // where it is heading, centre drift and all, so you can see which way the
    // safe ground is sliding as well as how fast it is shrinking
    const tNext = BR.t + 45;
    const rNext = brZoneRadiusAt(tNext), cNext = brZoneCentreAt(tNext);
    if (rNext < Z.r - 1) {
      const scale = rNext / Math.max(1, Z.r);
      ringPath((a) => brZoneEdge(a, tNext) * scale, cNext.cx, cNext.cz);
      miniCtx.strokeStyle = 'rgba(255,150,120,0.7)'; miniCtx.lineWidth = 1.2 * k;
      miniCtx.setLineDash([4 * k, 4 * k]); miniCtx.stroke(); miniCtx.setLineDash([]);
    }
    miniCtx.restore();""")
open(p, 'w', encoding='utf-8').write(s)
print('minimap shape ok')

# ---------------------------------------------------------------- test surface
s = open(p, encoding='utf-8').read()
s = sub1(s, "    fogAt: (x, z) => brFogAt(x, z),",
"""    fogAt: (x, z) => brFogAt(x, z),
    edgeAt: (a, t) => brZoneEdge(a, t),
    edgeGap: (x, z) => brEdgeGap(x, z),
    centreAt: (t) => brZoneCentreAt(t),
    get finalCentre() { return { x: BR.zone.fx, z: BR.zone.fz }; },
    get startCentre() { return { x: BR.zone.cx0, z: BR.zone.cz0 }; },
    // the edge sampled all the way round, for shape checks
    edgeRing: (n, t) => { const out = []; const N = n || 64; for (let i = 0; i < N; i++) out.push(brZoneEdge((i / N) * Math.PI * 2, t)); return out; },""")
open(p, 'w', encoding='utf-8').write(s)
print('zone test surface ok')

# ---------------------------------------------------------------- the wall has to arrive
# Moving the ring off-centre pushed the furthest bay further out, and the close
# rate was a fixed 11 units a second chosen against the old, tighter start. The
# wall therefore spent the whole match travelling and never got small enough to
# squeeze anybody: measured, it ended a fifteen-minute match at radius 10852
# with not one player ever outside it. The fog stopped killing people.
#
# The hold at the start is cut (the cages only last thirty seconds; holding for
# a hundred and fifty left the first sixth of the match static), and the speed
# limit is raised to a rate that still cannot outrun a walk but does finish the
# job: about 22 units a second against a walking speed near 40.
s = open(p, encoding='utf-8').read()
s = sub1(s, "const BR_ZONE_GRACE = 150;           // the wall holds this long before it moves at all",
            "const BR_ZONE_GRACE = 75;            // the wall holds this long before it moves at all")
s = sub1(s, "const BR_ZONE_MAX_CLOSE = 11;        // units a second, absolute cap. A walk is about 40.",
            "const BR_ZONE_MAX_CLOSE = 22;        // units a second, absolute cap. A walk is about 40.")
open(p, 'w', encoding='utf-8').write(s)
print('zone rate ok')
