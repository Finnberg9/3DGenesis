# =====================================================================
# TOO MANY SPIDERS
#
# Six of the ten land shapes were standing on thin splayed legs -- maw,
# centipede, scorpion, crab, mantis, stilt-walker -- so the set read as a
# bag of insects with a couple of blobs in it. Thin legs are a choice that
# only means something if most things do not have them.
#
# Three keep them, because they ARE arthropods and that is their whole
# silhouette: SCORPION, CENTIPEDE, STILT-WALKER. One stays gaunt because
# gaunt is the point: HOLLOW.
#
# The rest get heavy: thick limbs, fewer of them, planted under the body
# rather than splayed out beside it. A crab is an armoured tank on stumps,
# not a daddy-long-legs. A mantis stands on two heavy hind legs with its
# blades up, not on six wires. The thing carrying a head twice its size has
# to have legs that could carry it.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, ('ANCHOR %d/%d' % (n, cnt), a[:110]); return s.replace(a, b)

p = 'g3.html'; s = open(p, encoding='utf-8').read()

# ---- maw: a head that size needs legs that could carry it -------------------
s = sub1(s, """        put('s_plate', -a * 0.30, b * 0.95, b * 0.35, -0.2, 1, 0.4, 0.95, true);
        legRow('l_thin', [0.10, -0.38], { out: 0.80, rake: 1.0, reach: 1.5, knee: 0.7, th: 0.95, tip: 't_talon' });
        tailPut('s_knob', 0.9);""",
"""        put('s_plate', -a * 0.30, b * 0.95, b * 0.35, -0.2, 1, 0.4, 0.95, true);
        // short, heavy and planted under the body, not splayed beside it
        limb('l_thick',  a * 0.22, -b * 0.34, b * 0.66,  a * 0.30, -st, b * 0.78, 0.16, 0.04, 0.02, 't_pad', 1.55);
        limb('l_thick', -a * 0.40, -b * 0.34, b * 0.66, -a * 0.46, -st, b * 0.78, -0.16, 0.04, 0.02, 't_pad', 1.45);
        tailPut('s_knob', 0.9);""")

# ---- crab: an armoured tank on stumps ---------------------------------------
s = sub1(s, """        legRow('l_thin', [0.30, 0.00, -0.30], { out: 0.92, rake: 1.25, reach: 2.0, knee: 0.85, th: 0.9, tip: 't_talon' });
        limb('l_thick', a * 0.55, 0, b * 0.70, a * 1.25, -st * 0.5, b * 1.25, 0.15, -0.15, 0.25, 't_pincer', 1.1);""",
"""        // stumps, close in under the shell
        legRow('l_thick', [0.34, -0.02, -0.36], { out: 0.86, rake: 0.55, reach: 1.05, knee: 0.30, th: 1.6, tip: 't_pad' });
        limb('l_thick', a * 0.55, 0, b * 0.70, a * 1.20, -st * 0.45, b * 1.15, 0.15, -0.15, 0.25, 't_pincer', 1.5);""")

# ---- mantis: two heavy hind legs and blades up, not six wires ----------------
s = sub1(s, """        legRow('l_thin', [0.05, -0.32], { out: 0.75, rake: 0.9, reach: 1.35, knee: 0.9, th: 0.8, tip: 't_talon' });
        limb('l_thin', a * 0.66, b * 0.30, b * 0.42, a * 1.15, -b * 0.30, b * 0.75, 0.35, 0.45, 0.10, 't_claw', 0.72);""",
"""        // one heavy pair, digitigrade: the knee rides well above the hip
        limb('l_thick', -a * 0.18, -b * 0.20, b * 0.56, -a * 0.02, -st, b * 0.62, 0.30, 0.55, 0.04, 't_talon', 1.35);
        // and the blades, held up in front
        limb('l_thick', a * 0.62, b * 0.34, b * 0.44, a * 1.10, -b * 0.20, b * 0.72, 0.30, 0.50, 0.10, 't_claw', 0.95);""")

# ---- lurker and brute: legs you can believe carry that mass ------------------
s = sub1(s, """        limb('l_thick',  a * 0.34, -b * 0.55,  b * 0.62,  a * 0.42, -st, b * 0.86, 0.06, 0.02, 0.02, 't_pad', 1.5);
        limb('l_thick', -a * 0.36, -b * 0.55,  b * 0.62, -a * 0.44, -st, b * 0.86, -0.06, 0.02, 0.02, 't_pad', 1.5);""",
"""        limb('l_thick',  a * 0.34, -b * 0.55,  b * 0.62,  a * 0.42, -st, b * 0.90, 0.06, 0.02, 0.02, 't_pad', 2.0);
        limb('l_thick', -a * 0.36, -b * 0.55,  b * 0.62, -a * 0.44, -st, b * 0.90, -0.06, 0.02, 0.02, 't_pad', 2.0);""")
s = sub1(s, """        limb('l_thick', -a * 0.30, -b * 0.35, b * 0.50, -a * 0.20, -st, b * 0.58, 0.28, 0.05, 0.04, 't_pad', 1.35);
        limb('l_thick',  a * 0.50,  b * 0.35, b * 0.70,  a * 0.90, -st * 0.92, b * 0.95, 0.10, -0.28, 0.16, 't_claw', 1.15);""",
"""        limb('l_thick', -a * 0.30, -b * 0.35, b * 0.52, -a * 0.20, -st, b * 0.62, 0.28, 0.05, 0.04, 't_pad', 1.8);
        limb('l_thick',  a * 0.50,  b * 0.35, b * 0.72,  a * 0.92, -st * 0.92, b * 1.00, 0.10, -0.28, 0.16, 't_claw', 1.7);""")

# ---- scorpion: still eight, but heavier than a spider's -----------------------
s = sub1(s, "        legRow('l_thin', [0.42, 0.14, -0.14, -0.42], { out: 0.86, rake: 1.15, reach: 1.9, knee: 0.8, th: 0.8, tip: 't_talon' });",
            "        legRow('l_leg', [0.42, 0.14, -0.14, -0.42], { out: 0.86, rake: 1.0, reach: 1.55, knee: 0.85, th: 1.15, tip: 't_talon' });")

open(p, 'w', encoding='utf-8').write(s)
print('thick: six of ten are heavy now')
