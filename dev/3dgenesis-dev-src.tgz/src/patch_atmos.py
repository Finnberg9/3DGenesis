# Eerie atmosphere, ambient sound and the goal chain.
def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
p='g3.html'; s=open(p,encoding='utf-8').read()
code=open('src/objectives.js',encoding='utf-8').read()+'\n'+open('src/audio.js',encoding='utf-8').read()
s=sub1(s,"// ================================================================ player\n", code+"\n// ================================================================ player\n")
# nights on by default, and long enough to matter
s=sub1(s,'<input type="checkbox" id="f_day"> day / night','<input type="checkbox" id="f_day" checked> day / night')
s=sub1(s,'<b id="daylv">6</b></div><input id="dayl" type="range" min="1" max="40" step="1" value="6">','<b id="daylv">18</b></div><input id="dayl" type="range" min="1" max="40" step="1" value="18">')
s=sub1(s,"    dayLen: num('dayl', 6), yearLen: num('yearl', 70),","    dayLen: num('dayl', 18), yearLen: num('yearl', 70),")
# light and fog: dim green gloom under the canopy, real darkness at night
s=sub1(s,"""  const dayFog = [0.55, 0.68, 0.78], nightFog = [0.045, 0.075, 0.10];
  const fog = [
    nightFog[0] + (dayFog[0] - nightFog[0]) * lt,
    nightFog[1] + (dayFog[1] - nightFog[1]) * lt,
    nightFog[2] + (dayFog[2] - nightFog[2]) * lt,
  ];""","""  // Under the canopy the air is green and close; at night it is nearly black
  // and you see only what is near. Everything eases so walking out of a forest
  // or into dusk feels like it, not like a switch.
  const canHere = forestCanopyAt(player.camX, player.camZ);
  player._can = (player._can == null ? canHere : player._can) + (canHere - (player._can || 0)) * Math.min(1, frameDt * 1.5);
  const can = player._can;
  const lt2 = Math.pow(clamp(lt, 0, 1), 1.4);
  const dayFog = [0.55 - 0.2 * can, 0.66 - 0.16 * can, 0.72 - 0.34 * can], nightFog = [0.010, 0.016, 0.022];
  const fog = [
    nightFog[0] + (dayFog[0] - nightFog[0]) * lt2,
    nightFog[1] + (dayFog[1] - nightFog[1]) * lt2,
    nightFog[2] + (dayFog[2] - nightFog[2]) * lt2,
  ];""")
s=sub1(s,"  gArr[28] = t; gArr[29] = FOG_DENSITY; gArr[30] = 0.25 + 0.75 * lt; gArr[31] = terrain.LV.water * HEIGHT_SCALE;",
         "  gArr[28] = t; gArr[29] = FOG_DENSITY * (1 + 2.4 * can) * (1 + 3.2 * (1 - lt2)); gArr[30] = (0.1 + 0.9 * lt2) * (1 - 0.22 * can); gArr[31] = terrain.LV.water * HEIGHT_SCALE;")
# per-frame hooks and resets
s=sub1(s,"""  try { tick(dt); } catch (e) { running = false; fatal('Render loop failed: ' + e.message); throw e; }""","""  try { tick(dt); } catch (e) { running = false; fatal('Render loop failed: ' + e.message); throw e; }
  try { objTick(dt); sndTick(dt); } catch (e) { console.warn(e); }""")
s=sub1(s,"""  toast('New world, seed ' + seed + '. You are a newborn again.', 3600);""","""  objReset();
  toast('New world, seed ' + seed + '. You are a newborn again.', 3600);""")
s=sub1(s,"""    if (k === 'x') cycleMove();""","""    if (k === 'x') cycleMove();
    if (k === 'n') sndToggle();""")
s=sub1(s,"""    toast('Ate. +' + gain.toFixed(0) + ' energy.', 1400);""","""    toast('Ate. +' + gain.toFixed(0) + ' energy.', 1400); objOnEat();""")
s=sub1(s,"""    toast('Ate carrion. +' + gain.toFixed(0) + ' energy.', 1800);""","""    toast('Ate carrion. +' + gain.toFixed(0) + ' energy.', 1800); objOnEat();""")
s=sub1(s,"""  startAnim(best, 'flinch', 0.35);
  best.energy -= dmg;""","""  startAnim(best, 'flinch', 0.35);
  sndHit();
  best.energy -= dmg;""")
s=sub1(s,"""function edOnKill(prey) {
  PROG.kills++;""","""function edOnKill(prey) {
  PROG.kills++;
  objOnKill(prey);""")
# goal rewards count as genome space
s=sub1(s,"const base = planBaseCost(des.plan | 0) + FREE_SPACE + PROG.kills * KILL_SPACE + (SANDBOX ? 200 : 0);",
         "const base = planBaseCost(des.plan | 0) + FREE_SPACE + PROG.kills * KILL_SPACE + (PROG.bonus || 0) + (SANDBOX ? 200 : 0);")
# audio needs a user gesture
s=sub1(s,"""function loop(now) {""","""window.addEventListener('pointerdown', () => sndInit(), { once: true });
window.addEventListener('keydown', () => sndInit(), { once: true });
function loop(now) {""")
open(p,'w',encoding='utf-8').write(s)
print('atmos ok')
s=open(p,encoding='utf-8').read()
# prehistoric voices
s=sub1(s,"// ================================================================ player\n", open('src/sfx_data.js',encoding='utf-8').read()+"\n"+open('src/voices.js',encoding='utf-8').read()+"\n// ================================================================ player\n")
s=sub1(s,"  if (t > SND.nextCall) { SND.nextCall = t + (night ? 7 : 14) + Math.random() * (night ? 12 : 22); sndCall(Math.random() * 1.6 - 0.8, night); }",
         "  if (t > SND.nextCall) { SND.nextCall = t + (night ? 12 : 24) + Math.random() * (night ? 14 : 26); sndCall(Math.random() * 1.6 - 0.8, night); }\n  voxTick(dt);")
s=sub1(s,"""    if (k === 'n') sndToggle();""","""    if (k === 'n') sndToggle();
    if (k === 'r') playerRoar();""")
s=sub1(s,"""  PROG.kills++;
  objOnKill(prey);""","""  PROG.kills++;
  objOnKill(prey);
  if (player.c) setTimeout(() => voxCall(player.c, 'win'), 400);""")
s=sub1(s,"<b>X</b> switch attack &nbsp;","<b>X</b> switch attack &nbsp;·&nbsp; <b>R</b> roar &nbsp;·&nbsp; <b>N</b> sound &nbsp;")
# minimap: three times bigger on hover, drawn at a resolution that stays sharp
s=sub1(s,"""  #mini:hover{width:432px;height:270px;border-color:var(--cyan);""","""  #mini:hover{width:min(1000px,56vw,100vh);height:auto;aspect-ratio:1.6;border-color:var(--cyan);""")
s=sub1(s,'<canvas id="mini" width="432" height="270"></canvas>','<canvas id="mini" width="1296" height="810"></canvas>')
open(p,'w',encoding='utf-8').write(s)
print('voices+minimap ok')
