// =====================================================================
// CREATURE EDITOR: scene
// A separate little world the creature floats in: a carved stone podium in
// a meadow ringed by hills and trees, a sky dome, and the creature bobbing
// above the podium. Rendered with the game's own pipelines; the simulation
// is paused while it is open.
// =====================================================================
const ED_POD_R = 6.5;           // radius of the clearing under the creature (editor units: 1 = one body radius)
const ED_FOV = 0.78;
let ED_HAT = null;              // ground height of the editor scene at (r, angle), for the camera
let edEnv = null;               // { vb, ib, count, skyVB, skyIB, skyCount }
function edNoise(a, s) {        // cheap smooth periodic noise on an angle
  return Math.sin(a * 3 + s) * 0.5 + Math.sin(a * 7 + s * 2.1) * 0.25 + Math.sin(a * 13 + s * 3.7) * 0.12;
}
function buildEditorEnv() {
  const V = [], I = [];
  const vert = (x, y, z, nx, ny, nz, c) => { V.push(x, y, z, nx, ny, nz, c[0], c[1], c[2]); return V.length / 9 - 1; };
  const hsh = (i, j) => { let n = ((i * 73856093) ^ (j * 19349663)) >>> 0; n = (n ^ (n >>> 13)) >>> 0; return (n % 1000) / 1000; };
  // ---- the habitat: a clearing on a mossy forest floor, the ground rolling up
  // into banks and roots toward the trees. The creature floats just above it.
  const GY = 0;
  const rings = [ED_POD_R, 7, 8, 9.5, 11, 13, 15.5, 18.5, 22, 26, 31, 37, 44, 52, 62, 74, 90, 110, 135, 165, 200];
  const SEG = 128;
  const hAt = ED_HAT = (r, a) => {
    const bank = Math.max(0, Math.min(1, (r - 14) / 30));
    const h = bank * bank * (3 + 7 * (0.5 + 0.5 * edNoise(a, 1.7))) + (r > 70 ? (r - 70) * 0.18 * (0.6 + 0.4 * edNoise(a, 3.3)) : 0);
    const bump = 0.12 * Math.sin(r * 0.7 + a * 5) * Math.min(1, Math.max(0, r - ED_POD_R) / 4);
    return GY + h + bump;
  };
  // moss, leaf litter and a trodden path; darker toward the trees
  const floorCol = (x, z, r, i, j) => {
    const n1 = edNoise(Math.atan2(z, x) * 3 + r * 0.21, 2.1) * 0.5 + 0.5;
    const n2 = hsh(i, j);
    const path = Math.max(0, 1 - Math.abs(z + Math.sin(x * 0.12) * 3) / 2.6) * (x > 0 ? 1 : 0.3);
    let c = colMix([0.20, 0.33, 0.12], [0.30, 0.25, 0.15], n1 * 0.7);
    c = colMix(c, [0.34, 0.27, 0.19], path * 0.7);
    c = colMix(c, [0.36, 0.44, 0.16], Math.max(0, n2 - 0.8) * 2);
    const dark = 1 - Math.min(0.45, Math.max(0, r - 10) / 60);
    const jit = 0.9 + n2 * 0.18;
    return [c[0] * jit * dark, c[1] * jit * dark, c[2] * jit * dark];
  };
  const base0 = V.length / 9;
  for (let i = 0; i < rings.length; i++) {
    for (let j = 0; j <= SEG; j++) {
      const a = j / SEG * Math.PI * 2, r = rings[i];
      const y = hAt(r, a);
      const e = 0.5;
      const yr = hAt(r + e, a), ya = hAt(r, a + e / r);
      const tr = [Math.cos(a) * e, yr - y, Math.sin(a) * e];
      const ta = [-Math.sin(a) * e, ya - y, Math.cos(a) * e];
      let n = v3.norm(v3.cross(ta, tr));
      if (n[1] < 0) n = v3.mul(n, -1);
      vert(Math.cos(a) * r, y, Math.sin(a) * r, n[0], n[1], n[2], floorCol(Math.cos(a) * r, Math.sin(a) * r, r, i, j));
    }
  }
  for (let i = 0; i < rings.length - 1; i++) for (let j = 0; j < SEG; j++) {
    const a = base0 + i * (SEG + 1) + j, b = a + SEG + 1;
    I.push(a, b, a + 1, a + 1, b, b + 1);
  }
  // ---- the clearing under the creature: its own grid so the soft shadow can
  // be baked into its colours every frame
  const TR = [];
  for (let i = 0; i <= 30; i++) TR.push(ED_POD_R * Math.pow(i / 30, 0.8));
  const TS = 128, topPos = [], topCol = [], TI = [];
  for (let i = 0; i < TR.length; i++) for (let j = 0; j <= TS; j++) {
    const a = j / TS * Math.PI * 2, r = TR[i];
    const x = Math.cos(a) * r, z = Math.sin(a) * r;
    topPos.push(x, GY + 0.001, z);
    topCol.push(...floorCol(x, z, r, i + 900, j));
  }
  for (let i = 0; i < TR.length - 1; i++) for (let j = 0; j < TS; j++) {
    const a = i * (TS + 1) + j, b = a + TS + 1;
    TI.push(a, b, a + 1, a + 1, b, b + 1);
  }
  const topN = topPos.length / 3;
  const topVB = dev.createBuffer({ size: topN * 36, usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST });
  const topIB = dev.createBuffer({ size: TI.length * 4, usage: GPUBufferUsage.INDEX | GPUBufferUsage.COPY_DST });
  dev.queue.writeBuffer(topIB, 0, new Uint32Array(TI));
  edEnv = {};
  const vb = dev.createBuffer({ size: V.length * 4, usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST });
  dev.queue.writeBuffer(vb, 0, new Float32Array(V));
  const ib = dev.createBuffer({ size: I.length * 4, usage: GPUBufferUsage.INDEX | GPUBufferUsage.COPY_DST });
  dev.queue.writeBuffer(ib, 0, new Uint32Array(I));
  edEnv.vb = vb; edEnv.ib = ib; edEnv.count = I.length;
  edEnv.top = { vb: topVB, ib: topIB, count: TI.length, pos: new Float32Array(topPos), col: new Float32Array(topCol), n: topN, buf: new Float32Array(topN * 9) };
  // ---- misty sky seen through the canopy --------------------------------------
  const SV = [], SI = [];
  const RS = 600, ST = 16, SS = 48;
  for (let i = 0; i <= ST; i++) {
    const el = -0.15 + (i / ST) * (Math.PI / 2 + 0.15);
    const y = Math.sin(el), rr = Math.cos(el);
    const u = Math.max(0, y);
    const c = colMix([0.50, 0.58, 0.50], [0.68, 0.76, 0.66], Math.min(1, u * 1.6));
    for (let j = 0; j <= SS; j++) {
      const a = j / SS * Math.PI * 2;
      SV.push(Math.cos(a) * rr * RS, y * RS, Math.sin(a) * rr * RS, 0, 1, 0, c[0], c[1], c[2]);
    }
  }
  for (let i = 0; i < ST; i++) for (let j = 0; j < SS; j++) {
    const a = i * (SS + 1) + j, b = a + SS + 1;
    SI.push(a, b, a + 1, a + 1, b, b + 1);
  }
  edEnv.skyVB = dev.createBuffer({ size: SV.length * 4, usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST });
  dev.queue.writeBuffer(edEnv.skyVB, 0, new Float32Array(SV));
  edEnv.skyIB = dev.createBuffer({ size: SI.length * 4, usage: GPUBufferUsage.INDEX | GPUBufferUsage.COPY_DST });
  dev.queue.writeBuffer(edEnv.skyIB, 0, new Uint32Array(SI));
  edEnv.skyCount = SI.length;
  Object.assign(edEnv, { GY, hAt });
  buildHabitatFoliage();
}
// Trees, ferns, big-leaved understory, grass and fallen logs around the clearing,
// using the same meshes as the world (scaled: one editor unit is one body radius,
// about five world units).
function buildHabitatFoliage() {
  if (typeof folInit === 'function') folInit();
  if (!FOL.ready) return;
  const rnd = C.makeRNG(4217);
  const W = 0.2;                                   // world units -> editor units
  const buckets = new Map();
  const put = (mesh, x, z, rot, s, tint) => {
    const y = edEnv.hAt(Math.hypot(x, z), Math.atan2(z, x)) - 0.15;
    let b = buckets.get(mesh); if (!b) { b = []; buckets.set(mesh, b); }
    b.push(x, y, z, rot, s, tint[0], tint[1], tint[2]);
  };
  const tint = () => [0.85 + rnd() * 0.25, 0.88 + rnd() * 0.2, 0.85 + rnd() * 0.2];
  // a ring of trunks: giants and canopy trees behind, palms and ferns nearer
  for (let i = 0; i < 46; i++) {
    const a = rnd() * Math.PI * 2, r = 14 + Math.pow(rnd(), 0.7) * 70;
    const kind = r > 40 && rnd() < 0.2 ? 0 : rnd() < 0.55 ? 1 : rnd() < 0.5 ? 2 : rnd() < 0.5 ? 3 : 8;
    put(FOL.tree[kind][(rnd() * 3) | 0][r > 55 ? 1 : 0], Math.cos(a) * r, Math.sin(a) * r, rnd() * 6.28, W * (0.8 + rnd() * 0.5), tint());
  }
  // understory: dense toward the edges, a few plants reaching into the clearing
  for (let i = 0; i < 520; i++) {
    const a = rnd() * Math.PI * 2, r = ED_POD_R + 0.4 + Math.pow(rnd(), 0.8) * 40;
    const k = rnd();
    const kind = k < 0.36 ? 2 : k < 0.56 ? 5 : k < 0.8 ? 0 : k < 0.9 ? 4 : 3;
    const s = (kind === 0 ? 0.28 : kind === 3 ? 0.22 : 0.3) * (0.7 + rnd() * 0.7) * (r < 9 ? 0.75 : 1);
    put(FOL.cover[kind][(rnd() * 2) | 0], Math.cos(a) * r, Math.sin(a) * r, rnd() * 6.28, s, [1, 1, 1]);
  }
  // pack into a static instance buffer
  let n = 0; for (const arr of buckets.values()) n += arr.length / FOL_IF;
  const data = new Float32Array(Math.max(1, n) * FOL_IF);
  const batches = []; let off = 0;
  for (const [mesh, arr] of buckets) { data.set(arr, off * FOL_IF); batches.push({ mesh, first: off, count: arr.length / FOL_IF }); off += arr.length / FOL_IF; }
  const buf = dev.createBuffer({ size: data.byteLength, usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST });
  dev.queue.writeBuffer(buf, 0, data);
  edEnv.fol = { buf, batches };
  // fallen logs: mossy bark tubes lying on the floor
  const logs = folMB();
  for (let i = 0; i < 5; i++) {
    const a = rnd() * Math.PI * 2, r = 9 + rnd() * 14, L = 6 + rnd() * 7, dir = rnd() * Math.PI;
    const cx = Math.cos(a) * r, cz = Math.sin(a) * r, dx = Math.cos(dir), dz = Math.sin(dir);
    const y0 = edEnv.hAt(r, a) + 0.3;
    const pts = [], rad = [];
    for (let k = 0; k <= 5; k++) { const u = k / 5 - 0.5; pts.push([cx + dx * L * u, y0 + Math.sin(k) * 0.05, cz + dz * L * u]); rad.push(0.55 - Math.abs(u) * 0.2); }
    folTube(logs, pts, rad, 8, colMix([0.30, 0.24, 0.17], [0.26, 0.36, 0.14], rnd() * 0.6), 1, 0, null);
  }
  edEnv.logs = folUpload(logs);
  const one = new Float32Array([0, 0, 0, 0, 1, 1, 1, 1]);
  edEnv.logInst = dev.createBuffer({ size: one.byteLength, usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST });
  dev.queue.writeBuffer(edEnv.logInst, 0, one);
}
function edDrawHabitat(pass) {
  if (!edEnv || !edEnv.fol || !folPipe) return;
  pass.setPipeline(folPipe); pass.setBindGroup(0, folBind);
  pass.setVertexBuffer(1, edEnv.fol.buf);
  for (const b of edEnv.fol.batches) {
    pass.setVertexBuffer(0, b.mesh.vb); pass.setIndexBuffer(b.mesh.ib, 'uint32');
    pass.drawIndexed(b.mesh.count, b.count, 0, 0, b.first);
  }
  pass.setVertexBuffer(1, edEnv.logInst);
  pass.setVertexBuffer(0, edEnv.logs.vb); pass.setIndexBuffer(edEnv.logs.ib, 'uint32');
  pass.drawIndexed(edEnv.logs.count, 1);
}
// (the old podium scenery is gone; the habitat is static and drawn by edDrawHabitat)
function editorScenery(t) { }
// Soft contact shadow: the union of every skeleton ball and foot, projected
// straight down, blurred, and fading as the creature bobs up.
function bakePodiumShadow(des, pl) {
  const T = edEnv.top, G = pl.G, sk = G.sk;
  const blobs = [];
  for (const k of sk.balls) if (!k.hide) blobs.push([k.x, k.z, k.r * 1.05]);
  for (const o of G.cls.limbs) { const f = v3.add(o.root, o.lb.f); blobs.push([f[0], f[2], 0.26]); const kk = v3.add(o.root, o.lb.k); blobs.push([kk[0], kk[2], 0.18]); }
  const k0 = 0.56 * clamp(1 - pl.hover * 0.8, 0.4, 1);
  const soft = 0.55 + pl.hover * 0.6;
  const P = T.pos, Cc = T.col, O = T.buf;
  for (let i = 0; i < T.n; i++) {
    const x = P[i * 3], z = P[i * 3 + 2];
    let sh = 0;
    for (let b = 0; b < blobs.length; b++) {
      const q = blobs[b];
      const d = Math.hypot(x - q[0], z - q[1]) - q[2];
      if (d < soft) { const u = 1 - Math.max(0, d) / soft; const v = u * u * (3 - 2 * u); if (v > sh) sh = v; }
    }
    const f = 1 - k0 * sh;
    const o = i * 9;
    O[o] = x; O[o + 1] = 0.001; O[o + 2] = z; O[o + 3] = 0; O[o + 4] = 1; O[o + 5] = 0;
    O[o + 6] = Cc[i * 3] * f; O[o + 7] = Cc[i * 3 + 1] * f; O[o + 8] = Cc[i * 3 + 2] * f;
  }
  dev.queue.writeBuffer(T.vb, 0, O);
}
// ---- synchronous skin build (the editor never shows a placeholder body) ----
function skinNow(skel) {
  const key = skinKey(skel);
  const hit = meshCache.get(key);
  if (hit && hit !== 'pending') { meshCache.delete(key); meshCache.set(key, hit); return hit.empty ? null : hit; }
  let m = null;
  try { m = buildSkinMesh(skel); } catch (e) { m = null; }
  if (!m) { meshCache.set(key, { empty: true }); return null; }
  const vb = dev.createBuffer({ size: m.vertData.byteLength, usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST });
  dev.queue.writeBuffer(vb, 0, m.vertData);
  const ib = dev.createBuffer({ size: m.idx.byteLength, usage: GPUBufferUsage.INDEX | GPUBufferUsage.COPY_DST });
  dev.queue.writeBuffer(ib, 0, m.idx);
  const rec = { vb, ib, count: m.idx.length, tris: m.tris };
  meshCache.set(key, rec);
  return rec;
}
// Flush instance buffers and draw everything queued. `target` optional
// {color view, resolve view, depth view} for offscreen thumbnails.
function edFlushAndDraw(pass) {
  let off = 0;
  bodyBatches.length = 0;
  for (const [mesh, arr] of bodyByMesh) {
    const n = arr.length / BINST_FLOATS;
    if (off + n > MAX_BODY_INST) break;
    bodyInstData.set(arr, off * BINST_FLOATS);
    bodyBatches.push({ mesh, first: off, count: n });
    off += n;
  }
  if (off) dev.queue.writeBuffer(bodyInstVB, 0, bodyInstData, 0, off * BINST_FLOATS);
  if (instCount) dev.queue.writeBuffer(instVB, 0, instData, 0, instCount * INST_FLOATS);
  if (spikeCount) dev.queue.writeBuffer(spikeVB, 0, spikeData, 0, spikeCount * INST_FLOATS);
  pass.setPipeline(instPipe); pass.setBindGroup(0, bindG.inst);
  if (instCount) {
    pass.setVertexBuffer(0, sphVB); pass.setIndexBuffer(sphIB, 'uint16');
    pass.setVertexBuffer(1, instVB); pass.drawIndexed(sphCount, instCount);
  }
  if (spikeCount) {
    pass.setVertexBuffer(0, coneVB); pass.setIndexBuffer(coneIB, 'uint16');
    pass.setVertexBuffer(1, spikeVB); pass.drawIndexed(coneCount, spikeCount);
  }
  drawTubes(pass);
  flushSkinDraws(pass);
  if (bodyBatches.length) {
    pass.setPipeline(bodyPipe); pass.setBindGroup(0, bindG.body);
    pass.setVertexBuffer(1, bodyInstVB);
    for (const bt of bodyBatches) {
      pass.setVertexBuffer(0, bt.mesh.vb);
      pass.setIndexBuffer(bt.mesh.ib, 'uint32');
      pass.drawIndexed(bt.mesh.count, bt.count, 0, 0, bt.first);
    }
  }
}
function edSetGlobals(eye, target, aspect, fov, fogDen, t) {
  m4persp(fov, aspect, 0.05, 1200, projM);
  m4look(eye[0], eye[1], eye[2], target[0], target[1], target[2], viewM);
  m4mul(projM, viewM, vpM);
  gArr.set(vpM, 0);
  gArr[16] = eye[0]; gArr[17] = eye[1]; gArr[18] = eye[2]; gArr[19] = 1;   // w=1: editor, no near-camera foliage fade
  gArr[20] = 0.42; gArr[21] = 0.82; gArr[22] = 0.38; gArr[23] = 0;
  gArr[24] = 0.52; gArr[25] = 0.60; gArr[26] = 0.52; gArr[27] = 1;
  gArr[28] = t; gArr[29] = fogDen; gArr[30] = 1; gArr[31] = -1000;
  dev.queue.writeBuffer(gBuf, 0, gArr);
}
function edResetInstances() {
  instCount = 0; spikeCount = 0; tubeN = 0;
  bodyByMesh.clear(); bodyCount = 0; bodyBatches.length = 0;
  resetSkinFrame();
}
// Editor placement of the creature: facing +x, centred over the podium.
function edPlacement(des, t) {
  const G = designGeo(des);
  const hover = 0.34 + Math.sin(t * 1.7) * 0.07;
  const cy = G.cls.stand + hover;
  return { cx: 0, cy, cz: 0, G, hover };
}
function edDesignX(des, t, hl, extra) {
  const pl = edPlacement(des, t);
  const X = Object.assign({
    R: 1, t, seed: 0.5, sync: true, quality: 2, yaw: 0, meshFar: true,
    toW: (l) => [l[0], l[1] + pl.cy, l[2]],
    toL: (w) => [w[0], w[1] - pl.cy, w[2]],
    dirW: (v) => v,
    gaitPhase: t * 0.9, tailAmp: 0.3, flexAmp: 0.12, tailSwing: 0,
    flap: Math.sin(t * 1.9) * 0.22, chomp: 0.1 + 0.1 * Math.sin(t * 1.3), grip: 0.2 + 0.2 * Math.sin(t * 0.9),
    blink: (pi) => (((t * 0.23 + pi * 0.137) % 1) < 0.03 ? 1 : 0),
    hl,
  }, extra || {});
  // attack preview on the podium
  const A = ED.anim && !extra ? ED.anim : null;
  if (A) {
    const k = (performance.now() - A.t0) / (A.dur * 1000);
    if (k >= 1) ED.anim = null;
    else {
      const an = { kind: A.kind, k, s: strikeCurve(k) };
      const lunge = A.kind === 'sweep' ? 0.05 * an.s : 0.28 * an.s;
      const lift = A.kind === 'slam' ? Math.max(0, -an.s) * 0.9 - Math.max(0, an.s) * 0.3 : 0;
      X.toW = (l) => [l[0] + lunge, l[1] + pl.cy + lift, l[2]];
      X.toL = (w) => [w[0] - lunge, w[1] - pl.cy - lift, w[2]];
      const rig = attackRig(pl.G, an, (A.seq & 1) ? 1 : -1, t, 0, X.toW);
      X.head = rig.head;
      if (rig.chomp != null) X.chomp = rig.chomp;
      if (A.kind === 'sweep') { X.tailSwing = an.s * 1.5 * rig.tailMul; X.tailAmp = 0.2; }
      X.limbPose = (o, li, root, knee, foot) => rig.limb(o, root, foot);
    }
  }
  return { X, pl };
}
