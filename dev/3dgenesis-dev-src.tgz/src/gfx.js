// =====================================================================
// GRAPHICS QUALITY (bottom-right selector): low / medium / high / ultra.
// Controls render resolution, how far out ground cover, food plants and
// detailed tree/creature models are drawn, the instance budget and the fog.
// The choice is remembered in this browser.
// =====================================================================
const GFX_PRESETS = {
  low:    { res: 0.60, cover: 380,  plant: 2600,  lod0: 420,  lod1: 1600, crit: 0.6, fog: 1.00, folMax: 50000 },
  medium: { res: 0.85, cover: 620,  plant: 4200,  lod0: 700,  lod1: 2600, crit: 0.9, fog: 0.80, folMax: 90000 },
  high:   { res: 1.00, cover: 900,  plant: 6500,  lod0: 1000, lod1: 3800, crit: 1.3, fog: 0.60, folMax: 140000 },
  ultra:  { res: 1.25, cover: 1250, plant: 11000, lod0: 1500, lod1: 6000, crit: 1.9, fog: 0.42, folMax: 200000 },
};
const GFX_ORDER = ['low', 'medium', 'high', 'ultra'];
const GFX = Object.assign({ name: 'high' }, GFX_PRESETS.high);
function gfxLoad() {
  let n = null;
  try { n = localStorage.getItem('g3d_gfx'); } catch (e) { n = null; }
  gfxSet(GFX_PRESETS[n] ? n : 'high', true);
}
function gfxSet(name, silent) {
  if (!GFX_PRESETS[name]) return;
  Object.assign(GFX, GFX_PRESETS[name], { name });
  COVER_R = GFX.cover; TREE_LOD0 = GFX.lod0; TREE_LOD1 = GFX.lod1;
  if (typeof FOL !== 'undefined') FOL.key = '';                 // rebuild the foliage set now
  try { localStorage.setItem('g3d_gfx', name); } catch (e) { /* private mode: not remembered */ }
  const el = document.getElementById('gfxsel');
  if (el) for (const b of el.querySelectorAll('button')) b.classList.toggle('on', b.dataset.q === name);
  if (!silent && typeof toast === 'function') toast('Graphics: ' + name, 1200);
}
function gfxBind() {
  const el = document.getElementById('gfxsel');
  if (!el) return;
  el.addEventListener('click', (e) => {
    const b = e.target.closest ? e.target.closest('button[data-q]') : null;
    if (b) { gfxSet(b.dataset.q); e.stopPropagation(); }
  });
  el.addEventListener('mousedown', (e) => e.stopPropagation());
  gfxLoad();
}
// keep clear of the control panel when it is open
function gfxPlace() {
  const el = document.getElementById('gfxsel'), tab = document.getElementById('ptab');
  if (!el) return;
  const open = tab && !tab.classList.contains('closed') && document.getElementById('panel') &&
               getComputedStyle(document.getElementById('panel')).display !== 'none';
  el.style.right = open ? '454px' : '14px';
}

// ---------------------------------------------------------------- feeding growth
// Eating another animal makes you bigger. A juvenile gets a big growth spurt;
// a grown animal keeps bulking past its genetic adult size, up to BULK_MAX,
// with diminishing returns. Size is real: develop() scales mass, reach,
// attack, storage and upkeep with it, so a bigger body hits harder, holds
// more, and has to eat more.
const BULK_MAX = 1.5;
function feedGrowth(c, preyMass, label) {
  if (!c || !c.alive || !c.cellState || !c.cellState.length) return;
  const ratio = clamp((preyMass || 0.5) / Math.max(0.2, c.ph.mass), 0.05, 1.5);
  const gain = 0.02 + 0.10 * ratio;
  const r0 = c.ph.radius, ef = c.energy / Math.max(1, c.ph.storage);
  let sum = 0, n = 0;
  for (const q of c.cellState) {
    if (!q.alive) continue;
    if (q.grow < 1) q.grow = q.grow + gain * 2.5;                    // juvenile spurt
    else q.grow = q.grow + gain * Math.max(0, 1 - (q.grow - 1) / (BULK_MAX - 1));
    q.grow = Math.min(BULK_MAX, q.grow);
    sum += q.grow; n++;
  }
  c._growthAvg = n ? Math.min(1, sum / n) : 0;
  c._bulk = n ? sum / n : 1;
  c.ph = C.develop(c.genome, c.cellState);
  // the same fraction of a bigger stomach
  c.energy = Math.min(c.ph.storage, Math.max(c.energy, ef * c.ph.storage));
  if (c.ph.radius > r0 * 1.004) toast((label || 'Fed') + ': you grew to size x' + (c._bulk || 1).toFixed(2) + '.', 2200);
}
