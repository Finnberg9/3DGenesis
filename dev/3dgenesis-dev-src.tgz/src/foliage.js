// =====================================================================
// FOREST AND GROUND COVER
// Trees are real meshes built once at start-up: tapered bark tubes with
// buttress roots, forking limbs, crowns made of hundreds of individual leaf
// blades, palm fronds, conifer skirts and hanging lianas. Several variants per
// kind and three levels of detail. They are drawn instanced from the static
// forest the simulation generates (so what you see is what you bump into),
// with wind sway in the vertex shader. Ground cover (tall grass, ferns, reeds,
// shrubs) is scattered procedurally around the camera.
// Units: world units. A grown animal is roughly 8-15 tall; the canopy stands at
// 200-280 and emergent giants reach past 400.
// =====================================================================
const FOL_VF = 11;           // pos3 nrm3 col3 sway1 leaf1
const FOL_IF = 8;            // pos3 yaw1 scale1 tint3
const FOL_MAX_INST = 60000;
function folRng(seed) {
  let a = seed >>> 0;
  return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}
function folMB() { return { v: [], i: [], n: 0 }; }
function folV(m, p, nr, c, sway, leaf) { m.v.push(p[0], p[1], p[2], nr[0], nr[1], nr[2], c[0], c[1], c[2], sway, leaf); return m.n++; }
const fadd = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
const fsub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const fmul = (a, k) => [a[0] * k, a[1] * k, a[2] * k];
const fdot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const fcross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const fnorm = (a) => { const l = Math.hypot(a[0], a[1], a[2]); return l > 1e-9 ? [a[0] / l, a[1] / l, a[2] / l] : [0, 1, 0]; };
const fcol = (c, k) => [Math.min(1, c[0] * k), Math.min(1, c[1] * k), Math.min(1, c[2] * k)];
// sway amplitude grows with height (the base never moves)
const fsw = (y, H, k) => k * Math.pow(Math.max(0, y) / Math.max(1, H), 1.6);

// Tapered tube along a polyline. pts: points, rad: radii, sides.
function folTube(m, pts, rad, sides, col, H, swayK, aoFloor) {
  const n = pts.length;
  let prevN = null;
  const rings = [];
  for (let k = 0; k < n; k++) {
    const t = fnorm(k === 0 ? fsub(pts[1], pts[0]) : k === n - 1 ? fsub(pts[n - 1], pts[n - 2]) : fsub(pts[k + 1], pts[k - 1]));
    let nr = prevN ? fsub(prevN, fmul(t, fdot(prevN, t))) : fcross(t, Math.abs(t[1]) < 0.9 ? [0, 1, 0] : [1, 0, 0]);
    nr = fnorm(nr); prevN = nr;
    const bn = fcross(t, nr);
    const ring = [];
    for (let s = 0; s < sides; s++) {
      const a = s / sides * Math.PI * 2;
      const d = fadd(fmul(nr, Math.cos(a)), fmul(bn, Math.sin(a)));
      const p = fadd(pts[k], fmul(d, rad[k]));
      const ao = aoFloor != null ? aoFloor + (1 - aoFloor) * Math.min(1, p[1] / 40) : 1;
      const bark = 0.9 + 0.2 * ((s * 7 + k * 3) % 5) / 5;
      ring.push(folV(m, p, d, fcol(col, ao * bark), fsw(p[1], H, swayK), 0));
    }
    rings.push(ring);
  }
  for (let k = 0; k < n - 1; k++) for (let s = 0; s < sides; s++) {
    const a = rings[k][s], b = rings[k][(s + 1) % sides], c = rings[k + 1][s], d = rings[k + 1][(s + 1) % sides];
    m.i.push(a, c, b, b, c, d);
  }
  // cap the tip
  const tip = pts[n - 1], last = rings[n - 1];
  const tv = folV(m, tip, fnorm(fsub(pts[n - 1], pts[n - 2])), col, fsw(tip[1], H, swayK), 0);
  for (let s = 0; s < sides; s++) m.i.push(last[s], tv, last[(s + 1) % sides]);
}
// A curved limb from a to b with a sag/rise, as a short tube
function folLimb(m, a, b, r0, r1, bend, sides, col, H, swayK) {
  const pts = [], rad = [];
  const N = 4;
  for (let k = 0; k <= N; k++) {
    const u = k / N;
    const p = fadd(fadd(a, fmul(fsub(b, a), u)), [0, Math.sin(u * Math.PI) * bend, 0]);
    pts.push(p); rad.push(r0 + (r1 - r0) * u);
  }
  folTube(m, pts, rad, sides, col, H, swayK, null);
}
// Buttress roots: thin curved plates flaring from the trunk into the ground
// Buttress roots: thick, sinuous flares that grow out of the trunk, taper and
// curl as they run out along the ground, with a rounded crest (not a flat
// blade) and soft normals so they read as wood, not sheet metal.
function folButtress(m, trunkR, hTop, reach, nFins, thick, col, rnd, H) {
  const S = 12;
  for (let f = 0; f < nFins; f++) {
    const a0 = (f / nFins + rnd() * 0.12) * Math.PI * 2;
    const curl = (rnd() - 0.5) * 0.9;                     // the root swings sideways as it runs out
    const R = reach * (0.7 + rnd() * 0.5), Ht = hTop * (0.75 + rnd() * 0.4);
    const T0 = thick * (2.2 + rnd() * 0.8);
    const rows = [];                                      // per step: [leftBottom, leftTop, crest, rightTop, rightBottom]
    for (let k = 0; k <= S; k++) {
      const u = k / S;
      const a = a0 + curl * u * u;
      const dir = [Math.cos(a), 0, Math.sin(a)], perp = [-Math.sin(a), 0, Math.cos(a)];
      const out = trunkR * 0.55 + R * u;
      const y = Ht * Math.pow(1 - u, 1.9) + 1.2 * (1 - u);
      const th = T0 * (1 - u * 0.75) * (0.85 + 0.3 * Math.sin(u * 7 + a0));
      const base = fmul(dir, out);
      const ao = 0.55 + 0.45 * Math.min(1, y / 30);
      const pt = (side, h, nr, sh) => folV(m, fadd(fadd(base, fmul(perp, side)), [0, h, 0]), fnorm(nr), fcol(col, sh), 0, 0);
      const up = [0, 1, 0];
      rows.push([
        pt(-th * 1.25, -3, fadd(fmul(perp, -1), [0, -0.2, 0]), 0.5),
        pt(-th, y * 0.92, fadd(fmul(perp, -1), fmul(up, 0.45)), ao),
        pt(0, y + th * 0.55, fadd(up, fmul(dir, 0.25)), ao * 1.05),
        pt(th, y * 0.92, fadd(perp, fmul(up, 0.45)), ao),
        pt(th * 1.25, -3, fadd(perp, [0, -0.2, 0]), 0.5),
      ]);
    }
    for (let k = 0; k < S; k++) {
      const A = rows[k], B = rows[k + 1];
      for (let c = 0; c < 4; c++) {
        const a0v = A[c], a1v = A[c + 1], b0v = B[c], b1v = B[c + 1];
        m.i.push(a0v, b0v, a1v, a1v, b0v, b1v);
      }
    }
  }
}
// One leaf blade: a folded diamond/oval card, two-sided (the pipeline does not cull)
function folLeaf(m, c, nrm, tg, L, W, col, sway) {
  const bt = fnorm(fcross(nrm, tg));
  const base = fsub(c, fmul(tg, L * 0.5)), tip = fadd(c, fmul(tg, L * 0.5));
  const mid = fadd(c, fmul(tg, -L * 0.05));
  const s1 = fsub(fadd(mid, fmul(bt, W * 0.5)), fmul(nrm, W * 0.18));
  const s2 = fsub(fsub(mid, fmul(bt, W * 0.5)), fmul(nrm, W * 0.18));
  const cDark = fcol(col, 0.82), cTip = fcol(col, 1.08);
  const i0 = folV(m, base, nrm, cDark, sway * 0.8, 1), i1 = folV(m, s1, fnorm(fadd(nrm, fmul(bt, 0.35))), col, sway, 1);
  const i2 = folV(m, tip, nrm, cTip, sway * 1.15, 1), i3 = folV(m, s2, fnorm(fsub(nrm, fmul(bt, 0.35))), col, sway, 1);
  m.i.push(i0, i1, i2, i0, i2, i3);
}
// A clump of foliage: many blades inside a squashed ellipsoid, darker inside
function folCluster(m, c, R, flat, count, col, rnd, H, swayK, leafL) {
  for (let k = 0; k < count; k++) {
    const u = rnd() * 2 - 1, th = rnd() * Math.PI * 2;
    const sr = Math.sqrt(1 - u * u);
    const dir = [sr * Math.cos(th), u, sr * Math.sin(th)];
    const rr = R * (0.45 + 0.55 * Math.sqrt(rnd()));
    const p = fadd(c, [dir[0] * rr, dir[1] * rr * flat, dir[2] * rr]);
    const nrm = fnorm(fadd(dir, [0, 0.9, 0]));
    const tg = fnorm(fadd(fcross(nrm, [rnd() - 0.5, rnd() - 0.5, rnd() - 0.5]), fmul(dir, 0.6)));
    const depth = rr / R;
    const shade = (0.45 + 0.55 * depth) * (0.75 + 0.25 * (dir[1] * 0.5 + 0.5));
    const hue = [col[0] * (0.85 + rnd() * 0.3), col[1] * (0.88 + rnd() * 0.24), col[2] * (0.85 + rnd() * 0.3)];
    const L = leafL * (0.7 + rnd() * 0.6);
    folLeaf(m, p, nrm, tg, L, L * (0.42 + rnd() * 0.2), fcol(hue, shade), fsw(p[1], H, swayK) + L * 0.08);
  }
}
// Low-detail crown: a lumpy blob
function folBlob(m, c, R, flat, col, rnd, H, swayK, seg) {
  const nu = seg || 7, nv = Math.max(3, (seg || 7) - 3);
  const idx = [];
  for (let j = 0; j <= nv; j++) {
    const row = [];
    const v = j / nv, phi = v * Math.PI;
    const bumps = [];
    for (let i = 0; i < nu; i++) bumps.push((j === 0 || j === nv) ? 1 : 0.72 + 0.5 * rnd());
    for (let i = 0; i <= nu; i++) {
      const th = (i % nu) / nu * Math.PI * 2;
      const d = [Math.sin(phi) * Math.cos(th), Math.cos(phi), Math.sin(phi) * Math.sin(th)];
      const bump = bumps[i % nu];
      const p = fadd(c, [d[0] * R * bump, d[1] * R * flat * bump, d[2] * R * bump]);
      const sh = 0.6 + 0.4 * (d[1] * 0.5 + 0.5);
      row.push(folV(m, p, d, fcol(col, sh), fsw(p[1], H, swayK), 1));
    }
    idx.push(row);
  }
  for (let j = 0; j < nv; j++) for (let i = 0; i < nu; i++) {
    const a = idx[j][i], b = idx[j][i + 1], c2 = idx[j + 1][i], d = idx[j + 1][i + 1];
    m.i.push(a, b, c2, b, d, c2);
  }
}
// A liana hanging from a point, swinging, with a few leaves
function folVine(m, top, len, rnd, H, lod) {
  const pts = [], rad = [];
  const N = lod ? 3 : 7;
  const wx = (rnd() - 0.5) * 6, wz = (rnd() - 0.5) * 6;
  for (let k = 0; k <= N; k++) {
    const u = k / N;
    pts.push([top[0] + wx * Math.sin(u * 3.1), top[1] - len * u, top[2] + wz * Math.sin(u * 2.3)]);
    rad.push(0.9 * (1 - u * 0.5));
  }
  const base = m.n;
  folTube(m, pts, rad, lod ? 3 : 4, [0.30, 0.27, 0.16], H, 0, null);
  // vines swing: override sway so it grows DOWN the vine from its anchor
  for (let v = base; v < m.n; v++) { const y = m.v[v * FOL_VF + 1]; m.v[v * FOL_VF + 9] = fsw(top[1], H, 3) + (top[1] - y) * 0.06; }
  if (!lod) for (let k = 0; k < 7; k++) {
    const u = 0.15 + rnd() * 0.85, p = [top[0] + wx * Math.sin(u * 3.1), top[1] - len * u, top[2] + wz * Math.sin(u * 2.3)];
    const nrm = fnorm([rnd() - 0.5, 0.3, rnd() - 0.5]);
    folLeaf(m, fadd(p, fmul(nrm, 1.5)), nrm, fnorm([rnd() - 0.5, -0.4, rnd() - 0.5]), 5, 2.6, [0.20 + rnd() * 0.06, 0.40 + rnd() * 0.08, 0.14], fsw(top[1], H, 3) + len * u * 0.06);
  }
}
// A palm frond: arching spine with paired leaflets hanging from it
function folFrond(m, base, dir, len, rise, droop, col, rnd, H, swayK, lod) {
  const side = fnorm(fcross(dir, [0, 1, 0]));
  const P = (u) => fadd(fadd(base, fmul(dir, len * u)), [0, (rise * u - droop * u * u) * len, 0]);
  const N = lod === 2 ? 3 : lod ? 5 : 12;
  const spine = [], rad = [];
  for (let k = 0; k <= N; k++) { spine.push(P(k / N)); rad.push(0.6 * (1 - k / N) + 0.1); }
  if (!lod) folTube(m, spine, rad, 3, [0.36, 0.40, 0.18], H, swayK, null);
  for (let k = 1; k <= N; k++) {
    const u = k / N, p = P(u), q = P(Math.max(0, u - 1 / N));
    const t = fnorm(fsub(p, q));
    const ll = len * 0.34 * Math.sin(Math.PI * Math.min(1, u * 0.95 + 0.08)) * (lod ? 1.4 : 1);
    for (const sg of [1, -1]) {
      const out = fnorm(fadd(fmul(side, sg), [0, -0.55, 0]));
      const c = fadd(p, fmul(out, ll * 0.5));
      const nrm = fnorm(fcross(t, out)); const nr = nrm[1] < 0 ? fmul(nrm, -1) : nrm;
      folLeaf(m, c, nr, out, ll, ll * (lod ? 0.5 : 0.22), fcol(col, 0.85 + 0.25 * u), fsw(c[1], H, swayK) + len * u * 0.05);
    }
  }
}

// ---- tree archetypes ----------------------------------------------------------------
const LEAF_GREEN = [[0.16, 0.36, 0.12], [0.20, 0.42, 0.14], [0.13, 0.32, 0.13], [0.24, 0.44, 0.12]];
const BARK_A = [0.40, 0.33, 0.25], BARK_B = [0.55, 0.50, 0.42], BARK_C = [0.30, 0.24, 0.18];
function buildTreeMesh(kind, variant, lod) {
  const rnd = folRng(1000 + kind * 97 + variant * 13 + 7);
  const m = folMB();
  const leafCol = LEAF_GREEN[(kind + variant) % LEAF_GREEN.length];
  const nLeaf = (n) => Math.max(4, Math.round(n * [1, 0.4, 0][lod]));
  const leafL = (l) => l * [1, 1.9, 1][lod];
  const sides = [12, 6, 3][lod];
  // far LOD: every crown is merged into one lumpy blob drawn at the end
  const farCrowns = [];
  const crown = (c, R, flat, count, col, H, sw, L) => {
    if (lod === 2) farCrowns.push({ c, R, flat, col, sw });
    else folCluster(m, c, R, flat, nLeaf(count), col, rnd, H, sw, leafL(L));
  };
  const LIMB = lod === 2 ? () => {} : folLimb;
  const trunk = (H, r0, r1, lean, col, bendAmp) => {
    const pts = [], rad = [];
    const N = lod === 2 ? 2 : lod ? 4 : 8;
    const la = rnd() * Math.PI * 2;
    for (let k = 0; k <= N; k++) {
      const u = k / N;
      pts.push([Math.cos(la) * lean * H * u * u + Math.sin(u * 5 + la) * bendAmp, H * u - 2, Math.sin(la) * lean * H * u * u + Math.cos(u * 4 + la) * bendAmp]);
      rad.push((r0 + (r1 - r0) * Math.pow(u, 0.7)) * (1 + 0.45 * Math.exp(-u * 14)));
    }
    folTube(m, pts, rad, sides, col, H, 0.02 * H, 0.45);
    return pts;
  };
  let H = 100;
  switch (kind) {
    case 0: {   // emergent giant: buttressed pillar with an umbrella crown far above the canopy
      H = 360 + variant * 45 + rnd() * 40;
      const tp = trunk(H * 0.84, 10, 4.2, 0.02, BARK_B, 2);
      if (lod < 2) folButtress(m, 10, 42, 34, lod ? 4 : 7, 1.8, BARK_B, rnd, H);
      const top = tp[tp.length - 1];
      const nb = 6 + (variant % 2);
      for (let b = 0; b < nb; b++) {
        const a = b / nb * Math.PI * 2 + rnd() * 0.4, reach = 55 + rnd() * 35;
        const start = fadd(top, [0, -18 - rnd() * 25, 0]);
        const end = [top[0] + Math.cos(a) * reach, top[1] + 12 + rnd() * 26, top[2] + Math.sin(a) * reach];
        LIMB(m, start, end, 3.4, 1.2, 8, lod ? 3 : 5, BARK_B, H, 0.02 * H);
        crown(fadd(end, [0, 10, 0]), 30 + rnd() * 10, 0.5, 110, leafCol, H, 0.03 * H, 8);
        if (rnd() < 0.5) crown(fadd(fmul(fadd(start, end), 0.5), [0, 14, 0]), 20, 0.55, 50, leafCol, H, 0.03 * H, 7);
        if (lod < 2) for (let v = 0; v < 3; v++) folVine(m, fadd(fmul(fadd(start, fmul(fsub(end, start), 0.3 + rnd() * 0.6)), 1), [0, -2, 0]), 80 + rnd() * 170, rnd, H, lod);
      }
      crown(fadd(top, [0, 22, 0]), 34, 0.45, 110, leafCol, H, 0.03 * H, 8);
      break;
    }
    case 1: {   // canopy broadleaf: forked limbs, several dense crowns, lianas
      H = 190 + variant * 35 + rnd() * 30;
      const tp = trunk(H * 0.62, 6, 3.2, 0.05, variant === 1 ? BARK_A : BARK_C, 3);
      if (lod < 2) folButtress(m, 6, 20, 16, lod ? 3 : 5, 1.2, variant === 1 ? BARK_A : BARK_C, rnd, H);
      const fork = tp[tp.length - 1];
      const nl = 3 + (variant % 2);
      for (let b = 0; b < nl; b++) {
        const a = b / nl * Math.PI * 2 + rnd() * 0.6, reach = 30 + rnd() * 26;
        const end = [fork[0] + Math.cos(a) * reach, H * (0.8 + rnd() * 0.12), fork[2] + Math.sin(a) * reach];
        LIMB(m, fork, end, 2.8, 1.1, 6, lod ? 3 : 5, BARK_A, H, 0.02 * H);
        crown(end, 26 + rnd() * 8, 0.62, 95, leafCol, H, 0.03 * H, 7);
        crown(fadd(end, [(rnd() - 0.5) * 24, -10, (rnd() - 0.5) * 24]), 16, 0.7, 40, fcol(leafCol, 0.9), H, 0.03 * H, 6);
        if (lod < 2 && rnd() < 0.8) folVine(m, fadd(end, [0, -8, 0]), 60 + rnd() * 110, rnd, H, lod);
      }
      crown([fork[0], H * 0.93, fork[2]], 30, 0.55, 100, leafCol, H, 0.03 * H, 7);
      // epiphyte clumps along the trunk
      if (lod === 0) for (let e = 0; e < 3; e++) { const y = H * (0.25 + rnd() * 0.35); crown([Math.cos(e * 2.1) * 6.5, y, Math.sin(e * 2.1) * 6.5], 5, 0.7, 14, [0.28, 0.46, 0.16], H, 0.01 * H, 3.5); }
      break;
    }
    case 2: {   // palm: slender curved stem, crown of arching fronds
      H = 95 + variant * 22 + rnd() * 20;
      const la = rnd() * Math.PI * 2, lean = 0.12 + rnd() * 0.12;
      const pts = [], rad = [];
      const N = lod ? 4 : 10;
      for (let k = 0; k <= N; k++) { const u = k / N; pts.push([Math.cos(la) * lean * H * u * u, H * u - 1, Math.sin(la) * lean * H * u * u]); rad.push(2.3 - 0.8 * u); }
      folTube(m, pts, rad, lod ? 4 : 6, BARK_B, H, 0.05 * H, 0.6);
      const top = pts[N];
      const nf = lod === 2 ? 4 : 12 + variant * 2;
      for (let f = 0; f < nf; f++) {
        const a = f / nf * Math.PI * 2 + rnd() * 0.3;
        const dir = fnorm([Math.cos(a), 0, Math.sin(a)]);
        folFrond(m, top, dir, 34 + rnd() * 14, 0.55 + rnd() * 0.3, 1.1 + rnd() * 0.4, fcol(leafCol, 1.1), rnd, H, 0.06 * H, lod);
      }
      if (lod < 2) for (let k = 0; k < 5; k++) folLeaf(m, fadd(top, [(rnd() - 0.5) * 3, 2, (rnd() - 0.5) * 3]), [0, 1, 0], fnorm([rnd() - 0.5, 1, rnd() - 0.5]), 14, 3, [0.3, 0.46, 0.16], 0.06 * H);
      break;
    }
    case 3: {   // understory tree: short, broad-leaved, lopsided crown
      H = 46 + variant * 14 + rnd() * 14;
      const tp = trunk(H * 0.6, 2.4, 1.3, 0.12, BARK_A, 1.5);
      const top = tp[tp.length - 1];
      for (let k = 0; k < 4; k++) {
        const c = fadd(top, [(rnd() - 0.5) * 22, H * 0.25 + rnd() * 10, (rnd() - 0.5) * 22]);
        LIMB(m, top, c, 1.1, 0.5, 2, 3, BARK_A, H, 0.02 * H);
        crown(c, 11 + rnd() * 5, 0.7, 45, fcol(leafCol, 1.1), H, 0.05 * H, 6.5);
      }
      break;
    }
    case 4: {   // conifer: straight trunk, drooping tiered skirts of needles
      H = 150 + variant * 30 + rnd() * 30;
      const tp = trunk(H, 4.5, 0.6, 0.01, BARK_C, 0.5);
      const tiers = lod === 2 ? 5 : 11;
      const dark = [0.08, 0.24, 0.14];
      for (let k = 0; k < tiers; k++) {
        const u = k / tiers, y = H * (0.18 + u * 0.8), rr = 34 * (1 - u * 0.85) + 4;
        if (lod === 2) { if (k % 3 === 0) folBlob(m, [0, y + rr * 0.3, 0], rr * 1.1, 0.8, dark, rnd, H, 0.02 * H, 5); continue; }
        const nsp = lod ? 6 : 11;
        for (let s = 0; s < nsp; s++) {
          const a = s / nsp * Math.PI * 2 + k * 0.5 + rnd() * 0.3;
          const out = fnorm([Math.cos(a), -0.35 - u * 0.2, Math.sin(a)]);
          const c = fadd([0, y, 0], fmul(out, rr * 0.5));
          const up = fnorm(fcross(out, fcross([0, 1, 0], out)));
          folLeaf(m, c, up, out, rr, rr * 0.5, fcol(dark, 0.85 + rnd() * 0.3), fsw(c[1], H, 0.03 * H));
          if (!lod) folLeaf(m, fadd(c, [0, -1, 0]), fnorm(fcross(out, up)), out, rr * 0.8, rr * 0.28, fcol(dark, 0.75), fsw(c[1], H, 0.03 * H));
        }
      }
      break;
    }
    case 5: {   // acacia: leaning forked trunk, wide flat-topped crown
      H = 78 + variant * 16 + rnd() * 12;
      const tp = trunk(H * 0.55, 3.2, 1.8, 0.15, BARK_A, 1);
      const fork = tp[tp.length - 1];
      for (let b = 0; b < 4; b++) {
        const a = b / 4 * Math.PI * 2 + rnd() * 0.8, reach = 20 + rnd() * 18;
        const end = [fork[0] + Math.cos(a) * reach, H * (0.88 + rnd() * 0.08), fork[2] + Math.sin(a) * reach];
        LIMB(m, fork, end, 1.8, 0.8, 3, 4, BARK_A, H, 0.02 * H);
        crown(end, 20 + rnd() * 6, 0.26, 75, [0.30, 0.42, 0.14], H, 0.02 * H, 4.5);
      }
      break;
    }
    case 6: {   // cactus
      H = 38 + variant * 10;
      const green = [0.22, 0.42, 0.24];
      folTube(m, [[0, -1, 0], [0, H * 0.5, 0], [0, H, 0]], [3.4, 3.2, 2.6], lod ? 6 : 10, green, H, 0, 0.7);
      for (const sg of [1, -1]) {
        const y0 = H * (0.35 + rnd() * 0.2), out = 6 + rnd() * 3;
        folTube(m, [[0, y0, 0], [sg * out, y0 + 1, 0], [sg * out, y0 + 12 + rnd() * 8, 0]], [2, 1.9, 1.6], lod ? 5 : 8, green, H, 0, null);
      }
      break;
    }
    case 7: {   // mangrove: crown on a tangle of arching stilt roots
      H = 70 + variant * 14 + rnd() * 10;
      const tp = trunk(H * 0.7, 2.8, 1.8, 0.05, BARK_C, 1);
      if (lod < 2) for (let r = 0; r < (lod ? 5 : 9); r++) {
        const a = r / 9 * Math.PI * 2 + rnd() * 0.5, R = 16 + rnd() * 10;
        LIMB(m, [0, 18 + rnd() * 10, 0], [Math.cos(a) * R, -2, Math.sin(a) * R], 1.2, 0.8, 9, 3, BARK_C, H, 0);
      }
      const top = tp[tp.length - 1];
      for (let k = 0; k < 4; k++) crown(fadd(top, [(rnd() - 0.5) * 26, 10 + rnd() * 8, (rnd() - 0.5) * 26]), 15 + rnd() * 5, 0.6, 55, [0.15, 0.36, 0.20], H, 0.03 * H, 5.5);
      break;
    }
    case 8: {   // tree fern
      H = 34 + variant * 10 + rnd() * 8;
      folTube(m, [[0, -1, 0], [0.5, H * 0.5, 0.3], [1, H, 0.5]], [1.8, 1.5, 1.3], lod ? 4 : 6, [0.26, 0.20, 0.14], H, 0.03 * H, 0.6);
      const nf = lod === 2 ? 4 : 11;
      for (let f = 0; f < nf; f++) {
        const a = f / nf * Math.PI * 2 + rnd() * 0.3;
        folFrond(m, [1, H, 0.5], fnorm([Math.cos(a), 0, Math.sin(a)]), 20 + rnd() * 6, 0.9, 1.4, [0.20, 0.44, 0.14], rnd, H, 0.06 * H, lod);
      }
      break;
    }
  }
  if (farCrowns.length) {
    let cx = 0, cy = 0, cz = 0;
    for (const f of farCrowns) { cx += f.c[0]; cy += f.c[1]; cz += f.c[2]; }
    cx /= farCrowns.length; cy /= farCrowns.length; cz /= farCrowns.length;
    let R = 0, fl = 0;
    for (const f of farCrowns) { R = Math.max(R, Math.hypot(f.c[0] - cx, f.c[2] - cz) + f.R); fl += f.flat; }
    fl /= farCrowns.length;
    const ys = farCrowns.map(f => f.c[1]); const ySpan = Math.max(...ys) - Math.min(...ys);
    folBlob(m, [cx, cy, cz], R * 0.9, Math.max(fl, (ySpan * 0.5 + 20) / Math.max(1, R)), farCrowns[0].col, rnd, H, farCrowns[0].sw, 9);
  }
  return { m, H };
}
// ---- ground cover ---------------------------------------------------------------------
function folGrass(m, rnd, n, hMin, hMax, colBase, colTip, W) {
  for (let b = 0; b < n; b++) {
    const a = rnd() * Math.PI * 2, r = rnd() * 3.2;
    const x0 = Math.cos(a) * r, z0 = Math.sin(a) * r;
    const h = hMin + rnd() * (hMax - hMin);
    const lean = [Math.cos(a) * (0.2 + rnd() * 0.4), 0, Math.sin(a) * (0.2 + rnd() * 0.4)];
    const side = fnorm([-Math.sin(a + 1.2), 0, Math.cos(a + 1.2)]);
    const w = (W || 0.7) * (0.7 + rnd() * 0.6);
    const S = 3;
    const prev = [];
    for (let k = 0; k <= S; k++) {
      const u = k / S;
      const c = [x0 + lean[0] * h * u * u, h * u, z0 + lean[2] * h * u * u];
      const nrm = fnorm(fcross(side, [lean[0], 1, lean[2]]));
      const col = [colBase[0] + (colTip[0] - colBase[0]) * u, colBase[1] + (colTip[1] - colBase[1]) * u, colBase[2] + (colTip[2] - colBase[2]) * u];
      const ww = w * (1 - u * 0.85);
      if (k < S) prev.push([folV(m, fadd(c, fmul(side, ww)), nrm, col, u * u * 2.2, 1), folV(m, fsub(c, fmul(side, ww)), nrm, col, u * u * 2.2, 1)]);
      else prev.push([folV(m, c, nrm, col, 2.2, 1)]);
    }
    for (let k = 0; k < S - 1; k++) { const [a0, b0] = prev[k], [a1, b1] = prev[k + 1]; m.i.push(a0, a1, b0, b0, a1, b1); }
    const [a0, b0] = prev[S - 1], tip = prev[S][0];
    m.i.push(a0, tip, b0);
  }
}
function buildCoverMesh(kind, variant) {
  const rnd = folRng(5000 + kind * 31 + variant * 7);
  const m = folMB();
  switch (kind) {
    case 0: folGrass(m, rnd, 16, 4, 10, [0.14, 0.30, 0.08], [0.46, 0.62, 0.24]); break;          // tall green grass
    case 1: folGrass(m, rnd, 16, 5, 12, [0.36, 0.34, 0.14], [0.86, 0.76, 0.42]); break;          // golden savanna grass
    case 2: {                                                                                      // fern
      const nf = 9;
      for (let f = 0; f < nf; f++) {
        const a = f / nf * Math.PI * 2 + rnd() * 0.4;
        folFrond(m, [0, 1, 0], fnorm([Math.cos(a), 0, Math.sin(a)]), 6 + rnd() * 3, 1.0, 1.3, [0.18, 0.42, 0.13], rnd, 10, 0.4, 1);
      }
      break;
    }
    case 3: folGrass(m, rnd, 12, 10, 20, [0.22, 0.30, 0.12], [0.50, 0.56, 0.30], 0.45); break;    // reeds
    case 4: folCluster(m, [0, 5, 0], 6, 0.7, 45, [0.18, 0.36, 0.14], rnd, 10, 0.3, 3.2); break;  // shrub
    case 5: {                                                                                      // big-leaf understory plant
      for (let k = 0; k < 7; k++) {
        const a = k / 7 * Math.PI * 2 + rnd() * 0.5;
        const out = fnorm([Math.cos(a), 0.5, Math.sin(a)]);
        const c = fadd([0, 2, 0], fmul(out, 4));
        folLeaf(m, c, fnorm(fadd(fcross(out, fcross([0, 1, 0], out)), [0, 0.4, 0])), out, 9, 5, [0.16 + rnd() * 0.05, 0.40 + rnd() * 0.06, 0.12], 0.8);
      }
      break;
    }
  }
  return m;
}

// ---- GPU side ---------------------------------------------------------------------------
const FOL = { ready: false, tree: [], cover: [], instBuf: null, inst: new Float32Array(FOL_MAX_INST * FOL_IF), batches: [], key: '', coverKey: '', count: 0, canopy: null };
const TREE_VARIANTS = 3, COVER_KINDS = 6, COVER_VARIANTS = 2;
function folUpload(m) {
  const vd = new Float32Array(m.v), id = new Uint32Array(m.i);
  const vb = dev.createBuffer({ size: Math.max(16, vd.byteLength), usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST });
  dev.queue.writeBuffer(vb, 0, vd);
  const ib = dev.createBuffer({ size: Math.max(16, id.byteLength), usage: GPUBufferUsage.INDEX | GPUBufferUsage.COPY_DST });
  dev.queue.writeBuffer(ib, 0, id);
  return { vb, ib, count: id.length, tris: id.length / 3 };
}
function folInit() {
  if (FOL.ready) return;
  const t0 = performance.now();
  let tris = 0;
  for (let k = 0; k < 9; k++) {
    FOL.tree[k] = [];
    for (let v = 0; v < TREE_VARIANTS; v++) {
      FOL.tree[k][v] = [];
      for (let l = 0; l < 3; l++) { const { m, H } = buildTreeMesh(k, v, l); const g = folUpload(m); g.H = H; FOL.tree[k][v][l] = g; tris += l === 0 ? g.tris : 0; }
    }
  }
  for (let k = 0; k < COVER_KINDS; k++) { FOL.cover[k] = []; for (let v = 0; v < COVER_VARIANTS; v++) FOL.cover[k][v] = folUpload(buildCoverMesh(k, v)); }
  FOL.instBuf = dev.createBuffer({ size: FOL.inst.byteLength, usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST });
  FOL.ready = true;
  FOL.buildMs = performance.now() - t0; FOL.lod0Tris = tris;
}
// Which ground cover grows where, by biome: [kind, weight]...
const COVER_BY_BIOME = {
  forest: [[2, 0.55], [5, 0.3], [0, 0.35], [4, 0.2]], plains: [[0, 0.8], [4, 0.08]], savanna: [[1, 0.8], [4, 0.05]],
  marsh: [[3, 0.8], [0, 0.3]], taiga: [[2, 0.3], [4, 0.2], [0, 0.2]], beach: [[1, 0.12]], tundra: [[0, 0.1]], shallow: [[3, 0.4]],
};
const COVER_R = 720, COVER_CELL = 15;
const TREE_LOD0 = 750, TREE_LOD1 = 2400;
// Rebuild the instance lists when the camera has moved or turned enough.
function folUpdate(camX, camY, camZ, yaw) {
  if (!FOL.ready || !world || !world.forest) return;
  const key = Math.round(camX / 40) + ',' + Math.round(camZ / 40) + ',' + Math.round(yaw / 0.25) + ',' + Math.round(camY / 80);
  if (key === FOL.key) return;
  FOL.key = key;
  const buckets = new Map();
  const put = (mesh, x, y, z, rot, s, tint) => {
    let b = buckets.get(mesh); if (!b) { b = []; buckets.set(mesh, b); }
    b.push(x, y, z, rot, s, tint[0], tint[1], tint[2]);
  };
  const fx = Math.cos(yaw), fz = Math.sin(yaw);
  const T = terrain;
  for (const tr of world.forest.trees) {
    const dx = tr.x - camX, dz = tr.y - camZ, d = Math.hypot(dx, dz);
    if (d > FAR * 0.95) continue;
    // behind the camera (with margin for the wide field of view and tall crowns)
    if (d > 260 && (dx * fx + dz * fz) / d < -0.45) continue;
    const lod = d < TREE_LOD0 ? 0 : d < TREE_LOD1 ? 1 : 2;
    const g = FOL.tree[tr.kind][tr.v % TREE_VARIANTS][lod];
    const hs = ((tr.x * 131) ^ (tr.y * 71)) & 1023;
    const tint = [0.9 + (hs & 31) / 150, 0.92 + ((hs >> 5) & 31) / 160, 0.9 + ((hs >> 3) & 31) / 170];
    put(g, tr.x, groundAt(tr.x, tr.y) - 1, tr.y, tr.rot, tr.s, tint);
  }
  // ground cover on a hashed grid around the camera
  const c0 = Math.floor((camX - COVER_R) / COVER_CELL), c1 = Math.floor((camX + COVER_R) / COVER_CELL);
  const r0 = Math.floor((camZ - COVER_R) / COVER_CELL), r1 = Math.floor((camZ + COVER_R) / COVER_CELL);
  if (camY - groundAt(camX, camZ) < 900) for (let j = r0; j <= r1; j++) for (let i = c0; i <= c1; i++) {
    let h = ((i * 73856093) ^ (j * 19349663)) >>> 0; h = Math.imul(h ^ (h >>> 15), 2246822519) >>> 0; h = (h ^ (h >>> 13)) >>> 0;
    const x = (i + ((h & 255) / 256)) * COVER_CELL, z = (j + (((h >>> 8) & 255) / 256)) * COVER_CELL;
    const dx = x - camX, dz = z - camZ;
    if (dx * dx + dz * dz > COVER_R * COVER_R || x < 0 || z < 0 || x >= WORLD_W || z >= WORLD_H) continue;
    const d = Math.hypot(dx, dz);
    if (d > 60 && (dx * fx + dz * fz) / d < -0.5) continue;
    const e = T.height(x, z);
    if (e < T.LV.water - 0.004 && T.biomeAt(x, z) !== 'shallow' && T.biomeAt(x, z) !== 'marsh') continue;
    const opts = COVER_BY_BIOME[T.biomeAt(x, z)];
    if (!opts) continue;
    let r = ((h >>> 16) & 1023) / 1024, kind = -1;
    // thin out toward the edge of the radius so it does not end in a hard ring
    const fade = 1 - Math.max(0, (d - COVER_R * 0.6) / (COVER_R * 0.4));
    for (const [k, wgt] of opts) { if (r < wgt * fade) { kind = k; break; } r -= wgt * fade; }
    if (kind < 0) continue;
    const g = FOL.cover[kind][(h >>> 26) & 1];
    const s = 0.7 + ((h >>> 20) & 63) / 70;
    put(g, x, groundAt(x, z) - 0.3, z, ((h >>> 3) & 255) / 40, s, [1, 1, 1]);
  }
  // pack
  let off = 0;
  FOL.batches.length = 0;
  for (const [mesh, arr] of buckets) {
    const n = arr.length / FOL_IF;
    if (off + n > FOL_MAX_INST) break;
    FOL.inst.set(arr, off * FOL_IF);
    FOL.batches.push({ mesh, first: off, count: n });
    off += n;
  }
  FOL.count = off;
  if (off) dev.queue.writeBuffer(FOL.instBuf, 0, FOL.inst, 0, off * FOL_IF);
}
function folDraw(pass) {
  if (!FOL.ready || !FOL.batches.length) return;
  pass.setPipeline(folPipe); pass.setBindGroup(0, folBind);
  pass.setVertexBuffer(1, FOL.instBuf);
  for (const b of FOL.batches) {
    pass.setVertexBuffer(0, b.mesh.vb); pass.setIndexBuffer(b.mesh.ib, 'uint32');
    pass.drawIndexed(b.mesh.count, b.count, 0, 0, b.first);
  }
}
// Canopy shade on the forest floor: fraction of sky covered, on a coarse grid.
function forestCanopyAt(x, z) {
  const F = FOL.canopy;
  if (!F) return 0;
  const i = clamp(Math.floor(x / F.cell), 0, F.nx - 1), j = clamp(Math.floor(z / F.cell), 0, F.nz - 1);
  return F.a[j * F.nx + i];
}
function buildCanopyMap() {
  if (!world || !world.forest) return;
  const cell = 32, nx = Math.ceil(WORLD_W / cell), nz = Math.ceil(WORLD_H / cell);
  const a = new Float32Array(nx * nz);
  const CR = [85, 55, 22, 18, 28, 36, 0, 30, 12];
  for (const t of world.forest.trees) {
    const R = CR[t.kind] * t.s; if (!R) continue;
    const i0 = Math.max(0, Math.floor((t.x - R) / cell)), i1 = Math.min(nx - 1, Math.floor((t.x + R) / cell));
    const j0 = Math.max(0, Math.floor((t.y - R) / cell)), j1 = Math.min(nz - 1, Math.floor((t.y + R) / cell));
    for (let j = j0; j <= j1; j++) for (let i = i0; i <= i1; i++) {
      const dx = (i + 0.5) * cell - t.x, dz = (j + 0.5) * cell - t.y, d = Math.hypot(dx, dz) / R;
      if (d < 1) a[j * nx + i] = Math.min(1, a[j * nx + i] + 0.55 * (1 - d * d));
    }
  }
  FOL.canopy = { a, nx, nz, cell };
}
