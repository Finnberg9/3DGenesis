# =====================================================================
# THREE TABS
#
# The builder had twelve: kit, shop, body, proportions, paint, and seven
# categories that now only ever list what you already own -- which is what
# the kit tab is. Seven tabs to say what one tab already said.
#
#   YOUR KIT     everything you own, in one list, draggable onto the body
#   THE SHOP     everything you do not, by rarity, with prices
#   BODY         the shape, and directly under it the sizing and the paint
#
# The category tabs are gone rather than hidden: the palette they served is
# the kit list now, and the thing they were actually for -- browsing by kind
# when everything in the game was on show -- stopped existing when the shop
# was split out.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, ('ANCHOR %d/%d' % (n, cnt), a[:110]); return s.replace(a, b)

p = 'g3.html'; s = open(p, encoding='utf-8').read()

s = sub1(s, """const VIS_CATS = [
  { id: 'kit', label: 'your kit', hint: 'every part you own. drag one onto the body' },
  { id: 'body', label: 'body shape', hint: 'the skeleton everything else hangs on' },
  { id: 'shape', label: 'proportions', hint: 'stretch the body, neck and tail' },
  { id: 'paint', label: 'colour & skin', hint: 'hide colour, pattern and covering' },
  { id: 'limbs', label: 'limbs, feet & hands', hint: 'legs carry you, arms grab and strike' },
  { id: 'eyes', label: 'eyes', hint: 'how far you see danger and food' },
  { id: 'mouth', label: 'mouths & jaws', hint: 'what you can eat and how hard you bite' },
  { id: 'horns', label: 'horns', hint: 'attack, and the gore move' },
  { id: 'armor', label: 'spikes & armour', hint: 'defence, and damage to whatever bites you' },
  { id: 'fins', label: 'fins', hint: 'swimming, and steering in water' },
  { id: 'wings', label: 'wings', hint: 'flight, once the wings beat your weight' },
  { id: 'details', label: 'details', hint: 'crests, frills and display pieces' },
  { id: 'shop', label: 'the shop', hint: 'what you do not have yet, and what it costs' },
];""",
"""// Three. What you have, what you do not, and what you are.
const VIS_CATS = [
  { id: 'kit', label: 'your kit', hint: 'every part you own. drag one onto the body' },
  { id: 'shop', label: 'the shop', hint: 'what you do not have yet, and what it costs' },
  { id: 'body', label: 'body', hint: 'the shape you are, then its proportions and its colours' },
];""")

# the body tab absorbs the sizing sliders and the paint controls
s = sub1(s, """    if (planLocked) html += '<div class="edhint">your body shape is fixed for this world. reset the world to start as a different shape</div>';
    else html += '<div class="edhint">pick a shape. it sets your size, stance, neck and tail, and where parts can go</div>';
  } else if (ED.tab === 'shape') {""",
"""    if (planLocked) html += '<div class="edhint">your body shape is fixed for this world. reset the world to start as a different shape</div>';
    else html += '<div class="edhint">pick a shape. it sets your size, stance, neck and tail, and where parts can go</div>';
    html += edShapeHtml() + edPaintHtml();
  } else if (ED.tab === 'shape') {""")

# The sizing and the paint move out of their own tabs and into functions the
# body tab calls. Lifting them rather than duplicating them is what keeps one
# set of controls: two copies of a slider is two places for it to drift.
s = sub1(s, """  } else if (ED.tab === 'shape') {
    const bd = ED.des.body;
    const sl = (k, label) => `<label class="edsl"><span>${label}</span><input type="range" data-body="${k}" min="${C.BODY_RANGE[k][0]}" max="${C.BODY_RANGE[k][1]}" step="0.01" value="${bd[k]}"></label>`;
    html += '<div class="edsec">' + sl('len', 'body length') + sl('girth', 'body thickness') + sl('neck', 'neck length') + sl('tail', 'tail length') + '</div>';
    html += '<div class="edsec"><label class="edchk"><input type="checkbox" id="edKeepPaint"' + (ED.keepPaint ? ' checked' : '') + '> keep my colours when changing body</label></div>';
  } else if (ED.tab === 'paint') {
    const c = ED.des.col;
    const row = (k, label) => `<div class="edpaint"><div class="edpl">${label}</div><div class="edsw">` +
      SWATCHES.map(s => `<button class="sw" data-paint="${k}" data-c="${hex(s)}" style="background:${hex(s)}"></button>`).join('') +
      `<input type="color" data-paintc="${k}" value="${hex(c[k])}"></div></div>`;
    html += row('base', 'body colour') + row('coat', 'underside colour') + row('detail', 'pattern colour');
    html += '<div class="edpl">pattern</div><div class="edgrid pats">' + PATTERNS.map((n, i) => `<div class="edtile pat${(c.pat | 0) === i ? ' cur' : ''}" data-pat="${i}"><canvas width="96" height="96" data-patc="${i}"></canvas></div>`).join('') + '</div>';
    html += '<div class="edpl">skin</div><div class="edgrid skins">' + SKIN_ITEMS.map((id, i) => {
      const av = edSkinAllowed(i);
      return `<div class="edtile item${skinOf(ED.des) === i ? ' cur' : ''}${av ? '' : ' locked'}" data-skin="${i}" title="${SKIN_NAMES[i]}">${tileHTML(id, av)}</div>`;
    }).join('') + '</div>';
    html += '<div class="edhint">to colour a single part, click it on the creature. new skins are earned by killing animals that wear them</div>';
  } else if (ED.tab === 'kit' || ED.tab === 'shop') {""",
"""  } else if (ED.tab === 'kit' || ED.tab === 'shop') {""")
s = sub1(s, "function edRefreshUI() {",
"""// The sizing block, under the shapes on the body tab.
function edShapeHtml() {
  const bd = ED.des.body;
  const sl = (k, label) => `<label class="edsl"><span>${label}</span><input type="range" data-body="${k}" min="${C.BODY_RANGE[k][0]}" max="${C.BODY_RANGE[k][1]}" step="0.01" value="${bd[k]}"></label>`;
  return '<div class="edpl">size &amp; proportions</div>' +
    '<div class="edsec">' + sl('len', 'body length') + sl('girth', 'body thickness') + sl('neck', 'neck length') + sl('tail', 'tail length') + '</div>' +
    '<div class="edsec"><label class="edchk"><input type="checkbox" id="edKeepPaint"' + (ED.keepPaint ? ' checked' : '') + '> keep my colours when changing body</label></div>';
}
// The colours, under the sizing.
function edPaintHtml() {
  const c = ED.des.col;
  const row = (k, label) => `<div class="edpaint"><div class="edpl">${label}</div><div class="edsw">` +
    SWATCHES.map(s2 => `<button class="sw" data-paint="${k}" data-c="${hex(s2)}" style="background:${hex(s2)}"></button>`).join('') +
    `<input type="color" data-paintc="${k}" value="${hex(c[k])}"></div></div>`;
  let h = row('base', 'body colour') + row('coat', 'underside colour') + row('detail', 'pattern colour');
  h += '<div class="edpl">pattern</div><div class="edgrid pats">' + PATTERNS.map((n, i) => `<div class="edtile pat${(c.pat | 0) === i ? ' cur' : ''}" data-pat="${i}"><canvas width="96" height="96" data-patc="${i}"></canvas></div>`).join('') + '</div>';
  h += '<div class="edpl">skin</div><div class="edgrid skins">' + SKIN_ITEMS.map((id, i) => {
    const av = edSkinAllowed(i);
    return `<div class="edtile item${skinOf(ED.des) === i ? ' cur' : ''}${av ? '' : ' locked'}" data-skin="${i}" title="${SKIN_NAMES[i]}">${tileHTML(id, av)}</div>`;
  }).join('') + '</div>';
  h += '<div class="edhint">to colour a single part, click it on the creature. new skins are earned by killing animals that wear them</div>';
  return h;
}
function edRefreshUI() {""")
# the pattern icons are drawn on the body tab now, not a paint tab
s = sub1(s, "  if (ED.tab === 'paint') edDrawPatternIcons();",
            "  if (ED.tab === 'body') edDrawPatternIcons();")
# and anything that used to send you to a category tab sends you to your kit
s = s.replace("ED.tab = 'mouth';", "ED.tab = 'kit';")

open(p, 'w', encoding='utf-8').write(s)
print('tabs: three ok')
