s=open('g3.html',encoding='utf-8').read()
core=open('src/core_defaults.js',encoding='utf-8').read()
a="""
  const API = {
    ...DESIGN_API,"""
assert s.count(a)==1
s=s.replace(a,core+a)
for a,b in [("design: g.design ? JSON.parse(JSON.stringify(g.design)) : undefined,","design: g.design ? cloneDesign(g.design) : undefined,"),
            ("design: JSON.parse(JSON.stringify(src.design)),","design: cloneDesign(src.design),"),
            ("function cloneDesign(d) { return d ? JSON.parse(JSON.stringify(d)) : null; }",
             "// runtime caches on a design (render geometry etc.) are underscore-prefixed and never copied\n  const noCache = (k, v) => (k && k[0] === '_') ? undefined : v;\n  function cloneDesign(d) { return d ? JSON.parse(JSON.stringify(d, noCache)) : null; }")]:
    assert s.count(a)==1,a; s=s.replace(a,b)
open('g3.html','w',encoding='utf-8').write(s)
print('core2 ok')
