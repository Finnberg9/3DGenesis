# PARTS COME IN PAIRS
# A body is bilateral. Taking one spike off a corpse gave you one spike, which
# meant a symmetrical animal needed two separate kills for one symmetrical
# change, and mirror mode in the editor (the obvious way to place anything)
# was refused on the very part you had just earned. Every pickup now yields a
# PAIR, so what you loot is immediately wearable on both sides.
#
# Only PICKUPS pair. Buying still adds one copy per purchase, because the shop
# charges per copy and doubling the goods at the same price would halve every
# price in the game. Selling is unchanged: one copy at a time.
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, (a[:90], n); return s.replace(a, b)

p = 'g3.html'; s = open(p, encoding='utf-8').read()

# ---------------------------------------------------------------- the grant
s = sub1(s, """  const id = pk.opts[i - 1];
  if (!id) return;
  const n = ownedGain(id, 1);
  toast('Took ' + VIS[id].name + '. You now have ' + n + '. Press B to put ' + (n > 1 ? 'one' : 'it') + ' on.', 3600);""",
"""  const id = pk.opts[i - 1];
  if (!id) return;
  // One pickup, one pair. choosePicked is the single funnel every pickup runs
  // through (a kill, a player kill, searching a carcass), so pairing here
  // cannot be inconsistent between the three of them.
  const n = ownedGain(id, PICKUP_PAIR);
  toast('Took a pair of ' + VIS[id].name + '. You now have ' + n + '. Press B to put ' +
        (n > 2 ? 'them' : 'the pair') + ' on, or M in the editor to mirror.', 3600);""")

# the constant, next to the other progression numbers so it is findable
s = sub1(s, "function ownedGain(id, n) {",
"""// A looted part arrives as a pair: a body has two sides and a single spike
// cannot be placed symmetrically. Purchases deliberately do not use this.
const PICKUP_PAIR = 2;
function ownedGain(id, n) {""")

# ---------------------------------------------------------------- the offers say so
for old, new in [
    ("label: 'You search the body. Take one of its parts'",
     "label: 'You search the body. Take a pair of one of its parts'"),
    ("label: 'You killed ' + from + '. Take one of their parts'",
     "label: 'You killed ' + from + '. Take a pair of one of their parts'"),
    ("+ BONES_PER_KILL + ' bones. Take one of its parts'",
     "+ BONES_PER_KILL + ' bones. Take a pair of one of its parts'"),
]:
    if old in s: s = s.replace(old, new, 1)

open(p, 'w', encoding='utf-8').write(s)
print('pickup pairs ok')
