# =====================================================================
# 1. FLYING WAS FOLLOWING THE GROUND.
#    Altitude is stored as height ABOVE THE GROUND (player.fly), which is the
#    right thing to store -- the renderer, the ceiling and the landing all want
#    it -- but nothing took the ground out of it while you were airborne. So
#    crossing a hill added the hill to your altitude and crossing a valley took
#    it away: you jolted up and down with the terrain instead of flying
#    through the air over it. The ground's own movement is now subtracted the
#    moment it happens, so a level glide is level in the world, and the hill
#    passes under you.
#
# 2. ONE PRESS, ONE FLAP.
#    Holding space beat the wings over and over on a timer, which is a
#    helicopter. A flap is now an event: you press, the wings beat once, you
#    gain height, and you glide until you want another. Bigger wings carry far
#    more per beat and beat more slowly, so a pterosaur takes one stroke and
#    sails, and something small has to work at it.
#
# 3. The carcass prompt shows even when something living is also in front of
#    you, because a body at your feet does not stop being lootable.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, (a[:100], n); return s.replace(a, b)
p = 'g3.html'; s = open(p, encoding='utf-8').read()

# ---------------------------------------------------------------- 1. the jolt
s = sub1(s, """  // walking off a drop puts you in the air without a flap
  const gy = groundAt(c.x, c.y);
  if (FL.lastG != null && player.fly <= 0.6 && gy < FL.lastG - 0.5) player.fly += (FL.lastG - gy);
  FL.lastG = gy;
  const airborne = player.fly > 0.6;""",
"""  // walking off a drop puts you in the air without a flap
  const gy = groundAt(c.x, c.y);
  if (FL.lastG != null && player.fly <= 0.6 && gy < FL.lastG - 0.5) player.fly += (FL.lastG - gy);
  // YOU FLY THROUGH THE AIR, NOT OVER THE GROUND.
  // player.fly is height above the ground, so a hill passing under you added
  // itself to your altitude and a valley took it away -- the flight path rode
  // the terrain and you jolted up and down over every ridge. Whatever the
  // ground did under you this frame comes straight back out of the stored
  // altitude, which leaves your real height in the world exactly where your
  // own climb and sink put it. Fly level and you stay level; the hill rises
  // to meet you, and if it reaches you, you have flown into it.
  if (FL.lastG != null && player.fly > 0.6) player.fly = Math.max(0, player.fly - (gy - FL.lastG));
  FL.lastG = gy;
  const airborne = player.fly > 0.6;""")

# ---------------------------------------------------------------- 2. one press, one flap
s = sub1(s, """  const period = 0.9 - 0.3 * clamp(wing, 0, 1.4);
  if (keys[' '] && FL.beat <= 0 && !FIGHT.exhausted && FIGHT.stam > 3) {
    FL.beat = period;
    fightSpend(4 + 3 * mass);
    FL.thrust = 1;
    FL.vy += (120 + 110 * wing) / Math.sqrt(mass) * (airborne ? 1 : 1.5);
    FL.spd += 42 * wing / Math.sqrt(mass);
    if (SND.ctx && SND.on) sndWingbeat(0, p.mass || 5, 0.22);
  }""",
"""  // A flap is an event, not a state. FL.want is set by the key going DOWN
  // (see the keydown handler), so holding space does nothing after the first
  // beat: you press again when you want another. The refractory period is the
  // wing's own beat -- a big wing is slow and cannot be spammed, which is what
  // stops one being better than the other.
  const period = 0.62 - 0.26 * clamp(wing, 0, 1.4);
  if (FL.want && FL.beat <= 0 && !FIGHT.exhausted && FIGHT.stam > 3) {
    FL.beat = period;
    fightSpend(4 + 3 * mass);
    FL.thrust = 1;
    // Lift per beat goes with the wing, hard. A big wing moves a lot of air
    // in one stroke and a small one does not, which is the whole difference
    // between soaring and fluttering.
    FL.vy += (46 + 235 * wing) / Math.sqrt(mass) * (airborne ? 1 : 1.55);
    FL.spd += 52 * wing / Math.sqrt(mass);
    if (SND.ctx && SND.on) sndWingbeat(0, p.mass || 5, 0.26);
  }
  FL.want = false;""")
# the key edge
s = sub1(s, "    if (k === ' ' && !player.spectator) tryJump();",
"""    if (k === ' ' && !player.spectator) {
      // one press, one wingbeat: the browser's key repeat is not a wing
      if (!e.repeat && player.c && player.c.alive && player.c.ph.canFly) FL.want = true;
      tryJump();
    }""")
s = sub1(s, "const FL = { spd: 0, vy: 0, roll: 0, rollT: 0, beat: 0, phase: 0, thrust: 0, stall: 0, lastG: null, msg: 0, glide: 0 };",
            "const FL = { spd: 0, vy: 0, roll: 0, rollT: 0, beat: 0, phase: 0, thrust: 0, stall: 0, lastG: null, msg: 0, glide: 0, want: false };")

# ---------------------------------------------------------------- the HUD says what it does now
s = sub1(s, "`<br><span class=\"k\">space</span> flap · <span class=\"k\">look</span> to dive and climb · <span class=\"k\">A D</span> bank · <span class=\"k\">W</span> tuck · <span class=\"k\">S</span> flare`;",
            "`<br><span class=\"k\">space</span> one flap · <span class=\"k\">look</span> to dive and climb · <span class=\"k\">A D</span> bank · <span class=\"k\">W</span> tuck · <span class=\"k\">S</span> flare`;")
open(p, 'w', encoding='utf-8').write(s)
print('flight ok')

# ---------------------------------------------------------------- 3. the carcass line
s = open(p, encoding='utf-8').read()
s = sub1(s, """      act.innerHTML = mayHit""", """      const body0 = inspectTarget();
      const carcLine = body0 ? '<div class="keys"><span class="ok">V</span> search the body at your feet &middot; ' + ((body0.parts || []).length) + ' parts</div>' : '';
      act.innerHTML = (mayHit""")
s = sub1(s, """          '<div class="keys"><span class="pkno">' + (friend ? 'you cannot hurt your own' : 'you cannot hurt this yet') + '</span> ' + rest;""",
            """          '<div class="keys"><span class="pkno">' + (friend ? 'you cannot hurt your own' : 'you cannot hurt this yet') + '</span> ' + rest) + carcLine;""")
open(p, 'w', encoding='utf-8').write(s)
print('carcass line ok')

# ---------------------------------------------------------------- test surface
s = open(p, encoding='utf-8').read()
s = sub1(s, "  camDefaultDist: (ph) => camDefaultDist(ph),",
"""  camDefaultDist: (ph) => camDefaultDist(ph),
  flight: {
    get alt() { return player.fly; },
    get worldY() { return groundAt(player.c.x, player.c.y) + player.fly; },
    get spd() { return FL.spd; }, get vy() { return FL.vy; }, get stall() { return FL.stall; },
    flap: () => { FL.want = true; },
    get beat() { return FL.beat; },
    wing: (ph) => flightWing(ph || (player.c && player.c.ph)),
    set: (alt, spd) => { player.fly = alt; FL.spd = spd == null ? FL.spd : spd; FL.vy = 0; FL.beat = 0; FL.want = false; FL.stall = 0; FL.lastG = groundAt(player.c.x, player.c.y); },
    tick: (dt) => flightTick(dt),
  },""")
open(p, 'w', encoding='utf-8').write(s)
print('flight test surface ok')
