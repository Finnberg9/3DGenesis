# AIMING
# Picking a target used to take anything in the forward HALF of the world: you
# could gut something standing 89 degrees off your nose. A strike now needs the
# body actually pointed at it, within 10 degrees, with a small allowance for
# how wide the target is so a sauropod's flank is not a needle to thread.
# Mating and the other soft interactions keep the old generous cone: only the
# damage is aimed.
def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
p='g3.html'; s=open(p,encoding='utf-8').read()
s=sub1(s,"const GRAV = 520;","""// Damage needs the nose on the target: 10 degrees, widened by however much of
// the sky the target itself covers at this range.
const AIM_DEG = 10;
const AIM_COS = Math.cos(AIM_DEG * Math.PI / 180);
const GRAV = 520;""")
s=sub1(s,"""function pickTarget() {
  const c = player.c;
  if (!c || !c.alive) return null;
  const p = c.ph;
  const fx = Math.cos(player.yaw), fz = Math.sin(player.yaw);
  const rr = interactRange(p);
  let best = null, bestD = Infinity;
  const list = world.creatures;
  for (let i = 0; i < list.length; i++) {
    const o = list[i];
    if (o === c || !o.alive || !o.ph) continue;
    const dx = o.x - c.x, dz = o.y - c.y;
    const d = Math.hypot(dx, dz);
    if (d > rr + o.ph.radius) continue;
    if (d > 1e-6 && (dx * fx + dz * fz) / d < 0.0) continue;   // anything in the forward half
    if (d < bestD) { bestD = d; best = o; }
  }
  return best;
}""","""// aimed: true when this is for a strike. A strike needs the nose on it; the
// soft interactions (mate, eat, inspect) keep the wide forward cone.
function pickTarget(aimed) {
  const c = player.c;
  if (!c || !c.alive) return null;
  const p = c.ph;
  const fx = Math.cos(player.yaw), fz = Math.sin(player.yaw);
  const rr = interactRange(p);
  let best = null, bestD = Infinity;
  const list = world.creatures;
  for (let i = 0; i < list.length; i++) {
    const o = list[i];
    if (o === c || !o.alive || !o.ph) continue;
    const dx = o.x - c.x, dz = o.y - c.y;
    const d = Math.hypot(dx, dz);
    if (d > rr + o.ph.radius) continue;
    if (d > 1e-6) {
      const cosA = (dx * fx + dz * fz) / d;
      if (aimed) {
        // the target's own angular half-width at this range: a big animal up
        // close is a wide thing to hit, a small one far off is not
        const half = Math.atan2(Math.max(1, (o.ph.radius || 4) * BODY_SCALE), Math.max(1, d));
        if (cosA < Math.cos(Math.min(Math.PI * 0.45, AIM_DEG * Math.PI / 180 + half))) continue;
      } else if (cosA < 0.0) continue;
    }
    if (d < bestD) { bestD = d; best = o; }
  }
  return best;
}
// What the strike keys aim at.
function pickAimed() { return pickTarget(true); }""")
open(p,'w',encoding='utf-8').write(s)
print('aim cone ok')
s=open(p,encoding='utf-8').read()
# the attack path aims; everything else keeps the wide cone
n = 0
for a, b in [("function tryAttack() {\n  const best = pickTarget();", "function tryAttack() {\n  const best = pickAimed();")]:
    if a in s: s = s.replace(a, b); n += 1
open(p,'w',encoding='utf-8').write(s)
s=sub1(s,"  rebuild: () => rebuildWorld(),","  rebuild: () => rebuildWorld(),\n  swingTarget: () => fightFindSwingTarget(player.c, interactRange(player.c.ph) * 1.0),")
open(p,'w',encoding='utf-8').write(s)
print('tryAttack aimed:', n)
