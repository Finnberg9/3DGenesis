// =====================================================================
// CREATURE EDITOR: state, progress, thumbnails, interaction, UI
// =====================================================================
const ED = {
  open: false, mode: 'start', des: null, grants: new Set(), undo: [], redo: [],
  sel: null, hover: null, drag: null, ghost: null, mirror: true, tab: 'body',
  cam: { yaw: 0.95, pitch: 0.2, zoom: 1 }, thumbs: {}, thumbsReady: false,
  origPh: null, statBrain: null, t0: 0, lastT: 0, ui: null, shift: 0,
};
// ---- persistent progress: kills, unlocked parts, saved creatures -------------
const PROG_KEY = 'genesis3d.progress.v2';
const PROG_KEY_OLD = 'genesis3d.progress.v1';
// parts that used to be free at the start; they are not carried over as earned
const OLD_STARTERS = new Set(['m_beak', 'm_grazer', 'm_jaws', 'e_round', 'e_slit', 'h_straight', 's_spike', 's_knob', 'l_leg', 'l_thin', 't_paw', 'f_fin', 'd_crest']);
const PROG = { kills: 0, unlocked: new Set(STARTER_ITEMS), saved: [], last: null };
const SANDBOX = /[?&]sandbox=1/.test(location.search);
function loadProgress() {
  try {
    let raw = localStorage.getItem(PROG_KEY), migrating = false;
    if (!raw) { raw = localStorage.getItem(PROG_KEY_OLD); migrating = !!raw; }
    if (!raw) return;
    const o = JSON.parse(raw);
    if (migrating && Array.isArray(o.unlocked)) o.unlocked = o.unlocked.filter(id => !OLD_STARTERS.has(id));
    if (o && typeof o === 'object') {
      PROG.kills = Math.max(0, (o.kills | 0));
      if (Array.isArray(o.unlocked)) for (const id of o.unlocked) if (VIS[id]) PROG.unlocked.add(id);
      if (Array.isArray(o.saved)) PROG.saved = o.saved.filter(s => s && s.design && s.design.parts).slice(0, 24);
      if (o.last && o.last.parts) PROG.last = o.last;
    }
  } catch (e) { /* private mode or corrupt data: start fresh */ }
}
function saveProgress() {
  try {
    localStorage.setItem(PROG_KEY, JSON.stringify({
      kills: PROG.kills, unlocked: [...PROG.unlocked], saved: PROG.saved, last: PROG.last,
    }));
  } catch (e) { /* storage full or blocked: progress simply is not remembered */ }
}
loadProgress();
// Parts you have not unlocked are still yours up to the number your body
// already carries (so a default body can be rearranged), but no more copies.
function countItem(des, id) {
  let n = 0;
  for (const p of des.parts || []) if (p.id === id) n++;
  for (const l of des.limbs || []) { if (l.id === id) n++; if (l.tip && l.tip.id === id) n++; }
  return n;
}
function spareOf(id) {
  if (SANDBOX || PROG.unlocked.has(id)) return Infinity;
  if (!ED.des) return 0;
  return Math.max(0, ((ED.grantCount && ED.grantCount[id]) || 0) - countItem(ED.des, id));
}
const itemAvailable = (id) => spareOf(id) > 0;
const isUnlocked = (id) => SANDBOX || PROG.unlocked.has(id);
function edCanUse(id, n) {
  const sp = spareOf(id);
  if (sp >= n) return true;
  const own = (ED.grantCount && ED.grantCount[id]) || 0;
  edFlash(own ? (sp > 0 && n > 1 ? 'You only have one more of these. Turn mirror off, or kill animals that have one to unlock it.' : 'Your body only has ' + own + ' of these. Kill an animal that has one to unlock more.')
              : 'Locked. Kill an animal that has one and choose it to unlock it.');
  return false;
}
function grantCountOf(d) {
  const m = {};
  for (const p of d.parts || []) m[p.id] = (m[p.id] || 0) + 1;
  for (const l of d.limbs || []) { m[l.id] = (m[l.id] || 0) + 1; if (l.tip) m[l.tip.id] = (m[l.tip.id] || 0) + 1; }
  m[SKIN_ITEMS[skinOf(d)]] = 1;
  return m;
}
const planBaseCost = (() => { const cache = {}; return (p) => (cache[p] != null ? cache[p] : (cache[p] = C.designCost(C.defaultDesign(p)))); })();
const KILL_SPACE = 3, FREE_SPACE = 8;
// A body you already have is never over budget just for being opened: the
// floor is whatever it cost when the editor opened (evolved or inherited
// bodies can exceed the plan formula).
function edCapacity(des) {
  const base = planBaseCost(des.plan | 0) + FREE_SPACE + PROG.kills * KILL_SPACE + (SANDBOX ? 200 : 0);
  return (ED.open && ED.capFloor) ? Math.max(base, ED.capFloor) : base;
}
function stripDesign(d) { return C.cloneDesign(d); }

// ---- design edits ---------------------------------------------------------------
function edTouch() { ED.des._rev = (ED.des._rev || 0) + 1; ED.statsDirty = true; }
function edPushUndo() {
  ED.undo.push(JSON.stringify(stripDesign(ED.des)));
  if (ED.undo.length > 80) ED.undo.shift();
  ED.redo.length = 0;
}
function edRestore(json) {
  const d = JSON.parse(json);
  ED.des = d; ED.sel = null; edTouch(); edRefreshUI();
}
function edUndo() { if (!ED.undo.length) return; ED.redo.push(JSON.stringify(stripDesign(ED.des))); edRestore(ED.undo.pop()); }
function edRedo() { if (!ED.redo.length) return; ED.undo.push(JSON.stringify(stripDesign(ED.des))); edRestore(ED.redo.pop()); }
let edMirrorKey = 1000;
const nextKey = () => (++edMirrorKey) + Math.floor(Math.random() * 1e6) * 1000;
function twinOf(list, obj) { return obj && obj.m ? list.find(q => q !== obj && q.m === obj.m) : null; }
function itemCost(id) { return (C.ITEM_SIM[id] || { cost: 1 }).cost; }
function edSpaceLeft() { return edCapacity(ED.des) - C.designCost(ED.des); }
function edDenied(msg) { edFlash(msg); }
function mirrorPoint(p) { return [p[0], p[1], -p[2]]; }
function edAddPart(id, hit) {
  const des = ED.des, sk = designGeo(des).sk;
  const sim = C.ITEM_SIM[id];
  if (!sim) return false;
  const single = sim.t === 'MOUTH';
  const pair = ED.mirror && !single && Math.abs(hit.p[2]) > 0.08;
  let need = itemCost(id) * (pair ? 2 : 1);
  if (single) for (const q of des.parts) if (C.ITEM_SIM[q.id] && C.ITEM_SIM[q.id].t === 'MOUTH') need -= itemCost(q.id);
  const sameMouth = single && des.parts.some(q => q.id === id);
  if (!sameMouth && !edCanUse(id, pair ? 2 : 1)) return false;
  if (need > edSpaceLeft()) { edDenied(pair ? 'Not enough genome space for a mirrored pair. Turn off mirror or kill more to grow.' : 'Not enough genome space. Kill more animals to grow it.'); return false; }
  edPushUndo();
  if (single) des.parts = des.parts.filter(q => !(C.ITEM_SIM[q.id] && C.ITEM_SIM[q.id].t === 'MOUTH'));
  const pt = { id, b: 0, o: [0, 0, 0], n: [0, 1, 0], spin: 0, s: 1, c: null, m: 0 };
  C.setAnchor(sk, pt, hit.p, hit.n, hit.b);
  des.parts.push(pt);
  if (pair) {
    const k = nextKey(); pt.m = k;
    const tw = JSON.parse(JSON.stringify(pt));
    const mp = mirrorPoint(hit.p), mn = mirrorPoint(hit.n);
    C.setAnchor(sk, tw, mp, mn, mirrorBall(sk, hit.b, mp));
    des.parts.push(tw);
  }
  ED.sel = { kind: 'part', ref: pt };
  edTouch(); edRefreshUI();
  return true;
}
// the mirror of a ball is itself for centre-line balls, else its lateral twin
function mirrorBall(sk, b, p) {
  const k = sk.balls[b];
  if (!k || Math.abs(k.z) < 1e-6) return b;
  return C.nearestBall(sk, p[0], p[1], p[2], k.g === 'tail');
}
function defaultLimbPose(sk, stand, hit, id) {
  const n = hit.n, root = hit.p;
  const under = n[1] < -0.25 && root[1] < 0.2;
  if (under) {
    // a leg: straight down to the ground with a slight forward knee
    const fy = -stand - root[1];
    const fz = n[2] * 0.25;
    // a springing leg folds into a Z: the knee sits well behind the hip, like a hare's
    if (id === 'l_spring') return { k: [-0.42, fy * 0.42, fz * 0.6 + n[2] * 0.1], f: [0.1, fy, fz] };
    return { k: [0.14, fy * 0.5, fz * 0.6 + n[2] * 0.08], f: [0.04, fy, fz] };
  }
  // an arm: out along the normal, bending down and forward
  const out = v3.norm([n[0] * 0.6 + 0.35, n[1] * 0.3 - 0.25, n[2] * 0.9]);
  const k = v3.add(v3.mul(out, 0.72), [0, 0.05, 0]);
  const f = v3.add(k, v3.mul(v3.norm([out[0] + 0.3, -0.7, out[2] * 0.5]), 0.7));
  return { k, f };
}
function edAddLimb(id, hit) {
  const des = ED.des, G = designGeo(des), sk = G.sk;
  const pair = ED.mirror && Math.abs(hit.p[2]) > 0.08;
  const need = itemCost(id) * (pair ? 2 : 1);
  if (!edCanUse(id, pair ? 2 : 1)) return false;
  if (need > edSpaceLeft()) { edDenied('Not enough genome space for ' + (pair ? 'a pair of limbs' : 'a limb') + '.'); return false; }
  edPushUndo();
  const pose = defaultLimbPose(sk, G.cls.stand, hit, id);
  const lb = { id, b: 0, o: [0, 0, 0], n: hit.n.slice(), k: pose.k, f: pose.f, th: 1, c: null, tip: null, m: 0 };
  C.setAnchor(sk, lb, hit.p, hit.n, hit.b);
  des.limbs.push(lb);
  if (pair) {
    const k = nextKey(); lb.m = k;
    const tw = JSON.parse(JSON.stringify(lb));
    const mp = mirrorPoint(hit.p);
    C.setAnchor(sk, tw, mp, mirrorPoint(hit.n), mirrorBall(sk, hit.b, mp));
    tw.k = mirrorPoint(lb.k); tw.f = mirrorPoint(lb.f);
    des.limbs.push(tw);
  }
  ED.sel = { kind: 'limb', ref: lb };
  edTouch(); edRefreshUI();
  return true;
}
function edSetTip(lb, id) {
  const des = ED.des;
  const tw = ED.mirror ? twinOf(des.limbs, lb) : null;
  let need = itemCost(id) * (tw ? 2 : 1);
  if (lb.tip) need -= itemCost(lb.tip.id);
  if (tw && tw.tip) need -= itemCost(tw.tip.id);
  const uses = (lb.tip && lb.tip.id === id ? 0 : 1) + (tw && !(tw.tip && tw.tip.id === id) ? 1 : 0);
  if (uses && !edCanUse(id, uses)) return false;
  if (need > edSpaceLeft()) { edDenied('Not enough genome space for that.'); return false; }
  edPushUndo();
  lb.tip = { id, c: null, s: 1 };
  if (tw) tw.tip = { id, c: null, s: 1 };
  ED.sel = { kind: 'limb', ref: lb };
  edTouch(); edRefreshUI();
  return true;
}
function edDeleteSel() {
  const s = ED.sel;
  if (!s) return;
  edPushUndo();
  const des = ED.des;
  if (s.kind === 'part') {
    const tw = ED.mirror ? twinOf(des.parts, s.ref) : null;
    des.parts = des.parts.filter(q => q !== s.ref && q !== tw);
    if (!ED.mirror && s.ref.m) { const o = twinOf(des.parts, s.ref); if (o) o.m = 0; }
  } else if (s.kind === 'limb') {
    const tw = ED.mirror ? twinOf(des.limbs, s.ref) : null;
    des.limbs = des.limbs.filter(q => q !== s.ref && q !== tw);
    if (!ED.mirror && s.ref.m) { const o = twinOf(des.limbs, s.ref); if (o) o.m = 0; }
  }
  ED.sel = null; edTouch(); edRefreshUI();
}
// Move a part (and its mirror twin) to a new surface hit.
function edMovePart(pt, hit) {
  const des = ED.des, sk = designGeo(des).sk;
  C.setAnchor(sk, pt, hit.p, hit.n, hit.b);
  let tw = twinOf(des.parts, pt);
  const center = Math.abs(hit.p[2]) <= 0.08;
  if (ED.mirror && !center && !(C.ITEM_SIM[pt.id] && C.ITEM_SIM[pt.id].t === 'MOUTH')) {
    if (!tw) {
      if (itemCost(pt.id) > edSpaceLeft()) { edTouch(); return; }
      pt.m = pt.m || nextKey(); tw = JSON.parse(JSON.stringify(pt)); des.parts.push(tw);
    }
    const mp = mirrorPoint(hit.p);
    C.setAnchor(sk, tw, mp, mirrorPoint(hit.n), mirrorBall(sk, hit.b, mp));
    tw.s = pt.s; tw.spin = pt.spin; tw.c = pt.c ? pt.c.slice() : null;
  } else if (tw && (center || !ED.mirror)) {
    if (center) des.parts = des.parts.filter(q => q !== tw);
    pt.m = 0; if (!center) tw.m = 0;
  }
  edTouch();
}
function edMoveLimbRoot(lb, hit) {
  const des = ED.des, sk = designGeo(des).sk;
  C.setAnchor(sk, lb, hit.p, hit.n, hit.b);
  const tw = ED.mirror ? twinOf(des.limbs, lb) : null;
  if (tw) {
    const mp = mirrorPoint(hit.p);
    C.setAnchor(sk, tw, mp, mirrorPoint(hit.n), mirrorBall(sk, hit.b, mp));
  }
  edTouch();
}
function edSetJoint(lb, which, local) {
  const des = ED.des, G = designGeo(des);
  const root = C.anchorPos(G.sk, lb);
  let v = v3.sub(local, root);
  if (which === 'k') {
    const L = v3.len(v); if (L > 3.2) v = v3.mul(v, 3.2 / L); if (L < 0.2) v = v3.mul(v3.norm(v), 0.2);
    lb.k = v;
  } else {
    const d = v3.sub(v, lb.k), L = v3.len(d);
    if (L > 3.2) v = v3.add(lb.k, v3.mul(d, 3.2 / L));
    if (L < 0.2) v = v3.add(lb.k, v3.mul(v3.norm(d), 0.2));
    lb.f = v;
  }
  const tw = ED.mirror ? twinOf(des.limbs, lb) : null;
  if (tw) { tw.k = mirrorPoint(lb.k); tw.f = mirrorPoint(lb.f); }
  edTouch();
}
// apply a property to the selection and its mirror twin
function edSelProp(fn) {
  const s = ED.sel; if (!s) return;
  const list = s.kind === 'part' ? ED.des.parts : ED.des.limbs;
  fn(s.ref);
  const tw = ED.mirror ? twinOf(list, s.ref) : null;
  if (tw) fn(tw, true);
  edTouch();
}
function edSetPlan(p) {
  edPushUndo();
  const keepCol = ED.des && ED.des.col ? JSON.parse(JSON.stringify(ED.des.col)) : null;
  ED.des = C.defaultDesign(p);
  if (keepCol && ED.keepPaint) ED.des.col = keepCol;
  ED.grantCount = grantCountOf(ED.des);
  ED.sel = null; edTouch(); edRefreshUI();
}
function designItems(d) {
  const s = new Set();
  for (const p of d.parts || []) s.add(p.id);
  for (const l of d.limbs || []) { s.add(l.id); if (l.tip) s.add(l.tip.id); }
  const sk = skinOf(d); if (sk > 0) s.add(SKIN_ITEMS[sk]);
  return [...s];
}

// ---- camera and picking --------------------------------------------------------
function edCamera(t) {
  const des = ED.des, pl = edPlacement(des, t), G = pl.G;
  const top = G.sk.balls.reduce((m, k) => k.hide ? m : Math.max(m, k.y + k.r), 0);
  const target = [0, Math.max(0.4, (pl.cy + top + pl.cy - G.cls.stand) * 0.5 * 0.9 + 0.1), 0];
  const dist = (G.ext * 2.7 + 5.2) * ED.cam.zoom;
  const cp = Math.cos(ED.cam.pitch);
  const eye = [target[0] + Math.cos(ED.cam.yaw) * cp * dist, target[1] + Math.sin(ED.cam.pitch) * dist,
               target[2] + Math.sin(ED.cam.yaw) * cp * dist];
  eye[1] = Math.max(eye[1], 0.5);
  // never below the meadow or the hills around it
  if (ED_HAT) {
    const r = Math.hypot(eye[0], eye[2]), a = Math.atan2(eye[2], eye[0]);
    eye[1] = Math.max(eye[1], ED_HAT(r, a) + 0.9, ED_HAT(r + 2, a) + 0.6);
  }
  return { eye, target, pl };
}
function edRay(clientX, clientY) {
  const rect = canvas.getBoundingClientRect();
  const nx = ((clientX - rect.left) / rect.width) * 2 - 1;
  const ny = 1 - ((clientY - rect.top) / rect.height) * 2;
  const cam = ED.lastCam;
  if (!cam) return null;
  const f = v3.norm(v3.sub(cam.target, cam.eye));
  const r = v3.norm(v3.cross(f, [0, 1, 0]));
  const u = v3.cross(r, f);
  const th = Math.tan(ED_FOV / 2), asp = rect.width / Math.max(1, rect.height);
  const d = v3.norm(v3.add(f, v3.add(v3.mul(r, (nx + ED.shift) * th * asp), v3.mul(u, ny * th))));
  return { o: cam.eye, d };
}
function edProject(p) {
  const M = ED.vp || vpM, x = p[0], y = p[1], z = p[2];
  const cx = M[0] * x + M[4] * y + M[8] * z + M[12];
  const cy = M[1] * x + M[5] * y + M[9] * z + M[13];
  const cw = M[3] * x + M[7] * y + M[11] * z + M[15];
  if (cw <= 1e-6) return null;
  const rect = canvas.getBoundingClientRect();
  return [rect.left + (cx / cw + 1) * 0.5 * rect.width, rect.top + (1 - cy / cw) * 0.5 * rect.height, cw];
}
function edBodyHit(clientX, clientY) {
  const ray = edRay(clientX, clientY);
  if (!ray) return null;
  const pl = edPlacement(ED.des, ED.lastT);
  const G = pl.G;
  const o = [ray.o[0], ray.o[1] - pl.cy, ray.o[2]];
  const h = C.raySkin(G.sk, o[0], o[1], o[2], ray.d[0], ray.d[1], ray.d[2], 80);
  if (!h) return null;
  h.world = [h.p[0], h.p[1] + pl.cy, h.p[2]];
  return h;
}
function partWorld(pt) {
  const pl = edPlacement(ED.des, ED.lastT);
  const p = C.anchorPos(pl.G.sk, pt);
  return [p[0], p[1] + pl.cy, p[2]];
}
function limbWorld(lb) {
  const pl = edPlacement(ED.des, ED.lastT);
  const r = C.anchorPos(pl.G.sk, lb);
  const w = (v) => [v[0], v[1] + pl.cy, v[2]];
  return { root: w(r), knee: w(v3.add(r, lb.k)), foot: w(v3.add(r, lb.f)) };
}
function segDist(px, py, a, b) {
  const dx = b[0] - a[0], dy = b[1] - a[1];
  const L2 = dx * dx + dy * dy || 1;
  const u = clamp(((px - a[0]) * dx + (py - a[1]) * dy) / L2, 0, 1);
  return Math.hypot(px - (a[0] + dx * u), py - (a[1] + dy * u));
}
// What is under the cursor: joint handle > part > limb > body > nothing.
function edPick(cx, cy) {
  const des = ED.des;
  const body = edBodyHit(cx, cy);
  const eye = ED.lastCam ? ED.lastCam.eye : [0, 0, 0];
  const bodyT = body ? v3.len(v3.sub(body.world, eye)) : Infinity;
  if (ED.sel && ED.sel.kind === 'limb') {
    const lw = limbWorld(ED.sel.ref);
    for (const [key, p] of [['f', lw.foot], ['k', lw.knee], ['r', lw.root]]) {
      const s = edProject(p);
      if (s && Math.hypot(s[0] - cx, s[1] - cy) < 16) return { kind: 'handle', ref: ED.sel.ref, which: key };
    }
  }
  let best = null, bestD = Infinity;
  for (const pt of des.parts) {
    const vis = VIS[pt.id]; if (!vis) continue;
    const w = partWorld(pt);
    const s = edProject(w); if (!s) continue;
    const size = vis.size * (pt.s || 1) * 1.1;
    const ref = ED.lastCam ? v3.cross(v3.norm(v3.sub(ED.lastCam.target, ED.lastCam.eye)), [0, 1, 0]) : [1, 0, 0];
    const s2 = edProject(v3.add(w, v3.mul(v3.norm(ref), size)));
    const pr = s2 ? Math.max(12, Math.hypot(s2[0] - s[0], s2[1] - s[1])) : 14;
    const d = Math.hypot(s[0] - cx, s[1] - cy);
    const depth = v3.len(v3.sub(w, eye));
    if (d < pr && depth < bodyT + size * 1.5 && d / pr < bestD) { bestD = d / pr; best = { kind: 'part', ref: pt }; }
  }
  if (best) return best;
  for (const lb of des.limbs) {
    const lw = limbWorld(lb);
    const a = edProject(lw.root), b = edProject(lw.knee), c = edProject(lw.foot);
    if (!a || !b || !c) continue;
    const d = Math.min(segDist(cx, cy, a, b), segDist(cx, cy, b, c));
    if (d < 12 && d < bestD) { bestD = d; best = { kind: 'limb', ref: lb }; }
  }
  if (best) return best;
  if (body) return { kind: 'body', hit: body };
  return null;
}
// nearest limb end to the cursor, for snapping feet and hands
function edNearestLimbEnd(cx, cy) {
  let best = null, bd = 70;
  for (const lb of ED.des.limbs) {
    const s = edProject(limbWorld(lb).foot);
    if (!s) continue;
    const d = Math.hypot(s[0] - cx, s[1] - cy);
    if (d < bd) { bd = d; best = lb; }
  }
  return best;
}

// ---- rendering ---------------------------------------------------------------------
const edHandleData = new Float32Array(16 * INST_FLOATS);
let edHandleN = 0, edHandleVB = null;
function edHandle(p, r, col) {
  if (edHandleN >= 16) return;
  const o = edHandleN * INST_FLOATS;
  edHandleData.set([p[0], p[1], p[2], 0, 1, 0, r, r, r, col[0], col[1], col[2], 0, 0, 0], o);
  edHandleN++;
}
function renderEditor(tSec) {
  if (!edEnv) buildEditorEnv();
  if (!edHandleVB) edHandleVB = dev.createBuffer({ size: edHandleData.byteLength, usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST });
  edHandleN = 0;
  resize();
  ED.lastT = tSec;
  const rect = canvas.getBoundingClientRect();
  const pal = ED.ui && ED.ui.pal;
  const palW = pal && pal.offsetParent ? pal.getBoundingClientRect().width : 0;
  ED.shift = rect.width > 0 ? clamp(palW / rect.width, 0, 0.45) : 0;
  const cam = edCamera(tSec);
  ED.lastCam = cam;
  const aspect = canvas.width / canvas.height;
  edSetGlobals(cam.eye, cam.target, aspect, ED_FOV, 1 / 85, tSec);
  // lens shift so the creature centres in the part of the screen the palette leaves free
  projM[8] = ED.shift; m4mul(projM, viewM, vpM); gArr.set(vpM, 0); dev.queue.writeBuffer(gBuf, 0, gArr);
  ED.vp = vpM.slice();
  edResetInstances();
  editorScenery(tSec);
  // shadow on the podium, shrinking as the body bobs up
  const pl = cam.pl, G = pl.G;
  bakePodiumShadow(ED.des, pl);
  // design, with a ghost of whatever is being dragged in
  let des = ED.des;
  const gh = ED.ghost;
  // The ghost is its own design object, kept while the drop target is unchanged so
  // its skin bakes once; until then it shows the last skin it had.
  const ghSig = gh ? ED.des._rev + '|' + gh.kind + '|' + (gh.id || '') + '|' + (gh.limb ? ED.des.limbs.indexOf(gh.limb) : -1) + '|' +
    JSON.stringify(gh.parts || gh.limbs || null, (k, v) => (k[0] === '_' ? undefined : typeof v === 'number' ? Math.round(v * 40) / 40 : v)) : null;
  if (!gh) ED._ghostDes = null;
  if (gh && ED._ghostDes && ED._ghostDes._sig === ghSig) des = ED._ghostDes;
  else if (gh) {
    const gm = ED._ghostDes && ED._ghostDes._mesh;
    const prevMesh = gm && gm.gpu && !gm.shared ? gm : ED.des._mesh;
    des = Object.assign({}, ED.des, { parts: ED.des.parts.slice(), limbs: ED.des.limbs.slice(), _rev: 1 });
    des._geo = null; des._job = null; des._queued = 0; des._want = 0; des._sig = ghSig;
    des._mesh = prevMesh ? Object.assign({}, prevMesh, { key: 0, shared: true }) : null;
    ED._ghostDes = des;
    if (gh.kind === 'surface') {
      for (const p of gh.parts) des.parts.push(p);
    } else if (gh.kind === 'limb') {
      for (const l of gh.limbs) des.limbs.push(l);
    } else if (gh.kind === 'tip') {
      des.limbs = des.limbs.map(l => (l === gh.limb || (ED.mirror && gh.limb.m && l.m === gh.limb.m)) ? Object.assign({}, l, { tip: { id: gh.id, c: null, s: 1 } }) : l);
    }
  }
  const hl = { part: ED.sel && ED.sel.kind === 'part' ? ED.sel.ref : (ED.hover && ED.hover.kind === 'part' ? ED.hover.ref : null),
               limb: ED.sel && ED.sel.kind === 'limb' ? ED.sel.ref : (ED.hover && ED.hover.kind === 'limb' ? ED.hover.ref : null),
               mirror: ED.mirror };
  const offBody = ED.drag && ED.drag.type === 'move' && ED.drag.off;
  const { X } = edDesignX(des, tSec, hl, offBody ? { tint: [1, 0.2, 0.2], tintK: 0 } : null);
  drawDesign(des, X);
  // limb joint handles
  if (ED.sel && ED.sel.kind === 'limb' && ED.des.limbs.includes(ED.sel.ref)) {
    const lw = limbWorld(ED.sel.ref);
    const lbv = VIS[ED.sel.ref.id] || VIS.l_leg, thk = clamp(ED.sel.ref.th || 1, 0.5, 2) * (lbv.thick || 1);
    const hr = Math.max(0.1 * thk, v3.len(v3.sub(cam.eye, cam.target)) * 0.011);
    const hot = ED.hover && ED.hover.kind === 'handle' ? ED.hover.which : (ED.drag && ED.drag.type === 'joint' ? ED.drag.which : null);
    edHandleN = 0;
    for (const [key, p] of [['r', lw.root], ['k', lw.knee], ['f', lw.foot]]) {
      const c = key === hot ? [1, 0.85, 0.2] : [0.2, 0.95, 0.9];
      edHandle(p, hr * 1.25, [0.03, 0.12, 0.16]);
      edHandle(p, hr, c);
    }
  }
  const enc = dev.createCommandEncoder();
  const pass = enc.beginRenderPass({
    colorAttachments: [{ view: msaaTex.createView(), resolveTarget: ctx.getCurrentTexture().createView(),
      clearValue: { r: 0.52, g: 0.60, b: 0.52, a: 1 }, loadOp: 'clear', storeOp: 'discard' }],
    depthStencilAttachment: { view: depthTex.createView(), depthClearValue: 1.0, depthLoadOp: 'clear', depthStoreOp: 'store' },
  });
  pass.setPipeline(unlitPipe); pass.setBindGroup(0, bindG.unlit);
  pass.setVertexBuffer(0, edEnv.skyVB); pass.setIndexBuffer(edEnv.skyIB, 'uint32'); pass.drawIndexed(edEnv.skyCount);
  pass.setPipeline(terrainPipe); pass.setBindGroup(0, bindG.terrain);
  pass.setVertexBuffer(0, edEnv.vb); pass.setIndexBuffer(edEnv.ib, 'uint32'); pass.drawIndexed(edEnv.count);
  pass.setVertexBuffer(0, edEnv.top.vb); pass.setIndexBuffer(edEnv.top.ib, 'uint32'); pass.drawIndexed(edEnv.top.count);
  edDrawHabitat(pass);
  edFlushAndDraw(pass);
  if (edHandleN) {
    // joint handles stay visible through the body
    dev.queue.writeBuffer(edHandleVB, 0, edHandleData, 0, edHandleN * INST_FLOATS);
    pass.setPipeline(overPipe); pass.setBindGroup(0, bindG.over);
    pass.setVertexBuffer(0, sphVB); pass.setIndexBuffer(sphIB, 'uint16');
    pass.setVertexBuffer(1, edHandleVB); pass.drawIndexed(sphCount, edHandleN);
  }
  pass.end();
  dev.queue.submit([enc.finish()]);
  if (ED.statsDirty) { ED.statsDirty = false; edUpdateStats(); }
}

// ---- thumbnails ------------------------------------------------------------------
// Every part and body plan is rendered once, offscreen, into a small image for
// the palette, with the same geometry and shading the creature itself uses.
const THUMB = 192;
async function edMakeThumbs() {
  if (ED.thumbsReady || ED.thumbsBusy) return;
  ED.thumbsBusy = true;
  const jobs = [];
  for (const id of Object.keys(VIS)) jobs.push({ key: id, id });
  for (let p = 0; p < C.PLANS.length; p++) jobs.push({ key: 'plan' + p, plan: p });
  const cols = 8, rows = Math.ceil(jobs.length / cols);
  const atlas = dev.createTexture({ size: [cols * THUMB, rows * THUMB], format: fmt,
    usage: GPUTextureUsage.COPY_DST | GPUTextureUsage.COPY_SRC | GPUTextureUsage.RENDER_ATTACHMENT });
  const res = dev.createTexture({ size: [THUMB, THUMB], format: fmt, usage: GPUTextureUsage.RENDER_ATTACHMENT | GPUTextureUsage.COPY_SRC });
  const ms = dev.createTexture({ size: [THUMB, THUMB], format: fmt, sampleCount: SAMPLES, usage: GPUTextureUsage.RENDER_ATTACHMENT });
  const dp = dev.createTexture({ size: [THUMB, THUMB], format: 'depth24plus', sampleCount: SAMPLES, usage: GPUTextureUsage.RENDER_ATTACHMENT });
  const neutral = { base: [0.55, 0.64, 0.60], coat: [0.88, 0.86, 0.78], detail: [0.25, 0.32, 0.30], pat: 0 };
  for (let i = 0; i < jobs.length; i++) {
    const j = jobs[i];
    edResetInstances();
    let view = [0.55, 0.32, 0.78];
    const skinJob = j.id && VIS[j.id] && VIS[j.id].cat === 'skin';
    let thumbDes = null;
    if (skinJob) {
      // a round sample body wearing that covering
      const d = C.defaultDesign(9); d.parts = d.parts.filter(p => p.id === 'm_grazer' ? false : true).filter(p => !(p.id === 's_knob'));
      d.col = { base: [0.52, 0.6, 0.5], coat: [0.86, 0.84, 0.74], detail: [0.3, 0.36, 0.3], pat: 0, skin: VIS[j.id].skin };
      thumbDes = d;
      const { X } = edDesignX(d, 0.6, null, { toW: (l) => [l[0], l[1], l[2]], toL: (w) => [w[0], w[1], w[2]], blink: () => 0, sync: 'now', quality: 2 });
      drawDesign(d, X);
      view = [0.35, 0.35, 0.86];
    } else if (j.plan != null) {
      const d = C.defaultDesign(j.plan);
      const { X } = edDesignX(d, 0.6, null, { toW: (l) => [l[0], l[1], l[2]], toL: (w) => [w[0], w[1], w[2]], blink: () => 0, sync: 'now', quality: 0 });
      drawDesign(d, X);
      view = [0.62, 0.30, 0.74];
    } else {
      thumbItem(j.id, neutral);
      const v = VIS[j.id];
      if (v.cat === 'mouth') view = [0.9, 0.25, 0.55];
      else if (v.kind === 'tip') view = [0.55, 0.45, 0.8];
    }
    // frame whatever was emitted
    const bb = instBounds(thumbDes ? designGeo(thumbDes) : j.plan != null ? designGeo(C.defaultDesign(j.plan)) : null);
    const c = [(bb[0] + bb[3]) / 2, (bb[1] + bb[4]) / 2, (bb[2] + bb[5]) / 2];
    const rad = Math.max(0.05, Math.hypot(bb[3] - bb[0], bb[4] - bb[1], bb[5] - bb[2]) / 2);
    const vd = v3.norm(view);
    const dist = rad / Math.sin(0.42) * 1.02;
    edSetGlobals(v3.add(c, v3.mul(vd, dist)), c, 1, 0.84, 0, 0.6);
    const enc = dev.createCommandEncoder();
    const pass = enc.beginRenderPass({
      colorAttachments: [{ view: ms.createView(), resolveTarget: res.createView(), clearValue: { r: 0, g: 0, b: 0, a: 0 }, loadOp: 'clear', storeOp: 'discard' }],
      depthStencilAttachment: { view: dp.createView(), depthClearValue: 1.0, depthLoadOp: 'clear', depthStoreOp: 'discard' },
    });
    edFlushAndDraw(pass);
    pass.end();
    enc.copyTextureToTexture({ texture: res }, { texture: atlas, origin: [(i % cols) * THUMB, Math.floor(i / cols) * THUMB] }, [THUMB, THUMB]);
    dev.queue.submit([enc.finish()]);
  }
  const bpr = cols * THUMB * 4;
  const buf = dev.createBuffer({ size: bpr * rows * THUMB, usage: GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ });
  const enc = dev.createCommandEncoder();
  enc.copyTextureToBuffer({ texture: atlas }, { buffer: buf, bytesPerRow: bpr }, [cols * THUMB, rows * THUMB]);
  dev.queue.submit([enc.finish()]);
  try {
    await buf.mapAsync(GPUMapMode.READ);
    const data = new Uint8Array(buf.getMappedRange());
    const bgra = fmt.startsWith('bgra');
    const cv2 = document.createElement('canvas'); cv2.width = THUMB; cv2.height = THUMB;
    const c2 = cv2.getContext('2d');
    const img = c2.createImageData(THUMB, THUMB);
    for (let i = 0; i < jobs.length; i++) {
      const ox = (i % cols) * THUMB, oy = Math.floor(i / cols) * THUMB;
      for (let y = 0; y < THUMB; y++) {
        let si = (oy + y) * bpr + ox * 4, di = y * THUMB * 4;
        for (let x = 0; x < THUMB; x++, si += 4, di += 4) {
          const a = data[si + 3];
          // premultiplied edges from MSAA resolve against a transparent clear
          const k = a > 0 ? 255 / a : 0;
          const r = bgra ? data[si + 2] : data[si], g = data[si + 1], b = bgra ? data[si] : data[si + 2];
          img.data[di] = Math.min(255, r * k); img.data[di + 1] = Math.min(255, g * k); img.data[di + 2] = Math.min(255, b * k); img.data[di + 3] = a;
        }
      }
      c2.putImageData(img, 0, 0);
      ED.thumbs[jobs[i].key] = cv2.toDataURL('image/png');
    }
    buf.unmap();
  } catch (e) { /* thumbnails are cosmetic; tiles fall back to text */ }
  buf.destroy(); atlas.destroy(); res.destroy(); ms.destroy(); dp.destroy();
  ED.thumbsReady = true; ED.thumbsBusy = false;
  if (ED.open) edRefreshUI();
}
function instBounds(geo) {
  const bb = [Infinity, Infinity, Infinity, -Infinity, -Infinity, -Infinity];
  const add = (x, y, z, r) => {
    bb[0] = Math.min(bb[0], x - r); bb[1] = Math.min(bb[1], y - r); bb[2] = Math.min(bb[2], z - r);
    bb[3] = Math.max(bb[3], x + r); bb[4] = Math.max(bb[4], y + r); bb[5] = Math.max(bb[5], z + r);
  };
  for (let i = 0; i < instCount; i++) {
    const o = i * INST_FLOATS;
    add(instData[o], instData[o + 1], instData[o + 2], Math.max(instData[o + 6], instData[o + 7], instData[o + 8]) * 0.9);
  }
  for (let i = 0; i < spikeCount; i++) {
    const o = i * INST_FLOATS;
    add(spikeData[o], spikeData[o + 1], spikeData[o + 2], spikeData[o + 6]);
    add(spikeData[o] + spikeData[o + 3] * spikeData[o + 7], spikeData[o + 1] + spikeData[o + 4] * spikeData[o + 7], spikeData[o + 2] + spikeData[o + 5] * spikeData[o + 7], 0);
  }
  for (let i = 0; i < tubeN; i++) {
    const o = i * INST_FLOATS;
    add(tubeData[o], tubeData[o + 1], tubeData[o + 2], tubeData[o + 6]);
    add(tubeData[o] + tubeData[o + 3] * tubeData[o + 7], tubeData[o + 1] + tubeData[o + 4] * tubeData[o + 7], tubeData[o + 2] + tubeData[o + 5] * tubeData[o + 7], tubeData[o + 6]);
  }
  if (geo) for (const k of geo.sk.balls) if (!k.hide) add(k.x, k.y, k.z, k.r);
  if (!isFinite(bb[0])) return [-1, -1, -1, 1, 1, 1];
  return bb;
}
// One item on its own, in a sensible pose for its icon.
function thumbItem(id, cols) {
  const v = VIS[id];
  const env = { t: 0.8, seed: 0, base: cols.base, coat: cols.coat, detail: cols.detail, limb: cols.base, flap: 0.15, chomp: 0.35, grip: 0.3, blink: 0, lod: 0 };
  const col = itemColor(id, null, cols);
  if (v.kind === 'limb') {
    const th = v.thick || 1;
    drawLimbTube([0, 0, 0], [0.35, -0.75, 0.25], [0.15, -1.5, 0.35], th, 1, col, true);
    pushSX(-0.05, 0.08, 0, 0, 1, 0, 0, 0, 0, 0.4, 0.25, 0.4, colMul(cols.base, 0.9));
    return;
  }
  if (v.kind === 'tip') {
    const foot = [0, 0, 0], knee = [0.04, 0.3, 0.02];
    drawLimbTube([0.07, 0.55, 0.04], knee, foot, 1, 0.6, cols.base, false);
    const dirW2 = v3.norm(v3.sub(foot, knee));
    const g = makeG(foot, [1, 0, 0], dirW2, v3.cross(dirW2, [1, 0, 0]), v.size * 0.8, [1, 0, 0], [0, -1, 0]);
    env.limb = cols.base;
    v.draw(g, col, env);
    return;
  }
  let n = [0, 1, 0], fr;
  if (v.cat === 'mouth') n = [1, 0, 0];
  else if (v.cat === 'eyes') n = [0.35, 0.3, 0.88];
  else if (v.cat === 'fins' || v.cat === 'wings') n = [0, 0.25, 1];
  else if (id === 'd_gills') n = [0, 0, 1];
  fr = partFrame(n, 0, 1, false);
  // a patch of skin under the part so it reads as attached
  const Sg = v.size;
  const g = makeG([0, 0, 0], fr.x, fr.y, fr.z, Sg, frameLocal(fr, [1, 0, 0]), frameLocal(fr, [0, 1, 0]));
  if (v.cat !== 'wings' && v.cat !== 'fins') g.sp(0, -0.35, 0, 0, 1, 0, 1.25, 0.4, 1.25, cols.base);
  v.draw(g, col, env);
}
