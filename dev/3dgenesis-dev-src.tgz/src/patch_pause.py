# PAUSE MENU, and the match rules the player kept falling through:
#  - Esc opens a pause overlay with a way back to the main menu. There was no
#    way out of a game at all before this.
#  - Nothing respawns you inside a match. Dying in one is the end of your run
#    unless your killer takes you into their pack.
#  - Taking a creature into a match no longer founds a deme of six grown kin
#    beside you, which put animals in the match that were not in the match.
#  - The builder drops its shop while a match is on, so nobody buys an
#    advantage on the start line.
def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
p='g3.html'; s=open(p,encoding='utf-8').read()

# ---------------------------------------------------------------- no kin in a match
s=sub1(s,"function becomeDesigned(des) {","function becomeDesigned(des, opts) {")
# Both becomeArchetype and becomeDesigned found a deme of six grown kin. In a
# match that puts animals into the fight that were never drafted into it.
s=sub1(s,"""  const KIN = 6;
  for (let i = 0; i < KIN; i++) {""","""  const KIN = (typeof opts === 'object' && opts && opts.noKin) || BR.on || BR.arming ? 0 : 6;
  for (let i = 0; i < KIN; i++) {""", 2)
for _t in ["  toast('You hatch as a newborn, with ' + KIN + ' grown adults of your design nearby"]:
    assert s.count(_t) == 1, ('kin toast', s.count(_t))
    s = s.replace(_t, "  if (KIN) " + _t.strip())
open(p,'w',encoding='utf-8').write(s)
print('no-kin ok')
s=open(p,encoding='utf-8').read()

# ---------------------------------------------------------------- never respawn mid-match
s=sub1(s,"""  if (BR.on && BR.phase !== 'over') {
    const me = BR.players[BR.slot];""","""  if (BR.on) {
    const me = BR.players[BR.slot];""")
s=sub1(s,"""      brOnPlayerKilled(BR.slot, killer, dead && dead.deathCause ? dead.deathCause : 'the island');
    }
    player.spectator = true;
    return;
  }""","""      if (BR.phase !== 'over') brOnPlayerKilled(BR.slot, killer, dead && dead.deathCause ? dead.deathCause : 'the island');
      else me.alive = false;
    }
    // You do not come back as some wild animal's newborn. The match decides
    // what happens to you, and if it has nothing to offer you watch it out.
    player.spectator = true;
    return;
  }""")
open(p,'w',encoding='utf-8').write(s)
print('respawn guard ok')
s=open(p,encoding='utf-8').read()

# ---------------------------------------------------------------- pause menu
s=sub1(s,"""<div id="brPanel"></div>""","""<div id="pauseBox"></div>
<div id="brPanel"></div>""")
s=sub1(s,"  #brPanel{position:fixed;right:14px;top:120px;","""  #pauseBox{position:fixed;inset:0;display:none;z-index:90;align-items:center;justify-content:center;
    background:rgba(3,8,8,.82);backdrop-filter:blur(3px)}
  #pauseBox.show{display:flex}
  #pauseBox .pbin{min-width:320px;padding:30px 38px;border-radius:16px;text-align:center;
    background:linear-gradient(180deg,rgba(14,26,24,.98),rgba(6,14,14,.98));border:1px solid #3d6a5e;color:#eafaf4}
  #pauseBox h3{margin:0 0 6px;font-size:20px;letter-spacing:.20em}
  #pauseBox .psub{margin:0 0 20px;font-size:12px;color:#8fb4c4;line-height:1.6}
  #pauseBox button{display:block;width:100%;font:inherit;font-size:14px;margin:8px 0;padding:11px 20px;border-radius:9px;
    cursor:pointer;background:#0a201d;border:1px solid #3d6a5e;color:#dff3ec}
  #pauseBox button:hover{border-color:#b3140c;color:#fff}
  #pauseBox button.warn{border-color:#8a3a2c;color:#ffd9cf}
  #brPanel{position:fixed;right:14px;top:120px;""")
s=sub1(s,"""function brRenderHud() {""","""// ---------------------------------------------------------------- pause
// Esc from the game. There was no way back to the main menu at all before
// this: once you were playing, you were playing.
let paused = false;
function pauseOpen() {
  if (!started || ED.open) return;
  paused = true;
  const el = document.getElementById('pauseBox');
  if (!el) return;
  const inMatch = BR.on && BR.phase !== 'over';
  el.innerHTML = '<div class="pbin"><h3>PAUSED</h3>' +
    '<p class="psub">' + (inMatch
      ? 'You are ' + Math.round(Math.max(0, BR_MATCH_SECS - BR.t) / 60) + ' minutes from the end of a match.<br>Leaving forfeits it.'
      : 'The island keeps running while you are here.') + '</p>' +
    '<button data-pause="resume">resume</button>' +
    (inMatch ? '<button data-pause="menu" class="warn">forfeit and quit to menu</button>'
             : '<button data-pause="menu">quit to main menu</button>') +
    '</div>';
  el.classList.add('show');
  for (const b of el.querySelectorAll('[data-pause]')) {
    b.onclick = () => (b.getAttribute('data-pause') === 'menu' ? quitToMenu() : pauseClose());
  }
}
function pauseClose() {
  paused = false;
  const el = document.getElementById('pauseBox');
  if (el) { el.classList.remove('show'); el.innerHTML = ''; }
}
function quitToMenu() {
  pauseClose();
  if (BR.on) brStop();
  player.picker = null; renderPicker();
  player.spectator = false;
  started = false;
  document.body.classList.remove('brmatch');
  const st = document.getElementById('start');
  if (st) st.style.display = '';
  menuPage(null);
  MENU.i = 0;
  menuRender();
  const m = document.getElementById('mmMusic');
  if (m) { try { m.volume = 0.45; m.currentTime = 0; m.play().catch(() => {}); } catch (e) { /* no audio */ } }
}
function brRenderHud() {""")
s=sub1(s,"""    if (k === 'escape' && player.picker) { player.picker = null; renderPicker(); return; }""",
"""    if (k === 'escape') {
      if (player.picker) { player.picker = null; renderPicker(); return; }
      if (paused) { pauseClose(); return; }
      pauseOpen(); return;
    }""")
open(p,'w',encoding='utf-8').write(s)
print('pause menu ok')
s=open(p,encoding='utf-8').read()

# ---------------------------------------------------------------- online builder
# No buying on the start line, and nothing saved out of a match.
s=sub1(s,"""      const buyable = !owned && !SANDBOX;""","""      const buyable = !owned && !SANDBOX && !brLocked();""")
s=sub1(s,"""          : owned && !SANDBOX
            ? `<button class="edsell${selling ? ' arm' : ''}" data-sell="${id}">${selling ? 'sell for ' + boneRefund(id) + '?' : 'owned &middot; sell ' + boneRefund(id)}</button>`
            : '<div class="edowned">yours</div>') +""",
"""          : owned && !SANDBOX && !brLocked()
            ? `<button class="edsell${selling ? ' arm' : ''}" data-sell="${id}">${selling ? 'sell for ' + boneRefund(id) + '?' : 'owned &middot; sell ' + boneRefund(id)}</button>`
            : owned ? '<div class="edowned">yours</div>'
                    : `<div class="edowned locked">locked &middot; not for sale in a match</div>`) +""")
s=sub1(s,"""  { const b = $('edBoneN'); if (b) b.textContent = boneBalance(); }""",
"""  { const b = $('edBoneN'); if (b) b.textContent = boneBalance(); }
  // In a match the shop is shut and nothing is saved out: everyone builds from
  // what they already own, on the same budget.
  { const bs = $('edBones'); if (bs) bs.style.display = brLocked() ? 'none' : ''; }
  { const sv = $('edSaved'); if (sv) sv.style.display = brLocked() ? 'none' : ''; }
  { const h = $('edMatchNote'); if (h) h.style.display = brLocked() ? '' : 'none'; }""")
s=sub1(s,"""    <span class="edsp"></span>""","""    <span id="edMatchNote" style="display:none;font-size:12px;color:#ffd9cf">match build &middot; shop closed</span>
    <span class="edsp"></span>""")
open(p,'w',encoding='utf-8').write(s)
print('online builder ok')

# ---------------------------------------------------------------- camera
# The third-person camera started 150 units back, which framed the animal as a
# dot on a landscape. Start it over the shoulder instead, scaled to the body so
# a sauropod and a lizard are framed the same way. The wheel still zooms out.
s=open(p,encoding='utf-8').read()
s=sub1(s,"const THIRD_MAX = 1600, THIRD_DEFAULT = 150, THIRD_SNAP = 26;",
         "const THIRD_MAX = 1600, THIRD_DEFAULT = 42, THIRD_SNAP = 26;")
s=sub1(s,"""function updateCamera(dt) {""","""// Where the camera sits behind a body by default: close enough to read the
// animal, far enough not to clip through it, and proportional so it frames a
// big body and a small one the same way.
function camDefaultDist(p) {
  if (!p) return THIRD_DEFAULT;
  const body = Math.max(2, (p.bodyRX || p.radius || 4) * BODY_SCALE);
  return clamp(THIRD_DEFAULT * 0.55 + body * 3.4, THIRD_SNAP + 8, 260);
}
function updateCamera(dt) {""")
# every place that seeds the distance uses it
s=s.replace("player.dist = Math.max(player.dist, THIRD_DEFAULT);", "player.dist = camDefaultDist(me.ph || (me.genome && C.develop(me.genome)));")
s=s.replace("player.dist = THIRD_DEFAULT;", "player.dist = camDefaultDist(player.c && player.c.ph);")
open(p,'w',encoding='utf-8').write(s)
# test surface
s=sub1(s,"  rebuild: () => rebuildWorld(),","""  rebuild: () => rebuildWorld(),
  closeEditor: (apply) => closeEditor(!!apply),
  pauseOpen: () => pauseOpen(), pauseClose: () => pauseClose(), quitToMenu: () => quitToMenu(),
  get paused() { return paused; },
  get started() { return started; },
  becomeDesigned: (d) => becomeDesigned(d),
  get creatureCount() { return world ? world.creatures.length : 0; },
  camDefaultDist: (ph) => camDefaultDist(ph),""")
open(p,'w',encoding='utf-8').write(s)
print('camera ok')

# ---------------------------------------------------------------- live builder
# The world used to stop dead while you were in the creature builder, which
# made it a free pause button: you could open it mid-hunt and the predator on
# your heels would simply wait. The island keeps running now. In exchange,
# nothing can touch you while you are in there, so it is not a punishment
# either -- it is a workbench that the world goes on around.
s=open(p,encoding='utf-8').read()
s=sub1(s,"""  if (ED.open) {
    try { renderEditor(now / 1000); } catch (e) { console.error(e); }
    requestAnimationFrame(loop);
    return;
  }""","""  if (ED.open) {
    // The shield goes on BEFORE the step and again after it: the step is what
    // would starve or drown you, so guarding only afterwards let the world kill
    // you and then hand back a corpse to protect.
    try { edShield(); } catch (e) { console.warn(e); }
    // the world goes on, but without drawing it: the editor owns the screen
    try { tick(dt, true); } catch (e) { console.warn('sim while editing', e); }
    try { objTick(dt); sndTick(dt); spatTick(dt); } catch (e) { console.warn(e); }
    try { if (BR.on) brTick(dt); } catch (e) { console.warn('br while editing', e); }
    try { edShield(); } catch (e) { console.warn(e); }
    try { renderEditor(now / 1000); } catch (e) { console.error(e); }
    requestAnimationFrame(loop);
    return;
  }""")
s=sub1(s,"""function fightHitFilter(victim, att, dmg) {
  const c = player.c;""","""function fightHitFilter(victim, att, dmg) {
  const c = player.c;
  // At the workbench you cannot be hit. See edShield().
  if (ED.open && victim === c) return null;""")
s=sub1(s,"""// ---------------------------------------------------------------- pause""",
"""// While the builder is open the world runs but you are out of it: no hit
// lands (fightHitFilter refuses them), and nothing that ticks away at a body
// -- hunger, drowning, the match fog -- is allowed to finish you either.
function edShield() {
  const c = player.c;
  if (!c) return;
  if (ED.shieldE == null) ED.shieldE = c.energy;
  // if the step managed to finish you off, take it back: you were at a
  // workbench, not in the world
  if (!c.alive) { c.alive = true; c.deathCause = null; }
  // hold the body exactly where the editor found it
  c.energy = Math.max(c.energy, Math.min(ED.shieldE, c.ph.storage));
  c._drown = 0; c._sub = false;
  c._hurtT = 0;
  if (c.energy <= 0) c.energy = 1;
}

// ---------------------------------------------------------------- pause""")
# and let go of the shield when the editor closes
s=sub1(s,"""  const mode = ED.mode, des = stripDesign(ED.des);
  ED.open = false;""","""  const mode = ED.mode, des = stripDesign(ED.des);
  ED.open = false; ED.shieldE = null;""")
s=sub1(s,"""function openEditor(mode) {""","""function openEditor(mode) {
  ED.shieldE = null;""")
open(p,'w',encoding='utf-8').write(s)
s=sub1(s,"""function respawn() {
  const dead = player.c;""","""function respawn() {
  // Not while you are at the workbench. edShield() is holding that body
  // together on purpose; swapping it out from under the editor would leave the
  // builder editing a creature that no longer exists.
  if (ED.open) { edShield(); return; }
  const dead = player.c;""")
# hold the body exactly, rather than at-least: 'at least' still let a step
# drain it to nothing between the two shield calls
s=s.replace("""  c.energy = Math.max(c.energy, Math.min(ED.shieldE, c.ph.storage));""",
            """  c.energy = Math.max(1, Math.min(ED.shieldE, c.ph.storage));""")
open(p,'w',encoding='utf-8').write(s)
print('live builder ok')
