# Animals commit to a heading for 1-1.8 s instead of re-aiming every tick, and
# always turn at a finite rate, so walks read as purposeful instead of jittery.
# Urgent situations (fleeing, fighting back, fear, closing on prey) skip the
# commitment but still turn smoothly.
def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
p='g3.html'; s=open(p,encoding='utf-8').read()
s=sub1(s,"""      dirx = _dx; diry = _dy;
      // move (terrain modulates land speed; mountains cost extra upkeep)""","""      dirx = _dx; diry = _dy;
      // ---- heading commitment and finite turn rate
      {
        const dl = Math.hypot(dirx, diry);
        if (dl > 1e-6) {
          const urgent = !!c.foe || c.fear > 0.3 || !!(hunting && prey);
          if (c._hx == null) { c._hx = dirx / dl; c._hy = diry / dl; c._cx = c._hx; c._cy = c._hy; c._hdT = 0; }
          c._hdT -= dt;
          if (urgent || c._hdT <= 0) {
            c._cx = dirx / dl; c._cy = diry / dl;
            if (!urgent) c._hdT = 1.0 + ((c.id * 0.6180339 + c.age * 0.37) % 1) * 0.8;
          }
          // turn toward the committed heading at a bounded rate
          const cur = Math.atan2(c._hy, c._hx), want = Math.atan2(c._cy, c._cx);
          let d = want - cur; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI;
          const maxTurn = (urgent ? 5.0 : 2.2) * dt;
          const a = cur + Math.max(-maxTurn, Math.min(maxTurn, d));
          c._hx = Math.cos(a); c._hy = Math.sin(a);
          dirx = c._hx * dl; diry = c._hy * dl;
        }
      }
      // move (terrain modulates land speed; mountains cost extra upkeep)""")
open(p,'w',encoding='utf-8').write(s)
print('heading ok')
