// =====================================================================
// SEA FLOOR
// What grows under the water, built as ordinary ground-cover meshes so it
// goes through the same instanced draw as grass and ferns: giant kelp on the
// cold shelf, sea grass in the wash, coral heads and sea fans on warm reefs,
// and shells, urchins and rubble on the sand. Placement is by depth below the
// surface and by how warm the water is, which is the same north-cold /
// south-warm gradient the terrain generator uses for its biomes.
// Kinds 9..13 (land cover is 0..5, rock cover 6..8).
// =====================================================================
const SEA_KIND_KELP = 9, SEA_KIND_WEED = 10, SEA_KIND_CORAL = 11, SEA_KIND_FAN = 12, SEA_KIND_RUBBLE = 13;

// A kelp stipe: a long limp rope from the floor with blades hanging off it.
// Sway rises steeply with height so the holdfast stays put and the canopy
// rolls, which is what a kelp bed does in a swell.
function seaKelpStipe(m, x0, z0, H, rnd, col, bladeCol) {
  const pts = [], rad = [];
  const leanX = (rnd() - 0.5) * H * 0.28, leanZ = (rnd() - 0.5) * H * 0.28;
  const N = 6;
  for (let k = 0; k <= N; k++) {
    const u = k / N;
    pts.push([x0 + leanX * u * u, H * u, z0 + leanZ * u * u]);
    rad.push(0.55 * (1 - 0.45 * u) * (0.8 + rnd() * 0.4));
  }
  folTube(m, pts, rad, 5, col, H, 3.4, 0.55);
  // blades: paired, alternating up the stipe, wider toward the top
  const nb = 7 + ((rnd() * 4) | 0);
  for (let b = 0; b < nb; b++) {
    const u = 0.18 + (b / nb) * 0.8;
    const c0 = [x0 + leanX * u * u, H * u, z0 + leanZ * u * u];
    const a = b * 2.39996 + rnd() * 0.6;                       // golden angle: no two blades line up
    const out = fnorm([Math.cos(a), -0.25 - rnd() * 0.35, Math.sin(a)]);
    const L = H * (0.13 + rnd() * 0.10) * (0.55 + 0.75 * u);
    const c = fadd(c0, fmul(out, L * 0.45));
    const nrm = fnorm(fadd(fcross(out, [Math.cos(a + 1.57), 0, Math.sin(a + 1.57)]), [0, 0.25, 0]));
    folLeaf(m, c, nrm, out, L, L * 0.30, fcol(bladeCol, 0.8 + rnd() * 0.4), fsw(c[1], H, 3.4) + L * 0.05);
  }
  // gas bladder at the tip so the frond reads as buoyant
  folBlob(m, [x0 + leanX, H * 1.01, z0 + leanZ], H * 0.035, 1.1, fcol(bladeCol, 1.15), rnd, H, 3.6, 5);
}

// Branching staghorn coral: a recursive fork, thickest at the base.
function seaCoralBranch(m, p, dir, len, rad, depth, col, rnd, H) {
  const tip = fadd(p, fmul(dir, len));
  const pts = [p, fadd(p, fmul(dir, len * 0.5)), tip];
  folTube(m, pts, [rad, rad * 0.78, rad * 0.55], 5, col, H, 0, 0.6);
  if (depth <= 0) {
    folBlob(m, tip, rad * 1.5, 1.0, fcol(col, 1.25), rnd, H, 0, 5);   // pale growing tip
    return;
  }
  const n = 2 + ((rnd() * 2) | 0);
  for (let k = 0; k < n; k++) {
    const a = rnd() * 6.2832;
    const d2 = fnorm(fadd(fmul(dir, 1.5), [Math.cos(a) * 0.95, 0.25 + rnd() * 0.5, Math.sin(a) * 0.95]));
    seaCoralBranch(m, tip, d2, len * (0.62 + rnd() * 0.18), rad * 0.66, depth - 1, col, rnd, H);
  }
}

// A sea fan: a flat lattice standing on edge, so it catches the current
// broadside on. Two-sided (leaf = 1) and swaying from the base.
function seaFan(m, c, yaw, R, col, rnd, H) {
  const ax = [Math.cos(yaw), 0, Math.sin(yaw)];
  const nrm = [-Math.sin(yaw), 0, Math.cos(yaw)];
  const ribs = 9;
  for (let r = 0; r < ribs; r++) {
    const u = (r / (ribs - 1)) * 2 - 1;                       // -1..1 across the fan
    const spread = Math.sqrt(Math.max(0, 1 - u * u));
    const top = R * (0.45 + 0.55 * spread);
    const pts = [], rad = [];
    for (let k = 0; k <= 4; k++) {
      const v = k / 4;
      pts.push(fadd(c, [ax[0] * u * R * 0.55 * v, top * v, ax[2] * u * R * 0.55 * v]));
      rad.push(R * 0.035 * (1 - 0.6 * v));
    }
    folTube(m, pts, rad, 4, col, H, 1.7, 0.7);
    // webbing between this rib and the next, as a run of small blades
    if (r < ribs - 1) for (let k = 1; k <= 3; k++) {
      const v = k / 3.4;
      const p = fadd(c, [ax[0] * (u + 0.5 / (ribs - 1) * 2) * R * 0.55 * v, top * v, ax[2] * (u + 0.5 / (ribs - 1) * 2) * R * 0.55 * v]);
      folLeaf(m, p, nrm, ax, R * 0.22, R * 0.16, fcol(col, 0.85 + rnd() * 0.3), fsw(p[1], H, 1.7));
    }
  }
}

// An anemone: a squat column with a crown of waving tentacles.
function seaAnemone(m, c, R, col, tipCol, rnd, H) {
  folTube(m, [c, fadd(c, [0, R * 0.9, 0])], [R * 0.62, R * 0.5], 6, col, H, 0.6, 0.6);
  const top = fadd(c, [0, R * 0.9, 0]);
  const n = 16;
  for (let k = 0; k < n; k++) {
    const a = k / n * 6.2832 + rnd() * 0.2;
    const out = fnorm([Math.cos(a), 0.75 + rnd() * 0.5, Math.sin(a)]);
    const L = R * (0.7 + rnd() * 0.5);
    const p = fadd(top, fmul(out, L * 0.5));
    const nrm = fnorm(fcross(out, [Math.cos(a + 1.57), 0, Math.sin(a + 1.57)]));
    folLeaf(m, p, nrm, out, L, L * 0.16, fcol(tipCol, 0.85 + rnd() * 0.35), fsw(p[1], H, 2.6) + L * 0.12);
  }
}

// A scallop shell: a ribbed fan lying on the sand.
function seaShell(m, c, R, yaw, col, rnd) {
  const ribs = 7;
  const prev = [];
  for (let r = 0; r <= ribs; r++) {
    const a = yaw - 0.9 + (r / ribs) * 1.8;
    const bulge = Math.sin((r / ribs) * Math.PI);
    const p = [c[0] + Math.cos(a) * R, c[1] + R * 0.24 * bulge, c[2] + Math.sin(a) * R];
    const n = fnorm([Math.cos(a) * 0.35, 1, Math.sin(a) * 0.35]);
    prev.push(folV(m, p, n, fcol(col, 0.85 + 0.3 * (r % 2)), 0, -1));
  }
  const hinge = folV(m, c, [0, 1, 0], fcol(col, 0.75), 0, -1);
  for (let r = 0; r < ribs; r++) m.i.push(hinge, prev[r], prev[r + 1]);
}

const SEA_KELP_COL = [0.20, 0.17, 0.07], SEA_BLADE_COL = [0.26, 0.29, 0.10];
const SEA_CORAL_COLS = [[0.72, 0.30, 0.34], [0.86, 0.52, 0.22], [0.48, 0.30, 0.62], [0.90, 0.74, 0.34], [0.26, 0.56, 0.58]];
const SEA_FAN_COLS = [[0.74, 0.24, 0.30], [0.84, 0.44, 0.20], [0.42, 0.26, 0.58]];

function buildSeaCover(kind, variant) {
  const rnd = folRng(9300 + kind * 37 + variant * 11);
  const m = folMB();
  if (kind === SEA_KIND_KELP) {
    // a holdfast clump of 3-5 stipes, 55-105 units tall
    const n = 3 + ((rnd() * 3) | 0);
    const H = 55 + variant * 26 + rnd() * 24;
    for (let k = 0; k < n; k++) {
      const a = rnd() * 6.2832, r = rnd() * 3.2;
      seaKelpStipe(m, Math.cos(a) * r, Math.sin(a) * r, H * (0.72 + rnd() * 0.45), rnd, SEA_KELP_COL, SEA_BLADE_COL);
    }
    folRock(m, [0, 0, 0], 2.4, 0.45, [0.22, 0.24, 0.20], 800 + variant, 0, 0);   // holdfast
  } else if (kind === SEA_KIND_WEED) {
    // sea grass: shorter, limper and bluer than land grass, plus a weed frond
    folGrass(m, rnd, 20, 5, 13 + variant * 4, [0.10, 0.22, 0.14], [0.26, 0.48, 0.28], 0.85);
    for (let k = 0; k < 3; k++) {
      const a = rnd() * 6.2832;
      folFrond(m, [Math.cos(a) * 2, 0.5, Math.sin(a) * 2], fnorm([Math.cos(a), 0.9, Math.sin(a)]),
               7 + rnd() * 5, 1.4, 0.8, [0.14, 0.34, 0.20], rnd, 12, 2.2, 1);
    }
  } else if (kind === SEA_KIND_CORAL) {
    // a reef head: staghorn thickets over a brain-coral boulder
    const col = SEA_CORAL_COLS[(variant * 2 + 1) % SEA_CORAL_COLS.length];
    folRock(m, [0, 0, 0], 4.5 + variant * 1.6, 0.62, fcol(col, 0.55), 830 + variant * 7, 1, 0);
    const n = 3 + variant;
    for (let k = 0; k < n; k++) {
      const a = k / n * 6.2832 + rnd() * 0.7, r = 1.4 + rnd() * 2.6;
      const c2 = SEA_CORAL_COLS[((variant + k) * 3) % SEA_CORAL_COLS.length];
      seaCoralBranch(m, [Math.cos(a) * r, 2.2, Math.sin(a) * r],
                     fnorm([Math.cos(a) * 0.45, 1, Math.sin(a) * 0.45]), 5.5 + rnd() * 3, 0.85, 2, c2, rnd, 18);
    }
    seaAnemone(m, [3.5, 0.6, -2.4], 1.5, [0.66, 0.34, 0.40], [0.94, 0.62, 0.58], rnd, 18);
  } else if (kind === SEA_KIND_FAN) {
    // sea fans standing on edge, with anemones around the base
    const n = 2 + variant;
    for (let k = 0; k < n; k++) {
      const a = rnd() * 6.2832, r = rnd() * 3.4;
      seaFan(m, [Math.cos(a) * r, 0.4, Math.sin(a) * r], rnd() * 3.14,
             9 + rnd() * 7 + variant * 3, SEA_FAN_COLS[(k + variant) % SEA_FAN_COLS.length], rnd, 22);
    }
    for (let k = 0; k < 3; k++) {
      const a = rnd() * 6.2832;
      seaAnemone(m, [Math.cos(a) * 4.5, 0.3, Math.sin(a) * 4.5], 1.1 + rnd() * 0.9,
                 [0.60, 0.40, 0.46], [0.92, 0.70, 0.52], rnd, 12);
    }
  } else {
    // rubble: shells, urchins and small stones on the sand
    for (let k = 0; k < 5 + variant * 3; k++) {
      const a = rnd() * 6.2832, r = rnd() * 6;
      folRock(m, [Math.cos(a) * r, 0, Math.sin(a) * r], 0.35 + rnd() * rnd() * 1.1, 0.5 + rnd() * 0.3,
              [0.50, 0.48, 0.42], 860 + k * 3 + variant * 40, 0, 0);
    }
    for (let k = 0; k < 3 + variant; k++) {
      const a = rnd() * 6.2832, r = 1 + rnd() * 5;
      seaShell(m, [Math.cos(a) * r, 0.1, Math.sin(a) * r], 0.9 + rnd() * 0.9, rnd() * 6.2832,
               [0.82, 0.76, 0.66], rnd);
    }
    // urchins: a dark ball of spines
    for (let k = 0; k < 1 + variant; k++) {
      const a = rnd() * 6.2832, r = 2 + rnd() * 4;
      const c = [Math.cos(a) * r, 0.5, Math.sin(a) * r];
      folRock(m, c, 0.85, 0.85, [0.14, 0.10, 0.16], 890 + k, 0, 0);
      for (let s = 0; s < 14; s++) {
        const sa = rnd() * 6.2832, su = rnd() * 0.9;
        const d = fnorm([Math.cos(sa) * Math.sqrt(1 - su * su), su, Math.sin(sa) * Math.sqrt(1 - su * su)]);
        folTube(m, [fadd(c, fmul(d, 0.5)), fadd(c, fmul(d, 1.9 + rnd() * 0.8))], [0.10, 0.02], 3,
                [0.20, 0.13, 0.22], 4, 0, 0.8);
      }
    }
  }
  return m;
}

// ---- placement ------------------------------------------------------------
// Warmth at a point, matching the terrain generator's north-cold/south-warm
// gradient (the generator keeps its own tempAt() private, so this is the same
// formula without the altitude lapse, which does not apply under water).
function seaWarmth(x, z) { return clamp(0.16 + (z / WORLD_H) * 0.78, 0, 1); }
const SEA_COVER_SHORE = [[SEA_KIND_WEED, 0.50], [SEA_KIND_RUBBLE, 0.34], [SEA_KIND_FAN, 0.04]];
const SEA_COVER_REEF  = [[SEA_KIND_CORAL, 0.38], [SEA_KIND_FAN, 0.24], [SEA_KIND_WEED, 0.16], [SEA_KIND_RUBBLE, 0.14]];
const SEA_COVER_KELP  = [[SEA_KIND_KELP, 0.34], [SEA_KIND_WEED, 0.30], [SEA_KIND_RUBBLE, 0.18], [SEA_KIND_FAN, 0.06]];
const SEA_COVER_DEEP  = [[SEA_KIND_RUBBLE, 0.14], [SEA_KIND_WEED, 0.05], [SEA_KIND_FAN, 0.03]];
// depth is world units of water over the sea floor at this point
function seaCoverAt(x, z, depth) {
  if (depth < 0.8 || depth > 320) return null;     // nothing on the tideline, nothing on the abyssal plain
  if (depth < 5) return SEA_COVER_SHORE;
  const warm = seaWarmth(x, z);
  if (depth < 48 && warm > 0.58) return SEA_COVER_REEF;    // coral wants warm, sunlit water
  if (depth < 110) return SEA_COVER_KELP;                  // kelp runs down the shelf
  return SEA_COVER_DEEP;
}
