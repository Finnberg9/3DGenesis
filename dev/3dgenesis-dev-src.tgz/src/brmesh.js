// =====================================================================
// THE CAGES
// One steel box per bay on the ring: a plate floor, four walls of vertical
// bars on a heavy frame, a barred roof, and a gate on the inward face that
// slides up when the match starts. Above the gate is a lit bay number, built
// out of seven-segment bars so it reads from a long way off.
// Built as ordinary foliage meshes, so they go through the same instanced
// draw as the trees.
// =====================================================================
const MAT_STEEL = -2;          // dark grey plate, pitted, rusting
const MAT_GLOW = -3;           // lamp glass and the bay numerals: lit, not weathered
const BR_STEEL = [0.355, 0.340, 0.320];   // dark grey steel, warmed against a cool ambient
const BR_STEEL_D = [0.260, 0.248, 0.234]; // the heavy frame, darker still
const BR_RUST = [0.360, 0.215, 0.125];    // the parts that have gone over to rust
const BR_PLATE = [0.285, 0.275, 0.262];   // floor plate
const BR_LAMP = [0.95, 0.72, 0.22];

// An axis-aligned box as 12 triangles, flat-shaded, with a tint per face so
// the edges read without any lighting help.
function brBox(m, cx, cy, cz, hx, hy, hz, col, mat) {
  const lf = mat == null ? MAT_STEEL : mat;
  const P = [
    [-1, -1, -1], [1, -1, -1], [1, 1, -1], [-1, 1, -1],
    [-1, -1, 1], [1, -1, 1], [1, 1, 1], [-1, 1, 1],
  ].map(p => [cx + p[0] * hx, cy + p[1] * hy, cz + p[2] * hz]);
  const F = [
    [[0, 3, 2, 1], [0, 0, -1], 0.88], [[4, 5, 6, 7], [0, 0, 1], 0.96],
    [[0, 1, 5, 4], [0, -1, 0], 0.76], [[3, 7, 6, 2], [0, 1, 0], 1.08],
    [[0, 4, 7, 3], [-1, 0, 0], 0.92], [[1, 2, 6, 5], [1, 0, 0], 1.00],
  ];
  for (const [q, n, k] of F) {
    const c = fcol(col, k);
    const i0 = folV(m, P[q[0]], n, c, 0, lf), i1 = folV(m, P[q[1]], n, c, 0, lf);
    const i2 = folV(m, P[q[2]], n, c, 0, lf), i3 = folV(m, P[q[3]], n, c, 0, lf);
    m.i.push(i0, i1, i2, i0, i2, i3);
  }
}
// Seven-segment digit, drawn in the XY plane, 1 unit wide by 2 tall, centred.
const BR_SEG = [
  [1, 1, 1, 0, 1, 1, 1], [0, 0, 1, 0, 0, 1, 0], [1, 0, 1, 1, 1, 0, 1], [1, 0, 1, 1, 0, 1, 1],
  [0, 1, 1, 1, 0, 1, 0], [1, 1, 0, 1, 0, 1, 1], [1, 1, 0, 1, 1, 1, 1], [1, 0, 1, 0, 0, 1, 0],
  [1, 1, 1, 1, 1, 1, 1], [1, 1, 1, 1, 0, 1, 1],
];
function brDigit(m, d, cx, cy, cz, h, col, mat) {
  const s = BR_SEG[clamp(d | 0, 0, 9)];
  const w = h * 0.55, t = h * 0.10;
  //      top(0)
  // ul(1)      ur(2)
  //      mid(3)
  // ll(4)      lr(5)
  //      bot(6)
  const put = (x, y, hx, hy) => brBox(m, cx + x, cy + y, cz, hx, hy, t * 0.5, col, mat == null ? MAT_GLOW : mat);
  if (s[0]) put(0, h * 0.5, w * 0.5, t * 0.5);
  if (s[1]) put(-w * 0.5, h * 0.25, t * 0.5, h * 0.25);
  if (s[2]) put(w * 0.5, h * 0.25, t * 0.5, h * 0.25);
  if (s[3]) put(0, 0, w * 0.5, t * 0.5);
  if (s[4]) put(-w * 0.5, -h * 0.25, t * 0.5, h * 0.25);
  if (s[5]) put(w * 0.5, -h * 0.25, t * 0.5, h * 0.25);
  if (s[6]) put(0, -h * 0.5, w * 0.5, t * 0.5);
}
// The cage body: everything except the gate, which moves and so is its own
// mesh. The open face is +X, which is the face the bay is turned to face the
// island with.
function buildCageMesh() {
  const m = folMB();
  const R = BR_CAGE_R, H = BR_CAGE_H, bar = 0.65, frame = 1.6;
  // Floor plate on a deep plinth. The cage is anchored to the LOWEST ground
  // under its footprint, so the plinth has to reach down far enough to bury
  // itself on the uphill side instead of leaving a gap you can see under.
  brBox(m, 0, -11, 0, R, 11, R, BR_PLATE, MAT_STEEL);
  // corner posts
  for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
    brBox(m, sx * (R - frame), H * 0.5, sz * (R - frame), frame, H * 0.5, frame, BR_STEEL_D, MAT_STEEL);
  }
  // three walls of bars (back -X, sides +-Z), a gap on +X for the gate
  const nb = 13;
  for (let i = 0; i < nb; i++) {
    const u = (i / (nb - 1)) * 2 - 1;
    brBox(m, -R + frame, H * 0.5, u * (R - frame), bar, H * 0.5, bar, BR_STEEL, MAT_STEEL);
    brBox(m, u * (R - frame), H * 0.5, -R + frame, bar, H * 0.5, bar, BR_STEEL, MAT_STEEL);
    brBox(m, u * (R - frame), H * 0.5, R - frame, bar, H * 0.5, bar, BR_STEEL, MAT_STEEL);
  }
  // rails: top and waist, all four sides
  for (const y of [H - frame, H * 0.5]) {
    brBox(m, 0, y, -R + frame, R, frame * 0.5, frame * 0.5, BR_STEEL_D, MAT_STEEL);
    brBox(m, 0, y, R - frame, R, frame * 0.5, frame * 0.5, BR_STEEL_D, MAT_STEEL);
    brBox(m, -R + frame, y, 0, frame * 0.5, frame * 0.5, R, BR_STEEL_D, MAT_STEEL);
  }
  // barred roof
  for (let i = 0; i < nb; i++) {
    const u = (i / (nb - 1)) * 2 - 1;
    brBox(m, u * (R - frame), H, 0, bar, bar, R, BR_STEEL_D, MAT_STEEL);
  }
  // gate frame and lintel on the open face
  brBox(m, R - frame, H + frame, 0, frame, frame, R, BR_RUST, MAT_STEEL);
  // a dim lamp in each back corner, so the inside of the cage is lit
  for (const sz of [-1, 1]) brBox(m, -R + frame * 2.2, H - frame * 2, sz * (R * 0.55), 1.4, 1.0, 1.4, BR_LAMP, MAT_GLOW);
  return m;
}
// The gate: a slab of bars filling the +X face. Drawn separately so it can
// slide up out of the frame.
function buildGateMesh() {
  const m = folMB();
  const R = BR_CAGE_R, H = BR_CAGE_H, frame = 1.6;
  brBox(m, 0, H - frame, 0, frame * 0.6, frame, R - frame, BR_RUST, MAT_STEEL);
  brBox(m, 0, 0, 0, frame * 0.6, frame * 0.8, R - frame, BR_RUST, MAT_STEEL);
  const nb = 11;
  for (let i = 0; i < nb; i++) {
    const u = (i / (nb - 1)) * 2 - 1;
    brBox(m, 0, H * 0.5, u * (R - frame * 1.6), frame * 0.5, H * 0.5, 0.8, BR_STEEL, MAT_STEEL);
  }
  for (const y of [H * 0.25, H * 0.5, H * 0.75]) {
    brBox(m, 0, y * 2 * 0.5, 0, frame * 0.4, 0.7, R - frame, BR_STEEL_D, MAT_STEEL);
  }
  return m;
}
// One mesh per digit 0-9, to hang over the gate.
function buildDigitMesh(d) {
  const m = folMB();
  // Backing plate in the middle with a lit numeral on each face, so the bay
  // number reads whichever side of the cage you come at it from.
  brBox(m, 0, 0, 0, 7, 6.5, 0.9, BR_STEEL_D, MAT_STEEL);
  brDigit(m, d, 0, 0, 1.4, 9, BR_LAMP, MAT_GLOW);
  brDigit(m, d, 0, 0, -1.4, 9, BR_LAMP, MAT_GLOW);
  return m;
}
// The mast the number sits on, rising off the roof line.
function buildSignpostMesh() {
  const m = folMB();
  const H = BR_CAGE_H;
  brBox(m, 0, H * 0.5 + 7, 0, 1.1, H * 0.5 + 7, 1.1, BR_STEEL_D, MAT_STEEL);
  brBox(m, 0, H + 6.5, 0, 9, 1.0, 1.0, BR_STEEL_D, MAT_STEEL);     // cross bar under the plate
  return m;
}
const BRMESH = { cage: null, gate: null, signpost: null, digits: [], ready: false };
function brMeshInit() {
  if (BRMESH.ready) return;
  BRMESH.cage = folUpload(buildCageMesh());
  BRMESH.gate = folUpload(buildGateMesh());
  BRMESH.signpost = folUpload(buildSignpostMesh());
  for (let d = 0; d < 10; d++) BRMESH.digits[d] = folUpload(buildDigitMesh(d));
  BRMESH.ready = true;
}
// Queue the ring into the foliage instance buckets. Called from folUpdate,
// which is where the buckets live.
function brPutCages(put, camX, camZ) {
  if (!BR.on || !BRMESH.ready) return;
  const lift = BR.gateY * (BR_CAGE_H + 6);
  for (const bay of BR.bays) {
    const dx = bay.x - camX, dz = bay.z - camZ;
    if (dx * dx + dz * dz > 3400 * 3400) continue;
    put(BRMESH.cage, bay.x, bay.y, bay.z, bay.yaw, 1, [1, 1, 1]);
    if (BR.gateY < 0.999) {
      const gx = bay.x + Math.cos(bay.yaw) * BR_CAGE_R;
      const gz = bay.z + Math.sin(bay.yaw) * BR_CAGE_R;
      put(BRMESH.gate, gx, bay.y + lift, gz, bay.yaw, 1, [1, 1, 1]);
    }
    // The bay number, on a post standing off the roof rather than floating
    // beside the cage with nothing holding it up.
    const s = String(bay.n);
    const nx = Math.cos(bay.yaw), nz = Math.sin(bay.yaw);
    const sx = bay.x + nx * (BR_CAGE_R - 2), sz = bay.z + nz * (BR_CAGE_R - 2);
    put(BRMESH.signpost, sx, bay.y, sz, bay.yaw, 1, [1, 1, 1]);
    for (let k = 0; k < s.length; k++) {
      const off = (k - (s.length - 1) / 2) * 7.5;
      const px = sx - nz * off, pz = sz + nx * off;
      put(BRMESH.digits[+s[k]], px, bay.y + BR_CAGE_H + 13, pz, bay.yaw + Math.PI / 2, 1, [1, 1, 1]);
    }
  }
}
