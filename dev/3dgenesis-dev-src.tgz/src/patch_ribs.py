# =====================================================================
# THE RIBCAGE ARCS UP
#
# The ribs hung DOWN off the spine. That is correct anatomy for an animal
# standing up -- backbone on top, ribs slung underneath -- and it is exactly
# wrong for a carcass lying in the dirt, where it reads as an upside-down
# cage folding into the ground.
#
# Flipped. The backbone lies ON the soil and the ribs sweep up off it and bow
# outward as they rise, which is the half-buried ribcage everybody pictures.
#
#   old:  y = spineY * cos(th)        going down as th runs out
#   new:  y = spineY + ribH * sin(th) going up, with the bow coming from
#         z = w * (1 - cos(th)), so a rib leaves the spine vertically and
#         tips outward at the top instead of splaying from the root.
#
# The sink is measured off the SPINE height now rather than the full height
# of the cage, so the soil takes the backbone and leaves the ribs standing.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, ('ANCHOR %d/%d' % (n, cnt), a[:110]); return s.replace(a, b)

p = 'g3.html'; s = open(p, encoding='utf-8').read()

s = sub1(s, """  const hs = maxR * 1.05;
  const sinkBy = (hs + 0.35) * S * sinkK * 0.70;""",
"""  const hs = maxR * 1.05;
  // The backbone lies on the soil; the ribs are what stands up off it.
  const spineY = hs * 0.24;
  const ribH = hs * 1.30;
  // Sink is measured off the SPINE, not the top of the cage, so the ground
  // takes the backbone and leaves the ribs above the grass.
  const sinkBy = (spineY + 0.35) * S * sinkK * 0.70;""")
s = sub1(s, "  const sp = spine.map((b, i) => [b.x, hs * (0.55 + 0.45 * b.r / maxR) + (remRand(r, i) - 0.5) * 0.03, (remRand(r, i + 50) - 0.5) * 0.05]);",
            "  const sp = spine.map((b, i) => [b.x, spineY * (0.75 + 0.45 * b.r / maxR) + (remRand(r, i) - 0.5) * 0.03, (remRand(r, i + 50) - 0.5) * 0.05]);")
s = sub1(s, """      let prev = top;
      for (let q = 1; q <= ribN; q++) {
        // A tighter sweep keeps the rib standing up out of the ground rather
        // than folding it flat along the soil.
        const th = (q / ribN) * 1.42;
        const p = [b.x + side * 0 - 0.06 * q / ribN, Math.max(0.10, top[1] * Math.cos(th * 0.82) * (1 - splay * 0.4)),
                   side * w * Math.sin(th) * (1 + splay)];
        T(prev, p, vr * 0.62, vr * 0.5, q === ribN ? boneD : bone);
        prev = p;
      }
      if (rot > 0.02 && !lod) Ball([b.x, top[1] * 0.45, side * w * 0.7], 0.16 * b.r * rot, flesh);""",
"""      // A rib leaves the backbone going straight up and bows outward as it
      // rises, so the cage stands over the spine instead of hanging under it.
      // Slightly past a quarter turn, so the tips lean out rather than meeting.
      const arc = 1.78 + 0.30 * remRand(r, i * 11 + side);
      const h = ribH * (0.80 + 0.35 * b.r / maxR) * (0.86 + 0.28 * remRand(r, i * 13 + side));
      let prev = top;
      for (let q = 1; q <= ribN; q++) {
        const th = (q / ribN) * arc;
        const p = [b.x - 0.05 * q / ribN,
                   top[1] + h * Math.sin(th),
                   side * w * (1 - Math.cos(th)) * (0.92 + splay)];
        T(prev, p, vr * 0.62, vr * 0.46, q === ribN ? boneD : bone);
        prev = p;
      }
      if (rot > 0.02 && !lod) Ball([b.x, top[1] + h * 0.42, side * w * 0.62], 0.16 * b.r * rot, flesh);""")
s = sub1(s, "    if (rot > 0.02) El([b.x, hs * 0.35, 0], [1, 0, 0], b.r * 0.55 * rot, b.r * 0.5 * rot, b.r * 0.45 * rot, flesh);   // guts, shrinking",
            "    if (rot > 0.02) El([b.x, spineY + ribH * 0.22, 0], [1, 0, 0], b.r * 0.55 * rot, b.r * 0.5 * rot, b.r * 0.45 * rot, flesh);   // guts, shrinking")
# the neck runs along the ground from the backbone to the skull, not down from a high spine
s = sub1(s, "  let prevN = sp.length ? sp[sp.length - 1] : [0, hs, 0];",
            "  let prevN = sp.length ? sp[sp.length - 1] : [0, spineY, 0];")
s = sub1(s, "    const p = [n.x, Math.max(vr * 1.2, hs * (0.6 - 0.5 * (i + 1) / (neck.length + 1))), (i + 1) * 0.06 * (remRand(r, 90) - 0.5)];",
            "    const p = [n.x, Math.max(vr * 1.2, spineY * (1 - 0.45 * (i + 1) / (neck.length + 1))), (i + 1) * 0.06 * (remRand(r, 90) - 0.5)];")

open(p, 'w', encoding='utf-8').write(s)
print('ribs: arcing up ok')
