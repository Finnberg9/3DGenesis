# Physical attack moves: punch added, every animal can headbutt, the player
# picks the move (X cycles), AI strikes vary between their available moves.
def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
p='g3.html'; s=open(p,encoding='utf-8').read()
s=sub1(s,"""  headbutt: { label: 'headbutt',  dmg: 0.65, reach: 0.80, dur: 0.50 },
};""","""  headbutt: { label: 'headbutt',  dmg: 0.65, reach: 0.80, dur: 0.50 },
  punch:    { label: 'punch',     dmg: 0.90, reach: 1.00, dur: 0.42 },
};""")
s=sub1(s,"""  if (p.dSweep && !out.includes('sweep')) out.push('sweep');
  if (!out.length) out.push('headbutt');       // a baby has nothing else
  return out;""","""  if (p.dSweep && !out.includes('sweep')) out.push('sweep');
  if ((p.dArms || 0) > 0) out.push('punch');
  if (!out.includes('headbutt')) out.push('headbutt');   // anything with a head can butt
  return out;""")
s=sub1(s,"""function bestMove(p, n) {""","""// the move the player has chosen (X cycles), falling back to the strongest
function playerMove(p) {
  const list = movesFor(p, tallyParts(p));
  if (player.moveSel && list.includes(player.moveSel)) return player.moveSel;
  return bestMove(p, tallyParts(p));
}
function cycleMove() {
  const c = player.c; if (!c || !c.alive) return;
  const list = movesFor(c.ph, tallyParts(c.ph));
  const cur = playerMove(c.ph);
  player.moveSel = list[(list.indexOf(cur) + 1) % list.length];
  toast('attack: ' + MOVE_DEF[player.moveSel].label + '  (' + list.map(m => MOVE_DEF[m].label).join(' / ') + ')', 1800);
}
function bestMove(p, n) {""")
s=sub1(s,"""  const mv = bestMove(p, nn), MD = MOVE_DEF[mv];
  player.atkCD = MD.dur + 0.10;""","""  const mv = playerMove(p), MD = MOVE_DEF[mv];
  player.atkCD = MD.dur + 0.10;""")
s=sub1(s,"""    if (c._seenStrike != null && c !== player.c) startAnim(c, bestMove(p, tallyParts(p)), 0.5);""","""    if (c._seenStrike != null && c !== player.c) {
      // wild animals mix their moves: mostly the strongest, sometimes another
      const list = movesFor(p, tallyParts(p));
      const mv = Math.random() < 0.55 ? bestMove(p, tallyParts(p)) : list[(Math.random() * list.length) | 0];
      startAnim(c, mv, MOVE_DEF[mv].dur);
    }""")
s=sub1(s,"""    if (k === 'f') tryAttack();""","""    if (k === 'f') tryAttack();
    if (k === 'x') cycleMove();""")
s=sub1(s,"""'<div class="keys"><span class="hit">F</span> ' + MOVE_DEF[bestMove(mp, tallyParts(mp))].label + ' ' +""",
"""'<div class="keys"><span class="hit">F</span> ' + MOVE_DEF[playerMove(mp)].label + ' <span>X</span> switch ' +""")
s=sub1(s,"""<b>left click</b> / <b>F</b> attack &nbsp;""","""<b>left click</b> / <b>F</b> attack &nbsp;·&nbsp; <b>X</b> switch attack &nbsp;""")
open(p,'w',encoding='utf-8').write(s)
print('moves ok')
s=open(p,encoding='utf-8').read()
s=sub1(s,"""      case 'claw':     armSwing = sgn; lungeX = sgn * R * 0.42; headThrust = sgn * R * 0.15; break;""","""      case 'claw':     armSwing = sgn; lungeX = sgn * R * 0.42; headThrust = sgn * R * 0.15; break;
      case 'punch':    armSwing = sgn; lungeX = sgn * R * 0.35; break;""")
open(p,'w',encoding='utf-8').write(s)
