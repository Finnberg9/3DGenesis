# STANDING STILL
# An idle animal's legs kept sweeping through a small stride: the stride had a
# fixed floor (0.05 R) that the gait amount never scaled away, so a creature
# doing nothing paddled its feet back and forth forever. The floor is gone, and
# the gait phase stops advancing once the body is genuinely still, so a stopped
# animal holds its stance instead of drifting through a cycle of it.
def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
p='g3.html'; s=open(p,encoding='utf-8').read()

# the stride floor is what moved idle feet
s=sub1(s,"    const stride = R * (0.05 + 0.80 * gaitAmt);",
         "    const stride = R * 0.85 * gaitAmt;      // no floor: still is still")
# and the phase: once the gait has faded out, hold it where it is
s=sub1(s,"""  const gaitHz = 3.0 + c._spSm * 0.05;
  c._phase = (c._phase || (c.id % 6.283)) + gaitHz * frameDt;""",
"""  const gaitHz = 3.0 + c._spSm * 0.05;
  // The clock only runs while the animal is actually walking. Letting it run
  // through a standstill meant every idle body was mid-stride at some tiny
  // amplitude, which reads as a slow bob.
  if (c._phase == null) c._phase = c.id % 6.283;
  if (gaitAmt > 0.02) c._phase += gaitHz * frameDt;""")
open(p,'w',encoding='utf-8').write(s)
print('idle ok')
s=open(p,encoding='utf-8').read()

# the same floor on the designed/skinned path
import re
n = s.count("const stride = R * (0.05 + 0.80 * gaitAmt);")
if n:
    s = s.replace("const stride = R * (0.05 + 0.80 * gaitAmt);", "const stride = R * 0.85 * gaitAmt;")
    open(p,'w',encoding='utf-8').write(s)
print('idle floors cleared:', n)
