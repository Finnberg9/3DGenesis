# =====================================================================
# KIT AND SHOP: WHAT YOU HAVE, AND WHAT YOU DO NOT
#
# "Right now it's so hard to see what you have or not." It was: every
# category tab showed every part in the game, owned and unowned mixed
# together, told apart only by a small padlock and a line of grey text.
# Finding the one spike you actually own meant reading forty cards.
#
# Split in two, on the only line that matters to a player mid-match:
#
#   KIT   Everything you own, all categories at once, as a list. One row per
#         part: how many you have, how many are on the body, how many are
#         spare. Drag straight out of it onto the creature. This is the first
#         tab and the one that opens by default in a match.
#
#   SHOP  Everything you do not own, by rarity, with its price. Buying is the
#         only way a part moves from the right-hand list to the left-hand one.
#
# The category tabs stay -- they are how you browse by kind -- but they now
# show ONLY what you own. Nothing is listed anywhere that you cannot use,
# except in the shop, where being unable to use it is the point.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, ('ANCHOR %d/%d' % (n, cnt), a[:110]); return s.replace(a, b)

p = 'g3.html'; s = open(p, encoding='utf-8').read()

# ---------------------------------------------------------------- 1. two new tabs
s = sub1(s, """const VIS_CATS = [
  { id: 'body', label: 'body shape', hint: 'the skeleton everything else hangs on' },""",
"""const VIS_CATS = [
  { id: 'kit', label: 'your kit', hint: 'every part you own. drag one onto the body' },
  { id: 'body', label: 'body shape', hint: 'the skeleton everything else hangs on' },""")
s = sub1(s, """  { id: 'details', label: 'details', hint: 'crests, frills and display pieces' },
];""",
"""  { id: 'details', label: 'details', hint: 'crests, frills and display pieces' },
  { id: 'shop', label: 'the shop', hint: 'what you do not have yet, and what it costs' },
];""")

# ---------------------------------------------------------------- 2. the two lists
s = sub1(s, """  } else {
    const ids = Object.keys(VIS).filter(id => VIS[id].cat === ED.tab);
    html += '<div class="edgrid cards">';""",
r"""  } else if (ED.tab === 'kit' || ED.tab === 'shop') {
    // One row per part. The kit is what you own; the shop is the rest.
    const kit = ED.tab === 'kit';
    const all = Object.keys(VIS).filter((id) => C.ITEM_SIM[id]);
    const held = (id) => (SANDBOX ? 1 : Math.max(0, PROG.owned[id] | 0) + (ED.des ? countItem(ED.des, id) : 0));
    let ids = all.filter((id) => (held(id) > 0) === kit);
    if (kit) {
      // heaviest kit first: what you are proudest of is at the top
      ids.sort((x, y) => (boneTierIdx(boneTier(y)) - boneTierIdx(boneTier(x))) ||
                         ((PROG.owned[y] | 0) - (PROG.owned[x] | 0)) || (VIS[x].name < VIS[y].name ? -1 : 1));
    } else {
      // cheapest first, so the next thing you can afford is at the top
      ids.sort((x, y) => (bonePrice(x) - bonePrice(y)) || (VIS[x].name < VIS[y].name ? -1 : 1));
    }
    const bal = boneBalance();
    if (!ids.length) {
      html += '<div class="edempty">' + (kit
        ? 'You own nothing yet.<br><span>Kill something and take a part off it, or buy one in the shop.</span>'
        : 'You own every part in the game.<br><span>There is nothing left to buy.</span>') + '</div>';
    }
    html += '<div class="edlist">';
    let lastTier = null;
    for (const id of ids) {
      const v = VIS[id], tier = boneTier(id), col = BONE_TIER_COL[tier];
      const nOwn = SANDBOX ? Infinity : Math.max(0, PROG.owned[id] | 0);
      const worn = ED.des ? countItem(ED.des, id) : 0;
      const sp = spareOf(id);
      const price = bonePrice(id);
      if (!kit && tier !== lastTier) { lastTier = tier; html += `<div class="edpl" style="color:${col}">${BONE_TIER_LABEL[tier]} &middot; ${price} bones</div>`; }
      const cat = (VIS_CATS.find((c2) => c2.id === v.cat) || { label: v.cat });
      html += `<div class="edrowi${kit ? ' edcard' : ' shopr'}" data-item="${id}">` +
        `<div class="edtile item" data-item="${id}">${tileHTML(id, kit || SANDBOX)}</div>` +
        `<div class="edrowt">` +
          `<div class="edrown">${v.name}` +
            (kit && nOwn !== Infinity ? `<span class="edrowq">&times;${nOwn}</span>` : '') +
            `<span class="edtierb" style="color:${col}">${BONE_TIER_LABEL[tier]}</span></div>` +
          `<div class="edrowm">` +
            (kit
              ? (SANDBOX ? 'sandbox &middot; unlimited'
                 : `${worn} on the body &middot; <b class="${sp ? '' : 'none'}">${sp} to place</b> &middot; ${itemCost(id)} space each`)
              : `${cat.label} &middot; ${itemCost(id)} space &middot; ${v.use || effectText(id) || ''}`) +
          `</div>` +
        `</div>` +
        (kit
          ? (!SANDBOX && !brLocked() && sp > 0 ? `<button class="edsell" data-sell="${id}">sell one &middot; ${boneRefund(id)}</button>` : '')
          : (!brLocked() ? `<button class="edbuy${bal >= price ? '' : ' poor'}" data-buy="${id}" style="border-color:${col}"><span>buy</span><b style="color:${col}">${price}</b></button>`
                         : '<span class="edrowlk">shut in a match</span>')) +
        `</div>`;
    }
    html += '</div>';
    html += kit
      ? '<div class="edhint">drag a row onto the creature to wear it. a part you are wearing cannot be sold: take it off first</div>'
      : '<div class="edhint">bones come from kills. anything you buy lands in your kit and stays there between matches</div>';
  } else {
    // A category tab lists only what you own. Everything else is in the shop.
    const ids = Object.keys(VIS).filter(id => VIS[id].cat === ED.tab &&
      (SANDBOX || (PROG.owned[id] | 0) > 0 || (ED.des ? countItem(ED.des, id) : 0) > 0));
    if (!ids.length) {
      html += '<div class="edempty">Nothing of this kind in your kit.<br><span>The shop has them. Last tab.</span></div>';
    }
    html += '<div class="edgrid cards">';""")

open(p, 'w', encoding='utf-8').write(s)
print('kit: lists ok')

# ---------------------------------------------------------------- 3. the look of a list
s = open(p, encoding='utf-8').read()
s = sub1(s, "  /* ================= LOADOUT SKIN =================================== */",
r"""  /* a row: thumbnail, name and numbers, one action on the right */
  .edlist { display: flex; flex-direction: column; }
  .edrowi { display: flex; align-items: center; gap: 11px; padding: 7px 2px;
    border-bottom: 1px solid rgba(196,186,166,.07); cursor: grab; }
  .edrowi.shopr { cursor: default; }
  .edrowi:hover { background: rgba(255,255,255,.035); }
  .edrowi .edtile { width: 46px; height: 46px; flex: 0 0 46px; aspect-ratio: auto; }
  .edrowt { flex: 1; min-width: 0; }
  .edrown { font-size: 12.5px; font-weight: 600; letter-spacing: .08em; text-transform: uppercase;
    display: flex; align-items: baseline; gap: 7px; }
  .edrowq { font-size: 13px; font-weight: 700; letter-spacing: .02em; }
  .edrowm { font-size: 10.5px; letter-spacing: .04em; margin-top: 2px;
    overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .edrowm b.none { opacity: .45; }
  .edrowlk { font-size: 10px; letter-spacing: .12em; text-transform: uppercase; }
  .edempty { padding: 26px 8px; text-align: center; font-size: 12px; letter-spacing: .10em;
    text-transform: uppercase; line-height: 1.9; }
  .edempty span { font-size: 10.5px; letter-spacing: .06em; text-transform: none; }
  /* ================= LOADOUT SKIN =================================== */""")
s = sub1(s, """  /* the loot picker that appears over a kill */""",
r"""  /* the two lists, in the skin's own palette */
  .edrowi { border-bottom-color: rgba(196,186,166,.08); }
  .edrowi:hover { background: rgba(255,255,255,.04); }
  .edrown { color: var(--bone); }
  .edrowq { color: var(--bone); }
  .edrowm { color: var(--bone-f); }
  .edrowm b { color: var(--bone-d); font-weight: 600; }
  .edrowlk { color: var(--bone-f); }
  .edempty { color: var(--bone-d); }
  .edempty span { color: var(--bone-f); }
  .edrowi .edtile { background: #0b0b0e; border-color: rgba(196,186,166,.10); }
  .edbuy, .edsell { border-radius: 0; font-size: 10.5px; letter-spacing: .14em; text-transform: uppercase;
    padding: 7px 11px; background: rgba(255,255,255,.03); border: 1px solid var(--rule); color: var(--bone-d);
    width: auto; margin-top: 0; flex: 0 0 auto; }
  .edbuy { gap: 9px; }
  .edbuy b { font-size: 11.5px; letter-spacing: .02em; }
  .edbuy:hover { background: rgba(255,255,255,.075); color: var(--bone); }
  .edbuy.poor { opacity: .32; }
  .edsell:hover { border-color: rgba(194,64,44,.55); color: #e0b4a8; background: rgba(120,28,18,.20); }
  .edsell.arm { border-color: var(--blood-l); color: #f0c8bc; background: rgba(150,36,22,.32); }
  .edcard .edcname { color: var(--bone); font-size: 11.5px; letter-spacing: .10em; text-transform: uppercase; font-weight: 600; }
  .edcuse { color: var(--bone-f); }
  .edccost { color: var(--bone-f); letter-spacing: .05em; }
  .edstock { color: var(--bone-d); letter-spacing: .05em; }
  .edstock.none { color: var(--bone-f); }
  .edhave { background: rgba(0,0,0,.72); color: var(--bone); border: 1px solid var(--rule); border-radius: 0; }
  .edowned { color: var(--bone-f); }
  /* the loot picker that appears over a kill */""")

open(p, 'w', encoding='utf-8').write(s)
print('kit: list styling ok')

# ---------------------------------------------------------------- 4. it opens on your kit
# Mid-game the builder opened on "mouths", which is a category, not an answer
# to the question you opened it to ask -- which is "what have I got".
s = open(p, encoding='utf-8').read()
s = sub1(s, """    ED.statBrain = c.genome.brain; ED.statScale = c.genome.scale || 1;
    ED.tab = 'mouth';""",
"""    ED.statBrain = c.genome.brain; ED.statScale = c.genome.scale || 1;
    ED.tab = 'kit';""")
# and the "you need a mouth" nudge points at the shop when you have not got one
s = sub1(s, """    if (!hasMouth) { edFlash('Your creature needs a mouth to eat. Add one from the mouths tab.'); ED.tab = 'mouth'; edRefreshUI(); return; }""",
"""    if (!hasMouth) {
      const own = Object.keys(VIS).some((id) => VIS[id].cat === 'mouth' && ((PROG.owned[id] | 0) > 0));
      edFlash(own ? 'Your creature needs a mouth. There is one in your kit.'
                  : 'Your creature needs a mouth. You do not own one: take one off a body, or buy one in the shop.');
      ED.tab = own ? 'kit' : 'shop';
      edRefreshUI(); return;
    }""")

# ---------------------------------------------------------------- 5. test surface
s = sub1(s, "    // the palette IS the shop now\n    tab: (t) => { ED.tab = t; edRefreshUI(); },",
"""    // the palette IS the shop now
    tab: (t) => { ED.tab = t; edRefreshUI(); },
    get curTab() { return ED.tab; },
    // what each of the two lists is showing right now
    rows: () => [...document.querySelectorAll('#edGrid .edrowi')].map((e) => ({
      id: e.getAttribute('data-item'),
      name: (e.querySelector('.edrown') || {}).textContent || '',
      meta: (e.querySelector('.edrowm') || {}).textContent || '',
      buy: !!e.querySelector('[data-buy]'), sell: !!e.querySelector('[data-sell]'),
      drag: e.classList.contains('edcard'),
    })),
    cards: () => [...document.querySelectorAll('#edGrid .edgrid.cards .edcard')].map((e) => e.getAttribute('data-item')),
    empty: () => { const e = document.querySelector('#edGrid .edempty'); return e ? e.textContent : null; },""")

open(p, 'w', encoding='utf-8').write(s)
print('kit: defaults and surface ok')
