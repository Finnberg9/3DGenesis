# =====================================================================
# THE SHAPE TILES WERE HIDING THE CREATURE
#
#   d.parts = d.parts.filter(q => sim.t === 'FIN' || sim.t === 'WING')
#
# Every plan tile was rendered with all its parts thrown away except wings
# and fins. No eyes, no jaws, no horns, no spikes, no crests, no tendrils.
# So the picker showed fourteen bare torsos, which is exactly why they read
# as blobs and sticks -- and why all four fliers looked identical, since the
# one part any of them was allowed to keep was the wing.
#
# It was presumably meant to keep a SHAPE picker about shape. But the shape
# you pick comes with a body, and hiding the head that comes with it is the
# picker lying about what you are choosing.
#
# The tile draws the whole animal now, still flat grey so it reads as a
# silhouette rather than as a painted creature.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, ('ANCHOR %d/%d' % (n, cnt), a[:110]); return s.replace(a, b)

p = 'g3.html'; s = open(p, encoding='utf-8').read()

s = sub1(s, """      const d = C.defaultDesign(j.plan);
      d.parts = (d.parts || []).filter(q => { const sim = C.ITEM_SIM[q.id]; return sim && (sim.t === 'FIN' || sim.t === 'WING'); });""",
"""      const d = C.defaultDesign(j.plan);
      // The whole animal, not a bare torso. A body plan arrives wearing a
      // head, a jaw, horns and whatever else it is born with, and a picker
      // that hides all of it is not showing you the thing you are choosing.""")
# a silhouette wants a touch more camera distance now that there is a head on it
s = sub1(s, "      view = [0.62, 0.30, 0.74];", "      view = [0.60, 0.26, 0.80];")

open(p, 'w', encoding='utf-8').write(s)
print('tiles: the whole creature ok')

# A wing is a flat membrane. Viewed from the side it is a line, which is
# exactly what all four fliers were showing: one long needle and a lump. They
# are looked at from above and in front now, so the wing shows its AREA, which
# is the only thing that distinguishes one winged animal from another at
# thumbnail size.
s = open(p, encoding='utf-8').read()
s = sub1(s, "      view = [0.60, 0.26, 0.80];",
"""      const winged = (d.parts || []).some((q) => { const sim = C.ITEM_SIM[q.id]; return sim && sim.t === 'WING'; });
      view = winged ? [0.30, 0.74, 0.60] : [0.60, 0.26, 0.80];""")
open(p, 'w', encoding='utf-8').write(s)
print('tiles: wings seen from above ok')
