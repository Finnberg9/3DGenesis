# =====================================================================
# THE STARTING PACK IS A WORKING ANIMAL
#
# The cage pile held a mouth and one random weapon. That is not a creature:
# with no eyes you cannot see and with no spare limbs you cannot change how
# you stand, so the first thing every player did was walk out of the cage
# with the body they were handed and no way to alter it.
#
# The pack is now the three things a body actually needs -- EYES, LIMBS and a
# MOUTH -- all from the common tier, and sometimes one extra. Everything in
# it comes as a PAIR, because a body is bilateral and one of anything cannot
# be placed symmetrically.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, ('ANCHOR %d/%d' % (n, cnt), a[:110]); return s.replace(a, b)

p = 'g3.html'; s = open(p, encoding='utf-8').read()

s = sub1(s, """const BR_PILE_MOUTHS = ['m_beak', 'm_grazer', 'm_jaws', 'm_hook', 'm_duck'];
const BR_PILE_ARMS = ['s_spike', 's_knob', 's_quills', 's_plate', 't_claw', 't_talon', 'h_straight', 'h_curved'];
function brPileFor(slot) {
  const r = carcRng(carcHash(slot | 0, 0x10de, BR.seed >>> 0));
  return [BR_PILE_MOUTHS[Math.floor(r() * BR_PILE_MOUTHS.length)],
          BR_PILE_ARMS[Math.floor(r() * BR_PILE_ARMS.length)]];
}""",
"""// The three things a body cannot work without, plus a maybe. Common tier
// only: the pack is a working animal, not a head start.
const BR_PILE_EYES = ['e_round', 'e_slit'];
const BR_PILE_LIMBS = ['l_leg', 'l_thin'];
const BR_PILE_MOUTHS = ['m_beak', 'm_grazer', 'm_jaws', 'm_hook'];
// Sometimes one more thing. Deliberately not always, and never better than
// solid, so two players' packs are never far apart.
const BR_PILE_EXTRA = ['s_spike', 's_knob', 't_paw', 't_talon', 'h_straight', 'd_frill', 't_claw'];
const BR_PILE_PAIR = 2;          // a body is bilateral: everything comes in twos
function brPileFor(slot) {
  const r = carcRng(carcHash(slot | 0, 0x10de, BR.seed >>> 0));
  const out = [
    BR_PILE_EYES[Math.floor(r() * BR_PILE_EYES.length)],
    BR_PILE_LIMBS[Math.floor(r() * BR_PILE_LIMBS.length)],
    BR_PILE_MOUTHS[Math.floor(r() * BR_PILE_MOUTHS.length)],
  ];
  if (r() < 0.55) out.push(BR_PILE_EXTRA[Math.floor(r() * BR_PILE_EXTRA.length)]);
  return out;
}""")
s = sub1(s, """  const ids = brPileFor(BR.slot);
  for (const id of ids) ownedGain(id, 1);
  BR._pileTaken = true;
  FOL.key = '';                       // the heap comes off the floor now
  const names = ids.map((id) => (VIS[id] ? VIS[id].name : id)).join(' and a ');
  toast('You take a ' + names + '. Press B to put them on before the gate opens.', 5000);""",
"""  const ids = brPileFor(BR.slot);
  for (const id of ids) ownedGain(id, BR_PILE_PAIR);
  BR._pileTaken = true;
  FOL.key = '';                       // the heap comes off the floor now
  const names = ids.map((id) => (VIS[id] ? VIS[id].name : id));
  toast('You take a pair each of ' + names.join(', ') + '. Press B to put them on before the gate opens.', 5500);""")
s = sub1(s, """      const ids = brPileFor(BR.slot).map((id) => (VIS[id] ? VIS[id].name : id));
      act.innerHTML = '<div class="acth" style="color:#f5d98a">YOUR STARTING KIT</div>' +
        '<div class="keys"><span class="ok">E</span> take the pile &middot; a ' + ids[0] + ' and a ' + ids[1] +
        ' &middot; <span class="ok">B</span> to put them on</div>';""",
"""      const ids = brPileFor(BR.slot).map((id) => (VIS[id] ? VIS[id].name : id));
      act.innerHTML = '<div class="acth" style="color:#f5d98a">YOUR STARTING KIT</div>' +
        '<div class="keys"><span class="ok">E</span> take the pile &middot; a pair each of ' + ids.join(', ') +
        ' &middot; <span class="ok">B</span> to put them on</div>';""")
open(p, 'w', encoding='utf-8').write(s)
print('pile ok')
