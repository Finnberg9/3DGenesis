# First person: see your own body. The body is drawn, the eyes on your own
# head are hidden (they would sit right next to the lens), and the camera sits
# just in front of the head so you look out over your snout and down at your
# own legs, arms and weapons.
def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
p='g3.html'; s=open(p,encoding='utf-8').read()
s=sub1(s,"    if (c === player.c && isFirstPerson()) continue;",
         "    if (c === player.c && isFirstPerson() && !(c.genome && c.genome.design)) continue;   // designed bodies are visible in first person")
s=sub1(s,"    hide: deadTypes(c), gaitPhase:","    hide: fpHide(c, deadTypes(c)), fpHead: c === player.c && isFirstPerson(), gaitPhase:")
s=sub1(s,"""  const toW = (l0) => { const l = tilt(l0); return [A.wx(l[0] * Rw, l[2] * Rw), A.bodyY + l[1] * Rw, A.wz(l[0] * Rw, l[2] * Rw)]; };""",
"""  const toW = (l0) => { const l = tilt(l0); return [A.wx(l[0] * Rw, l[2] * Rw), A.bodyY + l[1] * Rw, A.wz(l[0] * Rw, l[2] * Rw)]; };
  if (c === player.c) fpRecordEye(c, G, toW, Rw, A.yaw);""")
s=sub1(s,"function deadTypes(c) {","""// ---- first-person body ----------------------------------------------------------
// Where the eye sits, stored relative to the body (forward / up from the ground
// under it), so the camera follows this frame's position without a frame of lag.
function fpRecordEye(c, G, toW, Rw, yaw) {
  // the eye sits just above and inside the top of the head: the head and neck
  // fold away (skinned bodies), so you look out over your own shoulders and
  // down at your legs, and are never inside your own skin
  const sk = G.sk, hb = sk.balls[sk.headIdx];
  if (!hb) { c._fpOff = null; return; }
  const w = toW([hb.x + hb.r * 0.15, hb.y + hb.r * 1.1 + 0.15, 0]);
  const dx = w[0] - c.x, dz = w[2] - c.y;
  const fwd = dx * Math.cos(yaw) + dz * Math.sin(yaw);
  // clear of the skin by more than the near plane, whatever the body size
  c._fpOff = { f: fwd, y: w[1] - groundAt(c.x, c.y) - (player.jumpY || 0) - (player.fly || 0) };
}
function fpHide(c, dead) {
  if (c !== player.c || !isFirstPerson()) return dead;
  const s = new Set(dead || []);
  s.add('EYE'); s.add('MOUTH');   // both sit right at the lens
  return s;
}
function deadTypes(c) {""")
s=sub1(s,"""    const fwd = (bx * 0.35 + nk * bx * 0.25) * BODY_SCALE;
    player.camX = clamp(c.x + Math.cos(player.yaw) * fwd, 0, WORLD_W);
    player.camZ = clamp(c.y + Math.sin(player.yaw) * fwd, 0, WORLD_H);
    const eye = Math.max(headY, groundAt(player.camX, player.camZ)
                + ((p.standH || p.radius) * 0.6) * BODY_SCALE + NEAR * 3) + player.jumpY;""","""    const fo = c.genome && c.genome.design ? c._fpOff : null;
    const fwd = fo ? fo.f : (bx * 0.35 + nk * bx * 0.25) * BODY_SCALE;
    player.camX = clamp(c.x + Math.cos(player.yaw) * fwd, 0, WORLD_W);
    player.camZ = clamp(c.y + Math.sin(player.yaw) * fwd, 0, WORLD_H);
    const eye = fo ? Math.max(groundAt(c.x, c.y) + fo.y, groundAt(player.camX, player.camZ) + NEAR * 3) + player.jumpY
                   : Math.max(headY, groundAt(player.camX, player.camZ)
                + ((p.standH || p.radius) * 0.6) * BODY_SCALE + NEAR * 3) + player.jumpY;""")
open(p,'w',encoding='utf-8').write(s)
print('fp ok')
