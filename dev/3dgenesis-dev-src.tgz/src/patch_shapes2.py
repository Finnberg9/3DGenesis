# =====================================================================
# SECOND LOOK
#
# Rendered the fourteen and actually looked at them this time. The land
# shapes read: the splayed arthropods are arthropods, the hunched ones are
# hunched, the heads hang. Four things did not:
#
#   THE FLIERS ARE THE SAME BIRD FOUR TIMES. All four had a long needle
#   snout, and the snout is most of what a small silhouette is. Only ONE of
#   them should have that: the skimmer, whose whole identity is a beak
#   carried out level. The flit gets a short one, the moth gets none at all
#   -- moths have no beak -- and the drake gets a jaw rather than a spike.
#
#   THE MOTH HAS A SMALLER WINGSPAN THAN THE DRAKE. Its whole point is being
#   almost entirely wing.
#
#   THE LURKER IS A PLAIN BALL. It needs the thing that makes a Monsters Inc
#   silhouette work: one enormous feature. Its mouth is the width of its
#   body, so the body has to be short and tall and the head has to be most
#   of the front of it.
#
#   THE HYDRA IS A SAUSAGE. Its neck was long in the numbers and invisible in
#   the render because the neck balls taper to nothing: a long neck that is
#   thin everywhere reads as a snout on a log. Thicker, and rising.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, ('ANCHOR %d/%d' % (n, cnt), a[:110]); return s.replace(a, b)
import re

p = 'g3.html'; s = open(p, encoding='utf-8').read()

ROWS = [
 # A short beak, a round body, upright: a bird, not a dart.
 (34, "{ a: 0.50, b: 0.44, seg: 9,  prof: 'round',  arch: 0.24, droop: 0.00, wide: 0.10, neck: 0.55, nx: 0.55, ny: 0.75,  ns: 3, head: 0.30, snx: 0.42, snr: 0.34, tail: 0.9, tailR: 0.14, ts: 5, stand: 1.15, hump: 0.40 }, // 34 flit: small, round and upright, with a stubby beak"),
 # No beak at all, a fat furry thorax, and the wings do the talking.
 (35, "{ a: 0.46, b: 0.52, seg: 9,  prof: 'blob',   arch: 0.14, droop: 0.00, wide: 0.24, neck: 0.10, nx: 0.85, ny: 0.10,  ns: 2, head: 0.30, snx: 0.22, snr: 0.34, tail: 0.5, tailR: 0.16, ts: 4, stand: 0.40, waist: 0.44, waistAt: 0.42, waistW: 0.12 }, // 35 mothwing: a blunt furred body with no beak whatever"),
 # THE long beak in the set, carried out level. This one owns that shape.
 (37, "{ a: 0.86, b: 0.46, seg: 9,  prof: 'animal', arch: 0.26, droop: 0.00, wide: 0,    neck: 1.05, nx: 0.78, ny: -0.06, ns: 4, head: 0.40, snx: 1.55, snr: 0.26, tail: 0.25, tailR: 0.10, ts: 4, stand: 1.00, hump: 0.55 }, // 37 skimmer: the one long beak, held out level on a folded frame"),
 # A jaw, not a spike, and a neck thick enough to see.
 (36, "{ a: 1.52, b: 0.74, seg: 13, prof: 'animal', arch: 0.46, droop: 0.06, wide: 0.12, neck: 2.30, nx: 0.58, ny: 0.62,  ns: 7, head: 0.46, snx: 0.62, snr: 0.50, tail: 2.7, tailR: 0.30, ts: 10, stand: 1.65, hump: 0.70, waist: 0.20, waistAt: 0.34 }, // 36 drake: a raised shoulder, a thick neck that rears, a heavy jaw, a long tail"),
 # Short, tall and almost all face.
 (30, "{ a: 0.82, b: 1.30, seg: 9,  prof: 'round',  arch: 0.40, droop: 0.04, wide: 0.50, neck: 0.20, nx: 0.88, ny: -0.42, ns: 2, head: 1.05, snx: 0.42, snr: 1.00, tail: 0.0, tailR: 0.20, ts: 3, stand: 0.95, hump: 0.80 }, // 30 lurker: a short tall boulder whose front IS its face"),
 # The neck has to be thick enough to read as a neck.
 (24, "{ a: 1.10, b: 0.86, seg: 12, prof: 'animal', arch: 0.42, droop: 0.14, wide: 0.24, neck: 2.90, nx: 0.52, ny: 0.62,  ns: 9, head: 0.34, snx: 0.62, snr: 0.42, tail: 1.6, tailR: 0.22, ts: 8, stand: 1.30, hump: 0.60, waist: 0.24, waistAt: 0.34 }, // 24 hydra: a short heavy body under a neck that rises and reaches"),
]
for idx, row in ROWS:
    m = re.search(r"^    \{ a:[^\n]*\},\s*// %d\b[^\n]*$" % idx, s, re.M)
    assert m, 'no row for plan %d' % idx
    s = s[:m.start()] + '    ' + row + s[m.end():]

# A long neck that tapers to a thread is a snout on a log. Give the neck real
# thickness, scaled off the body, so it reads as a neck at thumbnail size.
s = sub1(s, "      const r = neckLen > 0.12 ? (0.34 - 0.10 * u) * (1 + NK * 0.15) : 0.0001;",
"""      // Thickness comes off the BODY, not a flat 0.34: on a big animal a
      // constant-width neck vanishes, which is why the long-necked plans all
      // rendered as a snout stuck on a log.
      const r = neckLen > 0.12 ? (0.30 + 0.55 * b) * (1 - 0.34 * u) * (1 + NK * 0.10) : 0.0001;""")

# the wings each flier is born with, so the moth really is mostly wing
s = sub1(s, """        put('w_feather', a * 0.05, b * 0.62, b * 0.58, 0, 0.7, 0.7, 1.15, true);
        put('d_crest', head.x - hr * 0.25, head.y + hr, 0, -0.3, 1, 0, 0.8, false);""",
"""        put('w_feather', a * 0.05, b * 0.62, b * 0.58, 0, 0.7, 0.7, 1.05, true);
        put('d_crest', head.x - hr * 0.25, head.y + hr, 0, -0.3, 1, 0, 0.8, false);""")
s = sub1(s, """        put('w_bat', a * 0.10, b * 0.55, b * 0.45, 0, 0.55, 0.85, 2.4, true);
        put('w_insect', -a * 0.35, b * 0.40, b * 0.42, -0.2, 0.5, 0.85, 1.5, true);""",
"""        // almost entirely wing: two pairs, both enormous
        put('w_bat', a * 0.18, b * 0.50, b * 0.42, 0, 0.50, 0.88, 3.6, true);
        put('w_insect', -a * 0.30, b * 0.42, b * 0.44, -0.2, 0.45, 0.88, 2.8, true);""")

open(p, 'w', encoding='utf-8').write(s)
print('shapes2: fliers, lurker and hydra ok')
