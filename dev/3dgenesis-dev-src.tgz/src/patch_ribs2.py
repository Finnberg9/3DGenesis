# =====================================================================
# THE RIBS CLOSE OVER THE SPINE
#
# They arced up, but they never came back. `z = w * (1 - cos(th))` only ever
# grows, so every rib swept outward for its whole length and the cage read as
# a row of spokes off a stick -- a fern, not a ribcage.
#
# A rib leaves the backbone, bows OUT at the middle of its arc, and comes back
# IN at the tip, so the left and right sides reach toward each other over the
# spine:
#
#   z = w * sin(th)          out at th = pi/2, back to nothing at th = pi
#   y = h * (1 - cos(th))/2  rising the whole way, full height at the tip
#
# The arc stops a little short of pi so the tips lean toward each other
# without meeting, which is what a broken cage in the dirt looks like, and
# more segments so the sweep is a curve rather than four faceted tubes.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, ('ANCHOR %d/%d' % (n, cnt), a[:110]); return s.replace(a, b)

p = 'g3.html'; s = open(p, encoding='utf-8').read()

s = sub1(s, "  const ribN = lod ? 3 : 4;", "  const ribN = lod ? 4 : 7;")
s = sub1(s, """      const arc = 1.78 + 0.30 * remRand(r, i * 11 + side);
      const h = ribH * (0.80 + 0.35 * b.r / maxR) * (0.86 + 0.28 * remRand(r, i * 13 + side));
      let prev = top;
      for (let q = 1; q <= ribN; q++) {
        const th = (q / ribN) * arc;
        const p = [b.x - 0.05 * q / ribN,
                   top[1] + h * Math.sin(th),
                   side * w * (1 - Math.cos(th)) * (0.92 + splay)];
        T(prev, p, vr * 0.62, vr * 0.46, q === ribN ? boneD : bone);
        prev = p;
      }
      if (rot > 0.02 && !lod) Ball([b.x, top[1] + h * 0.42, side * w * 0.62], 0.16 * b.r * rot, flesh);""",
"""      // Just short of a half turn: the tips lean toward each other over the
      // spine without meeting, which is what a broken cage in the dirt is.
      const arc = 2.62 + 0.26 * remRand(r, i * 11 + side);
      const h = ribH * (0.85 + 0.40 * b.r / maxR) * (0.88 + 0.26 * remRand(r, i * 13 + side));
      let prev = top;
      for (let q = 1; q <= ribN; q++) {
        const th = (q / ribN) * arc;
        const p = [b.x - 0.05 * q / ribN,
                   top[1] + h * (1 - Math.cos(th)) * 0.5,
                   side * w * Math.sin(th) * (1.05 + splay)];
        T(prev, p, vr * 0.60, vr * 0.42, q === ribN ? boneD : bone);
        prev = p;
      }
      // the shrivelled meat still on it sits at the widest part of the bow
      if (rot > 0.02 && !lod) Ball([b.x, top[1] + h * 0.5, side * w * 0.85], 0.16 * b.r * rot, flesh);""")

open(p, 'w', encoding='utf-8').write(s)
print('ribs2: the cage closes ok')
