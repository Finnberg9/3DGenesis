# =====================================================================
# CARCASSES ON THE GROUND, AND INSPECTING A BODY.
#
# The island only had bones where something had died while you were watching,
# which in the opening minutes of a match is nowhere. The roadmap's hook --
# "each remains entry should carry its creature's design parts so they can be
# picked up" -- is wired up here, and the world is seeded with old carcasses
# that were already there when you arrived.
#
# The field is STREAMED and DETERMINISTIC, the way the foliage is: one
# candidate per cell of the map, presence and position and body rolled from
# the world seed and the cell, built only while you are near it and dropped
# again when you leave. So it costs nothing to have carcasses over the whole
# 51200 x 32000 island, and every player in a match finds the same bodies in
# the same places.
#
# Each one carries a real design rolled from the same generator wild animals
# come from, at the world's own rarity ceiling, so what is lying on the ground
# is a plausible dead animal and the parts on it are worth having. You walk up
# to a body, inspect it, and take ONE part off it; the body is then picked
# clean, for good.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, (a[:100], n); return s.replace(a, b)
p = 'g3.html'; s = open(p, encoding='utf-8').read()

# ---------------------------------------------------------------- remains carry their parts
s = sub1(s, """  REMAINS.push({
    x: c.x, z: c.y, yaw: c._yaw3 != null ? c._yaw3 : Math.atan2(c.vy || 0, c.vx || 1),
    R: (c.ph.radius || 4) * BODY_SCALE, G, t0: simT,
    seed: (c.id * 2654435761) >>> 0,
    hide: deadTypes(c),
  });""",
"""  REMAINS.push({
    x: c.x, z: c.y, yaw: c._yaw3 != null ? c._yaw3 : Math.atan2(c.vy || 0, c.vx || 1),
    R: (c.ph.radius || 4) * BODY_SCALE, G, t0: simT,
    seed: (c.id * 2654435761) >>> 0,
    hide: deadTypes(c),
    // What it was wearing, so the body can be searched. This is the roadmap's
    // hook: a skeleton is loot, not scenery.
    design: c.genome.design, parts: designItems(c.genome.design), looted: false,
  });""")

# ---------------------------------------------------------------- the carcass field
s = sub1(s, """// deterministic per-skeleton jitter so bones do not lie in perfect symmetry""",
"""// =====================================================================
// THE CARCASS FIELD
// Old bodies that were on the island before you got there. One candidate per
// CARC_CELL square, rolled from the world seed, so the whole map is covered
// for the cost of the handful within sight.
// =====================================================================
const CARC_CELL = 1150;          // one candidate per cell this wide
const CARC_CHANCE = 0.46;        // ...and this often
const CARC_KEEP = 2600;          // built while this close, dropped beyond it
const CARC_DRAW = 1250;
const CARC_BUILD_PER_FRAME = 1;  // one skeleton a frame: it streams, never hitches
const CARC = { cells: new Map(), live: [], q: [], seed: 0, t: 0 };
function carcHash(a, b, c) {
  let h = (Math.imul(a | 0, 73856093) ^ Math.imul(b | 0, 19349663) ^ Math.imul(c | 0, 83492791)) >>> 0;
  h = Math.imul(h ^ (h >>> 15), 2246822519) >>> 0;
  h = Math.imul(h ^ (h >>> 13), 3266489917) >>> 0;
  return (h ^ (h >>> 16)) >>> 0;
}
function carcRng(seed) {
  let h = seed >>> 0;
  return () => { h = Math.imul(h ^ (h >>> 15), 2246822519) >>> 0; h = Math.imul(h ^ (h >>> 13), 3266489917) >>> 0; return ((h ^ (h >>> 16)) >>> 0) / 4294967296; };
}
// The cheap half: does this cell hold a body, and where. No geometry.
function carcPlan(ix, iz) {
  const key = ix + ',' + iz;
  if (CARC.cells.has(key)) return CARC.cells.get(key);
  const h = carcHash(ix, iz, CARC.seed);
  const rnd = carcRng(h);
  let ent = null;
  if (rnd() < CARC_CHANCE) {
    const x = (ix + 0.12 + rnd() * 0.76) * CARC_CELL;
    const z = (iz + 0.12 + rnd() * 0.76) * CARC_CELL;
    // nothing rots on the sea floor, and nothing lies on a cliff
    if (x > 60 && z > 60 && x < WORLD_W - 60 && z < WORLD_H - 60 && !terrain.isWater(x, z)) {
      ent = { key, x, z, yaw: rnd() * 6.2832, seed: h, rnd: h,
              age: REMAINS_ROT * (0.6 + rnd() * 3.2),   // all of them old, to varying degrees
              G: null, design: null, parts: null, looted: false, carcass: true, R: 4 };
    }
  }
  CARC.cells.set(key, ent);
  return ent;
}
// The expensive half: roll the body and build its skeleton. Done off a queue,
// one a frame, so walking into a new stretch of map never costs a hitch.
function carcBuild(ent) {
  if (!ent || ent.G) return;
  try {
    const rnd = carcRng(ent.seed ^ 0x5bf03635);
    const d = C.randomDesign(rnd, { rarityCap: (world && world.rarityCap) || 'ultra', diversity: 0.85 });
    const G = designGeo(d);
    if (!G || !G.sk) { ent.dead = true; return; }
    ent.design = d;
    ent.parts = designItems(d).filter(id => VIS[id]);
    ent.G = G;
    ent.R = (G.cls && G.cls.radius ? G.cls.radius : 4) * BODY_SCALE;
    if (!(ent.R > 0.5)) ent.R = 4 * BODY_SCALE;
  } catch (e) { ent.dead = true; }
}
// Keep the cells around the player loaded and everything else dropped.
function carcTick(dt) {
  if (!world || !terrain) return;
  CARC.seed = (world.seed | 0) >>> 0;
  CARC.t += dt;
  if (CARC.t < 0.25 && CARC.live.length) { carcDrainQueue(); return; }
  CARC.t = 0;
  const px = player.camX, pz = player.camZ;
  const i0 = Math.floor((px - CARC_KEEP) / CARC_CELL), i1 = Math.floor((px + CARC_KEEP) / CARC_CELL);
  const j0 = Math.floor((pz - CARC_KEEP) / CARC_CELL), j1 = Math.floor((pz + CARC_KEEP) / CARC_CELL);
  const live = [];
  for (let i = i0; i <= i1; i++) for (let j = j0; j <= j1; j++) {
    const e = carcPlan(i, j);
    if (!e || e.dead) continue;
    if (Math.hypot(e.x - px, e.z - pz) > CARC_KEEP) continue;
    live.push(e);
    if (!e.G && CARC.q.indexOf(e) < 0) CARC.q.push(e);
  }
  CARC.live = live;
  carcDrainQueue();
}
function carcDrainQueue() {
  for (let n = 0; n < CARC_BUILD_PER_FRAME && CARC.q.length; n++) {
    const e = CARC.q.shift();
    if (e && !e.G && !e.dead) carcBuild(e);
  }
}
function drawCarcasses() {
  for (const e of CARC.live) {
    if (!e.G) continue;
    const d = Math.hypot(e.x - player.camX, e.z - player.camZ);
    if (d > CARC_DRAW) continue;
    // Held at an age past the rot but short of burial, so an old body stays an
    // old body instead of sinking away while you are looking for it.
    drawSkeleton(e, Math.min(e.age, REMAINS_LIFE * 0.58), d);
  }
}
// Everything searchable near a point: the field, plus the fresh dead.
function carcNearest(x, z, rr) {
  let best = null, bd = rr * rr;
  for (const e of CARC.live) {
    if (e.looted || !e.G) continue;
    const d2 = (e.x - x) * (e.x - x) + (e.z - z) * (e.z - z);
    if (d2 < bd) { bd = d2; best = e; }
  }
  for (const r of REMAINS) {
    if (r.looted || !r.parts || !r.parts.length) continue;
    const d2 = (r.x - x) * (r.x - x) + (r.z - z) * (r.z - z);
    if (d2 < bd) { bd = d2; best = r; }
  }
  return best;
}
// deterministic per-skeleton jitter so bones do not lie in perfect symmetry""")
open(p, 'w', encoding='utf-8').write(s)
print('carcass field ok')

# ---------------------------------------------------------------- wire it into the frame
s = open(p, encoding='utf-8').read()
s = sub1(s, "  drawRemains(t);", "  drawRemains(t);\n  try { drawCarcasses(); } catch (e) { if (!drawCarcasses._w) { drawCarcasses._w = 1; console.warn('carcasses', e); } }")
s = sub1(s, """  try { if (BR.on) brTick(dt); } catch (e) { console.warn('br tick', e); }
  stepSim(dt);""",
"""  try { if (BR.on) brTick(dt); } catch (e) { console.warn('br tick', e); }
  try { carcTick(dt); } catch (e) { if (!carcTick._w) { carcTick._w = 1; console.warn('carcass tick', e); } }
  stepSim(dt);""")
# a fresh world is a fresh field
s = sub1(s, "    world.rarityCap = (opts && opts.rarityCap) || 'ultra';",
            "    world.rarityCap = (opts && opts.rarityCap) || 'ultra';\n    if (typeof CARC !== 'undefined') { CARC.cells.clear(); CARC.live.length = 0; CARC.q.length = 0; }")
open(p, 'w', encoding='utf-8').write(s)
print('carcass wired ok')

# ---------------------------------------------------------------- inspecting
s = open(p, encoding='utf-8').read()
s = sub1(s, """function tryEat() {""",
"""// Search a body. You get ONE part off it, and then it is picked clean: a
// carcass is a find, not a vending machine.
function tryInspect() {
  const c = player.c;
  if (!c || !c.alive || player.spectator) return;
  if (player.picker) return;
  const t = carcNearest(c.x, c.y, interactRange(c.ph) * 1.45);
  if (!t) { toast('Nothing to search here. Look for bones on the ground.', 1500); return; }
  const opts = (t.parts || []).filter(id => VIS[id]);
  // Searched is searched, whether or not you liked what was on it.
  t.looted = true;
  if (!opts.length) { toast('Picked clean. Nothing left on it.', 1800); return; }
  player.picker = { opts: opts.slice(0, 6), label: 'You search the body. Take one of its parts',
                    t0: performance.now(), items: true };
  renderPicker();
}
// The nearest body worth searching, for the prompt and the marker.
function inspectTarget() {
  const c = player.c;
  if (!c || !c.alive || player.spectator) return null;
  return carcNearest(c.x, c.y, interactRange(c.ph) * 1.45);
}
function tryEat() {""")
s = sub1(s, "    if (k === 'e') tryEat();", "    if (k === 'e') tryEat();\n    if (k === 'v') tryInspect();")
open(p, 'w', encoding='utf-8').write(s)
print('inspect ok')

# ---------------------------------------------------------------- the prompt and the marker
s = open(p, encoding='utf-8').read()
s = sub1(s, """      act.style.display = 'block';
    } else act.style.display = 'none';""",
"""      act.style.display = 'block';
    } else {
      // Nothing alive in front of you, but maybe something dead at your feet.
      const body = inspectTarget();
      if (body) {
        act.innerHTML = '<b class="pk">CARCASS</b> &middot; ' + ((body.parts || []).length) + ' parts on it' +
          '<div class="keys"><span class="ok">V</span> search it <span>E</span> eat</div>';
        act.style.display = 'block';
      } else act.style.display = 'none';
    }""")
# a pale marker over a body you have not searched, so they can be found
s = sub1(s, """function drawFight(t) {""",
"""// A soft marker over the nearest unsearched body in reach, so bones in long
// grass are findable rather than a pixel hunt.
function drawCarcassMark(t) {
  const b = inspectTarget();
  if (!b) return;
  const gy = groundAt(b.x, b.z != null ? b.z : b.y) + 16 + Math.sin(t * 2.2) * 1.6;
  pushC(b.x, gy, b.z != null ? b.z : b.y, 0, -1, 0, 1.9, 5.5, [0.86, 0.84, 0.70]);
}
function drawFight(t) {""")
s = sub1(s, "  try { drawCarcasses(); } catch (e) { if (!drawCarcasses._w) { drawCarcasses._w = 1; console.warn('carcasses', e); } }",
            "  try { drawCarcasses(); } catch (e) { if (!drawCarcasses._w) { drawCarcasses._w = 1; console.warn('carcasses', e); } }\n  try { drawCarcassMark(t); } catch (e) { /* no body in reach */ }")
open(p, 'w', encoding='utf-8').write(s)
print('carcass prompt ok')

# ---------------------------------------------------------------- the controls list
s = open(p, encoding='utf-8').read()
s = s.replace("('E','eat')", "('E','eat'),('V','search a carcass for a part')")
s = s.replace("['E', 'eat']", "['E', 'eat'], ['V', 'search a carcass for a part']")
open(p, 'w', encoding='utf-8').write(s)

# ---------------------------------------------------------------- test surface
s = open(p, encoding='utf-8').read()
s = sub1(s, "  openEditor: (m) => openEditor(m || 'game'),",
"""  openEditor: (m) => openEditor(m || 'game'),
  carc: {
    get near() { return CARC.live.length; },
    get built() { return CARC.live.filter(e => !!e.G).length; },
    list: () => CARC.live.map(e => ({ x: Math.round(e.x), z: Math.round(e.z), built: !!e.G, looted: !!e.looted, parts: (e.parts || []).length })),
    // build everything in range now, rather than one a frame
    flush: () => { let n = 0; while (CARC.q.length && n++ < 400) { const e = CARC.q.shift(); if (e && !e.G && !e.dead) carcBuild(e); } return CARC.live.filter(e => !!e.G).length; },
    // put the player next to the nearest built body
    walkTo: (i) => { const e = CARC.live.filter(q => q.G && !q.looted)[i || 0]; if (!e) return null;
      if (player.c) { player.c.x = e.x + 6; player.c.y = e.z + 6; }
      player.camX = e.x + 6; player.camZ = e.z + 6; fallResetGround();
      return { x: Math.round(e.x), z: Math.round(e.z), parts: e.parts.slice() }; },
    target: () => { const b = inspectTarget(); return b ? { parts: (b.parts || []).slice(), looted: !!b.looted } : null; },
    inspect: () => { tryInspect(); return player.picker ? player.picker.opts.slice() : null; },
    pick: (i) => choosePicked(i | 0),
    prompt: () => { updateHUD(); const el = document.getElementById('act'); return el && el.style.display !== 'none' ? el.innerHTML : ''; },
  },""")
open(p, 'w', encoding='utf-8').write(s)
print('carcass test surface ok')
