# CHUNKED TERRAIN
# The terrain was one static mesh covering the whole world, drawn in full every
# frame: 1.4M triangles at the old map size, and 5.7M once the map doubles.
# Nothing was ever culled, including the half of the world behind you.
#
# The vertex buffer is unchanged and still shared. Only the INDEX buffer is
# reorganised: it is laid out chunk by chunk in row-major order, each chunk
# owning a contiguous range, so a chunk is drawn by offsetting into the same
# buffer. Nothing is duplicated and no LOD is needed, so there are no seams
# between chunks at different detail -- the win comes entirely from not drawing
# what you cannot see.
#
# Chunks are emitted row-major, so neighbours in a row are contiguous and runs
# of visible chunks merge into single draw calls.
def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
p='g3.html'; s=open(p,encoding='utf-8').read()

s=sub1(s,"let terrVB, terrIB, terrCount;","""let terrVB, terrIB, terrCount;
// { x0,z0,x1,z1: world bounds | cx,cz: centre | cr: bounding radius in xz
//   yLo,yHi: height range | first,count: the chunk's slice of terrIB }
let terrChunks = [];
const TCHUNK = 64;                    // grid cells per chunk edge
const TERR_STATS = { drawn: 0, calls: 0, total: 0 };""")

s=sub1(s,"""  const idx = new Uint32Array((nx - 1) * (nz - 1) * 6);
  let q = 0;
  for (let j = 0; j < nz - 1; j++) for (let i = 0; i < nx - 1; i++) {
    const a = j * nx + i, b = a + nx;
    idx[q++] = a; idx[q++] = b; idx[q++] = a + 1;
    idx[q++] = a + 1; idx[q++] = b; idx[q++] = b + 1;
  }
  terrCount = idx.length;""","""  // ---- indices, laid out one chunk at a time -------------------------------
  const idx = new Uint32Array((nx - 1) * (nz - 1) * 6);
  const ncx = Math.ceil((nx - 1) / TCHUNK), ncz = Math.ceil((nz - 1) / TCHUNK);
  terrChunks = [];
  let q = 0;
  for (let cj = 0; cj < ncz; cj++) for (let ci = 0; ci < ncx; ci++) {
    const i0 = ci * TCHUNK, j0 = cj * TCHUNK;
    const i1 = Math.min(nx - 1, i0 + TCHUNK), j1 = Math.min(nz - 1, j0 + TCHUNK);
    if (i1 <= i0 || j1 <= j0) continue;
    const first = q;
    let yLo = Infinity, yHi = -Infinity;
    for (let j = j0; j < j1; j++) for (let i = i0; i < i1; i++) {
      const a = j * nx + i, b = a + nx;
      idx[q++] = a; idx[q++] = b; idx[q++] = a + 1;
      idx[q++] = a + 1; idx[q++] = b; idx[q++] = b + 1;
    }
    // the chunk's own height range, so a valley floor is not culled by a peak
    for (let j = j0; j <= j1; j++) for (let i = i0; i <= i1; i++) {
      const hh = hs[Math.min(nz - 1, j) * nx + Math.min(nx - 1, i)];
      if (hh < yLo) yLo = hh;
      if (hh > yHi) yHi = hh;
    }
    const x0 = i0 * GRID_STEP, z0 = j0 * GRID_STEP;
    const x1 = i1 * GRID_STEP, z1 = j1 * GRID_STEP;
    terrChunks.push({
      x0, z0, x1, z1,
      cx: (x0 + x1) * 0.5, cz: (z0 + z1) * 0.5,
      cr: Math.hypot(x1 - x0, z1 - z0) * 0.5,
      yLo: yLo * HEIGHT_SCALE, yHi: yHi * HEIGHT_SCALE,
      first, count: q - first,
    });
  }
  terrCount = idx.length;
  TERR_STATS.total = terrChunks.length;""")

# ---- the cull, and drawing only the runs that survive it
s=sub1(s,"""// Exact height of the drawn""","""// Which chunks are worth drawing. Distance first, then a horizontal frustum
// test that accounts for the chunk's own angular size, so a chunk is only
// dropped when the whole of it is off the side of the screen.
// maxD lets the shadow pass ask for a much smaller set than the camera does.
// How far the terrain itself is worth drawing. The fog reaches 96% opacity at
// about 12000 units, so ground beyond that is very nearly fog-coloured already
// and costs triangles for nothing. Ultra reaches further because it can.
function terrDrawDist() {
  const q = (typeof GFX === 'object' && GFX && GFX.crit) ? GFX.crit : 1;
  return Math.min(FAR, 12000 * clamp(q, 0.55, 1.6));
}
function terrVisibleRuns(maxD, aspect) {
  const fx = Math.cos(player.yaw), fz = Math.sin(player.yaw);
  // horizontal half-angle of the view, with a margin so nothing pops at the edge
  const halfV = 1.15 * 0.5;
  const halfH = Math.atan(Math.tan(halfV) * Math.max(0.5, aspect || 1.7)) + 0.12;
  const camX = player.camX, camZ = player.camZ;
  const runs = [];
  let run = null, drawn = 0;
  for (let k = 0; k < terrChunks.length; k++) {
    const ch = terrChunks[k];
    const dx = ch.cx - camX, dz = ch.cz - camZ;
    const d = Math.hypot(dx, dz);
    let keep = d - ch.cr <= maxD;
    if (keep && d > ch.cr) {
      const cosA = (dx * fx + dz * fz) / d;
      const ang = Math.min(Math.PI, halfH + Math.asin(Math.min(1, ch.cr / d)));
      if (cosA < Math.cos(ang)) keep = false;
    }
    // chunks are emitted row-major, so neighbours are contiguous in the index
    // buffer and a run of them is one draw call
    if (keep) {
      drawn += ch.count;
      if (run && run.first + run.count === ch.first) run.count += ch.count;
      else { run = { first: ch.first, count: ch.count }; runs.push(run); }
    } else run = null;
  }
  TERR_STATS.drawn = drawn; TERR_STATS.calls = runs.length;
  return runs;
}
function terrDraw(pass, maxD, aspect) {
  if (!terrVB || !terrChunks.length) return;
  pass.setVertexBuffer(0, terrVB); pass.setIndexBuffer(terrIB, 'uint32');
  const runs = terrVisibleRuns(maxD, aspect);
  for (let i = 0; i < runs.length; i++) pass.drawIndexed(runs[i].count, 1, runs[i].first);
}
// Exact height of the drawn""")

# ---- both draw sites
s=sub1(s,"""      pass.setVertexBuffer(0, terrVB); pass.setIndexBuffer(terrIB, 'uint32'); pass.drawIndexed(terrCount);""",
"""      // the far cascade covers a couple of thousand units around the camera;
      // there is no reason to feed it the whole world
      terrDraw(pass, 3000, 2.4);""")
s=sub1(s,"""  pass.setVertexBuffer(0, terrVB); pass.setIndexBuffer(terrIB, 'uint32');
  pass.drawIndexed(terrCount);""","""  terrDraw(pass, terrDrawDist(), aspect);""")
open(p,'w',encoding='utf-8').write(s)
print('terrain chunked ok')
s=open(p,encoding='utf-8').read()
s=sub1(s,"  rebuild: () => rebuildWorld(),","""  rebuild: () => rebuildWorld(),
  get terrStats() { return { chunks: TERR_STATS.total, drawnTris: TERR_STATS.drawn / 3, calls: TERR_STATS.calls, totalTris: terrCount / 3 }; },""")
open(p,'w',encoding='utf-8').write(s)
print('terr stats ok')
