// =====================================================================
// THE CLOUD WALL
// The closing zone was a global distance fog, which from outside read as a
// flat grey pane hanging in the air. It is a real object now: a wall of large
// soft cloud puffs standing on the ring, three rows deep and three layers
// high, boiling slowly and drifting inward as the ring closes. Inside the wall
// the old fog still takes your sight away, which is what makes it deadly; from
// outside you see weather coming for you.
//
// Drawn with its own alpha-blended pipeline over the shared sphere mesh, sorted
// back to front, so the puffs read as volume rather than as balls.
// =====================================================================
const CLOUD_MAX = 620;
const CLOUD_FLOATS = 8;                 // pos3, radius, tint3, density
const cloudData = new Float32Array(CLOUD_MAX * CLOUD_FLOATS);
let cloudVB = null, cloudPipe = null, cloudBind = null, cloudCount = 0;
const CLOUD_ROWS = [0, 210, 470];       // how far out from the ring each row stands
const CLOUD_LAYERS = [0.30, 0.72, 1.18];// height, as a fraction of the wall height
const CLOUD_WALL_H = 460;
const CLOUD_SEE = 7200;                 // puffs are only built this close to the eye

const WGSL_CLOUD_SRC = `
struct VO { @builtin(position) pos: vec4<f32>, @location(0) nrm: vec3<f32>,
            @location(1) wpos: vec3<f32>, @location(2) tint: vec3<f32>, @location(3) dens: f32 };
@vertex fn vs(@location(0) p: vec3<f32>, @location(1) n: vec3<f32>,
              @location(2) iPos: vec3<f32>, @location(3) iRad: f32,
              @location(4) iTint: vec3<f32>, @location(5) iDens: f32) -> VO {
  // squashed: a cloud bank is wider than it is tall
  let q = vec3<f32>(p.x * iRad, p.y * iRad * 0.62, p.z * iRad);
  let w = q + iPos;
  var o: VO;
  o.pos = g.viewProj * vec4<f32>(w, 1.0);
  o.nrm = normalize(vec3<f32>(n.x, n.y * 1.6, n.z));
  o.wpos = w; o.tint = iTint; o.dens = iDens;
  return o;
}
fn ch(p: vec2<f32>) -> f32 { var p3 = fract(vec3<f32>(p.x, p.y, p.x) * 0.1031); p3 += dot(p3, p3.yzx + vec3<f32>(33.33)); return fract((p3.x + p3.y) * p3.z); }
fn cn(p: vec2<f32>) -> f32 {
  let i = floor(p); let f = fract(p); let u = f * f * (3.0 - 2.0 * f);
  return mix(mix(ch(i), ch(i + vec2<f32>(1.0, 0.0)), u.x), mix(ch(i + vec2<f32>(0.0, 1.0)), ch(i + vec2<f32>(1.0, 1.0)), u.x), u.y);
}
@fragment fn fs(i: VO) -> @location(0) vec4<f32> {
  let N = normalize(i.nrm);
  let V = normalize(g.camPos.xyz - i.wpos);
  // soft at the silhouette, solid through the middle: a sphere becomes a puff
  let facing = clamp(dot(N, V), 0.0, 1.0);
  let t = g.params.x;
  // three scales of drift, so the wall boils instead of sliding
  let q = i.wpos * 0.0042;
  let n1 = cn(q.xz + vec2<f32>(t * 0.016, t * -0.011));
  let n2 = cn(q.xy * 2.3 + vec2<f32>(t * -0.027, t * 0.019));
  let n3 = cn(q.zx * 5.1 + vec2<f32>(t * 0.041, t * 0.033));
  let n = n1 * 0.55 + n2 * 0.30 + n3 * 0.15;
  var a = smoothstep(0.015, 0.50, facing);
  a *= smoothstep(0.34, 0.78, n * 0.72 + facing * 0.40);
  a *= i.dens;
  if (a < 0.012) { discard; }
  let day = g.params.z;
  let L = normalize(g.lightDir.xyz);
  let up = clamp(N.y * 0.5 + 0.5, 0.0, 1.0);
  let sun = clamp(dot(N, L) * 0.5 + 0.5, 0.0, 1.0);
  // lit from above and from the sun, dark and heavy underneath
  var col = mix(vec3<f32>(0.085, 0.100, 0.105), vec3<f32>(0.62, 0.65, 0.64), day);
  col *= 0.44 + 0.56 * up;
  col = mix(col, mix(vec3<f32>(0.16, 0.19, 0.22), vec3<f32>(0.96, 0.94, 0.88), day), sun * 0.40);
  col *= i.tint;
  // the fog between you and it
  let d = distance(i.wpos, g.camPos.xyz);
  let f = clamp(1.0 - exp(-(d * g.params.y) * (d * g.params.y)), 0.0, 1.0);
  col = mix(col, g.fogCol.rgb, f * 0.85);
  return vec4<f32>(col, clamp(a, 0.0, 1.0));
}`;

function cloudInit() {
  if (cloudPipe) return;
  const m = dev.createShaderModule({ code: WGSL_COMMON + WGSL_CLOUD_SRC });
  cloudPipe = dev.createRenderPipeline({
    layout: 'auto',
    vertex: { module: m, entryPoint: 'vs', buffers: [
      { arrayStride: 24, attributes: [
        { shaderLocation: 0, offset: 0, format: 'float32x3' },
        { shaderLocation: 1, offset: 12, format: 'float32x3' }] },
      { arrayStride: CLOUD_FLOATS * 4, stepMode: 'instance', attributes: [
        { shaderLocation: 2, offset: 0,  format: 'float32x3' },
        { shaderLocation: 3, offset: 12, format: 'float32' },
        { shaderLocation: 4, offset: 16, format: 'float32x3' },
        { shaderLocation: 5, offset: 28, format: 'float32' }] },
    ] },
    fragment: { module: m, entryPoint: 'fs', targets: [{ format: fmt, blend: {
      color: { srcFactor: 'src-alpha', dstFactor: 'one-minus-src-alpha' },
      alpha: { srcFactor: 'one', dstFactor: 'one-minus-src-alpha' } } }] },
    primitive: { topology: 'triangle-list', cullMode: 'none' },
    // no depth write: the puffs blend through each other
    depthStencil: { format: 'depth24plus', depthWriteEnabled: false, depthCompare: 'less' },
    multisample: { count: SAMPLES },
  });
  cloudVB = dev.createBuffer({ size: cloudData.byteLength, usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST });
  cloudBind = dev.createBindGroup({ layout: cloudPipe.getBindGroupLayout(0), entries: [{ binding: 0, resource: { buffer: gBuf } }] });
}

// A stable hash per puff, so a given puff keeps its size and phase as the wall
// creeps in rather than reshuffling every frame.
function cloudHash(k, s) {
  let h = (Math.imul(k | 0, 73856093) ^ Math.imul(s | 0, 19349663)) >>> 0;
  h = Math.imul(h ^ (h >>> 15), 2246822519) >>> 0;
  return ((h ^ (h >>> 13)) >>> 0) / 4294967296;
}
// Build the arc of the wall that is near enough to see, back to front.
function cloudBuild(t) {
  cloudCount = 0;
  if (!BR.on || BR.phase === 'off') return 0;
  const Z = BR.zone;
  const camX = player.camX, camZ = player.camZ;
  const R = Z.r;
  if (!(R > 0)) return 0;
  // the angle of the camera as seen from the ring centre, and how much of the
  // ring is close enough to matter
  const dcx = camX - Z.cx, dcz = camZ - Z.cz;
  const dCentre = Math.hypot(dcx, dcz);
  const aCam = Math.atan2(dcz, dcx);
  // half-angle of the visible arc: everything whose ring point is within CLOUD_SEE
  let halfArc = Math.PI;
  if (dCentre > 1 && R > 1) {
    const cosNeed = (dCentre * dCentre + R * R - CLOUD_SEE * CLOUD_SEE) / (2 * dCentre * R);
    if (cosNeed > 1) return 0;                 // the whole wall is too far to see
    if (cosNeed > -1) halfArc = Math.acos(cosNeed);
  }
  const stepA = Math.max(0.006, 165 / Math.max(200, R));   // puffs about 165 units apart
  const n = Math.min(240, Math.ceil((halfArc * 2) / stepA));
  const list = [];
  for (let k = -Math.floor(n / 2); k <= Math.floor(n / 2); k++) {
    const a = aCam + k * stepA;
    const ca = Math.cos(a), sa = Math.sin(a);
    for (let ri = 0; ri < CLOUD_ROWS.length; ri++) {
      const rr = R + CLOUD_ROWS[ri];
      const bx = Z.cx + ca * rr, bz = Z.cz + sa * rr;
      if (bx < -2000 || bz < -2000 || bx > WORLD_W + 2000 || bz > WORLD_H + 2000) continue;
      const dx = bx - camX, dz = bz - camZ;
      const d2 = dx * dx + dz * dz;
      if (d2 > CLOUD_SEE * CLOUD_SEE) continue;
      const gy = groundAt(clamp(bx, 1, WORLD_W - 1), clamp(bz, 1, WORLD_H - 1));
      for (let li = 0; li < CLOUD_LAYERS.length; li++) {
        const key = (k * 97 + ri * 31 + li) | 0;
        const h1 = cloudHash(key, 1), h2 = cloudHash(key, 2), h3 = cloudHash(key, 3);
        // slow boil: each puff breathes and drifts on its own phase
        const ph = h1 * 6.2832;
        const rad = (150 + h2 * 170) * (1 + 0.10 * Math.sin(t * 0.25 + ph));
        const y = gy + CLOUD_WALL_H * CLOUD_LAYERS[li] + Math.sin(t * 0.18 + ph) * 26 + h3 * 60;
        const px = bx + Math.sin(t * 0.11 + ph) * 34;
        const pz = bz + Math.cos(t * 0.09 + ph * 1.3) * 34;
        // the outer rows and the top layer are thinner, so the wall has an edge
        const dens = (ri === 0 ? 0.92 : ri === 1 ? 0.72 : 0.48) * (li === 2 ? 0.62 : 1);
        const g1 = 0.88 + h1 * 0.16;
        list.push({ x: px, y, z: pz, r: rad, tint: [g1 * 0.93, g1, g1 * 0.90], dens,
                    d2: (px - camX) * (px - camX) + (pz - camZ) * (pz - camZ) });
      }
    }
  }
  // back to front, so the blend stacks correctly
  list.sort((a, b) => b.d2 - a.d2);
  const n2 = Math.min(list.length, CLOUD_MAX);
  for (let i = 0; i < n2; i++) {
    const c = list[i], o = i * CLOUD_FLOATS;
    cloudData[o] = c.x; cloudData[o + 1] = c.y; cloudData[o + 2] = c.z;
    cloudData[o + 3] = c.r;
    cloudData[o + 4] = c.tint[0]; cloudData[o + 5] = c.tint[1]; cloudData[o + 6] = c.tint[2];
    cloudData[o + 7] = c.dens;
  }
  cloudCount = n2;
  if (n2) dev.queue.writeBuffer(cloudVB, 0, cloudData, 0, n2 * CLOUD_FLOATS);
  return n2;
}
function cloudDraw(pass) {
  if (!cloudCount || !cloudPipe) return;
  pass.setPipeline(cloudPipe); pass.setBindGroup(0, cloudBind);
  pass.setVertexBuffer(0, sphVB); pass.setIndexBuffer(sphIB, 'uint16');
  pass.setVertexBuffer(1, cloudVB);
  pass.drawIndexed(sphCount, cloudCount);
}
