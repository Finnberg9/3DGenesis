# Jumping: height comes from the legs. Longer legs spring higher; the springing
# leg is built for it. While airborne you clear terrain steps up to your height.
def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
p='g3.html'; s=open(p,encoding='utf-8').read()
s=sub1(s,"          return terrain.level(bx, by) - lv0 > terrain.maxStep;","          return terrain.level(bx, by) - lv0 > terrain.maxStep + (c.jumpLv || 0);")
s=sub1(s,"""  player.jumpV = JUMP_V0 * (0.75 + 0.35 * clamp((p.legLen || 1) * 0.6, 0, 1.2));""","""  player.jumpV = Math.sqrt(2 * GRAV * jumpHeight(p));""")
s=sub1(s,"""function tryJump() {""","""// How high this body can jump, in world units. The base hop clears about one
// climb step; leg length (stand height relative to body size) adds to it, and
// each springing leg multiplies it -- a full set clears several body heights.
function jumpHeight(p) {
  const base = JUMP_V0 * JUMP_V0 / (2 * GRAV) * 0.75;
  const legRatio = clamp((p.standH || p.radius) / Math.max(0.5, p.radius) - 0.6, 0, 2.2);
  const legs = p.dLegs || 0, spring = p.dSpring || 0;
  const springFrac = legs ? clamp(spring / legs, 0, 1) : 0;
  const size = Math.sqrt(Math.max(0.3, (p.radius || 4) / 4));
  return base * size * (1 + 0.55 * legRatio) * (1 + 3.2 * springFrac);
}
function tryJump() {""")
s=sub1(s,"""    player.jumpV -= GRAV * dt;
    player.jumpY += player.jumpV * dt;""","""    player.jumpV -= GRAV * dt;
    player.jumpY += player.jumpV * dt;
    // terrain steps you can clear while in the air
    const blockH = terrain.hMax * HEIGHT_SCALE / Math.max(1, terrain.ELEV);
    player.c.jumpLv = Math.max(0, Math.floor(player.jumpY / Math.max(1, blockH)));""")
s=sub1(s,"""    if (player.jumpY <= 0) { player.jumpY = 0; player.jumpV = 0; player.grounded = true; }""","""    if (player.jumpY <= 0) { player.jumpY = 0; player.jumpV = 0; player.grounded = true; player.c.jumpLv = 0; }""")
open(p,'w',encoding='utf-8').write(s)
print('jump ok')
