// =====================================================================
// DESIGNED CREATURES v2: one fused, skinned skin + hard parts
// =====================================================================
// ---- flesh builder ------------------------------------------------------------
// Collects SDF primitives in a part's local frame (same axes and units as the
// hard-part drawing frame) and converts them to body rest space.
function makeF(out, P, X, Y, Z, S, bone) {
  const W = (x, y, z) => [P[0] + (X[0] * x + Y[0] * y + Z[0] * z) * S, P[1] + (X[1] * x + Y[1] * y + Z[1] * z) * S, P[2] + (X[2] * x + Y[2] * y + Z[2] * z) * S];
  const D = (x, y, z) => v3.norm([X[0] * x + Y[0] * y + Z[0] * z, X[1] * x + Y[1] * y + Z[1] * z, X[2] * x + Y[2] * y + Z[2] * z]);
  const F = {
    bone, jawBone: bone,
    s(x, y, z, r, k, col) { const p = W(x, y, z); out.push({ t: 's', ax: p[0], ay: p[1], az: p[2], ra: r * S, k: k * S, bone: F.bone, col: col || null }); },
    c(a, b, ra, rb, k, col) { const p = W(a[0], a[1], a[2]), q = W(b[0], b[1], b[2]); out.push({ t: 'c', ax: p[0], ay: p[1], az: p[2], bx: q[0], by: q[1], bz: q[2], ra: ra * S, rb: rb * S, k: k * S, bone: F.bone, col: col || null }); },
    // ellipsoid: centre, its y axis along (ay...), x axis hint, radii
    e(x, y, z, ax, ay, az, hx, hy, hz, rx, ry, rz, k, col) {
      const p = W(x, y, z);
      const ey = D(ax, ay, az);
      let ex = D(hx, hy, hz);
      ex = v3.norm(v3.sub(ex, v3.mul(ey, v3.dot(ex, ey))));
      if (!isFinite(ex[0]) || v3.len(ex) < 0.5) ex = v3.norm(v3.cross(ey, Math.abs(ey[1]) < 0.9 ? [0, 1, 0] : [1, 0, 0]));
      const ez = v3.cross(ex, ey);
      out.push({ t: 'e', ax: p[0], ay: p[1], az: p[2], ex, ey, ez, rx: rx * S, ry: ry * S, rz: rz * S, k: k * S, bone: F.bone, col: col || null });
    },
    jaw() { F.bone = F.jawBone; },
    main() { F.bone = bone; },
  };
  return F;
}
// ---- skin coverings as earnable items -----------------------------------------
const SKIN_ITEMS = ['k_smooth', 'k_scales', 'k_feathers', 'k_fur', 'k_plates'];
const SKIN_NAMES = ['smooth skin', 'scales', 'feathers', 'fur', 'armour plates'];
SKIN_ITEMS.forEach((id, i) => { VIS[id] = { name: SKIN_NAMES[i], cat: 'skin', size: 0.3, col: 'base', skin: i, draw(g, c) { g.ball(0, 0.5, 0, 0.5, c); } }; });
function skinOf(d) { const c = d && d.col; return c && c.skin != null ? c.skin | 0 : (C.PLAN_SKIN ? C.PLAN_SKIN[(d && d.plan) | 0] : 0); }
// ---- per-item flesh (fused into the skin) and hard pieces (drawn on top) ------
// Items not listed draw entirely as hard pieces with their original VIS art.
const HARD = {};
const FLESH = {};
// mouths ------------------------------------------------------------------------
FLESH.m_beak = (F) => { F.e(0, 0.08, 0, 0, 1, 0, 1, 0, 0, 0.66, 0.34, 0.7, 0.28); };
HARD.m_beak = (g, c, e) => {
  g.cn(0.16, 0.05, 0, -0.34, 1, 0, 0.52, 1.45, c);
  const j = g.rotated(0, 0, 1, e.jaw);
  j.cn(-0.3, 0.05, 0, 0.06, 1, 0, 0.42, 0.95, colMul(c, 0.82));
};
FLESH.m_grazer = (F, c) => {
  F.e(0, 0.24, 0, 0, 1, 0, 1, 0, 0, 0.56, 0.5, 0.86, 0.3);
  F.e(0.2, 0.42, 0, 0, 1, 0, 1, 0, 0, 0.36, 0.38, 0.8, 0.1, c);
  F.jaw(); F.e(-0.32, 0.36, 0, 0, 1, 0, 1, 0, 0, 0.3, 0.34, 0.72, 0.1, c); F.main();
};
HARD.m_grazer = (g, c, e) => {
  const j = g.rotated(0, 0, 1, e.jaw * 0.5);
  j.sp(-0.06, 0.66, 0, 0, 1, 0, 0.07 + e.chomp * 0.08, 0.12, 0.56, MAW);
  g.sp(0.46, 0.7, 0.3, 0.3, 1, 0.4, 0.1, 0.05, 0.08, colMul(c, 0.3)); g.sp(0.46, 0.7, -0.3, 0.3, 1, -0.4, 0.1, 0.05, 0.08, colMul(c, 0.3));
};
FLESH.m_trunk = (F, c, e) => {
  let p = [0, 0, 0], d = [0, 1, 0];
  for (let i = 0; i < 7; i++) {
    const r = 0.46 - i * 0.045;
    d = v3.norm(v3.add(d, [-0.23, 0, 0]));
    const q = v3.add(p, v3.mul(d, 0.42));
    F.c(p, q, r, r - 0.045, 0.06);
    p = q;
  }
};
HARD.m_trunk = (g, c) => {
  let p = [0, 0, 0], d = [0, 1, 0];
  for (let i = 0; i < 7; i++) { d = v3.norm(v3.add(d, [-0.23, 0, 0])); p = v3.add(p, v3.mul(d, 0.42)); }
  g.sp(p[0], p[1], p[2], d[0], d[1], d[2], 0.16, 0.05, 0.16, colMul(c, 0.35));
};
const jawFlesh = (F, big) => {
  const k = big ? 1.18 : 1;
  F.e(0.3 * k, 0.4, 0, 0.15, 1, 0, 1, 0, 0, 0.34 * k, 0.68 * k, 0.9 * k, 0.28);
  F.jaw(); F.e(-0.42 * k, 0.34, 0, -0.1, 1, 0, 1, 0, 0, 0.3 * k, 0.6 * k, 0.82 * k, 0.16); F.main();
};
FLESH.m_jaws = (F) => jawFlesh(F, false);
FLESH.m_maw = (F) => jawFlesh(F, true);
const jawHard = (g, e, big) => {
  const k = big ? 1.18 : 1;
  const j = g.rotated(0, 0, 1, e.jaw);
  g.sp(-0.05 * k, 0.36, 0, 0, 1, 0, 0.3 * k, 0.5 * k, 0.66 * k, MAW);
  const nT = big ? 6 : 5;
  for (let i = 0; i < nT; i++) {
    const z = (i - (nT - 1) / 2) * 0.26 * k, y = 0.62 + (1 - Math.abs(i - (nT - 1) / 2) / nT) * 0.1;
    g.cn(0.16 * k, y, z, -1, 0.12, 0, 0.075 * k, 0.3 * k, IVORY);
    j.cn(-0.26 * k, y - 0.04, z * 0.95, 1, 0.12, 0, 0.07 * k, 0.26 * k, IVORY);
  }
  if (big) for (const s of [1, -1]) { g.cn(0.2 * k, 0.7, s * 0.52 * k, -1, 0.18, 0, 0.12 * k, 0.72 * k, IVORY); j.cn(-0.3 * k, 0.66, s * 0.6 * k, 1, 0.2, 0, 0.1 * k, 0.5 * k, IVORY); }
  j.sp(-0.16 * k, 0.42, 0, 0, 1, 0, 0.12 * k, 0.34 * k, 0.38 * k, TONGUE);
};
HARD.m_jaws = (g, c, e) => jawHard(g, e, false);
HARD.m_maw = (g, c, e) => jawHard(g, e, true);
FLESH.m_hook = (F) => { F.e(0, 0.1, 0, 0, 1, 0, 1, 0, 0, 0.62, 0.36, 0.66, 0.26); };
HARD.m_hook = (g, c, e) => {
  let p = [0.2, 0.12, 0], d = [0, 1, 0];
  for (let i = 0; i < 4; i++) {
    d = v3.norm(v3.add(d, [-0.42, 0, 0]));
    const q = v3.add(p, v3.mul(d, 0.34));
    g.tb(p, q, 0.46 - i * 0.1, 0.36 - i * 0.1, c);
    g.ball(q[0], q[1], q[2], 0.36 - i * 0.1, c);
    p = q;
  }
  g.cn(p[0], p[1], p[2], d[0], d[1], d[2], 0.1, 0.3, c);
  g.rotated(0, 0, 1, e.jaw).cn(-0.3, 0.05, 0, 0.1, 1, 0, 0.34, 0.8, colMul(c, 0.85));
};
// eyes: a fleshy socket fused into the skin, a glossy eyeball on top ----------
// socket and lids: a low seat under the eyeball and a ring of flesh around the
// gaze axis, heavier on top like a brow, leaving an almond opening
const socket = (F, k, e) => {
  const fw = (e && e.fw) || [1, 0, 0], up = (e && e.up) || [0, 1, 0];
  const f = v3.norm(v3.add([0, 1, 0], v3.mul(fw, 0.8)));
  let u0 = v3.sub(up, v3.mul(f, v3.dot(up, f)));
  u0 = v3.len(u0) > 1e-3 ? v3.norm(u0) : [1, 0, 0];
  const s0 = v3.cross(f, u0);
  const R = 0.9 * k, C0 = [0, 0.22 * k, 0];
  // a raised orbital mound, so the eye sits proud of the face
  F.e(0, 0.0, 0, 0, 1, 0, 1, 0, 0, 1.18 * k, 0.66 * k, 1.18 * k, 0.45 * k);
  for (let i = 0; i < 10; i++) {
    const a = i / 10 * Math.PI * 2, ca = Math.cos(a), sa = Math.sin(a);
    const top = 0.5 + 0.5 * ca;                        // 1 at the brow, 0 at the lower lid
    const rr = R * (0.98 - 0.1 * top), along = R * (0.4 - 0.14 * top);
    const q = v3.add(v3.add(C0, v3.mul(f, along)), v3.add(v3.mul(u0, ca * rr), v3.mul(s0, sa * rr)));
    F.s(q[0], q[1], q[2], R * (0.2 + 0.16 * top), R * 0.4);
  }
};
FLESH.e_round = (F, c, e) => socket(F, 1, e);
FLESH.e_slit = (F, c, e) => socket(F, 1, e);
FLESH.e_big = (F, c, e) => socket(F, 1.25, e);
HARD.e_round = (g, c, e) => drawEye(g, c, e, 1, 'round');
HARD.e_slit = (g, c, e) => drawEye(g, c, e, 1, 'slit');
HARD.e_big = (g, c, e) => drawEye(g, c, e, 1.25, 'goggle');
FLESH.e_stalk = (F, c, e) => {
  F.c([0, 0, 0], [0.1, 1.3, 0.05], 0.4, 0.26, 0.2);
  F.c([0.1, 1.3, 0.05], [0.25, 2.05, 0.1], 0.26, 0.22, 0.12);
  F.e(0.25, 2.1, 0.1, 0, 1, 0, 1, 0, 0, 1.05, 0.62, 1.05, 0.2);
};
HARD.e_stalk = (g, c, e) => { drawEye(g.at(0.25, 2.1, 0.1), c, e, 0.95, 'round'); };
FLESH.e_cluster = (F) => { F.e(0, 0.05, 0, 0, 1, 0, 1, 0, 0, 1.0, 0.3, 0.92, 0.3); };
// spider-style: two big glossy front eyes and smaller ones behind, each a
// wet black dome standing clear of the skin with a tinted rim and catch-light
HARD.e_cluster = (g, c, e) => {
  const pts = [[0.42, 0.44, 0.24, 0.30], [0.42, 0.44, -0.24, 0.30], [0.02, 0.44, 0.52, 0.19], [0.02, 0.44, -0.52, 0.19],
               [-0.28, 0.40, 0.32, 0.15], [-0.28, 0.40, -0.32, 0.15]];
  const rim = colMul(c, 0.35), ball = colMix(BLACKP, c, 0.12);
  for (const p of pts) {
    const r = p[3];
    g.sp(p[0], p[1] - r * 0.55, p[2], 0, 1, 0, r * 1.18, r * 0.45, r * 1.18, rim);
    g.ball(p[0], p[1], p[2], r, ball);
    if (!e || !e.lod) g.ball(p[0] + r * 0.35, p[1] + r * 0.62, p[2] + r * 0.2, r * 0.22, WHITE);
  }
};
FLESH.e_bug = (F) => { F.e(0, 0.1, 0, 0, 1, 0, 1, 0, 0, 1.12, 0.4, 1.12, 0.3); };
HARD.e_bug = VIS.e_bug.draw;
// horns: a skin mound at the root and a smooth tapered horn -------------------
const mound = (F, r, h) => { F.e(0, 0.02, 0, 0, 1, 0, 1, 0, 0, r, h || r * 0.55, r, r * 0.9); };
FLESH.h_straight = (F) => mound(F, 0.42);
HARD.h_straight = (g, c) => {
  const d = v3.norm([-0.22, 1, 0]);
  g.tb([0, 0, 0], v3.mul(d, 1.2), 0.3, 0.17, c);
  g.cn(...v3.mul(d, 1.2), d[0], d[1], d[2], 0.17, 0.75, c);
  g.tb([0, 0.02, 0], v3.mul(d, 0.25), 0.33, 0.3, colMul(c, 0.86));
};
const hornChain = (g, c, pts, r0, r1, tipLen) => {
  for (let i = 0; i < pts.length - 1; i++) {
    const u0 = i / (pts.length - 1), u1 = (i + 1) / (pts.length - 1);
    const ra = r0 + (r1 - r0) * u0, rb = r0 + (r1 - r0) * u1;
    const col = i % 3 === 1 ? colMul(c, 0.93) : c;
    g.tb(pts[i], pts[i + 1], ra, rb, col);
    if (i > 0) g.ball(pts[i][0], pts[i][1], pts[i][2], ra * 0.98, col);
  }
  const a = pts[pts.length - 2], b = pts[pts.length - 1];
  const d = v3.norm(v3.sub(b, a));
  g.ball(b[0], b[1], b[2], r1 * 0.98, c);
  g.cn(b[0], b[1], b[2], d[0], d[1], d[2], r1, tipLen, c);
};
FLESH.h_curved = (F) => mound(F, 0.42);
HARD.h_curved = (g, c) => {
  const pts = [[0, 0, 0]]; let p = [0, 0, 0], d = [0, 1, 0];
  for (let i = 0; i < 6; i++) { d = v3.norm(v3.add(d, [-0.28, 0, 0.05])); p = v3.add(p, v3.mul(d, 0.33)); pts.push(p); }
  hornChain(g, c, pts, 0.3, 0.08, 0.35);
};
FLESH.h_ram = (F) => mound(F, 0.46);
HARD.h_ram = (g, c) => {
  const pts = [[0, 0, 0]];
  const N = 16;
  for (let i = 1; i <= N; i++) {
    const th = i / N * Math.PI * 1.75, rr = 0.85 * (1 - i / N * 0.45);
    pts.push([-Math.sin(th) * rr, 0.25 + (1 - Math.cos(th)) * rr * 0.8, 0.22 * i / N]);
  }
  hornChain(g, c, pts, 0.36, 0.1, 0.15);
  // growth ridges
  for (let i = 2; i < pts.length - 2; i += 2) g.ball(pts[i][0], pts[i][1], pts[i][2], 0.36 * (1 - i / N * 0.7) * 1.06, colMul(c, 0.84));
};
FLESH.h_antler = (F) => mound(F, 0.34);
HARD.h_antler = (g, c) => {
  const beam = [[0, 0, 0], [-0.22, 0.8, 0.1], [-0.52, 1.6, 0.25], [-0.72, 2.3, 0.4]];
  hornChain(g, c, beam, 0.16, 0.08, 0.4);
  for (const [i, dx, dz] of [[1, 0.9, 0.1], [2, 0.8, 0.4], [2, 0.2, -0.5]]) {
    const d = v3.norm([dx, 0.8, dz]);
    const e = v3.add(beam[i], v3.mul(d, 0.45));
    g.tb(beam[i], e, 0.1, 0.07, c); g.cn(e[0], e[1], e[2], d[0], d[1], d[2], 0.07, 0.35, c);
  }
};
FLESH.h_rhino = (F) => mound(F, 0.62, 0.3);
HARD.h_rhino = (g, c) => {
  const d = v3.norm([-0.16, 1, 0]);
  g.tb([0, 0, 0], v3.mul(d, 0.5), 0.52, 0.4, c);
  g.cn(...v3.mul(d, 0.5), d[0], d[1], d[2], 0.4, 1.2, c);
  g.cn(-0.72, 0, 0, -0.1, 1, 0, 0.24, 0.6, colMul(c, 0.9));
};
FLESH.h_tusk = (F) => mound(F, 0.34, 0.22);
HARD.h_tusk = (g, c) => {
  const pts = [[0, 0, 0]]; let p = [0, 0, 0], d = [0, 1, 0];
  for (let i = 0; i < 5; i++) { d = v3.norm(v3.add(d, [0.3, 0, 0.05])); p = v3.add(p, v3.mul(d, 0.4)); pts.push(p); }
  hornChain(g, c, pts, 0.26, 0.1, 0.35);
};
// spikes and armour ---------------------------------------------------------------
FLESH.s_spike = (F) => mound(F, 0.4, 0.2);
HARD.s_spike = (g, c) => { const d = v3.norm([-0.18, 1, 0]); g.cn(0, 0, 0, d[0], d[1], d[2], 0.3, 1.5, c); };
FLESH.s_quills = (F) => mound(F, 0.38, 0.14);
HARD.s_quills = (g, c, e) => {
  const dirs = [[-0.2, 1, 0], [-0.5, 1, 0.3], [-0.5, 1, -0.3], [0.1, 1, 0.45], [0.1, 1, -0.45], [-0.8, 1, 0]];
  dirs.forEach((d, i) => { g.cn(d[0] * 0.15, 0, d[2] * 0.15, d[0], d[1], d[2], 0.07, 1.5 + (i % 3) * 0.25, i % 2 ? c : e.detail); });
};
FLESH.s_plate = (F) => {
  F.e(0, 0.02, 0, 0, 1, 0, 1, 0, 0, 0.72, 0.22, 0.3, 0.25);
};
HARD.s_plate = (g, c) => {
  const bk = backOf(g);
  g.cn(0, -0.1, 0, bk[0] * 0.3, 1, bk[2] * 0.3, 0.85, 1.9, c, bk[0], 0, bk[2], 0.09);
  g.cn(0, 0.15, 0, bk[0] * 0.3, 1, bk[2] * 0.3, 0.55, 1.35, colMul(c, 1.3), bk[0], 0, bk[2], 0.11);
};
FLESH.s_shell = (F) => { F.e(0, 0, 0, 0, 1, 0, 1, 0, 0, 1.55, 0.3, 1.35, 0.3); };
HARD.s_shell = VIS.s_shell.draw;
FLESH.s_knob = (F, c) => { F.s(0, 0.3, 0, 0.62, 0.25, c); };
HARD.s_knob = (g) => {
  for (let i = 0; i < 6; i++) { const a = i / 6 * 6.283; g.cn(Math.cos(a) * 0.42, 0.55, Math.sin(a) * 0.42, Math.cos(a), 1, Math.sin(a), 0.1, 0.35, IVORY); }
  g.cn(0, 0.88, 0, 0, 1, 0, 0.1, 0.4, IVORY);
};
FLESH.s_club = (F, c) => { F.c([0, 0, 0], [0, 0.8, 0], 0.3, 0.34, 0.2); F.s(0, 1.3, 0, 0.72, 0.2, c); };
HARD.s_club = (g) => {
  for (let i = 0; i < 10; i++) {
    const a = i * 2.39996, y = 1 - (i + 0.5) / 10 * 2, r = Math.sqrt(1 - y * y);
    const d = [Math.cos(a) * r, y, Math.sin(a) * r];
    g.cn(d[0] * 0.62, 1.3 + d[1] * 0.62, d[2] * 0.62, d[0], d[1], d[2], 0.13, 0.5, IVORY);
  }
};
// feet and hands (frame: y along the shin away from the ankle, x forward) ---------
FLESH.t_paw = (F) => {
  F.e(0.1, 0.24, 0, 0, 1, 0, 1, 0, 0, 0.62, 0.36, 0.62, 0.22);
  for (let i = 0; i < 4; i++) { const z = (i - 1.5) * 0.3, x = 0.46 + (1.5 - Math.abs(i - 1.5)) * 0.1; F.s(x, 0.44, z, 0.2, 0.08); }
};
HARD.t_paw = (g) => {
  for (let i = 0; i < 4; i++) { const z = (i - 1.5) * 0.3, x = 0.46 + (1.5 - Math.abs(i - 1.5)) * 0.1; g.cn(x + 0.14, 0.52, z, 1, 0.45, 0, 0.065, 0.22, IVORY); }
};
FLESH.t_hoof = (F) => { F.e(0, 0.06, 0, 0, 1, 0, 1, 0, 0, 0.52, 0.3, 0.52, 0.2); };
HARD.t_hoof = (g, c) => {
  g.tb([0.04, 0.22, 0], [0.08, 0.8, 0], 0.48, 0.62, c);
  g.sp(0.08, 0.8, 0, 0, 1, 0, 0.6, 0.04, 0.6, colMul(c, 0.6));
  g.sp(0.36, 0.55, 0, 1, 0, 0, 0.1, 0.25, 0.04, colMul(c, 0.5), 0, 1, 0);
};
FLESH.t_talon = (F, c) => {
  F.s(0, 0.14, 0, 0.3, 0.12, c);
  for (const t of [[1, 0, 0.35], [1, 0, 0], [1, 0, -0.35], [-1, 0, 0]]) {
    const dir = v3.norm([t[0], 0.35, t[2]]);
    F.c([0, 0.2, 0], v3.add([0, 0.2, 0], v3.mul(dir, t[0] > 0 ? 0.85 : 0.45)), 0.14, 0.09, 0.08, c);
  }
};
HARD.t_talon = (g) => {
  for (const t of [[1, 0, 0.35], [1, 0, 0], [1, 0, -0.35], [-1, 0, 0]]) {
    const dir = v3.norm([t[0], 0.35, t[2]]);
    const b = v3.add([0, 0.2, 0], v3.mul(dir, t[0] > 0 ? 0.85 : 0.45));
    const cd = v3.norm([dir[0] * 0.6, 0.85, dir[2] * 0.6]);
    g.tb(b, v3.add(b, v3.mul(cd, 0.14)), 0.08, 0.065, KERATIN);
    g.cn(...v3.add(b, v3.mul(cd, 0.14)), cd[0], cd[1], cd[2], 0.065, 0.24, KERATIN);
  }
};
const fingerPts = (i, curl) => {
  const x = (i - 1.5) * 0.24;
  const pts = [[x, 0.7, 0]];
  let p = pts[0], d = [0, 1, 0];
  for (let k = 0; k < 3; k++) { d = v3.norm(v3.add(d, [0, 0, curl * 0.6])); p = v3.add(p, v3.mul(d, 0.26 - k * 0.03)); pts.push(p); }
  return { pts, d };
};
FLESH.t_hand = (F, c, e) => {
  F.e(0, 0.36, 0, 0, 1, 0, 1, 0, 0, 0.5, 0.46, 0.26, 0.2);
  const curl = 0.35;
  for (let i = 0; i < 4; i++) { const { pts } = fingerPts(i, curl); for (let k = 0; k < 3; k++) F.c(pts[k], pts[k + 1], 0.1, 0.085, 0.05); }
  F.c([0.42, 0.3, 0.05], [0.7, 0.6, 0.25], 0.11, 0.09, 0.08);
};
HARD.t_hand = (g) => {
  for (let i = 0; i < 4; i++) { const { pts, d } = fingerPts(i, 0.35); const p = pts[3]; g.cn(p[0], p[1], p[2], d[0], d[1], d[2], 0.06, 0.13, IVORY); }
};
FLESH.t_claw = (F) => { F.e(0, 0.3, 0, 0, 1, 0, 1, 0, 0, 0.56, 0.42, 0.42, 0.2); };
HARD.t_claw = (g, c) => {
  for (let i = 0; i < 3; i++) {
    const x = (i - 1) * 0.3;
    const pts = [[x, 0.6, 0.12]]; let p = pts[0], d = [0, 1, 0.3];
    for (let k = 0; k < 4; k++) { d = v3.norm(v3.add(d, [0, -0.08, 0.4])); p = v3.add(p, v3.mul(d, 0.27)); pts.push(p); }
    hornChain(g, c, pts, 0.12, 0.05, 0.18);
  }
};
FLESH.t_pincer = (F) => { F.s(0, 0.1, 0, 0.32, 0.12); };
HARD.t_pincer = (g, c, e) => {
  g.sp(0, 0.6, 0, 0, 1, 0, 0.5, 0.72, 0.42, c);
  const o = 0.18 + e.grip * 0.25;
  g.cn(0.18, 1.1, 0, -o, 1, 0, 0.24, 1.0, colMul(c, 1.1));
  g.cn(-0.2, 1.1, 0, o, 1, 0, 0.2, 0.85, colMul(c, 0.9));
  g.ball(0.2, 0.9, 0.2, 0.08, IVORY); g.ball(-0.2, 0.9, 0.2, 0.08, IVORY);
};
FLESH.t_flipper = (F, c) => { F.e(0.2, 0.9, 0, 0.25, 1, 0, 1, 0, 0, 0.72, 1.05, 0.13, 0.15); };
HARD.t_flipper = () => {};
FLESH.t_pad = (F, c) => { F.c([0, 0, 0], [0, 0.3, 0], 0.4, 0.46, 0.12); F.e(0, 0.36, 0, 0, 1, 0, 1, 0, 0, 0.66, 0.16, 0.66, 0.1, c); };
HARD.t_pad = (g, c) => { g.sp(0, 0.5, 0, 0, 1, 0, 0.3, 0.05, 0.3, colMul(c, 0.6)); };
// fins, wings and details: fleshy roots, hard membranes --------------------------
for (const id of ['f_fin', 'f_dorsal', 'f_fluke']) FLESH[id] = (F) => { F.e(0, 0.02, 0, 0, 1, 0, 1, 0, 0, 0.36, 0.2, 0.3, 0.2); };
for (const id of ['w_bat', 'w_feather', 'w_insect']) FLESH[id] = (F) => { F.e(0, 0.03, 0, 0, 1, 0, 1, 0, 0, 0.3, 0.2, 0.3, 0.2); };
FLESH.d_antenna = (F) => mound(F, 0.3, 0.2);
FLESH.d_crest = (F) => mound(F, 0.32, 0.15);
FLESH.d_gills = (F) => { for (let i = 0; i < 3; i++) F.e(0.03, 0.05, (i - 1) * 0.42, 0, 1, 0, 1, 0, 0, 0.72, 0.16, 0.16, 0.06); };
HARD.d_gills = (g, c) => { for (let i = 0; i < 2; i++) g.sp(0.03, 0.06, (i - 0.5) * 0.42, 0, 1, 0, 0.66, 0.08, 0.06, colMul(c, 0.4), 1, 0, 0); };
FLESH.d_gland = (F, c) => {
  F.e(0, 0.36, 0, 0, 1, 0, 1, 0, 0, 0.66, 0.58, 0.66, 0.25, c);
  for (let i = 0; i < 3; i++) { const a = i * 2.1; F.s(Math.cos(a) * 0.5, 0.6, Math.sin(a) * 0.5, 0.14, 0.06, colMul(c, 0.7)); }
};
HARD.d_gland = (g, c) => { g.ball(0.2, 0.84, 0.15, 0.14, colHi(c)); };
const hardOf = (id) => HARD[id] || (VIS[id] && VIS[id].draw) || null;

// ---- bones ----------------------------------------------------------------------
// 0 body, 1 jaw, a fixed block of tail slots, then (upper, lower) per limb.
// The layout is kept stable across edits so a mesh that is a moment out of
// date (while its replacement bakes) still binds to sensible bones.
const TAIL_SLOTS = 12;
// A foot/hand/claw's own rotation: spin about the limb axis, tilt about its side
// axis. Mirrored twins turn the opposite way so a pair stays symmetric.
function tipFrame(x, y, z, tip, side) {
  const sp = (tip && tip.spin || 0) * side, tl = (tip && tip.tilt || 0);
  if (sp) { x = v3.rot(x, y, sp); z = v3.rot(z, y, sp); }
  if (tl) { const ax = v3.norm(z); x = v3.rot(x, ax, tl * side); y = v3.rot(y, ax, tl * side); }
  return [x, y, z];
}
function boneLayout(G) {
  const nl = G.cls.limbs.length;
  const nt = G.sk.tailLen > 0.05 ? Math.min(TAIL_SLOTS, G.sk.plan.ts) : 0;
  const limb0 = 3 + TAIL_SLOTS;
  return { nl, jaw: 1, head: 2, tail0: 3, nt, limb0, count: limb0 + 2 * nl };
}
// neck and head move together on one bone that pivots at the shoulders
const isHeadBall = (B, i) => !!B[i] && (B[i].g === 'neck' || B[i].g === 'head');
function headPivot(sk) {
  if (sk._pivot) return sk._pivot;
  const B = sk.balls, P = sk.plan;
  let first = sk.headIdx;
  for (let i = P.seg + 6; i < sk.headIdx; i++) if (B[i] && !B[i].hide) { first = i; break; }
  let bi = 0, bd = Infinity;
  for (let i = 0; i < P.seg; i++) { const d = Math.hypot(B[i].x - B[first].x, B[i].y - B[first].y, B[i].z - B[first].z); if (d < bd) { bd = d; bi = i; } }
  return (sk._pivot = [B[bi].x, B[bi].y, 0]);
}
// ---- small affine kit: { R: row-major 3x3, t: [3] } -------------------------------
function affRotZAbout(pivot, ang, move) {
  const c = Math.cos(ang), s = Math.sin(ang);
  const R = [c, -s, 0, s, c, 0, 0, 0, 1];
  const t = [pivot[0] - (c * pivot[0] - s * pivot[1]) + move[0], pivot[1] - (s * pivot[0] + c * pivot[1]) + move[1], move[2]];
  return { R, t };
}
function affAxisAbout(pivot, axis, ang) {
  const [x, y, z] = v3.norm(axis), c = Math.cos(ang), s = Math.sin(ang), k = 1 - c;
  const R = [k * x * x + c, k * x * y - s * z, k * x * z + s * y, k * x * y + s * z, k * y * y + c, k * y * z - s * x, k * x * z - s * y, k * y * z + s * x, k * z * z + c];
  const t = [pivot[0] - (R[0] * pivot[0] + R[1] * pivot[1] + R[2] * pivot[2]), pivot[1] - (R[3] * pivot[0] + R[4] * pivot[1] + R[5] * pivot[2]), pivot[2] - (R[6] * pivot[0] + R[7] * pivot[1] + R[8] * pivot[2])];
  return { R, t };
}
const affDir = (A, v) => [A.R[0] * v[0] + A.R[1] * v[1] + A.R[2] * v[2], A.R[3] * v[0] + A.R[4] * v[1] + A.R[5] * v[2], A.R[6] * v[0] + A.R[7] * v[1] + A.R[8] * v[2]];
const affPt = (A, v) => v3.add(affDir(A, v), A.t);
function affMul(A, B) {   // A after B
  const R = new Array(9);
  for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) R[i * 3 + j] = A.R[i * 3] * B.R[j] + A.R[i * 3 + 1] * B.R[3 + j] + A.R[i * 3 + 2] * B.R[6 + j];
  return { R, t: affPt(A, B.t) };
}
function boneAff(o, A, hl) {
  const R = A.R;
  boneData[o] = R[0]; boneData[o + 1] = R[3]; boneData[o + 2] = R[6]; boneData[o + 3] = 0;
  boneData[o + 4] = R[1]; boneData[o + 5] = R[4]; boneData[o + 6] = R[7]; boneData[o + 7] = 0;
  boneData[o + 8] = R[2]; boneData[o + 9] = R[5]; boneData[o + 10] = R[8]; boneData[o + 11] = 0;
  boneData[o + 12] = A.t[0]; boneData[o + 13] = A.t[1]; boneData[o + 14] = A.t[2]; boneData[o + 15] = hl || 1;
}
// The mouth part the jaw bone hinges on (first mouth on the body)
function mouthPart(des) { return (des.parts || []).find(p => C.ITEM_SIM[p.id] && C.ITEM_SIM[p.id].t === 'MOUTH') || null; }
// Rest-space frame of a surface part.
// Anchors are stored against the skeleton balls; the visible skin is the SDF
// surface, which sits a little inside the ball radii, so the anchor is slid
// along its normal onto that surface (cached per design revision).
function partRest(G, pt) {
  const sk = G.sk, B = sk.balls;
  const bi = clamp(pt.b | 0, 0, B.length - 1), k = B[bi];
  let cache = G._rest;
  if (!cache) cache = G._rest = new Map();
  const hit = cache.get(pt);
  if (hit && hit.src === pt.o && hit.n === pt.n && hit.b === pt.b && hit.spin === pt.spin) return hit.r;
  let p = C.anchorPos(sk, pt);
  if (k.g !== 'tail') {
    const n0 = v3.norm(pt.n || [0, 1, 0]);
    const h = C.snapToSkin(sk, p, n0);
    if (h && v3.len(v3.sub(h.p, p)) < Math.max(0.12, k.r * 0.45)) p = h.p;
  }
  const side = p[2] < -0.04 ? -1 : 1;
  const fr = partFrame(pt.n || [0, 1, 0], pt.spin || 0, side, false);
  const r = { p, fr, bi, side };
  cache.set(pt, { src: pt.o, n: pt.n, b: pt.b, spin: pt.spin, r });
  return r;
}
function limbRadii(lb) {
  const vis = VIS[lb.id] || VIS.l_leg;
  const th = clamp(lb.th || 1, 0.5, 2) * (vis.thick || 1);
  return { th, r0: 0.17 * th, r1: 0.122 * th, r2: 0.092 * th };
}
// Everything fleshy about a design, as SDF primitives with bones and colours.
function creaturePrims(des, G) {
  const sk = G.sk, B = sk.balls, L = boneLayout(G);
  const cols = des.col || { base: [0.5, 0.6, 0.5], coat: [0.9, 0.9, 0.8], detail: [0.2, 0.3, 0.2], pat: 0 };
  const out = [];
  for (const q of sk.prims) out.push(Object.assign({}, q, { bone: isHeadBall(B, q.j) ? L.head : 0, col: null }));
  sk.tailPrims.forEach((q, j) => out.push(Object.assign({}, q, { bone: L.tail0 + j, col: null })));
  // limbs
  G.cls.limbs.forEach((o, li) => {
    const lb = o.lb, up = L.limb0 + 2 * li, lo = up + 1;
    const { th, r0, r1, r2 } = limbRadii(lb);
    const col = lb.c || null;
    const root = o.root, knee = v3.add(root, lb.k), foot = v3.add(root, lb.f);
    out.push({ t: 's', ax: root[0], ay: root[1], az: root[2], ra: r0 * 1.12, k: 0.24 * th, bone: up, col });
    out.push({ t: 'c', ax: root[0], ay: root[1], az: root[2], bx: knee[0], by: knee[1], bz: knee[2], ra: r0, rb: r1, k: 0.06, bone: up, col });
    out.push({ t: 'c', ax: knee[0], ay: knee[1], az: knee[2], bx: foot[0], by: foot[1], bz: foot[2], ra: r1 * 1.02, rb: r2, k: 0.06, bone: lo, col });
    // muscle swell on the upper segment
    const ud = v3.sub(knee, root), L1 = v3.len(ud);
    if (L1 > 0.2) {
      const m = v3.lerp(root, knee, 0.36), ey = v3.norm(ud);
      let ex = v3.norm(v3.cross(ey, [0, 0, 1])); if (!isFinite(ex[0]) || v3.len(ex) < 0.5) ex = [1, 0, 0];
      const bulk = lb.id === 'l_spring' ? 1.55 : 1;   // springing legs carry a huge thigh
      out.push({ t: 'e', ax: m[0], ay: m[1], az: m[2], ex, ey, ez: v3.cross(ex, ey), rx: r0 * 1.12 * bulk, ry: L1 * 0.32 * (bulk > 1 ? 1.2 : 1), rz: r0 * 1.08 * bulk, k: 0.08, bone: up, col });
    }
    if (lb.tip && FLESH[lb.tip.id]) {
      const tv = VIS[lb.tip.id];
      const dir = v3.norm(v3.sub(foot, knee));
      let xw = v3.sub([1, 0, 0], v3.mul(dir, dir[0]));
      if (v3.len(xw) < 0.3) xw = v3.sub([0, 1, 0], v3.mul(dir, dir[1]));
      xw = v3.norm(xw);
      const side = root[2] < -0.04 ? -1 : 1;
      const zw = v3.mul(v3.cross(dir, xw), side);
      const S = tv.size * clamp(lb.tip.s || 1, 0.4, 2.5) * th;
      const tc = lb.tip.c || (Array.isArray(tv.col) ? tv.col : null);
      const [tx0, ty0, tz0] = tipFrame(xw, dir, zw, lb.tip, side);
      const F = makeF(out, foot, tx0, ty0, tz0, S, lo);
      FLESH[lb.tip.id](F, tc, { base: cols.base });
    }
  });
  // part flesh
  const mouth = mouthPart(des);
  for (const pt of des.parts || []) {
    const fl = FLESH[pt.id];
    if (!fl) continue;
    const vis = VIS[pt.id];
    const { p, fr, bi } = partRest(G, pt);
    const bone = B[bi].g === 'tail' ? L.tail0 + (bi - sk.tailStart) : isHeadBall(B, bi) ? L.head : 0;
    const S = vis.size * clamp(pt.s || 1, 0.3, 3);
    const c = pt.c || (Array.isArray(vis.col) ? vis.col : null);
    const F = makeF(out, p, fr.x, fr.y, fr.z, S, bone);
    if (pt === mouth) F.jawBone = L.jaw;
    fl(F, c, { base: cols.base, fw: frameLocal(fr, [1, 0, 0]), up: frameLocal(fr, [0, 1, 0]) });
  }
  return out;
}

// ---- GPU mesh cache and background baking ------------------------------------------
// Meshes are baked off the main thread by a small pool of workers running the
// same meshPrims() source, so editing or a crowd of new creatures never stalls a
// frame. If workers are unavailable the queue is drained on the main thread
// within a per-frame time budget instead.
const meshLRU = new Set();
const MESH_LRU_MAX = 200;
const meshBuildQueue = [];
const meshJobs = new Map();
let meshJobId = 1, meshPool = null, meshPoolBroken = false;
function meshWorkerSource() {
  return ['"use strict";', 'const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);',
    `const MESH_V_FLOATS = ${MESH_V_FLOATS}; const PS = ${PS};`,
    packPrims, sdPacked, primBounds, primMinR, meshPrims].map(String).join('\n') + `
onmessage = (e) => {
  const d = e.data; let m = null, err = null;
  try { m = meshPrims(d.prims, d.q); } catch (x) { err = String((x && x.stack) || x); }
  if (m) postMessage({ id: d.id, vertData: m.vertData, idx: m.idx, tris: m.tris }, [m.vertData.buffer, m.idx.buffer]);
  else postMessage({ id: d.id, err: err || 'empty' });
};`;
}
function meshPoolInit() {
  if (meshPool || meshPoolBroken) return meshPool;
  try {
    if (typeof Worker === 'undefined') throw new Error('no workers');
    const url = URL.createObjectURL(new Blob([meshWorkerSource()], { type: 'text/javascript' }));
    const n = clamp(((navigator.hardwareConcurrency || 4) - 1) | 0, 1, 3);
    meshPool = [];
    for (let i = 0; i < n; i++) {
      const w = new Worker(url);
      const slot = { w, busy: 0 };
      w.onmessage = (e) => { slot.busy = 0; meshJobDone(e.data); meshDispatch(); };
      w.onerror = (e) => { console.warn('mesh worker failed, baking on the main thread', e.message || e); meshPoolFail(); };
      meshPool.push(slot);
    }
  } catch (e) { console.warn('mesh workers unavailable:', e.message); meshPoolBroken = true; meshPool = null; }
  return meshPool;
}
function meshPoolFail() {
  if (meshPoolBroken) return;
  meshPoolBroken = true;
  if (meshPool) for (const s of meshPool) { try { s.w.terminate(); } catch (e) {} }
  meshPool = null;
  // everything in flight goes back on the queue for the main-thread path
  for (const j of meshJobs.values()) { j.des._job = null; if (!j.des._queued) { j.des._queued = j.q; meshBuildQueue.push(j.des); } }
  meshJobs.clear();
}
function designMeshKey(des) { return (des._rev || 0); }
function uploadDesignMesh(m) {
  const vb = dev.createBuffer({ size: m.vertData.byteLength, usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST });
  dev.queue.writeBuffer(vb, 0, m.vertData);
  const ib = dev.createBuffer({ size: m.idx.byteLength, usage: GPUBufferUsage.INDEX | GPUBufferUsage.COPY_DST });
  dev.queue.writeBuffer(ib, 0, m.idx);
  return { vb, ib, count: m.idx.length, tris: m.tris };
}
function dropDesignMesh(des) {
  const m = des._mesh;
  if (m && m.gpu && !m.shared) { m.gpu.vb.destroy(); m.gpu.ib.destroy(); }
  des._mesh = null;
  meshLRU.delete(des);
}
function installDesignMesh(des, key, q, nl, m) {
  const old = des._mesh;
  if (old && old.gpu && !old.shared) { old.gpu.vb.destroy(); old.gpu.ib.destroy(); }
  des._mesh = { key, q, nl, gpu: m ? uploadDesignMesh(m) : null, failed: !m };
  meshLRU.delete(des); meshLRU.add(des);
  while (meshLRU.size > MESH_LRU_MAX) { const o = meshLRU.values().next().value; if (o === des) break; dropDesignMesh(o); }
  return des._mesh.gpu;
}
function buildDesignMeshNow(des, quality) {
  const G = designGeo(des);
  let m = null;
  try { m = meshPrims(creaturePrims(des, G), quality); } catch (e) { console.error(e); m = null; }
  return installDesignMesh(des, designMeshKey(des), quality, G.cls.limbs.length, m);
}
function meshRequest(des, q) {
  if (des._job) { if (des._job.key !== designMeshKey(des) || des._job.q < q) des._want = Math.max(des._want || 0, q); return; }
  if (des._queued) { if (q > des._queued) des._queued = q; return; }
  des._queued = q;
  if (q) meshBuildQueue.unshift(des); else meshBuildQueue.push(des);
  meshDispatch();
}
function meshDispatch() {
  const pool = meshPoolInit();
  if (!pool) return;
  for (const slot of pool) {
    if (slot.busy) continue;
    let des = null;
    while (meshBuildQueue.length && !des) {
      const d = meshBuildQueue.shift();
      const q = d._queued || 0; d._queued = 0;
      const m = d._mesh;
      if (m && m.key === designMeshKey(d) && m.q >= q) continue;
      des = d; des._jq = q;
    }
    if (!des) return;
    const G = designGeo(des);
    let prims;
    try { prims = creaturePrims(des, G); } catch (e) { console.error(e); continue; }
    const id = meshJobId++;
    const job = { des, key: designMeshKey(des), q: des._jq, nl: G.cls.limbs.length };
    des._job = job; meshJobs.set(id, job);
    slot.busy = id;
    slot.w.postMessage({ id, prims, q: job.q });
  }
}
function meshJobDone(r) {
  const job = meshJobs.get(r.id);
  if (!job) return;
  meshJobs.delete(r.id);
  const des = job.des;
  des._job = null;
  const cur = des._mesh;
  const fresh = cur && cur.key === designMeshKey(des);
  // take the result unless we already hold a mesh of the current design that is at least as good
  if (!(fresh && (job.key !== cur.key || cur.q >= job.q))) {
    if (r.err) { if (!cur) des._mesh = { key: job.key, q: job.q, nl: job.nl, gpu: null, failed: true }; if (r.err !== 'empty') console.warn('mesh bake failed', r.err); }
    else installDesignMesh(des, job.key, job.q, job.nl, r);
  }
  const want = des._want || 0; des._want = 0;
  const now = des._mesh;
  if (!now || now.key !== designMeshKey(des) || now.q < want) meshRequest(des, Math.max(want, job.q));
}
// sync: 'now' builds the exact mesh immediately (thumbnails). true builds a quick
// low-detail mesh right away only when there is nothing at all to show, and
// bakes the requested quality in the background. false never blocks.
function getDesignMesh(des, quality, sync) {
  const m = des._mesh;
  const fresh = m && m.key === designMeshKey(des);
  if (fresh && m.q >= quality) { meshLRU.delete(des); meshLRU.add(des); return m.gpu; }
  if (sync === 'now') return buildDesignMeshNow(des, quality);
  if (sync && !(m && m.gpu)) { buildDesignMeshNow(des, 0); if (quality > 0) meshRequest(des, quality); return des._mesh.gpu; }
  if (!(fresh && m.failed)) {
    // nothing to show yet: bake a quick coarse skin first, then the requested one
    if (!(m && m.gpu) && quality > 0 && !des._job && !des._queued) { meshRequest(des, 0); des._want = Math.max(des._want || 0, quality); }
    else meshRequest(des, quality);
  }
  return m && m.gpu ? m.gpu : null;
}
// main-thread fallback when workers are not available
function pumpDesignMeshes(budgetMs) {
  if (meshPoolInit()) { meshDispatch(); return; }
  const t0 = performance.now();
  while (meshBuildQueue.length && performance.now() - t0 < budgetMs) {
    const des = meshBuildQueue.shift();
    const q = des._queued || 0; des._queued = 0;
    const m = des._mesh;
    if (m && m.key === designMeshKey(des) && m.q >= q) continue;
    buildDesignMeshNow(des, q);
    const want = des._want || 0; des._want = 0;
    if (want > q) { des._queued = want; meshBuildQueue.push(des); }
  }
}

// ---- per-frame bones and skinned draws -------------------------------------------
const MAX_BONES = 8192;
const boneData = new Float32Array(MAX_BONES * 16);
let boneN = 0, boneBuf = null;
const skinDraws = [];
const MAX_SKIN_INST = 600;
const skinInstData = new Float32Array(MAX_SKIN_INST * BINST_FLOATS);
function boneIdentity(o, hl) {
  boneData.fill(0, o, o + 16);
  boneData[o] = 1; boneData[o + 5] = 1; boneData[o + 10] = 1; boneData[o + 15] = hl || 1;
}
// matrix taking rest segment a0->b0 to posed a1->b1 (rotation about the joint + move)
function boneSegment(o, a0, b0, a1, b1, hl) {
  const u0 = v3.norm(v3.sub(b0, a0)), u1 = v3.norm(v3.sub(b1, a1));
  let axis = v3.cross(u0, u1);
  const s = v3.len(axis), c = clamp(v3.dot(u0, u1), -1, 1);
  let R;
  if (s < 1e-6) R = c > 0 ? [1, 0, 0, 0, 1, 0, 0, 0, 1] : [1, 0, 0, 0, -1, 0, 0, 0, -1];
  else {
    axis = v3.mul(axis, 1 / s);
    const [x, y, z] = axis, t = 1 - c;
    // row-major 3x3
    R = [t * x * x + c, t * x * y - s * z, t * x * z + s * y,
         t * x * y + s * z, t * y * y + c, t * y * z - s * x,
         t * x * z - s * y, t * y * z + s * x, t * z * z + c];
  }
  // p' = R (p - a0) + a1 -> translation = a1 - R a0 ; store column-major mat4
  const tx = a1[0] - (R[0] * a0[0] + R[1] * a0[1] + R[2] * a0[2]);
  const ty = a1[1] - (R[3] * a0[0] + R[4] * a0[1] + R[5] * a0[2]);
  const tz = a1[2] - (R[6] * a0[0] + R[7] * a0[1] + R[8] * a0[2]);
  boneData[o] = R[0]; boneData[o + 1] = R[3]; boneData[o + 2] = R[6]; boneData[o + 3] = 0;
  boneData[o + 4] = R[1]; boneData[o + 5] = R[4]; boneData[o + 6] = R[7]; boneData[o + 7] = 0;
  boneData[o + 8] = R[2]; boneData[o + 9] = R[5]; boneData[o + 10] = R[8]; boneData[o + 11] = 0;
  boneData[o + 12] = tx; boneData[o + 13] = ty; boneData[o + 14] = tz; boneData[o + 15] = hl || 1;
}
// rotation by ang about an axis through a hinge point (same handedness as v3.rot)
function boneHinge(o, hinge, axis, ang, hl) {
  const [x, y, z] = v3.norm(axis), c = Math.cos(ang), s = Math.sin(ang), t = 1 - c;
  const R = [t * x * x + c, t * x * y - s * z, t * x * z + s * y,
             t * x * y + s * z, t * y * y + c, t * y * z - s * x,
             t * x * z - s * y, t * y * z + s * x, t * z * z + c];
  const tx = hinge[0] - (R[0] * hinge[0] + R[1] * hinge[1] + R[2] * hinge[2]);
  const ty = hinge[1] - (R[3] * hinge[0] + R[4] * hinge[1] + R[5] * hinge[2]);
  const tz = hinge[2] - (R[6] * hinge[0] + R[7] * hinge[1] + R[8] * hinge[2]);
  boneData[o] = R[0]; boneData[o + 1] = R[3]; boneData[o + 2] = R[6]; boneData[o + 3] = 0;
  boneData[o + 4] = R[1]; boneData[o + 5] = R[4]; boneData[o + 6] = R[7]; boneData[o + 7] = 0;
  boneData[o + 8] = R[2]; boneData[o + 9] = R[5]; boneData[o + 10] = R[8]; boneData[o + 11] = 0;
  boneData[o + 12] = tx; boneData[o + 13] = ty; boneData[o + 14] = tz; boneData[o + 15] = hl || 1;
}
function resetSkinFrame() { boneN = 0; skinDraws.length = 0; }
function flushSkinDraws(pass) {
  if (!skinDraws.length) return;
  if (!boneBuf) return;
  dev.queue.writeBuffer(boneBuf, 0, boneData, 0, boneN * 16);
  const n = Math.min(skinDraws.length, MAX_SKIN_INST);
  for (let i = 0; i < n; i++) skinInstData.set(skinDraws[i].inst, i * BINST_FLOATS);
  dev.queue.writeBuffer(skinInstVB, 0, skinInstData, 0, n * BINST_FLOATS);
  pass.setPipeline(skinPipe); pass.setBindGroup(0, skinBind);
  pass.setVertexBuffer(1, skinInstVB);
  for (let i = 0; i < n; i++) {
    const d = skinDraws[i];
    pass.setVertexBuffer(0, d.mesh.vb);
    pass.setIndexBuffer(d.mesh.ib, 'uint32');
    pass.drawIndexed(d.mesh.count, 1, 0, 0, i);
  }
}

// ---- draw one designed creature -----------------------------------------------------
// X: toW / toL (body space <-> world), dirW, R, t, seed, gaitPhase, tail, flap,
// chomp, grip, blink, hl, lod, far, hide, limbPose, quality, sync,
// place { pos, yaw } for the skin instance
function drawDesign(des, X) {
  const G = designGeo(des);
  const sk = G.sk, B = sk.balls, P = sk.plan;
  const col = des.col || { base: [0.5, 0.6, 0.5], coat: [0.9, 0.9, 0.8], detail: [0.2, 0.3, 0.2], pat: 0 };
  const base = X.tint ? colMix(col.base, X.tint, X.tintK) : col.base;
  const coat = X.tint ? colMix(col.coat, X.tint, X.tintK) : col.coat;
  const detail = col.detail;
  const R = X.R, t = X.t, seed = X.seed || 0;
  const hide = X.hide;
  const L = boneLayout(G);
  // serpentine wave (applied by the skin shader to every vertex; mirrored here for hard parts)
  const wAmp = sk.flex ? (X.flexAmp != null ? X.flexAmp : 0.25) : 0;
  const wPh = (X.gaitPhase || 0) * 1.2 + seed;
  const waveZ = (x) => wAmp ? wAmp * Math.sin(wPh - x * 2.4) * (0.35 + 0.65 * clamp((sk.a - x) / (2 * sk.a), 0, 1)) : 0;
  const wv = (p) => wAmp ? [p[0], p[1], p[2] + waveZ(p[0])] : p;
  // tail pose
  const tp = sk.tailLen > 0.05 ? tailPose(sk, X.gaitPhase != null ? X.gaitPhase : t, X.tailAmp != null ? X.tailAmp : 0.6, X.tailSwing || 0, seed) : [];
  const mesh = X.far && !X.meshFar ? null : getDesignMesh(des, X.quality || 0, !!X.sync);
  const hlOn = (obj, list) => X.hl && (X.hl.part === obj || X.hl.limb === obj || (X.hl.mirror && obj.m && ((X.hl.part && X.hl.part.m === obj.m) || (X.hl.limb && X.hl.limb.m === obj.m))));
  // posed limbs, in body space
  const limbs = G.cls.limbs.map((o, li) => {
    const lb = o.lb;
    const root = o.root, knee = v3.add(root, lb.k), foot = v3.add(root, lb.f);
    const pose = X.limbPose ? X.limbPose(o, li, root, knee, foot) : null;
    return pose ? { root, knee: X.toL(pose.knee), foot: X.toL(pose.foot), rest: { root, knee, foot } }
                : { root, knee, foot, rest: { root, knee, foot } };
  });
  const jawAng = (X.chomp || 0) * 0.42;
  // head and neck pose: pitch about the shoulders plus a thrust (body units)
  const hp = X.head || null;
  const headA = hp ? affRotZAbout(headPivot(sk), hp.pitch || 0, [hp.fwd || 0, hp.lift || 0, 0]) : null;
  const nlB = Math.max(L.nl, (des._mesh && des._mesh.nl) || 0);
  const boneCount = L.limb0 + 2 * nlB;
  if (mesh && boneBuf && boneN + boneCount <= MAX_BONES && skinDraws.length < MAX_SKIN_INST) {
    const bb = boneN;
    for (let j = 0; j < L.limb0; j++) boneIdentity((bb + j) * 16, 1);
    limbs.forEach((l, li) => {
      const h = hlOn(G.cls.limbs[li].lb) ? 1.3 : 1;
      boneSegment((bb + L.limb0 + 2 * li) * 16, l.rest.root, l.rest.knee, l.root, l.knee, h);
      boneSegment((bb + L.limb0 + 1 + 2 * li) * 16, l.rest.knee, l.rest.foot, l.knee, l.foot, h);
    });
    if (L.nt) {
      let a0 = [-sk.a * 0.92, sk.b * 0.08, 0], a1 = a0;
      for (let j = 0; j < L.nt; j++) {
        const k = B[sk.tailStart + j];
        const b0 = [k.x, k.y, k.z], b1 = tp[j].p;
        boneSegment((bb + L.tail0 + j) * 16, a0, b0, a1, b1, 1);
        a0 = b0; a1 = b1;
      }
    }
    const mp = mouthPart(des);
    if (headA) boneAff((bb + L.head) * 16, headA, 1);
    if (mp) {
      const pr = partRest(G, mp);
      let J = affAxisAbout(pr.p, pr.fr.z, jawAng * pr.side);
      if (headA && isHeadBall(B, pr.bi)) J = affMul(headA, J);
      boneAff((bb + L.jaw) * 16, J, 1);
    } else if (headA) boneAff((bb + L.jaw) * 16, headA, 1);
    for (let li = L.nl; li < nlB; li++) { boneIdentity((bb + L.limb0 + 2 * li) * 16, 1); boneIdentity((bb + L.limb0 + 1 + 2 * li) * 16, 1); }
    // lying along a slope: every bone is carried by the body's tilt
    if (X.tilt) for (let j = 0; j < boneCount; j++) {
      const o = (bb + j) * 16, D = boneData;
      const M = { R: [D[o], D[o + 4], D[o + 8], D[o + 1], D[o + 5], D[o + 9], D[o + 2], D[o + 6], D[o + 10]], t: [D[o + 12], D[o + 13], D[o + 14]] };
      boneAff(o, affMul(X.tilt, M), D[o + 15]);
    }
    boneN += boneCount;
    const inst = new Float32Array(BINST_FLOATS);
    const q = X.toW([0, 0, 0]);
    inst.set([q[0], q[1], q[2], X.yaw || 0, R, base[0], base[1], base[2], coat[0], coat[1], coat[2], detail[0], detail[1], detail[2], (col.pat | 0) + 16 * ((col.skin != null ? col.skin : (C.PLAN_SKIN ? C.PLAN_SKIN[des.plan | 0] : 0)) | 0), X.selBody ? 1 : 0, wAmp, wPh, sk.a, bb]);
    skinDraws.push({ mesh, inst });
  } else {
    // placeholder while the skin bakes: the same primitives as simple shapes
    for (const q of sk.prims) {
      const a = X.toW(wv([q.ax, q.ay, q.az]));
      if (q.t === 's') pushSX(a[0], a[1], a[2], 0, 1, 0, 0, 0, 0, q.ra * R, q.ra * R, q.ra * R, base);
      else { const b = X.toW(wv([q.bx, q.by, q.bz])); pushT(a[0], a[1], a[2], b[0], b[1], b[2], q.ra * R, base, q.rb * R); pushSX(b[0], b[1], b[2], 0, 1, 0, 0, 0, 0, q.rb * R, q.rb * R, q.rb * R, base); }
    }
    let prev = X.toW(wv([-sk.a * 0.92, sk.b * 0.08, 0]));
    for (let j = 0; j < tp.length; j++) {
      const q = X.toW(wv(tp[j].p)), r = B[sk.tailStart + j].r * 0.95 * R;
      pushT(prev[0], prev[1], prev[2], q[0], q[1], q[2], r * 1.1, base, r); prev = q;
    }
    if (!X.far) limbs.forEach((l, li) => {
      const { th } = limbRadii(G.cls.limbs[li].lb);
      drawLimbTube(X.toW(wv(l.root)), X.toW(wv(l.knee)), X.toW(wv(l.foot)), th, R, G.cls.limbs[li].lb.c || base, false);
    });
  }
  if (X.far) return;
  const env = { t, seed, base, coat, detail, limb: base, flap: X.flap || 0, chomp: X.chomp || 0, jaw: jawAng, grip: X.grip || 0, blink: 0, lod: X.lod || 0 };
  // ---- hard pieces of surface parts ----------------------------------------------
  const parts = des.parts || [];
  const mouth = mouthPart(des);
  for (let pi = 0; pi < parts.length; pi++) {
    const pt = parts[pi];
    const vis = VIS[pt.id];
    const draw = hardOf(pt.id);
    if (!vis || !draw) continue;
    const sim = C.ITEM_SIM[pt.id];
    if (hide && sim && hide.has(sim.t)) continue;
    if (X.lod >= 2 && vis.size * (pt.s || 1) < 0.24) continue;
    const r0 = partRest(G, pt);
    let lp = r0.p, n = r0.fr.y, fx = r0.fr.x, fz = r0.fr.z;
    if (B[r0.bi].g === 'tail') {
      // follow the tail bone: rigid transform of the segment this ball ends
      const j = r0.bi - sk.tailStart;
      const k = B[r0.bi];
      const off = v3.sub(lp, [k.x, k.y, k.z]);
      const yaw = tp[j] ? tp[j].yaw : 0;
      lp = v3.add(tp[j] ? tp[j].p : [k.x, k.y, k.z], rotYv(off, yaw));
      n = rotYv(n, yaw); fx = rotYv(fx, yaw); fz = rotYv(fz, yaw);
    } else if (headA && isHeadBall(B, r0.bi)) {
      lp = affPt(headA, lp); n = affDir(headA, n); fx = affDir(headA, fx); fz = affDir(headA, fz);
    }
    lp = wv(lp);
    const S = vis.size * clamp(pt.s || 1, 0.3, 3) * R;
    const fr = { x: fx, y: n, z: fz };
    const g = makeG(X.toW(lp), X.dirW(fx), X.dirW(n), X.dirW(fz), S, frameLocal(fr, [1, 0, 0]), frameLocal(fr, [0, 1, 0]));
    let cc = itemColor(pt.id, pt.c, { base, coat, detail });
    if (hlOn(pt)) cc = colHi(cc);
    env.seed = seed + pi * 1.7;
    env.blink = X.blink ? X.blink(pi) : 0;
    env.jaw = pt === mouth ? jawAng : 0;
    // mirrored wings get the mirrored angle, so both beat down together
    env.flap = (X.flap || 0) * (r0.p[2] < 0 ? -1 : 1);
    draw(g, cc, env);
  }
  // ---- hard pieces of feet and hands --------------------------------------------------
  limbs.forEach((l, li) => {
    const lb = G.cls.limbs[li].lb;
    if (hide && hide.has(G.cls.limbs[li].leg ? 'LEG' : 'ARM')) return;
    if (!lb.tip || !VIS[lb.tip.id]) return;
    const tv = VIS[lb.tip.id], draw = hardOf(lb.tip.id);
    if (!draw) return;
    const { th } = limbRadii(lb);
    const kw = X.toW(wv(l.knee)), fw = X.toW(wv(l.foot));
    const dirW2 = v3.norm(v3.sub(fw, kw));
    const fwdW = X.dirW([1, 0, 0]);
    let xw = v3.sub(fwdW, v3.mul(dirW2, v3.dot(fwdW, dirW2)));
    if (v3.len(xw) < 0.3) { const upW = X.dirW([0, 1, 0]); xw = v3.sub(upW, v3.mul(dirW2, v3.dot(upW, dirW2))); }
    xw = v3.norm(xw);
    const side = l.root[2] < -0.04 ? -1 : 1;
    const zw = v3.mul(v3.cross(dirW2, xw), side);
    const S = tv.size * clamp(lb.tip.s || 1, 0.4, 2.5) * th * R;
    const [tx1, ty1, tz1] = tipFrame(xw, dirW2, zw, lb.tip, side);
    const g = makeG(fw, tx1, ty1, tz1, S, [1, 0, 0], [0, -1, 0]);
    let tc = itemColor(lb.tip.id, lb.tip.c, { base, coat, detail });
    if (hlOn(lb)) tc = colHi(tc);
    env.limb = lb.c || base;
    draw(g, tc, env);
  });
}
