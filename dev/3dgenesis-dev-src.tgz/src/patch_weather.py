# ---------------------------------------------------------------- WEATHER
# Rain, storms, lightning and the global wetness channel they drive. The sky
# itself is a pure function of (seed, world.bt); only the wetness integral and
# the lightning timer carry state. See src/weather.js.
#
# fogCol.w has been sitting unused since the globals block was written. It is
# the wetness channel now, and the skin, terrain and foliage shaders read it.
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, (a[:90], n); return s.replace(a, b)
p = 'g3.html'; s = open(p, encoding='utf-8').read()

s = sub1(s, "// ================================================================ player\n",
         open('src/weather.js', encoding='utf-8').read() + "\n// ================================================================ player\n")
open(p, 'w', encoding='utf-8').write(s)
print('weather: module in ok')

s = open(p, encoding='utf-8').read()
# ---- stepped once per tick, before the frame is drawn, and in headless steps too
s = sub1(s, "  stepSim(dt);\n", "  stepSim(dt);\n  try { wxTick(dt); } catch (e) { if (!wxTick._w) { wxTick._w = 1; console.warn('weather tick', e); } }\n")
# ---- the wetness channel, and what the weather does to the air
s = sub1(s, "  gArr[24] = fog[0]; gArr[25] = fog[1]; gArr[26] = fog[2]; gArr[27] = 1;",
"""  gArr[24] = fog[0]; gArr[25] = fog[1]; gArr[26] = fog[2];
  // fogCol.w is the global wetness channel: 0 bone dry, 1 streaming.
  gArr[27] = clamp(world.wet || 0, 0, 1);""")
s = sub1(s, "  gArr[28] = t; gArr[29] = FOG_DENSITY * GFX.fog * (1 + 2.4 * can) * (1 + 3.2 * (1 - lt2)); gArr[30] = (0.1 + 0.9 * lt2) * (1 - 0.22 * can); gArr[31] = terrain.LV.water * HEIGHT_SCALE;",
"""  gArr[28] = t; gArr[29] = FOG_DENSITY * GFX.fog * (1 + 2.4 * can) * (1 + 3.2 * (1 - lt2)); gArr[30] = (0.1 + 0.9 * lt2) * (1 - 0.22 * can); gArr[31] = terrain.LV.water * HEIGHT_SCALE;
  // ---- what the weather does to the air -------------------------------
  // Rain is not a particle effect with the world unchanged behind it: the
  // air thickens, the light goes out of the sky, and the colour of the
  // distance goes grey-green. The drops are the last and smallest part.
  if (WX.rain > 0.002) {
    const r = WX.rain, st = WX.storm;
    gArr[29] = gArr[29] * (1 + 2.6 * r + 2.2 * st);
    const grey = clamp(r * 0.72, 0, 0.72);
    gArr[24] = gArr[24] * (1 - grey) + 0.30 * grey;
    gArr[25] = gArr[25] * (1 - grey) + 0.34 * grey;
    gArr[26] = gArr[26] * (1 - grey) + 0.33 * grey;
    gArr[30] = gArr[30] * (1 - 0.55 * r - 0.22 * st);
  }
  // ---- lightning: the flash lights the whole world for about a tenth of a
  // second, and it is BLUE-WHITE and far brighter than the sun, which is why
  // a storm at night is a series of stills rather than a lit scene.
  if (WX.flash > 0.002) {
    const fl = clamp(WX.flash, 0, 1.4);
    gArr[30] = gArr[30] + fl * 0.85;
    // the flash is WHITE with a little blue in it. Tinting the fog toward a
    // colour is how it ends up reading as a damage overlay instead.
    const fk = 0.55 * fl;
    gArr[24] = gArr[24] * (1 - fk) + 0.80 * fk;
    gArr[25] = gArr[25] * (1 - fk) + 0.83 * fk;
    gArr[26] = gArr[26] * (1 - fk) + 0.90 * fk;
  }""")
# the builder podium sees the same sky you will be standing in
s = sub1(s, "  gArr[24] = 0.52; gArr[25] = 0.60; gArr[26] = 0.52; gArr[27] = 1;",
         "  gArr[24] = 0.52; gArr[25] = 0.60; gArr[26] = 0.52;\n  gArr[27] = clamp((typeof world !== 'undefined' && world && world.wet != null) ? world.wet : 0, 0, 1);")
open(p, 'w', encoding='utf-8').write(s)
print('weather: globals and the air ok')

s = open(p, encoding='utf-8').read()
# ---- pipeline, per-frame build and draw, alongside the cloud wall
s = sub1(s, "  try { cloudInit(); } catch (e) { console.warn('cloud pipeline', e); }",
         "  try { cloudInit(); } catch (e) { console.warn('cloud pipeline', e); }\n  try { rainInit(); } catch (e) { console.warn('rain pipeline', e); }")
s = sub1(s, "  try { if (BR.on) cloudBuild(t); else cloudCount = 0; } catch (e) { console.warn('cloud build', e); }",
         "  try { if (BR.on) cloudBuild(t); else cloudCount = 0; } catch (e) { console.warn('cloud build', e); }\n  try { rainBuild(); } catch (e) { rainN = 0; if (!rainBuild._w) { rainBuild._w = 1; console.warn('rain build', e); } }")
s = sub1(s, "  try { cloudDraw(pass); } catch (e) { console.warn('cloud draw', e); }",
         "  try { cloudDraw(pass); } catch (e) { console.warn('cloud draw', e); }\n  try { rainDraw(pass); } catch (e) { console.warn('rain draw', e); }")
open(p, 'w', encoding='utf-8').write(s)
print('weather: rain drawn ok')

s = open(p, encoding='utf-8').read()
# ---- sound
s = sub1(s, "function sndTick(dt) {\n  if (!SND.ctx || !SND.on || !world) return;",
         "function sndTick(dt) {\n  if (!SND.ctx || !SND.on || !world) return;\n  try { wxSound(dt); } catch (e) {}")
open(p, 'w', encoding='utf-8').write(s)
print('weather: rain and thunder audible ok')

s = open(p, encoding='utf-8').read()
# ---- SKIN. The material already says how wet the animal is on a dry day.
# Rain is a SECOND source, and what it can do to a patch is limited by what
# that patch sheds: fur beads it, a plate sheets it, bare dermis soaks.
s = sub1(s, "  let wetLevel = clamp(wet * (0.55 + 0.45 * pool), 0.0, 1.0);",
"""  let dryWet = wet * (0.55 + 0.45 * pool);
  // fogCol.w is the weather. A fur coat sheds most of it and a chitin plate
  // sheets it, so the covering's own wetness doubles as how much rain sticks.
  let shed = 0.30 + 0.70 * wet;
  let rainWet = g.fogCol.w * shed * (0.45 + 0.55 * pool);
  let wetLevel = clamp(max(dryWet, rainWet), 0.0, 1.0);""")
open(p, 'w', encoding='utf-8').write(s)
print('weather: the animals get wet ok')

s = open(p, encoding='utf-8').read()
# ---- TERRAIN. Rain darkens everything and collects where the ground is flat.
# A puddle is not a texture: it is a patch whose normal goes flat and whose
# specular goes up, which is the only thing that reads as standing water.
s = sub1(s, """  // sand darkens where waves wet it
  let sea = g.params.w;
  let wet = (1.0 - smoothstep(sea + 0.5, sea + 5.0, i.wpos.y)) * step(sea - 30.0, i.wpos.y);
  col *= 1.0 - 0.3 * wet;""",
"""  // sand darkens where waves wet it
  let sea = g.params.w;
  let shore = (1.0 - smoothstep(sea + 0.5, sea + 5.0, i.wpos.y)) * step(sea - 30.0, i.wpos.y);
  // rain wets the whole island, and water RUNS OFF: a slope stays darker than
  // it was but flat ground holds a film and the hollows hold standing water.
  let rainW = g.fogCol.w;
  let flat = smoothstep(0.16, 0.02, slope);
  let puddle = smoothstep(0.60, 0.82, fbm(xz * 0.022 + vec2<f32>(11.3, 4.1))) * flat * smoothstep(0.30, 0.80, rainW);
  let wet = clamp(max(shore, rainW * (0.30 + 0.70 * flat)), 0.0, 1.0);
  col *= 1.0 - 0.34 * wet - 0.22 * puddle;""")
s = sub1(s, """  N = normalize(N + vec3<f32>(h0 - hx, 0.0, h0 - hz) * 2.2 * det * (0.4 + 0.6 * rockK));
  var lit = shade(col, N, i.wpos);
  let V = normalize(g.camPos.xyz - i.wpos);
  lit += vec3<f32>(0.5) * pow(max(dot(reflect(-normalize(g.lightDir.xyz), N), V), 0.0), 40.0) * wet * 0.25 * g.params.z;
  return vec4<f32>(lit, 1.0);""",
"""  N = normalize(N + vec3<f32>(h0 - hx, 0.0, h0 - hz) * 2.2 * det * (0.4 + 0.6 * rockK));
  // standing water fills the relief in rather than covering it: the normal
  // goes back to flat inside a puddle, which is what makes it a mirror
  N = normalize(mix(N, normalize(i.nrm), puddle * 0.88));
  var lit = shade(col, N, i.wpos);
  let V = normalize(g.camPos.xyz - i.wpos);
  let R = reflect(-normalize(g.lightDir.xyz), N);
  // two lobes again: a broad wet sheen over the whole soaked surface and a
  // tight one for the puddles, plus the sky a puddle reflects at a glance
  lit += vec3<f32>(0.5) * pow(max(dot(R, V), 0.0), 40.0) * wet * 0.30 * g.params.z;
  lit += vec3<f32>(1.0, 0.99, 0.95) * pow(max(dot(R, V), 0.0), 320.0) * puddle * 1.5 * g.params.z;
  let fres = pow(1.0 - clamp(dot(N, V), 0.0, 1.0), 4.0);
  lit = mix(lit, mix(lit, g.fogCol.rgb * 1.15, clamp(fres, 0.0, 1.0)), puddle * 0.85);
  return vec4<f32>(lit, 1.0);""")
open(p, 'w', encoding='utf-8').write(s)
print('weather: the ground gets wet, and holds puddles ok')

s = open(p, encoding='utf-8').read()
# ---- FOLIAGE. A wet leaf is darker and it flashes; wet bark just goes dark.
s = sub1(s, """  var lit = shade(col, N, i.wpos);
  if (metalSpec > 0.0) { lit += vec3<f32>(0.78, 0.80, 0.84) * metalSpec * shadowAt(i.wpos, N); }""",
"""  // rain: bark soaks and goes dark, a leaf holds a bead and catches the sky.
  // A leaf is a waxy surface and a trunk is not, so the leaf keeps more of its
  // colour and gets the hard little highlight, and the bark just goes dark.
  let wetW = g.fogCol.w;
  let isLeaf = i.leaf > 0.5;
  col *= 1.0 - select(0.34, 0.20, isLeaf) * wetW;
  var lit = shade(col, N, i.wpos);
  if (wetW > 0.01) {
    let Lw = normalize(g.lightDir.xyz);
    let Vw = normalize(g.camPos.xyz - i.wpos);
    let Hw = normalize(Lw + Vw);
    let gl = pow(max(dot(N, Hw), 0.0), select(80.0, 240.0, isLeaf));
    lit += vec3<f32>(0.95, 1.0, 1.0) * gl * wetW * select(0.20, 0.60, isLeaf) * g.params.z;
  }
  if (metalSpec > 0.0) { lit += vec3<f32>(0.78, 0.80, 0.84) * metalSpec * shadowAt(i.wpos, N); }""")
open(p, 'w', encoding='utf-8').write(s)
print('weather: wet leaves and wet bark ok')

s = open(p, encoding='utf-8').read()
# ---- test/automation surface: the harness has to be able to stand in a
# storm without waiting for one.
s = sub1(s, "  rebuild: () => rebuildWorld(),",
"""  rebuild: () => rebuildWorld(),
  weather: {
    get state() { return { rain: WX.rain, storm: WX.storm, gust: WX.gust, flash: WX.flash,
                           wet: world ? (world.wet || 0) : 0, cell: WX.cell, drops: rainN,
                           zone: WX.zone || 0, pipe: !!rainPipe, budget: RAIN_BUDGET[GFX.name] || 0,
                           canopy: WX.canopy, builds: WX.builds, sawRain: WX.sawRain, frozen: WX.frozen }; },
    at: (bt) => wxAt(bt),
    // force the sky for a screenshot or an assertion. wet follows rain unless
    // it is given on its own.
    set(rain, storm, wet) {
      WX.rain = clamp(rain || 0, 0, 1); WX.storm = clamp(storm || 0, 0, 1);
      if (world) world.wet = clamp(wet != null ? wet : WX.rain, 0, 1);
      WX.frozen = true;
    },
    bolt() { WX.flash = 1.1; },
    release() { WX.frozen = false; },
  },""")
open(p, 'w', encoding='utf-8').write(s)
print('weather: harness hook ok')

s = open(p, encoding='utf-8').read()
# freezing has to actually hold, or a forced storm is gone on the next tick
s = sub1(s, """  const w = wxAt(world.bt || 0);
  WX.rain = w.rain; WX.storm = w.storm; WX.gust = w.gust; WX.cell = w.cell;""",
"""  const w = wxAt(world.bt || 0);
  if (!WX.frozen) { WX.rain = w.rain; WX.storm = w.storm; WX.gust = w.gust; }
  WX.cell = w.cell;""")
# and a frozen sky must not have its wetness dragged back down by the integral
s = sub1(s, """  const cur = world.wet || 0;
  if (target > cur) world.wet = cur + (target - cur) * (1 - Math.exp(-dt / 6.5));
  else world.wet = target + (cur - target) * Math.exp(-dt / 95);""",
"""  const cur = world.wet || 0;
  if (WX.frozen) { /* held by the harness */ }
  else if (target > cur) world.wet = cur + (target - cur) * (1 - Math.exp(-dt / 6.5));
  else world.wet = target + (cur - target) * Math.exp(-dt / 95);""")
open(p, 'w', encoding='utf-8').write(s)
print('weather: the sky can be held still ok')
