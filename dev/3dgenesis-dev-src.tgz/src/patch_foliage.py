def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
p='g3.html'; s=open(p,encoding='utf-8').read()
fol=open('src/foliage.js',encoding='utf-8').read(); wg=open('src/wgsl_foliage.js',encoding='utf-8').read()
s=sub1(s,"""// Unlit geometry with vertex colour (the editor's sky dome)""",wg+"\n"+fol+"""
// Unlit geometry with vertex colour (the editor's sky dome)""")
s=sub1(s,"let terrainPipe, instPipe, waterPipe, bodyPipe, unlitPipe, tubePipe, overPipe, skinPipe, skinBind, skinInstVB, bindG;",
         "let terrainPipe, instPipe, waterPipe, bodyPipe, unlitPipe, tubePipe, overPipe, skinPipe, skinBind, skinInstVB, folPipe, folBind, bindG;")
s=sub1(s,"""  const skm = dev.createShaderModule({ code: WGSL_SKIN });""","""  const flm = dev.createShaderModule({ code: WGSL_FOLIAGE });
  folPipe = dev.createRenderPipeline({
    layout: 'auto',
    vertex: { module: flm, entryPoint: 'vs', buffers: [
      { arrayStride: FOL_VF * 4, attributes: [
        { shaderLocation: 0, offset: 0,  format: 'float32x3' },
        { shaderLocation: 1, offset: 12, format: 'float32x3' },
        { shaderLocation: 2, offset: 24, format: 'float32x3' },
        { shaderLocation: 3, offset: 36, format: 'float32'   },
        { shaderLocation: 4, offset: 40, format: 'float32'   }] },
      { arrayStride: FOL_IF * 4, stepMode: 'instance', attributes: [
        { shaderLocation: 5, offset: 0,  format: 'float32x3' },
        { shaderLocation: 6, offset: 12, format: 'float32'   },
        { shaderLocation: 7, offset: 16, format: 'float32'   },
        { shaderLocation: 8, offset: 20, format: 'float32x3' }] } ] },
    fragment: { module: flm, entryPoint: 'fs', targets: [{ format: fmt }] },
    primitive: { topology: 'triangle-list', cullMode: 'none' },
    depthStencil: depthState, multisample: MS,
  });
  const skm = dev.createShaderModule({ code: WGSL_SKIN });""")
s=sub1(s,"""function makeBindGroups() {
  skinBind =""","""function makeBindGroups() {
  folBind = dev.createBindGroup({ layout: folPipe.getBindGroupLayout(0), entries: [{ binding: 0, resource: { buffer: gBuf } }] });
  skinBind =""")
# world (re)builds: canopy map before the terrain so the forest floor is shaded
s=sub1(s,"""  terrain = world.terrain;
  buildTerrain(); buildWater(); buildMinimap();""","""  terrain = world.terrain;
  buildCanopyMap(); FOL.key = '';
  buildTerrain(); buildWater(); buildMinimap();""")
s=sub1(s,"""  buildPipelines();
  makeBindGroups();
  const info = buildTerrain();""","""  buildPipelines();
  makeBindGroups();
  folInit(); buildCanopyMap(); FOL.key = '';
  const info = buildTerrain();""")
# forest floor shade
s=sub1(s,"""    verts[v++] = wx; verts[v++] = h * HEIGHT_SCALE; verts[v++] = wz;
    verts[v++] = gx / gl; verts[v++] = gy / gl; verts[v++] = gz / gl;
    verts[v++] = r * jit; verts[v++] = g2 * jit; verts[v++] = b * jit;""","""    const shd = 1 - 0.45 * forestCanopyAt(wx, wz);
    verts[v++] = wx; verts[v++] = h * HEIGHT_SCALE; verts[v++] = wz;
    verts[v++] = gx / gl; verts[v++] = gy / gl; verts[v++] = gz / gl;
    verts[v++] = r * jit * shd; verts[v++] = g2 * jit * shd; verts[v++] = b * jit * shd;""")
s=sub1(s,"""  const nPlant = buildPlantInstances(player.camX, player.camZ, t);
""","""  const nPlant = buildPlantInstances(player.camX, player.camZ, t);
  folUpdate(player.camX, player.camY, player.camZ, player.yaw);
""")
s=sub1(s,"""  pass.setVertexBuffer(0, terrVB); pass.setIndexBuffer(terrIB, 'uint32');
  pass.drawIndexed(terrCount);
""","""  pass.setVertexBuffer(0, terrVB); pass.setIndexBuffer(terrIB, 'uint32');
  pass.drawIndexed(terrCount);
  folDraw(pass);
""")
s=sub1(s,"  const P = 4000; // overhang","  const P = 16000; // overhang")
open(p,'w',encoding='utf-8').write(s)
print('foliage ok')
