// ---- editor UI ---------------------------------------------------------------------
const SWATCHES = [
  [0.95, 0.95, 0.92], [0.78, 0.76, 0.70], [0.45, 0.43, 0.40], [0.14, 0.13, 0.13], [0.62, 0.12, 0.10], [0.90, 0.30, 0.22],
  [0.98, 0.58, 0.20], [0.98, 0.84, 0.28], [0.72, 0.84, 0.30], [0.30, 0.66, 0.30], [0.16, 0.44, 0.30], [0.22, 0.70, 0.66],
  [0.36, 0.72, 0.95], [0.20, 0.40, 0.82], [0.40, 0.26, 0.72], [0.70, 0.36, 0.82], [0.95, 0.52, 0.70], [0.56, 0.36, 0.22],
];
const PATTERNS = ['plain', 'stripes', 'spots', 'patches', 'saddle', 'speckle'];
const hex = (c) => '#' + c.map(v => Math.round(clamp(v, 0, 1) * 255).toString(16).padStart(2, '0')).join('');
const unhex = (h) => { const m = /^#?([0-9a-f]{6})$/i.exec(h || ''); if (!m) return null; const n = parseInt(m[1], 16); return [(n >> 16 & 255) / 255, (n >> 8 & 255) / 255, (n & 255) / 255]; };
const TAB_ICONS = {
  body: '<path d="M6 15c0-5 4-8 9-8s9 3 9 8-4 6-9 6-9-1-9-6z"/><circle cx="21" cy="12" r="1.2" fill="currentColor"/><path d="M9 20l-1 4M13 21v4M18 21v4M22 20l1 4"/>',
  mouth: '<path d="M5 12c3-4 17-4 20 0-3 7-17 7-20 0z"/><path d="M8 12l2 3 2-3 2 3 2-3 2 3 2-3"/>',
  eyes: '<path d="M4 15c4-6 18-6 22 0-4 6-18 6-22 0z"/><circle cx="15" cy="15" r="4"/><circle cx="15" cy="15" r="1.6" fill="currentColor"/>',
  horns: '<path d="M8 24c2-6 1-12-3-17 6 3 9 9 8 17M22 24c-2-6-1-12 3-17-6 3-9 9-8 17"/>',
  armor: '<path d="M4 24h22M7 24l3-10 3 10M13 24l3-14 3 14M19 24l3-9 3 9"/>',
  limbs: '<path d="M10 4c2 6 0 9 5 13s2 7-1 9M14 26h6"/><circle cx="10" cy="5" r="2"/>',
  fins: '<path d="M4 22c6-2 10-10 12-17 2 8 6 13 10 17H4z"/><path d="M16 5l-3 17M16 5l2 17"/>',
  wings: '<path d="M15 16C11 9 6 7 3 8c2 3 2 8 5 10 2-2 4-2 7-2zM15 16c4-7 9-9 12-8-2 3-2 8-5 10-2-2-4-2-7-2z"/>',
  details: '<path d="M15 4l2.6 7.4H25l-6 4.6 2.3 7.4L15 19l-6.3 4.4L11 16 5 11.4h7.4z"/>',
  paint: '<path d="M15 4c4 6 7 9 7 13a7 7 0 01-14 0c0-4 3-7 7-13z"/>',
  shape: '<path d="M4 20h22M7 20V9M15 20V5M23 20v-7"/><circle cx="7" cy="9" r="2"/><circle cx="15" cy="5" r="2"/><circle cx="23" cy="13" r="2"/>',
};
const icon = (k) => '<svg viewBox="0 0 30 30" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' + (TAB_ICONS[k] || '') + '</svg>';
function effectText(id) {
  const s = C.ITEM_SIM[id]; if (!s) return '';
  const out = [];
  switch (s.t) {
    case 'MOUTH': out.push(s.mode === 'carn' ? 'eats meat, unlocks a bite' : s.mode === 'scav' ? 'eats carrion well' : 'eats plants'); break;
    case 'EYE': out.push('+ vision'); break;
    case 'HORN': out.push('+ attack, unlocks gore'); break;
    case 'SPIKE': out.push('+ defence, hurts attackers'); break;
    case 'FIN': out.push('+ swimming'); break;
    case 'WING': out.push('flight, once wing area beats body weight'); break;
    case 'GLAND': out.push('poisons whatever eats you'); break;
    case 'ORN': out.push('display'); break;
    case 'LIMB': out.push('a leg if it reaches the ground (speed), otherwise an arm'); break;
    case 'TIP': out.push('snaps onto the end of a limb'); break;
  }
  if (s.atk) out.push('+' + s.atk + ' attack');
  if (s.def) out.push('+' + s.def + ' defence');
  if (s.reach) out.push('+' + s.reach + ' reach');
  if (s.sense) out.push('+' + s.sense + ' vision');
  if (s.spd) out.push((s.spd > 0 ? '+' : '') + Math.round(s.spd * 100) + '% land speed');
  if (s.fin) out.push('+ swimming');
  if (s.grab) out.push('grabs food from high up');
  if (s.sweep) out.push('unlocks tail sweep');
  return out.join(' / ');
}
function edBuildUI() {
  const root = document.createElement('div');
  root.id = 'edRoot';
  root.innerHTML = `
  <div id="edTop" class="edp">
    <button id="edUndo" title="undo (ctrl+z)">undo</button><button id="edRedo" title="redo (ctrl+y)">redo</button>
    <button id="edMirror" title="mirror parts left and right (M)">mirror: on</button>
    <button id="edRandom" title="roll a random creature from the parts you have unlocked">random</button>
    <button id="edView" title="reset the view (double-click the scene)">reset view</button>
    <button id="edSaved">my creatures</button>
    <span class="edname"><input id="edName" maxlength="22" spellcheck="false" placeholder="name your species" title="what your species is called"><button id="edRollName" title="roll a name">roll</button></span>
    <span class="edsp"></span>
    <button id="edCancel">cancel</button><button id="edDone" class="go">done</button>
  </div>
  <div id="edPal" class="edp">
    <div id="edTabBar"><button id="edPrev" title="previous (Q)">&#8249;</button><div id="edTabTitle"></div><button id="edNext" title="next (E)">&#8250;</button></div>
    <div id="edTabHint"></div>
    <div id="edGrid"></div>
  </div>
  <div id="edStats" class="edp"></div>
  <div id="edInsp" class="edp"></div>
  <div id="edSavedBox" class="edp"></div>
  <div id="edHelp" class="edp">drag parts from the right onto the body &middot; drag the scene to turn it &middot; scroll to zoom &middot; click a part to edit it &middot; drag a part off the body to remove it</div>
  <div id="edFlash" class="edp"></div>
  <div id="edTip" class="edp"></div>`;
  document.body.appendChild(root);
  const dragImg = document.createElement('img');
  dragImg.id = 'edDragImg'; dragImg.alt = '';
  document.body.appendChild(dragImg);
  ED.ui = { root, pal: $('edPal'), grid: $('edGrid'), stats: $('edStats'), insp: $('edInsp'),
            flash: $('edFlash'), tip: $('edTip'), dragImg, saved: $('edSavedBox'), title: $('edTabTitle') };
  $('edUndo').onclick = edUndo; $('edRedo').onclick = edRedo;
  $('edMirror').onclick = () => { ED.mirror = !ED.mirror; edRefreshUI(); };
  $('edView').onclick = () => { ED.cam.yaw = 0.95; ED.cam.pitch = 0.2; ED.cam.zoom = 1; };
  $('edRandom').onclick = () => edRandomize();
  $('edName').addEventListener('input', () => { ED.des.stem = edCleanStem($('edName').value); ED.des.name = speciesName(ED.des); edTouch(); });
  $('edRollName').onclick = () => { ED.des.stem = rollStem(); $('edName').value = ED.des.stem; ED.des.name = speciesName(ED.des); edTouch(); };
  $('edCancel').onclick = () => closeEditor(false);
  $('edDone').onclick = () => closeEditor(true);
  $('edSaved').onclick = () => { ED.savedOpen = !ED.savedOpen; edRenderSaved(); };
  const step = (d) => { const i = VIS_CATS.findIndex(c => c.id === ED.tab); ED.tab = VIS_CATS[(i + d + VIS_CATS.length) % VIS_CATS.length].id; edRefreshUI(); };
  $('edPrev').onclick = () => step(-1);
  $('edNext').onclick = () => step(1);
  edBindCanvas();
}
function edFlash(msg) {
  const el = ED.ui && ED.ui.flash; if (!el) return;
  el.textContent = msg; el.classList.add('show');
  clearTimeout(edFlash._t); edFlash._t = setTimeout(() => el.classList.remove('show'), 2600);
}
function tileHTML(key, avail, extra) {
  const src = ED.thumbs[key];
  const img = src ? `<img src="${src}" alt="" draggable="false">` : `<span class="edph">${(VIS[key] && VIS[key].name) || ''}</span>`;
  return img + (avail ? '' : '<span class="edlock"><svg viewBox="0 0 20 20"><rect x="4" y="9" width="12" height="9" rx="2" fill="currentColor"/><path d="M7 9V6a3 3 0 016 0v3" fill="none" stroke="currentColor" stroke-width="2"/></svg></span>') + (extra || '');
}
function edRefreshUI() {
  if (!ED.ui) return;
  const U = ED.ui;
  $('edMirror').textContent = 'mirror: ' + (ED.mirror ? 'on' : 'off');
  $('edMirror').classList.toggle('on', ED.mirror);
  $('edDone').textContent = ED.mode === 'start' ? 'play' : 'done';
  { const ne = $('edName'); if (ne && document.activeElement !== ne) ne.value = ED.des.stem || ''; }
  $('edUndo').disabled = !ED.undo.length; $('edRedo').disabled = !ED.redo.length;
  const cat = VIS_CATS.find(c => c.id === ED.tab) || VIS_CATS[0];
  U.title.textContent = cat.label;
  { const hint = $('edTabHint'); if (hint) hint.textContent = cat.hint || ''; }
  let html = '';
  if (ED.tab === 'body') {
    // the body plan is chosen once per world; only a reset lets you pick another
    const planLocked = ED.mode === 'game';
    html += '<div class="edgrid">';
    for (let p = 0; p < C.PLANS.length; p++) html += `<div class="edtile plan${ED.des.plan === p ? ' cur' : ''}${planLocked && ED.des.plan !== p ? ' locked' : ''}" data-plan="${p}">${tileHTML('plan' + p, !planLocked || ED.des.plan === p)}</div>`;
    html += '</div>';
    if (planLocked) html += '<div class="edhint">your body shape is fixed for this world. reset the world to start as a different shape</div>';
    else html += '<div class="edhint">pick the skeleton: it sets your size, stance, neck and tail, and where parts can go</div>';
  } else if (ED.tab === 'shape') {
    const bd = ED.des.body;
    const sl = (k, label) => `<label class="edsl"><span>${label}</span><input type="range" data-body="${k}" min="${C.BODY_RANGE[k][0]}" max="${C.BODY_RANGE[k][1]}" step="0.01" value="${bd[k]}"></label>`;
    html += '<div class="edsec">' + sl('len', 'body length') + sl('girth', 'body thickness') + sl('neck', 'neck length') + sl('tail', 'tail length') + '</div>';
    html += '<div class="edsec"><label class="edchk"><input type="checkbox" id="edKeepPaint"' + (ED.keepPaint ? ' checked' : '') + '> keep my colours when changing body</label></div>';
  } else if (ED.tab === 'paint') {
    const c = ED.des.col;
    const row = (k, label) => `<div class="edpaint"><div class="edpl">${label}</div><div class="edsw">` +
      SWATCHES.map(s => `<button class="sw" data-paint="${k}" data-c="${hex(s)}" style="background:${hex(s)}"></button>`).join('') +
      `<input type="color" data-paintc="${k}" value="${hex(c[k])}"></div></div>`;
    html += row('base', 'body colour') + row('coat', 'underside colour') + row('detail', 'pattern colour');
    html += '<div class="edpl">pattern</div><div class="edgrid pats">' + PATTERNS.map((n, i) => `<div class="edtile pat${(c.pat | 0) === i ? ' cur' : ''}" data-pat="${i}"><canvas width="96" height="96" data-patc="${i}"></canvas></div>`).join('') + '</div>';
    html += '<div class="edpl">skin</div><div class="edgrid skins">' + SKIN_ITEMS.map((id, i) => {
      const av = edSkinAllowed(i);
      return `<div class="edtile item${skinOf(ED.des) === i ? ' cur' : ''}${av ? '' : ' locked'}" data-skin="${i}" title="${SKIN_NAMES[i]}">${tileHTML(id, av)}</div>`;
    }).join('') + '</div>';
    html += '<div class="edhint">to colour a single part, click it on the creature. new skins are earned by killing animals that wear them</div>';
  } else {
    const ids = Object.keys(VIS).filter(id => VIS[id].cat === ED.tab);
    html += '<div class="edgrid cards">';
    for (const id of ids) {
      const av = itemAvailable(id);
      const v = VIS[id];
      html += `<div class="edcard${av ? '' : ' locked'}" data-item="${id}">` +
        `<div class="edtile item${av ? '' : ' locked'}" data-item="${id}">${tileHTML(id, av, `<span class="edcost">${itemCost(id)}</span>`)}</div>` +
        `<div class="edcname">${v.name}</div><div class="edcuse">${v.use || effectText(id) || ''}</div>` +
        `<div class="edccost">${itemCost(id)} genome space${av ? '' : ' · locked'}</div></div>`;
    }
    html += '</div>';
    if (ED.tab === 'limbs') html += '<div class="edhint">drag a limb onto the body, then drag its joints to shape it. drop feet, hands and claws onto the end of a limb</div>';
  }
  U.grid.innerHTML = html;
  if (ED.tab === 'paint') edDrawPatternIcons();
  edBindGrid();
  edRenderInspector();
  edUpdateStats();
  edRenderSaved();
}
function edSkinAllowed(i) {
  const id = SKIN_ITEMS[i];
  return i === 0 || isUnlocked(id) || !!(ED.grantCount && ED.grantCount[id]) || (C.PLAN_SKIN && C.PLAN_SKIN[ED.des.plan | 0] === i);
}
function edDrawPatternIcons() {
  const c = ED.des.col;
  for (const cv of ED.ui.grid.querySelectorAll('canvas[data-patc]')) {
    const i = +cv.getAttribute('data-patc');
    const g = cv.getContext('2d');
    const W = cv.width;
    const img = g.createImageData(W, W);
    for (let y = 0; y < W; y++) for (let x = 0; x < W; x++) {
      const px = (x / W - 0.5) * 3, py = (0.5 - y / W) * 3, pz = 0.4;
      const ny = 0.55 - y / W;
      let m = 0;
      if (i === 1) m = Math.sin(px * 7 + Math.sin(py * 2.6) * 0.9 + pz * 0.4) > 0.63 ? 1 : 0;
      else if (i === 2) m = Math.sin(px * 8.3 + 0.7) * Math.sin(py * 7.9 + 1.3) * Math.sin(pz * 8.7 + 2.1) > 0.12 ? 1 : 0;
      else if (i === 3) m = (Math.sin(px * 3.9 + Math.sin(pz * 3.1) * 1.7) * Math.sin(py * 3.6 + Math.sin(px * 2.7) * 1.4) + 0.35 * Math.sin(pz * 5.1 + px * 2)) > 0.24 ? 1 : 0;
      else if (i === 4) m = ny > 0.2 ? 1 : 0;
      else if (i === 5) m = Math.sin(px * 23) * Math.sin(py * 21 + 1) * Math.sin(pz * 25 + 2) > 0.1 ? 1 : 0;
      const coatW = y > W * 0.78 ? 1 : 0;
      const col = coatW ? c.coat : (m ? c.detail : c.base);
      const o = (y * W + x) * 4;
      img.data[o] = col[0] * 255; img.data[o + 1] = col[1] * 255; img.data[o + 2] = col[2] * 255; img.data[o + 3] = 255;
    }
    g.putImageData(img, 0, 0);
  }
}
function edBindGrid() {
  const U = ED.ui;
  for (const t of U.grid.querySelectorAll('[data-plan]')) {
    t.onclick = () => {
      const p = +t.getAttribute('data-plan');
      if (p === ED.des.plan) return;
      if (ED.mode === 'game') { edFlash('Your body shape is fixed for this world. Reset the world to choose another.'); return; }
      edSetPlan(p);
    };
  }
  for (const s of U.grid.querySelectorAll('input[data-body]')) {
    s.addEventListener('pointerdown', () => edPushUndo());
    s.addEventListener('input', () => {
      const k = s.getAttribute('data-body');
      ED.des.body[k] = clamp(parseFloat(s.value), C.BODY_RANGE[k][0], C.BODY_RANGE[k][1]);
      C.reseatDesign(ED.des);
      edTouch();
    });
  }
  const kp = $('edKeepPaint'); if (kp) kp.onchange = () => { ED.keepPaint = kp.checked; };
  for (const b of U.grid.querySelectorAll('[data-paint]')) {
    b.onclick = () => { edPushUndo(); ED.des.col[b.getAttribute('data-paint')] = unhex(b.getAttribute('data-c')); edTouch(); edRefreshUI(); };
  }
  for (const inp of U.grid.querySelectorAll('input[data-paintc]')) {
    inp.addEventListener('focus', () => edPushUndo());
    inp.addEventListener('input', () => { const c = unhex(inp.value); if (c) { ED.des.col[inp.getAttribute('data-paintc')] = c; edTouch(); } });
    inp.addEventListener('change', () => edRefreshUI());
  }
  for (const t of U.grid.querySelectorAll('[data-skin]')) {
    t.onclick = () => {
      const i = +t.getAttribute('data-skin');
      if (!edSkinAllowed(i)) { edFlash('Locked. Kill an animal with ' + SKIN_NAMES[i] + ' and choose it to unlock it.'); return; }
      edPushUndo(); ED.des.col.skin = i; edTouch(); edRefreshUI();
    };
  }
  for (const t of U.grid.querySelectorAll('[data-pat]')) {
    t.onclick = () => { edPushUndo(); ED.des.col.pat = +t.getAttribute('data-pat'); edTouch(); edRefreshUI(); };
  }
  for (const t of U.grid.querySelectorAll('[data-item]')) {
    const id = t.getAttribute('data-item');
    t.addEventListener('pointerenter', (e) => edShowTip(id, t));
    t.addEventListener('pointerleave', () => edHideTip());
    t.addEventListener('pointerdown', (e) => {
      e.preventDefault();
      if (!itemAvailable(id)) { edCanUse(id, 1); return; }
      edStartPaletteDrag(id, e);
    });
  }
}
function edShowTip(id, el) {
  const v = VIS[id]; if (!v) return;
  const av = itemAvailable(id);
  const tip = ED.ui.tip;
  const sp = spareOf(id), own = (ED.grantCount && ED.grantCount[id]) || 0;
  tip.innerHTML = `<b>${v.name}</b><span class="c">genome space ${itemCost(id)}</span><div>${effectText(id)}</div>` +
    (sp === Infinity ? '' : own ? `<div class="lk">not unlocked: your body has ${own}, ${sp} left to place. kill an animal that has one to unlock it</div>`
                                : '<div class="lk">locked: kill an animal that has one, then pick it</div>');
  const r = el.getBoundingClientRect(), pr = ED.ui.pal.getBoundingClientRect();
  tip.style.display = 'block';
  const z = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--ui')) || 1;
  tip.style.left = ((pr.left - 8) / z - tip.offsetWidth) + 'px';
  tip.style.top = (Math.max(8, r.top) / z) + 'px';
}
function edHideTip() { if (ED.ui) ED.ui.tip.style.display = 'none'; }
function edRenderInspector() {
  const el = ED.ui.insp, s = ED.sel;
  if (!s || !(s.kind === 'part' ? ED.des.parts.includes(s.ref) : ED.des.limbs.includes(s.ref))) { el.style.display = 'none'; ED.sel = null; return; }
  const sw = (attr) => '<div class="edsw sm">' + SWATCHES.map(c => `<button class="sw" ${attr}="${hex(c)}" style="background:${hex(c)}"></button>`).join('') + '</div>';
  let h = '';
  if (s.kind === 'part') {
    const pt = s.ref, v = VIS[pt.id];
    const cur = itemColor(pt.id, pt.c, ED.des.col);
    h += `<div class="edih"><b>${v ? v.name : pt.id}</b><span>${effectText(pt.id)}</span></div>`;
    h += '<div class="edpl">colour</div>' + sw('data-pc') + `<div class="edrow"><input type="color" id="edPC" value="${hex(cur)}"><button id="edPCreset">default colour</button></div>`;
    h += `<label class="edsl"><span>size</span><input type="range" id="edPS" min="0.4" max="2.6" step="0.01" value="${pt.s || 1}"></label>`;
    h += `<label class="edsl"><span>rotate</span><input type="range" id="edPR" min="-3.14" max="3.14" step="0.01" value="${pt.spin || 0}"></label>`;
  } else {
    const lb = s.ref, v = VIS[lb.id];
    const cur = itemColor(lb.id, lb.c, ED.des.col);
    const G = designGeo(ED.des);
    const o = G.cls.limbs.find(q => q.lb === lb);
    h += `<div class="edih"><b>${v ? v.name : 'limb'}</b><span>${o && o.leg ? 'walking leg' : 'arm (does not reach the ground)'}</span></div>`;
    h += '<div class="edpl">colour</div>' + sw('data-pc') + `<div class="edrow"><input type="color" id="edPC" value="${hex(cur)}"><button id="edPCreset">body colour</button></div>`;
    h += `<label class="edsl"><span>thickness</span><input type="range" id="edLT" min="0.5" max="2" step="0.01" value="${lb.th || 1}"></label>`;
    if (lb.tip && VIS[lb.tip.id]) {
      h += `<div class="edpl">${VIS[lb.tip.id].name}</div>`;
      h += `<label class="edsl"><span>size</span><input type="range" id="edTS" min="0.4" max="2.5" step="0.01" value="${lb.tip.s || 1}"></label>`;
      h += `<label class="edsl"><span>rotate</span><input type="range" id="edTR" min="-3.14" max="3.14" step="0.01" value="${lb.tip.spin || 0}"></label>`;
      h += `<label class="edsl"><span>tilt</span><input type="range" id="edTT" min="-1.3" max="1.3" step="0.01" value="${lb.tip.tilt || 0}"></label>`;
      h += '<div class="edrow">' + `<input type="color" id="edTC" value="${hex(itemColor(lb.tip.id, lb.tip.c, ED.des.col))}"><button id="edTipX">remove ${VIS[lb.tip.id].name}</button></div>`;
    } else h += '<div class="edhint">drag a foot, hand or claw onto the end of this limb. drag the glowing joints to bend and stretch it</div>';
  }
  h += '<div class="edrow"><button id="edDel" class="warn">remove</button><button id="edDesel">done editing</button></div>';
  el.innerHTML = h;
  el.style.display = 'block';
  const setCol = (c) => edSelProp((o) => { o.c = c ? c.slice() : null; });
  for (const b of el.querySelectorAll('[data-pc]')) b.onclick = () => { edPushUndo(); setCol(unhex(b.getAttribute('data-pc'))); edRenderInspector(); };
  const pc = $('edPC');
  if (pc) { pc.addEventListener('focus', () => edPushUndo()); pc.addEventListener('input', () => setCol(unhex(pc.value))); }
  const pr = $('edPCreset'); if (pr) pr.onclick = () => { edPushUndo(); setCol(null); edRenderInspector(); };
  const slider = (id, fn) => { const e = $(id); if (!e) return; e.addEventListener('pointerdown', () => edPushUndo()); e.addEventListener('input', () => fn(parseFloat(e.value))); };
  slider('edPS', (v) => edSelProp((o) => { o.s = v; }));
  slider('edPR', (v) => edSelProp((o) => { o.spin = v; }));
  slider('edLT', (v) => edSelProp((o) => { o.th = v; }));
  slider('edTS', (v) => edSelProp((o) => { if (o.tip) o.tip.s = v; }));
  slider('edTR', (v) => edSelProp((o) => { if (o.tip) o.tip.spin = v; }));
  slider('edTT', (v) => edSelProp((o) => { if (o.tip) o.tip.tilt = v; }));
  const tc = $('edTC');
  if (tc) { tc.addEventListener('focus', () => edPushUndo()); tc.addEventListener('input', () => edSelProp((o) => { if (o.tip) o.tip.c = unhex(tc.value); })); }
  const tx = $('edTipX'); if (tx) tx.onclick = () => { edPushUndo(); edSelProp((o) => { o.tip = null; }); edRenderInspector(); };
  $('edDel').onclick = () => edDeleteSel();
  $('edDesel').onclick = () => { ED.sel = null; edRenderInspector(); };
}
function fmtDelta(v, o, dec, invert) {
  if (o == null || !isFinite(o)) return '';
  const d = v - o;
  if (Math.abs(d) < Math.pow(10, -dec) * 0.5) return '';
  const good = invert ? d < 0 : d > 0;
  return `<i class="${good ? 'up' : 'dn'}">${d > 0 ? '+' : ''}${d.toFixed(dec)}</i>`;
}
function edDesignPh(des) {
  const g = { body: null, brain: ED.statBrain, hue: 0.3, scale: ED.statScale || 1, life: 1, design: C.cloneDesign(des) };
  C.compileDesign(g);
  return C.develop(g);
}
function edUpdateStats() {
  if (!ED.ui || !ED.des) return;
  let ph;
  try { ph = edDesignPh(ED.des); } catch (e) { return; }
  ED.curPh = ph;
  const o = ED.origPh;
  const used = C.designCost(ED.des), cap = edCapacity(ED.des);
  const frac = clamp(used / Math.max(1, cap), 0, 1);
  const hasMouth = ED.des.parts.some(p => C.ITEM_SIM[p.id] && C.ITEM_SIM[p.id].t === 'MOUTH');
  const aqua = ph.aquaticForm;
  const warn = [];
  if (!hasMouth) warn.push('no mouth: it could never eat. add one from the mouths tab');
  if (used > cap) warn.push('over genome space by ' + (used - cap) + '. remove something');
  const flyNeed = 0.32 * ph.mass;
  if ((ph.sWings || 0) > 0 && !ph.canFly) warn.push('wings carry ' + Math.round(((ph.wingEff || 0) / Math.max(0.01, flyNeed)) * 100) + '% of what flight needs' + (aqua ? ' (fins outweigh wings, so they act as fins)' : ''));
  if ((ph.sFins || 0) > 0 && !ph.canSwim) warn.push('fins are ' + Math.round(((ph.finEff || 0) / 0.8) * 100) + '% of what deep water needs');
  const diet = ph.carnivory > 0.5 ? 'meat eater' : ph.scavenger > 0.5 ? 'carrion eater' : 'plant eater';
  const legs = ph.dLegs || 0, arms = ph.dArms || 0;
  const row = (label, v, ov, dec, inv) => `<div class="edst"><span>${label}</span><b>${v.toFixed(dec)}${fmtDelta(v, ov, dec, inv)}</b></div>`;
  let h = `<div class="edcap"><div class="edcapl"><span>genome space</span><b class="${used > cap ? 'over' : ''}">${used} / ${cap}</b></div>` +
    `<div class="edbar"><i style="width:${(frac * 100).toFixed(1)}%" class="${used > cap ? 'over' : ''}"></i></div>` +
    `<div class="edkills">${PROG.kills} kill${PROG.kills === 1 ? '' : 's'} &middot; every kill adds ${KILL_SPACE} space and one new part</div></div>`;
  h += `<div class="edst big"><span>${diet}</span><b>${legs} leg${legs === 1 ? '' : 's'}${arms ? ', ' + arms + ' arm' + (arms === 1 ? '' : 's') : ''}</b></div>`;
  h += row('land speed', ph.speedLand, o && o.speedLand, 0);
  h += row('swim speed', ph.speedWater, o && o.speedWater, 0);
  h += `<div class="edst"><span>flight</span><b>${ph.canFly ? ph.speedAir.toFixed(0) : 'no'}${fmtDelta(ph.speedAir, o && o.speedAir, 0)}</b></div>`;
  h += row('attack', ph.attack, o && o.attack, 1);
  h += row('defence', ph.defense, o && o.defense, 1);
  h += row('vision', ph.sense, o && o.sense, 0);
  h += row('reach', ph.reach, o && o.reach, 0);
  h += row('energy use', ph.upkeep, o && o.upkeep, 2, true);
  h += row('adult size', ph.mass, o && o.mass, 1);
  // attacks this body can make, each playable on the podium
  try {
    const mv = movesFor(ph, tallyParts(ph));
    h += '<div class="edmoves"><span>attacks</span>' + mv.map(m => `<button data-try="${m}">${MOVE_DEF[m].label}</button>`).join('') + '</div>';
  } catch (e) { /* stats still render */ }
  if (warn.length) h += '<div class="edwarn">' + warn.map(w => '<div>' + w + '</div>').join('') + '</div>';
  ED.ui.stats.innerHTML = h;
  for (const b of ED.ui.stats.querySelectorAll('[data-try]')) {
    b.onclick = () => { const k = b.getAttribute('data-try'); ED.anim = { kind: k, t0: performance.now(), dur: MOVE_DEF[k].dur * 2.2, seq: ((ED.anim && ED.anim.seq) || 0) + 1 }; };
  }
  const done = $('edDone');
  if (done) done.classList.toggle('blocked', !hasMouth || used > cap);
}
function edRenderSaved() {
  const el = ED.ui.saved;
  if (!ED.savedOpen) { el.style.display = 'none'; return; }
  let h = '<div class="edih"><b>my creatures</b><button id="edSaveNow">save this one</button></div>';
  if (!PROG.saved.length) h += '<div class="edhint">nothing saved yet</div>';
  PROG.saved.forEach((s, i) => {
    const th = ED.thumbs['plan' + (s.design.plan | 0)];
    h += `<div class="edsv"><span class="edsvi">${th ? `<img src="${th}" alt="">` : ''}</span><span class="edsvn">${s.name}</span>` +
         `<button data-load="${i}">load</button><button data-del="${i}" class="warn">x</button></div>`;
  });
  el.innerHTML = h; el.style.display = 'block';
  $('edSaveNow').onclick = () => {
    PROG.saved.unshift({ name: speciesName(ED.des), design: stripDesign(ED.des) });
    PROG.saved = PROG.saved.slice(0, 24); saveProgress(); edRenderSaved(); edFlash('Saved.');
  };
  for (const b of el.querySelectorAll('[data-load]')) b.onclick = () => {
    const s = PROG.saved[+b.getAttribute('data-load')]; if (!s) return;
    if (ED.mode === 'game' && (s.design.plan | 0) !== (ED.des.plan | 0)) { edFlash('That creature has a different body shape. Reset the world to play it.'); return; }
    edPushUndo(); ED.des = C.cloneDesign(s.design); ED.sel = null;
    { const g = grantCountOf(ED.des); for (const k in g) ED.grantCount[k] = Math.max(ED.grantCount[k] || 0, g[k]); }
    edTouch(); ED.savedOpen = false; edRefreshUI();
  };
  for (const b of el.querySelectorAll('[data-del]')) b.onclick = () => { PROG.saved.splice(+b.getAttribute('data-del'), 1); saveProgress(); edRenderSaved(); };
}

// ---- palette drag and drop ---------------------------------------------------------
function edStartPaletteDrag(id, e) {
  const v = VIS[id];
  const kind = v.kind || 'surface';
  ED.drag = { type: 'new', id, kind };
  const img = ED.ui.dragImg;
  img.src = ED.thumbs[id] || '';
  img.style.display = ED.thumbs[id] ? 'block' : 'none';
  const move = (ev) => {
    img.style.left = ev.clientX + 'px'; img.style.top = ev.clientY + 'px';
    const over = document.elementFromPoint(ev.clientX, ev.clientY) === canvas;
    ED.ghost = null;
    if (over) {
      if (kind === 'tip') {
        const lb = edNearestLimbEnd(ev.clientX, ev.clientY);
        if (lb) ED.ghost = { kind: 'tip', id, limb: lb };
      } else {
        const hit = edBodyHit(ev.clientX, ev.clientY);
        if (hit) {
          if (kind === 'limb') {
            const G = designGeo(ED.des);
            const pose = defaultLimbPose(G.sk, G.cls.stand, hit);
            const lb = { id, b: hit.b, o: [0, 0, 0], n: hit.n, k: pose.k, f: pose.f, th: 1, c: null, tip: null, m: 0 };
            C.setAnchor(G.sk, lb, hit.p, hit.n, hit.b);
            const limbs = [lb];
            if (ED.mirror && Math.abs(hit.p[2]) > 0.08) {
              const tw = JSON.parse(JSON.stringify(lb)); const mp = mirrorPoint(hit.p);
              C.setAnchor(G.sk, tw, mp, mirrorPoint(hit.n), mirrorBall(G.sk, hit.b, mp)); tw.k = mirrorPoint(lb.k); tw.f = mirrorPoint(lb.f);
              limbs.push(tw);
            }
            ED.ghost = { kind: 'limb', id, hit, limbs };
          } else {
            const sk = designGeo(ED.des).sk;
            const pt = { id, b: 0, o: [0, 0, 0], n: [0, 1, 0], spin: 0, s: 1, c: null, m: 0 };
            C.setAnchor(sk, pt, hit.p, hit.n, hit.b);
            const parts = [pt];
            const single = C.ITEM_SIM[id] && C.ITEM_SIM[id].t === 'MOUTH';
            if (ED.mirror && !single && Math.abs(hit.p[2]) > 0.08) {
              const tw = JSON.parse(JSON.stringify(pt)); const mp = mirrorPoint(hit.p);
              C.setAnchor(sk, tw, mp, mirrorPoint(hit.n), mirrorBall(sk, hit.b, mp)); parts.push(tw);
            }
            ED.ghost = { kind: 'surface', id, hit, parts };
          }
        }
      }
    }
    img.style.opacity = ED.ghost ? '0' : '0.9';
  };
  const up = (ev) => {
    document.removeEventListener('pointermove', move);
    document.removeEventListener('pointerup', up);
    document.removeEventListener('pointercancel', up);
    img.style.display = 'none';
    const gh = ED.ghost;
    ED.ghost = null; ED.drag = null;
    if (!gh) return;
    if (gh.kind === 'surface') edAddPart(gh.id, gh.hit);
    else if (gh.kind === 'limb') edAddLimb(gh.id, gh.hit);
    else if (gh.kind === 'tip') edSetTip(gh.limb, gh.id);
  };
  document.addEventListener('pointermove', move);
  document.addEventListener('pointerup', up);
  document.addEventListener('pointercancel', up);
  move(e);
}

// ---- canvas interaction -----------------------------------------------------------------
function edBindCanvas() {
  canvas.addEventListener('pointerdown', (e) => {
    if (!ED.open) return;
    e.preventDefault();
    edHideTip();
    const pk = edPick(e.clientX, e.clientY);
    ED.drag = { type: 'press', x0: e.clientX, y0: e.clientY, x: e.clientX, y: e.clientY, pk, moved: 0, button: e.button };
    try { canvas.setPointerCapture(e.pointerId); } catch (_) {}
  });
  canvas.addEventListener('pointermove', (e) => {
    if (!ED.open) return;
    const d = ED.drag;
    if (!d || (d.type !== 'press' && d.type !== 'orbit' && d.type !== 'move' && d.type !== 'joint' && d.type !== 'root')) {
      ED.hover = edPick(e.clientX, e.clientY);
      canvas.style.cursor = ED.hover && (ED.hover.kind === 'part' || ED.hover.kind === 'limb' || ED.hover.kind === 'handle') ? 'pointer' : 'grab';
      return;
    }
    const dx = e.clientX - d.x, dy = e.clientY - d.y;
    d.moved += Math.abs(dx) + Math.abs(dy);
    d.x = e.clientX; d.y = e.clientY;
    if (d.type === 'press' && d.moved > 4) {
      const pk = d.pk;
      if (pk && pk.kind === 'handle') { edPushUndo(); d.type = pk.which === 'r' ? 'root' : 'joint'; d.which = pk.which; d.ref = pk.ref; }
      else if (pk && pk.kind === 'part' && d.button === 0) { edPushUndo(); ED.sel = { kind: 'part', ref: pk.ref }; d.type = 'move'; d.ref = pk.ref; edRenderInspector(); }
      else d.type = 'orbit';
    }
    if (d.type === 'orbit') {
      ED.cam.yaw += dx * 0.008;
      ED.cam.pitch = clamp(ED.cam.pitch + dy * 0.006, -0.12, 1.25);
    } else if (d.type === 'move') {
      const hit = edBodyHit(e.clientX, e.clientY);
      if (hit) { d.off = false; edMovePart(d.ref, hit); }
      else d.off = true;
      canvas.style.cursor = d.off ? 'no-drop' : 'grabbing';
    } else if (d.type === 'root') {
      const hit = edBodyHit(e.clientX, e.clientY);
      if (hit) edMoveLimbRoot(d.ref, hit);
    } else if (d.type === 'joint') {
      const ray = edRay(e.clientX, e.clientY);
      const lw = limbWorld(d.ref);
      const P = d.which === 'k' ? lw.knee : lw.foot;
      const n = v3.norm(v3.sub(ED.lastCam.target, ED.lastCam.eye));
      const den = v3.dot(ray.d, n);
      if (Math.abs(den) > 1e-4) {
        const tt = v3.dot(v3.sub(P, ray.o), n) / den;
        if (tt > 0) {
          const w = v3.add(ray.o, v3.mul(ray.d, tt));
          const pl = edPlacement(ED.des, ED.lastT);
          edSetJoint(d.ref, d.which, [w[0], w[1] - pl.cy, w[2]]);
        }
      }
    }
  });
  const end = (e) => {
    if (!ED.open) return;
    const d = ED.drag;
    ED.drag = null;
    if (!d) return;
    if (d.type === 'press') {
      // a click: select what was clicked, or clear the selection
      const pk = d.pk;
      if (pk && (pk.kind === 'part' || pk.kind === 'limb')) ED.sel = { kind: pk.kind, ref: pk.ref };
      else if (pk && pk.kind === 'handle') { /* keep selection */ }
      else ED.sel = null;
      edRenderInspector();
    } else if (d.type === 'move' && d.off) {
      ED.sel = { kind: 'part', ref: d.ref };
      const keep = ED.undo.pop();          // the move and the delete are one undo step
      edDeleteSel();
      if (keep) { ED.undo.pop(); ED.undo.push(keep); }
    } else if (d.type === 'joint' || d.type === 'root' || d.type === 'move') {
      edRenderInspector();
    }
    canvas.style.cursor = 'grab';
    ED.statsDirty = true;
  };
  canvas.addEventListener('pointerup', end);
  canvas.addEventListener('pointercancel', end);
  canvas.addEventListener('dblclick', (e) => { if (!ED.open) return; ED.cam.yaw = 0.95; ED.cam.pitch = 0.2; ED.cam.zoom = 1; });
  canvas.addEventListener('wheel', (e) => {
    if (!ED.open) return;
    e.preventDefault();
    const h = edPick(e.clientX, e.clientY);
    if (ED.sel && ED.sel.kind === 'part' && h && h.kind === 'part' && h.ref === ED.sel.ref) {
      if (!ED.wheelUndo || performance.now() - ED.wheelUndo > 600) edPushUndo();
      ED.wheelUndo = performance.now();
      const k = Math.exp(-e.deltaY * 0.0015);
      edSelProp((o) => { o.s = clamp((o.s || 1) * k, 0.4, 2.6); });
      edRenderInspector();
      return;
    }
    ED.cam.zoom = clamp(ED.cam.zoom * Math.exp(e.deltaY * 0.0012), 0.35, 2.6);
  }, { passive: false });
  canvas.addEventListener('contextmenu', (e) => { if (ED.open) e.preventDefault(); });
  addEventListener('keydown', (e) => {
    if (!ED.open) return;
    const tag = (e.target && e.target.tagName) || '';
    if (tag === 'INPUT' && e.target.type !== 'range' && e.target.type !== 'checkbox') return;
    const k = e.key.toLowerCase();
    if ((e.ctrlKey || e.metaKey) && k === 'z') { e.preventDefault(); if (e.shiftKey) edRedo(); else edUndo(); return; }
    if ((e.ctrlKey || e.metaKey) && k === 'y') { e.preventDefault(); edRedo(); return; }
    if (k === 'delete' || k === 'backspace') { e.preventDefault(); edDeleteSel(); return; }
    if (k === 'escape') { if (ED.sel) { ED.sel = null; edRenderInspector(); } return; }
    if (k === 'm') { ED.mirror = !ED.mirror; edRefreshUI(); return; }
    if ((k === 'q' || k === 'e') && ED.sel && ED.sel.kind === 'part') {
      edPushUndo(); edSelProp((o) => { o.spin = ((o.spin || 0) + (k === 'q' ? -0.2 : 0.2)); }); edRenderInspector();
    }
    // Q/E turn a selected limb's claw, hand or foot; R/F tilt it
    if ((k === 'q' || k === 'e' || k === 'r' || k === 'f') && ED.sel && ED.sel.kind === 'limb' && ED.sel.ref.tip) {
      edPushUndo();
      edSelProp((o) => {
        if (!o.tip) return;
        if (k === 'q' || k === 'e') o.tip.spin = clamp((o.tip.spin || 0) + (k === 'q' ? -0.2 : 0.2), -3.14, 3.14);
        else o.tip.tilt = clamp((o.tip.tilt || 0) + (k === 'r' ? -0.15 : 0.15), -1.3, 1.3);
      });
      edRenderInspector();
    }
  }, true);
}

// ---- open / close / apply ---------------------------------------------------------------
function openEditor(mode) {
  if (!ED.ui) edBuildUI();
  if (document.pointerLockElement && document.exitPointerLock) document.exitPointerLock();
  ED.mode = mode;
  const c = player.c;
  if (mode === 'game' && c && c.alive) {
    ED.des = c.genome.design ? C.cloneDesign(c.genome.design) : designFromGenome(c.genome);
    const g0 = C.cloneGenome(c.genome);
    if (!g0.design) { g0.design = C.cloneDesign(ED.des); C.compileDesign(g0); }
    ED.origPh = C.develop(c.genome);
    ED.statBrain = c.genome.brain; ED.statScale = c.genome.scale || 1;
    ED.tab = 'mouth';
  } else {
    ED.mode = 'start';
    ED.des = PROG.last ? C.cloneDesign(PROG.last) : C.defaultDesign(0);
    ED.origPh = null;
    ED.statBrain = (c && c.genome.brain) || C.seedHerbivore(world, world.rng).brain; ED.statScale = 1;
    ED.tab = 'body';
  }
  ED.capFloor = ED.mode === 'game' ? C.designCost(ED.des) : 0;
  ED.origItems = designItems(ED.des);
  ED.grantCount = grantCountOf(ED.des);
  ED.undo = []; ED.redo = []; ED.sel = null; ED.hover = null; ED.drag = null; ED.ghost = null; ED.savedOpen = false;
  ED.cam.yaw = 0.95; ED.cam.pitch = 0.2; ED.cam.zoom = 1;
  ED.open = true;
  document.body.classList.add('editing');
  const st = $('start'); if (st) st.style.display = 'none';
  edTouch();
  edRefreshUI();
  edMakeThumbs();
}
function closeEditor(apply) {
  if (!ED.open) return;
  if (apply) {
    const hasMouth = ED.des.parts.some(p => C.ITEM_SIM[p.id] && C.ITEM_SIM[p.id].t === 'MOUTH');
    if (!hasMouth) { edFlash('Your creature needs a mouth to eat. Add one from the mouths tab.'); ED.tab = 'mouth'; edRefreshUI(); return; }
    const used = C.designCost(ED.des), cap = edCapacity(ED.des);
    if (used > cap) { edFlash('Over genome space by ' + (used - cap) + '. Remove something first.'); return; }
    PROG.last = stripDesign(ED.des);
    saveProgress();
  }
  const mode = ED.mode, des = stripDesign(ED.des);
  ED.open = false; ED.drag = null; ED.ghost = null;
  document.body.classList.remove('editing');
  edHideTip();
  if (ED.ui) ED.ui.dragImg.style.display = 'none';
  lastT = 0;
  if (mode === 'start') {
    if (apply) { becomeDesigned(des); started = true; }
    else { const st = $('start'); if (st && !started) st.style.display = 'flex'; }
  } else if (apply) applyDesignToPlayer(des);
  updateHUD(); updateStats();
}
// Found a small deme of your design around you and become its newest member.
function becomeDesigned(des) {
  if (!world) return;
  const rng = world.rng;
  const g = C.seedHerbivore(world, rng);
  g.design = C.cloneDesign(des);
  C.compileDesign(g);
  const old = player.c;
  let x, y;
  if (old) { x = old.x; y = old.y; }
  else { const isl = terrain.island; x = isl ? isl.cx : WORLD_W / 2; y = isl ? isl.cy : WORLD_H / 2; }
  if (terrain.isDeep(x, y) && !C.develop(g).canSwim) { const sp2 = terrain.nearestShallow(x, y, false); if (sp2) { x = sp2[0]; y = sp2[1]; } }
  const me = C.makeCreature(g, x, y, 400);
  world.creatures.push(me);
  const KIN = 6;
  for (let i = 0; i < KIN; i++) {
    const kg = C.mutate(world, C.cloneGenome(g), rng, 0.10);
    const a2 = rng() * Math.PI * 2, r2 = 60 + rng() * 220;
    let kx = clamp(x + Math.cos(a2) * r2, 1, WORLD_W - 1), ky = clamp(y + Math.sin(a2) * r2, 1, WORLD_H - 1);
    if (terrain.isDeep(kx, ky)) { const sp3 = terrain.nearestShallow(kx, ky, false); if (sp3) { kx = sp3[0]; ky = sp3[1]; } }
    const kin = C.makeCreature(kg, kx, ky, 400);
    for (const q of kin.cellState) q.grow = 1;
    kin._growthAvg = 1;
    kin.ph = C.develop(kg, kin.cellState);
    kin.energy = kin.ph.storage;
    kin.age = C.maturity(kin.ph) + 2;
    world.creatures.push(kin);
  }
  player.c = me;
  player.absorbed = 0; player.fly = 0;
  player.camX = me.x; player.camZ = me.y;
  player.camY = groundAt(me.x, me.y) + 20;
  player.dist = Math.max(player.dist, THIRD_DEFAULT);
  toast('You hatch as a newborn, with ' + KIN + ' grown adults of your design nearby. Press B at any time to edit your creature.', 5200);
}
function applyDesignToPlayer(des) {
  const c = player.c;
  if (!c || !c.alive) { becomeDesigned(des); return; }
  const g = C.cloneGenome(c.genome);
  g.design = C.cloneDesign(des);
  C.compileDesign(g);
  const avg = clamp(c._growthAvg != null ? c._growthAvg : 0.5, 0.08, 1);
  c.genome = g;
  c.cellNodes = C.collectNodes(g.body, 0, []).map(e => e.node);
  c.cellState = c.cellNodes.map(() => ({ grow: avg, alive: true }));
  c.ph = C.develop(g, c.cellState);
  c.energy = Math.min(c.energy, c.ph.storage);
  c._sig = null; c._skel = null;
  toast('Your body is rebuilt. Stats and energy use now follow the new design.', 3200);
}
// An evolved (undesigned) body, read into the editor as the closest body plan
// with its parts placed where they would be.
function designFromGenome(genome) {
  const ph = C.develop(genome);
  const n = tallyParts(ph);
  const legs = n.LEG || 0, wings = n.WING || 0, fins = n.FIN || 0;
  let plan = 0;
  if (wings >= 1 && legs <= 2 && !ph.aquaticForm) plan = 7;
  else if (fins >= 2 && legs === 0) plan = 6;
  else if (legs === 0) plan = (ph.elong || 1) > 1.8 ? 3 : 9;
  else if (legs >= 7) plan = 4;
  else if (legs >= 5) plan = 5;
  else if (legs <= 2) plan = 2;
  else if ((ph.neck || 0) > 1.2) plan = 1;
  else if (ph.mass > 10 || (ph.elong || 1) < 1) plan = 8;
  const d = C.defaultDesign(plan);
  const P = C.PLANS[plan];
  d.body.neck = clamp((ph.neck || 0) / Math.max(0.1, P.neck || 0.1), C.BODY_RANGE.neck[0], C.BODY_RANGE.neck[1]);
  d.body.len = clamp(Math.sqrt((ph.elong || 1) / Math.max(0.3, P.a / P.b)) , C.BODY_RANGE.len[0], C.BODY_RANGE.len[1]);
  d.body.tail = (n.TAIL || 0) > 0 ? 1 : 0.2;
  C.reseatDesign(d);
  const rgb = C.hueToRGB(isFinite(ph.hue) ? ph.hue : 0.3, 0.52, 0.52).map(v => v / 255);
  d.col = { base: rgb, coat: [rgb[0] * 0.55 + 0.30, rgb[1] * 0.55 + 0.30, rgb[2] * 0.55 + 0.28], detail: rgb.map(v => v * 0.6), pat: 0 };
  const sk = C.buildDesignSkeleton(d);
  const B = sk.balls, head = B[sk.headIdx], snout = B[sk.headIdx + 1];
  const put = (id, tx, ty, tz, dx, dy, dz, s, mirror) => {
    const h = C.surfaceAt(sk, tx, ty, tz, dx, dy, dz); if (!h) return;
    const pt = { id, b: 0, o: [0, 0, 0], n: [0, 1, 0], spin: 0, s: s || 1, c: null, m: 0 };
    C.setAnchor(sk, pt, h.p, h.n, h.b); d.parts.push(pt);
    if (mirror && Math.abs(h.p[2]) > 0.08) {
      const k = nextKey(); pt.m = k;
      const tw = JSON.parse(JSON.stringify(pt)); const mp = mirrorPoint(h.p);
      C.setAnchor(sk, tw, mp, mirrorPoint(h.n), mirrorBall(sk, h.b, mp)); d.parts.push(tw);
    }
  };
  // keep only what the evolved body really has: the plan's eyes and its legs
  // (plain feet); every other default part is replaced below by the genome's own
  d.parts = d.parts.filter(p => C.ITEM_SIM[p.id] && C.ITEM_SIM[p.id].t === 'EYE' && p.id !== 'd_antenna');
  const cls0 = C.classifyLimbs(d, sk);
  const legSet = new Set(cls0.limbs.filter(o => o.leg).map(o => o.lb));
  d.limbs = d.limbs.filter(l => legSet.has(l));
  for (const l of d.limbs) { if (l.id === 'l_thick') l.id = 'l_leg'; l.tip = l.id === 'l_thin' ? null : { id: 't_paw', c: null, s: 1 }; }
  const mouth = ph.carnivory > 0.5 ? 'm_jaws' : ph.scavenger > 0.5 ? 'm_hook' : 'm_grazer';
  put(mouth, snout.x + snout.r * 0.9, snout.y - snout.r * 0.25, 0, 1, -0.35, 0, 1, false);
  const hr = head.r;
  if ((n.EYE || 0) >= 3) put('e_round', head.x - hr * 0.1, head.y + hr * 0.8, hr * 0.3, 0.1, 1, 0.4, 0.7, true);
  if ((n.HORN || 0) > 0) put('h_curved', head.x - hr * 0.2, head.y + hr, hr * 0.4, -0.2, 1, 0.4, 0.8, true);
  const spikes = Math.min(8, n.SPIKE || 0);
  for (let i = 0; i < spikes; i++) { const u = spikes === 1 ? 0 : i / (spikes - 1) - 0.5; put('s_spike', u * sk.a * 1.3, sk.b * 1.4, 0, 0, 1, 0, 0.8, false); }
  if ((n.GLAND || 0) > 0) put('d_gland', -sk.a * 0.2, sk.b * 0.3, sk.b, 0, 0.3, 1, 0.9, true);
  if (wings > 0 && !ph.aquaticForm) put(plan === 7 ? 'w_feather' : 'w_bat', sk.a * 0.1, sk.b * 0.6, sk.b * 0.5, 0, 0.7, 0.7, plan === 7 ? 1 : 0.8, true);
  if (fins > 0) put('f_fin', sk.a * 0.3, -sk.b * 0.2, sk.b, 0, -0.3, 1, 0.9, true);
  if (fins > 2) put('f_dorsal', -sk.a * 0.05, sk.b * 1.2, 0, 0, 1, 0, 1, false);
  return d;
}
// ---- kills: pick one part of the prey to unlock ------------------------------------------
const TYPE_ITEMS = {
  EYE: ['e_round', 'e_big', 'e_slit', 'e_stalk', 'e_cluster', 'e_bug'],
  HORN: ['h_straight', 'h_curved', 'h_ram', 'h_antler', 'h_rhino', 'h_tusk'],
  SPIKE: ['s_spike', 's_quills', 's_plate', 's_shell', 's_knob', 's_club'],
  LEG: ['l_leg', 'l_thick', 'l_thin', 't_paw', 't_hoof', 't_talon', 't_hand', 't_claw', 't_pincer', 't_pad'],
  FIN: ['f_fin', 'f_dorsal', 'f_fluke', 'd_gills', 't_flipper'],
  WING: ['w_bat', 'w_feather', 'w_insect'],
  GLAND: ['d_gland'], TAIL: ['s_club', 'f_fluke', 'd_frill'],
  ORN: ['d_crest', 'd_frill', 'd_antenna'],
};
function preyItems(prey) {
  if (!prey || !prey.genome) return [];
  const g = prey.genome;
  let ids = [];
  if (g.design) ids = designItems(g.design);
  else {
    const seed = (prey.id * 2654435761) >>> 0;
    const pickN = (arr, k, salt) => {
      const out = [], pool = arr.slice().sort((a, b) => (isUnlocked(a) - isUnlocked(b)) || (((seed ^ salt ^ a.length * 7) % 7) - 3));
      for (const id of pool) { if (out.length >= k) break; out.push(id); }
      return out;
    };
    const types = new Set();
    for (const e of C.collectNodes(g.body, 0, [])) types.add(e.node.type);
    for (const t of types) {
      if (t === 'MOUTH') {
        const m = C.collectNodes(g.body, 0, []).find(e => e.node.type === 'MOUTH');
        const mode = m ? m.node.mode : 'herb';
        ids.push(...pickN(mode === 'carn' ? ['m_jaws', 'm_maw'] : mode === 'scav' ? ['m_hook'] : ['m_beak', 'm_grazer', 'm_trunk'], 1, 11));
      } else if (TYPE_ITEMS[t]) ids.push(...pickN(TYPE_ITEMS[t], t === 'LEG' ? 2 : 1, t.length * 13));
    }
  }
  // locked ones first, then the rest; at most nine
  ids = [...new Set(ids)].filter(id => VIS[id]);
  ids.sort((a, b) => isUnlocked(a) - isUnlocked(b));
  return ids.slice(0, 9);
}
function edOnKill(prey) {
  PROG.kills++;
  saveProgress();
  const opts = preyItems(prey);
  if (!opts.length) { toast('Killed it. +' + KILL_SPACE + ' genome space.', 2600); return; }
  player.picker = { opts, label: 'You killed it: +' + KILL_SPACE + ' genome space. Take one of its parts', t0: performance.now(), items: true };
  renderPicker();
}
function renderPicker() {
  const el = $('picker');
  if (!el) return;
  const pk = player.picker;
  if (!pk) { el.style.display = 'none'; return; }
  if (!ED.thumbsReady) edMakeThumbs().then(() => { if (player.picker === pk) renderPicker(); });
  el.innerHTML = '<div class="ptitle">' + pk.label + '</div><div class="pgrid">' +
    pk.opts.map((id, i) => {
      const own = PROG.unlocked.has(id) || SANDBOX;
      const th = ED.thumbs[id];
      return `<div class="popt2${own ? ' own' : ''}" data-pick="${i + 1}"><b>${i + 1}</b>${th ? `<img src="${th}" alt="">` : ''}<span>${VIS[id].name}</span><em>${own ? 'already yours' : 'new'}</em></div>`;
    }).join('') + '</div><div class="pskip" data-pick="0"><b>0</b> take nothing</div>';
  el.style.display = 'block';
  for (const o of el.querySelectorAll('[data-pick]')) o.onclick = () => choosePicked(+o.getAttribute('data-pick'));
}
function choosePicked(i) {
  const pk = player.picker;
  if (!pk) return;
  player.picker = null; renderPicker();
  if (i === 0) { toast('Took nothing. Your genome space still grew.', 1800); return; }
  const id = pk.opts[i - 1];
  if (!id) return;
  const was = PROG.unlocked.has(id);
  PROG.unlocked.add(id); saveProgress();
  toast(was ? 'You already had the ' + VIS[id].name + '. Genome space still grew.' : 'Unlocked the ' + VIS[id].name + '. Press B to add it to your body.', 3600);
}
function edHudLine() {
  const el = $('v-genome');
  if (!el) return;
  const c = player.c;
  const des = c && c.genome && c.genome.design;
  const used = des ? C.designCost(des) : null;
  const cap = des ? edCapacity(des) : null;
  el.innerHTML = (des ? `<span class="k">genome</span> <span class="v">${used}/${cap}</span> &middot; ` : '') +
    `<span class="k">kills</span> <span class="v">${PROG.kills}</span> &middot; <span class="k">parts</span> <span class="v">${PROG.unlocked.size}/${Object.keys(VIS).length}</span>` +
    (c && c.hurtT > 0 ? `<br><span style="color:#ff8a76">under attack: cannot eat for ${c.hurtT.toFixed(1)} s</span>` : '');
}

// ---- species names: whatever you type, or a rolled one ---------------------
const NAME_BITS = ['tyranno', 'vela', 'stega', 'anky', 'brachio', 'cerato', 'allo', 'spino', 'megalo', 'dilopho', 'thero',
                   'gorgo', 'carno', 'ptera', 'plesio', 'mosa', 'cryo', 'pyro', 'umbra', 'ferro', 'nocti', 'vora', 'sanguino', 'titano'];
const NAME_TAIL = ['saurus', 'saurus', 'saurus', 'don', 'nyx', 'raptor', 'rex', 'venator', 'lophus', 'cephalo', 'therium'];
function edCleanStem(v) { return String(v || '').toLowerCase().replace(/[^a-z '-]/g, '').replace(/\s+/g, ' ').slice(0, 22); }
function rollStem() {
  const r = () => Math.random();
  return edCleanStem(NAME_BITS[(r() * NAME_BITS.length) | 0] + NAME_TAIL[(r() * NAME_TAIL.length) | 0]);
}
// title case, so "sanguino rex" reads as a name and not as typing
function speciesName(d) {
  const stem = edCleanStem(d && d.stem) || rollStem();
  return stem.replace(/(^|[ '-])([a-z])/g, (m, a, b) => a + b.toUpperCase());
}
