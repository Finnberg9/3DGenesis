# =====================================================================
# INVENTORY: parts are counted, not flagged.
#
# Until now a part was a yes/no: the first spike you took off a corpse
# unlocked "spike" for good and you could then cover a body in them. That
# is not what taking a part off a dead animal means. This turns the whole
# unlock system into a real inventory: you own N copies of a part, one per
# kill or purchase, and you can wear at most N of them at once.
#
# The one exception is the body you walked in with. An inherited, evolved
# or wild-born creature carries parts you never earned, and it has to stay
# rearrangeable or the editor would refuse to let you touch your own
# animal. So the allowance for a part is max(owned, what the body carried
# when the editor opened). The second half is not persisted, so it cannot
# be farmed into stock.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, (a[:100], n); return s.replace(a, b)
p = 'g3.html'; s = open(p, encoding='utf-8').read()

# ---------------------------------------------------------------- state
s = sub1(s, "const PROG = { kills: 0, bones: 0, bought: [], unlocked: new Set(STARTER_ITEMS), saved: [], last: null };",
"""// PROG.owned maps a part id to how many copies you hold. A part missing
// from it, or sitting at zero, is locked.
const PROG = { kills: 0, bones: 0, bought: [], owned: {}, saved: [], last: null };
for (const id of STARTER_ITEMS) PROG.owned[id] = (PROG.owned[id] | 0) + 1;
function ownedCount(id) { return SANDBOX ? Infinity : Math.max(0, PROG.owned[id] | 0); }
// How many different parts you hold at least one of.
function ownedKinds() { let k = 0; for (const id in PROG.owned) if ((PROG.owned[id] | 0) > 0) k++; return k; }
function ownedGain(id, n) {
  if (!VIS[id]) return 0;
  PROG.owned[id] = Math.max(0, PROG.owned[id] | 0) + Math.max(1, n | 0);
  saveProgress();
  return PROG.owned[id];
}
function ownedLose(id, n) {
  n = Math.max(1, n | 0);
  const have = Math.max(0, PROG.owned[id] | 0);
  if (have < n) return false;
  if (have - n > 0) PROG.owned[id] = have - n; else delete PROG.owned[id];
  saveProgress();
  return true;
}""")

# ---------------------------------------------------------------- load / save
s = sub1(s, "      if (Array.isArray(o.unlocked)) for (const id of o.unlocked) if (VIS[id]) PROG.unlocked.add(id);",
"""      if (o.owned && typeof o.owned === 'object' && !Array.isArray(o.owned)) {
        for (const id in o.owned) if (VIS[id]) { const n = o.owned[id] | 0; if (n > 0) PROG.owned[id] = n; }
      } else if (Array.isArray(o.unlocked)) {
        // Saves from before parts were counted held a flat "unlocked" list.
        // Turn each entry into a real count: as many copies as the largest
        // body you saved actually wears, and never fewer than one, so no
        // creature you already built becomes illegal overnight.
        const need = {};
        const scan = (d) => {
          if (!d) return;
          const m = {};
          for (const q of d.parts || []) if (q && q.id) m[q.id] = (m[q.id] || 0) + 1;
          for (const l of d.limbs || []) { if (!l) continue; if (l.id) m[l.id] = (m[l.id] || 0) + 1; if (l.tip && l.tip.id) m[l.tip.id] = (m[l.tip.id] || 0) + 1; }
          for (const k in m) need[k] = Math.max(need[k] || 0, m[k]);
        };
        if (Array.isArray(o.saved)) for (const sv of o.saved) if (sv && sv.design) scan(sv.design);
        scan(o.last);
        for (const id of o.unlocked) if (VIS[id]) PROG.owned[id] = Math.max(1, need[id] || 0);
      }""")
s = sub1(s, "      kills: PROG.kills, bones: PROG.bones | 0, bought: PROG.bought || [], unlocked: [...PROG.unlocked], saved: PROG.saved, last: PROG.last,",
            "      kills: PROG.kills, bones: PROG.bones | 0, bought: PROG.bought || [], owned: PROG.owned, saved: PROG.saved, last: PROG.last,")

# ---------------------------------------------------------------- the allowance
s = sub1(s, """function spareOf(id) {
  if (SANDBOX || PROG.unlocked.has(id)) return Infinity;
  if (!ED.des) return 0;
  return Math.max(0, ((ED.grantCount && ED.grantCount[id]) || 0) - countItem(ED.des, id));
}
const itemAvailable = (id) => spareOf(id) > 0;
const isUnlocked = (id) => SANDBOX || PROG.unlocked.has(id);
function edCanUse(id, n) {
  const sp = spareOf(id);
  if (sp >= n) return true;
  const own = (ED.grantCount && ED.grantCount[id]) || 0;
  edFlash(own ? (sp > 0 && n > 1 ? 'You only have one more of these. Turn mirror off, or kill animals that have one to unlock it.' : 'Your body only has ' + own + ' of these. Kill an animal that has one to unlock more.')
              : 'Locked. Kill an animal that has one and choose it to unlock it.');
  return false;
}""",
"""// The most copies of a part that may be on the body at once: what you own,
// or what the body was already carrying when the editor opened, whichever is
// larger. The grant half keeps an inherited or evolved body rearrangeable and
// is never written to storage, so it cannot be turned into stock.
function stockOf(id) {
  if (SANDBOX) return Infinity;
  return Math.max(Math.max(0, PROG.owned[id] | 0), (ED.grantCount && ED.grantCount[id]) || 0);
}
// How many more you may place right now.
function spareOf(id) {
  if (SANDBOX) return Infinity;
  if (!ED.des) return 0;
  return Math.max(0, stockOf(id) - countItem(ED.des, id));
}
const itemAvailable = (id) => spareOf(id) > 0;
const isUnlocked = (id) => SANDBOX || (PROG.owned[id] | 0) > 0;
function edCanUse(id, n) {
  const sp = spareOf(id);
  if (sp >= n) return true;
  const st = stockOf(id), nm = (VIS[id] && VIS[id].name) || id;
  edFlash(
    st <= 0 ? 'Locked. Kill an animal wearing ' + nm + ', or buy it on its card.'
    : sp > 0 && n > 1 ? 'Only ' + sp + ' spare. Turn mirror off, or get another.'
    : 'All ' + st + ' of your ' + nm + ' already on the body. Kill or buy another to add more.');
  return false;
}""")

# the random-creature roller draws from the same allowance
s = sub1(s, "  const allow = (id) => (SANDBOX || PROG.unlocked.has(id)) ? Infinity : ((ED.grantCount && ED.grantCount[id]) || 0);",
            "  const allow = (id) => stockOf(id);")

# ---------------------------------------------------------------- buying and selling
s = sub1(s, """function boneBuy(id) {
  if (!VIS[id]) return { ok: false, msg: 'No such part.' };
  if (isUnlocked(id)) return { ok: false, msg: 'You already own the ' + VIS[id].name + '.' };
  const price = bonePrice(id);
  if (boneBalance() < price) return { ok: false, msg: 'Not enough bones: the ' + VIS[id].name + ' costs ' + price + '.' };
  if (!boneSpend(price, 'buy:' + id)) return { ok: false, msg: 'Purchase failed.' };
  PROG.unlocked.add(id);
  PROG.bought = PROG.bought || [];
  if (!PROG.bought.includes(id)) PROG.bought.push(id);
  saveProgress();
  return { ok: true, msg: 'Bought the ' + VIS[id].name + ' for ' + price + ' bones.', price };
}""",
"""// Buying adds one copy. You may keep buying: four legs is four purchases.
function boneBuy(id) {
  if (!VIS[id]) return { ok: false, msg: 'No such part.' };
  if (SANDBOX) return { ok: false, msg: 'Sandbox: every part is already yours.' };
  const price = bonePrice(id);
  if (boneBalance() < price) return { ok: false, msg: 'Not enough bones: ' + VIS[id].name + ' costs ' + price + '.' };
  if (!boneSpend(price, 'buy:' + id)) return { ok: false, msg: 'Purchase failed.' };
  const n = ownedGain(id, 1);
  PROG.bought = PROG.bought || [];
  if (!PROG.bought.includes(id)) PROG.bought.push(id);
  saveProgress();
  return { ok: true, msg: 'Bought ' + VIS[id].name + ' for ' + price + ' bones. You have ' + n + '.', price, count: n };
}""")
s = sub1(s, """function boneSell(id) {
  if (!VIS[id]) return { ok: false, msg: 'No such part.' };
  if (!PROG.unlocked.has(id)) return { ok: false, msg: 'You do not own the ' + VIS[id].name + '.' };
  if (ED.des && countItem(ED.des, id) > 0) {
    return { ok: false, msg: 'Your creature is wearing the ' + VIS[id].name + '. Take it off first.' };
  }
  const back = boneRefund(id);
  PROG.unlocked.delete(id);
  if (PROG.bought) PROG.bought = PROG.bought.filter(q => q !== id);
  boneEarn(back, 'sell:' + id);
  saveProgress();
  return { ok: true, msg: 'Sold the ' + VIS[id].name + ' for ' + back + ' bones.', back };
}""",
"""// Selling gives back a quarter of one copy. Copies the creature is actually
// wearing cannot be sold out from under it, so you can only sell the spares.
function boneSell(id) {
  if (!VIS[id]) return { ok: false, msg: 'No such part.' };
  const have = Math.max(0, PROG.owned[id] | 0);
  if (have <= 0) return { ok: false, msg: 'You have no ' + VIS[id].name + ' to sell.' };
  const worn = ED.des ? countItem(ED.des, id) : 0;
  if (have - worn <= 0) {
    return { ok: false, msg: 'Your creature is wearing every ' + VIS[id].name + ' you own. Take one off first.' };
  }
  const back = boneRefund(id);
  if (!ownedLose(id, 1)) return { ok: false, msg: 'Sale failed.' };
  const left = Math.max(0, PROG.owned[id] | 0);
  if (!left && PROG.bought) PROG.bought = PROG.bought.filter(q => q !== id);
  boneEarn(back, 'sell:' + id);
  saveProgress();
  return { ok: true, msg: 'Sold one ' + VIS[id].name + ' for ' + back + ' bones. ' + (left ? left + ' left.' : 'None left.'), back, count: left };
}""")

# ---------------------------------------------------------------- the card
s = sub1(s, """      const owned = isUnlocked(id);
      const tier = boneTier(id), price = bonePrice(id), col = BONE_TIER_COL[tier];
      const bal = boneBalance();
      const buyable = !owned && !SANDBOX && !brLocked();
      const selling = ED.sellArm === id;""",
"""      const nOwn = SANDBOX ? Infinity : Math.max(0, PROG.owned[id] | 0);
      const worn = ED.des ? countItem(ED.des, id) : 0;
      const sp = spareOf(id);
      const tier = boneTier(id), price = bonePrice(id), col = BONE_TIER_COL[tier];
      const bal = boneBalance();
      const buyable = !SANDBOX && !brLocked();
      const sellable = !SANDBOX && !brLocked() && nOwn - worn > 0;
      const selling = ED.sellArm === id;""")
s = sub1(s, """        `<div class="edccost">${itemCost(id)} genome space · <span class="edtierb" style="color:${col}">${BONE_TIER_LABEL[tier]}</span></div>` +
        (buyable
          ? `<button class="edbuy${bal >= price ? '' : ' poor'}" data-buy="${id}" style="border-color:${col}"><span>buy</span><b style="color:${col}">${price}</b></button>`
          : owned && !SANDBOX && !brLocked()
            ? `<button class="edsell${selling ? ' arm' : ''}" data-sell="${id}">${selling ? 'sell for ' + boneRefund(id) + '?' : 'owned &middot; sell ' + boneRefund(id)}</button>`
            : owned ? '<div class="edowned">yours</div>'
                    : `<div class="edowned locked">locked &middot; not for sale in a match</div>`) +
        `</div>`;""",
"""        `<div class="edccost">${itemCost(id)} genome space · <span class="edtierb" style="color:${col}">${BONE_TIER_LABEL[tier]}</span></div>` +
        (SANDBOX ? '<div class="edowned">sandbox &middot; unlimited</div>'
          : `<div class="edstock${nOwn ? '' : ' none'}">${nOwn ? 'you own ' + nOwn + ' &middot; ' + (sp > 0 ? sp + ' to place' : 'all worn') : 'you own none'}</div>`) +
        (buyable
          ? `<button class="edbuy${bal >= price ? '' : ' poor'}" data-buy="${id}" style="border-color:${col}"><span>${nOwn ? 'buy another' : 'buy'}</span><b style="color:${col}">${price}</b></button>` : '') +
        (sellable
          ? `<button class="edsell${selling ? ' arm' : ''}" data-sell="${id}">${selling ? 'sell one for ' + boneRefund(id) + '?' : 'sell one &middot; ' + boneRefund(id)}</button>` : '') +
        (!buyable && !sellable && !SANDBOX ? '<div class="edowned locked">no trading in a match</div>' : '') +
        `</div>`;""")
# a count badge on the tile itself, so the grid reads at a glance
s = sub1(s, """        `<div class="edtile item${av ? '' : ' locked'}" data-item="${id}">${tileHTML(id, av, `<span class="edcost">${itemCost(id)}</span>`)}</div>` +
        `<div class="edcname">${v.name}</div><div class="edcuse">${v.use || effectText(id) || ''}</div>` +""",
"""        `<div class="edtile item${av ? '' : ' locked'}" data-item="${id}">${tileHTML(id, av, `<span class="edcost">${itemCost(id)}</span>`)}` +
          `${nOwn > 0 && nOwn !== Infinity ? `<span class="edhave">×${nOwn}</span>` : ''}</div>` +
        `<div class="edcname">${v.name}</div><div class="edcuse">${v.use || effectText(id) || ''}</div>` +""")
s = sub1(s, "  .edowned{margin-top:4px;font-size:10.5px;color:#6d97a4;text-align:center}",
"""  .edowned{margin-top:4px;font-size:10.5px;color:#6d97a4;text-align:center}
  .edstock{margin-top:3px;font-size:10.5px;color:#9fd0bf;text-align:center;letter-spacing:.02em}
  .edstock.none{color:#7d8f96;opacity:.8}
  .edhave{position:absolute;right:3px;top:3px;font-size:10.5px;font-weight:700;line-height:1;
    padding:2px 4px;border-radius:5px;background:rgba(8,26,24,.85);border:1px solid #37625a;color:#bff0dd}""")

# ---------------------------------------------------------------- tooltip
s = sub1(s, """  const sp = spareOf(id), own = (ED.grantCount && ED.grantCount[id]) || 0;
  tip.innerHTML = `<b>${v.name}</b><span class="c">genome space ${itemCost(id)}</span><div>${effectText(id)}</div>` +
    (sp === Infinity ? '' : own ? `<div class="lk">not unlocked: your body has ${own}, ${sp} left to place. kill an animal that has one to unlock it</div>`
                                : '<div class="lk">locked: kill an animal that has one, or buy it on this card for ' + bonePrice(id) + ' bones (' + BONE_TIER_LABEL[boneTier(id)] + ')</div>');""",
"""  const sp = spareOf(id), nOwn = Math.max(0, PROG.owned[id] | 0), grant = (ED.grantCount && ED.grantCount[id]) || 0;
  tip.innerHTML = `<b>${v.name}</b><span class="c">genome space ${itemCost(id)}</span><div>${effectText(id)}</div>` +
    (sp === Infinity ? ''
      : nOwn > 0 ? `<div class="lk">you own ${nOwn}${grant > nOwn ? ' (your body came with ' + grant + ')' : ''}, ${sp} left to place</div>`
      : grant > 0 ? `<div class="lk">not yours: the body you came in with has ${grant}, ${sp} left to place. kill an animal wearing one to keep it</div>`
      : '<div class="lk">locked: kill an animal that has one, or buy it on this card for ' + bonePrice(id) + ' bones (' + BONE_TIER_LABEL[boneTier(id)] + ')</div>');""")

# ---------------------------------------------------------------- the kill picker
s = sub1(s, """      const own = PROG.unlocked.has(id) || SANDBOX;
      const th = ED.thumbs[id];
      return `<div class="popt2${own ? ' own' : ''}" data-pick="${i + 1}"><b>${i + 1}</b>${th ? `<img src="${th}" alt="">` : ''}<span>${VIS[id].name}</span><em>${own ? 'already yours' : 'new'}</em></div>`;""",
"""      // Every option is worth taking now: a part you already hold is a
      // second copy, which is one more you can wear.
      const n = SANDBOX ? 0 : Math.max(0, PROG.owned[id] | 0);
      const th = ED.thumbs[id];
      return `<div class="popt2" data-pick="${i + 1}"><b>${i + 1}</b>${th ? `<img src="${th}" alt="">` : ''}<span>${VIS[id].name}</span><em>${SANDBOX ? 'sandbox' : n ? 'you have ' + n + ' &middot; +1' : 'new'}</em></div>`;""")
s = sub1(s, """  const was = PROG.unlocked.has(id);
  PROG.unlocked.add(id); saveProgress();
  toast(was ? 'You already had the ' + VIS[id].name + '. Genome space still grew.' : 'Unlocked the ' + VIS[id].name + '. Press B to add it to your body.', 3600);""",
"""  const n = ownedGain(id, 1);
  toast('Took ' + VIS[id].name + '. You now have ' + n + '. Press B to put ' + (n > 1 ? 'one' : 'it') + ' on.', 3600);""")

# ---------------------------------------------------------------- counters
s = sub1(s, "`<span class=\"k\">kills</span> <span class=\"v\">${PROG.kills}</span> &middot; <span class=\"k\">parts</span> <span class=\"v\">${PROG.unlocked.size}/${Object.keys(VIS).length}</span>` +",
            "`<span class=\"k\">kills</span> <span class=\"v\">${PROG.kills}</span> &middot; <span class=\"k\">parts</span> <span class=\"v\">${ownedKinds()}/${Object.keys(VIS).length}</span>` +")
s = sub1(s, "{ title: 'Adapt', text: 'Take four new body parts from your kills.', goal: 4, val: () => PROG.unlocked.size - OBJS.startUnlocked },",
            "{ title: 'Adapt', text: 'Take four new body parts from your kills.', goal: 4, val: () => ownedKinds() - OBJS.startUnlocked },")
s = sub1(s, "OBJS.startUnlocked = PROG.unlocked.size;", "OBJS.startUnlocked = ownedKinds();")

# ---------------------------------------------------------------- match loot
# Every part on a body you killed is offered, including ones you already hold:
# a duplicate is a second copy, which in a counted inventory is the whole point.
s = sub1(s, """  const opts = [...ids].filter(id => !PROG.unlocked.has(id));
  if (!opts.length) { brSay('You ate ' + from + '. Nothing on it you did not already have.', 2600); return; }""",
"""  const opts = [...ids];
  if (!opts.length) { brSay('You ate ' + from + '. There was nothing on it to take.', 2600); return; }""")

# ---------------------------------------------------------------- test surface
s = sub1(s, """    reset: () => { PROG.bones = 0; PROG.unlocked = new Set(); PROG.bought = []; ED.sellArm = null; saveProgress(); },
    grant: (id) => { PROG.unlocked.add(id); saveProgress(); },""",
"""    reset: () => { PROG.bones = 0; PROG.owned = {}; PROG.bought = []; ED.sellArm = null; saveProgress(); },
    grant: (id, n) => { ownedGain(id, n || 1); },
    count: (id) => Math.max(0, PROG.owned[id] | 0),
    stock: (id) => stockOf(id),
    spare: (id) => spareOf(id),
    kinds: () => ownedKinds(),
    canUse: (id, n) => { const sp = spareOf(id); return sp >= (n || 1); },
    take: (id) => { const n = ownedGain(id, 1); return n; },
    wornCount: (id) => (ED.des ? countItem(ED.des, id) : 0),""")

# ---------------------------------------------------------------- test surface: real placement
# The rule only means something where a part actually lands, so the checks
# drive edAddPart/edAddLimb themselves rather than a stand-in. The hit is a
# ray straight down onto a skeleton ball, which is what a drag onto the
# creature's back produces.
s = sub1(s, "  openEditor: (m) => openEditor(m || 'game'),",
"""  openEditor: (m) => openEditor(m || 'game'),
  inv: {
    granted: (id) => (ED.grantCount && ED.grantCount[id]) || 0,
    space: () => edSpaceLeft(),
    addSpace: (kills) => { PROG.kills += Math.max(1, kills | 0); saveProgress(); edRefreshUI(); return edSpaceLeft(); },
    // a part of this category that the open body is not already wearing and
    // you own none of, so a test starts from a true zero
    pickUnowned: (cat) => {
      for (const id of Object.keys(VIS)) {
        if (VIS[id].cat !== cat) continue;
        if ((PROG.owned[id] | 0) > 0) continue;
        if ((ED.grantCount && ED.grantCount[id]) || 0) continue;
        if (!C.ITEM_SIM[id]) continue;
        return id;
      }
      return null;
    },
    hit: (i) => {
      if (!ED.des) return null;
      const sk = designGeo(ED.des).sk, n = sk.balls.length;
      const k = sk.balls[Math.max(0, Math.min(n - 1, i | 0))];
      return C.raySkin(sk, k.x, k.y + 10, k.z, 0, -1, 0, 40);
    },
    place: (id, i) => {
      const h = window.__G3D.inv.hit(i == null ? 1 : i);
      if (!h) return false;
      const sim = C.ITEM_SIM[id];
      if (!sim) return false;
      return sim.t === 'LIMB' ? edAddLimb(id, h) : edAddPart(id, h);
    },
    remove: (id) => {
      if (!ED.des) return false;
      const ps = ED.des.parts || [];
      for (let i = ps.length - 1; i >= 0; i--) if (ps[i].id === id) { ED.des.parts.splice(i, 1); edTouch(); edRefreshUI(); return true; }
      const ls = ED.des.limbs || [];
      for (let i = ls.length - 1; i >= 0; i--) if (ls[i].id === id) { ED.des.limbs.splice(i, 1); edTouch(); edRefreshUI(); return true; }
      return false;
    },
  },""")

open(p, 'w', encoding='utf-8').write(s)
print('inventory ok')

# ---- the page must no longer reference the old flag set anywhere -------------
s = open(p, encoding='utf-8').read()
left = s.count('PROG.unlocked')
assert left == 0, 'PROG.unlocked still referenced %d time(s)' % left
print('no PROG.unlocked left: 0')
