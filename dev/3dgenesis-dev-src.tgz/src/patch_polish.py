# =====================================================================
# 1. THE MATCH CLOCK RAN AT DOUBLE SPEED IN THE CREATURE EDITOR.
#    tick() already advances the match (it has to: a dropped frame must not be
#    a dropped second), and the editor branch of the loop called brTick AGAIN
#    right after it. Every frame the builder was open cost the match two
#    seconds instead of one: the ring closed twice as fast, the island emptied
#    twice as early, and the clock on the HUD ran away from you while you were
#    looking at parts. The editor branch now does exactly what the playing
#    branch does -- tick once, then draw the HUD.
#
# 2. THE FOG ON THE MINIMAP IS WEATHER, NOT A DIAGRAM.
#    It was a half-transparent wash with a hard white ring drawn on top, which
#    read as a compass circle over a map you could still see through. It is a
#    solid grey mass now -- you cannot see the ground under it, because you
#    cannot -- and its inner boundary is a soft outline rather than a drawn
#    ring.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, (a[:100], n); return s.replace(a, b)
p = 'g3.html'; s = open(p, encoding='utf-8').read()

# ---------------------------------------------------------------- 1. double tick
s = sub1(s, """    try { objTick(dt); sndTick(dt); spatTick(dt); } catch (e) { console.warn(e); }
    try { if (BR.on) brTick(dt); } catch (e) { console.warn('br while editing', e); }
    try { edShield(); } catch (e) { console.warn(e); }""",
"""    try { objTick(dt); sndTick(dt); spatTick(dt); } catch (e) { console.warn(e); }
    // NOT brTick: tick() above already advanced the match. Calling it here as
    // well ran the match clock at double speed for as long as the builder was
    // open. Draw the HUD instead, exactly as the playing branch does.
    try { if (BR.on) brRenderHud(); } catch (e) { console.warn('br hud while editing', e); }
    try { edShield(); } catch (e) { console.warn(e); }""")
open(p, 'w', encoding='utf-8').write(s)
print('editor clock ok')

# ---------------------------------------------------------------- 2. the minimap fog
s = open(p, encoding='utf-8').read()
s = sub1(s, """    miniCtx.fillStyle = 'rgba(150,158,150,0.50)';
    miniCtx.fill('evenodd');
    // the edge itself
    ringPath((a) => brZoneEdge(a), Z.cx, Z.cz);
    miniCtx.strokeStyle = 'rgba(226,232,224,0.95)'; miniCtx.lineWidth = 2 * k; miniCtx.stroke();""",
"""    // Solid: under the cloud there is nothing to see, so the map shows
    // nothing. A flat grey mass with no ground reading through it.
    miniCtx.fillStyle = 'rgb(138,143,138)';
    miniCtx.fill('evenodd');
    // Its inner boundary, as an outline rather than a drawn ring: a soft pale
    // line just inside the grey, and a wider, fainter one under it so the edge
    // has a little depth instead of a hard rim.
    ringPath((a) => brZoneEdge(a), Z.cx, Z.cz);
    miniCtx.strokeStyle = 'rgba(196,201,194,0.30)'; miniCtx.lineWidth = 5 * k; miniCtx.stroke();
    miniCtx.strokeStyle = 'rgba(224,228,220,0.55)'; miniCtx.lineWidth = 1.1 * k; miniCtx.stroke();""")
open(p, 'w', encoding='utf-8').write(s)
print('minimap fog ok')
