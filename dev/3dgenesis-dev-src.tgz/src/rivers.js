// =====================================================================
// RIVERS
// Water that runs downhill in one direction, from the high ground to the sea,
// in a channel it cut for itself with rock banks standing over it.
//
// Three stages, and the ORDER matters:
//   1. route   -- steepest descent from a spring to the coast, forced monotonic
//   2. carve   -- cut the channel into the heightmap. Must happen BEFORE the
//                 terrain render mesh is built, or the mesh is already baked.
//                 The banks are cut steep on purpose: the terrain shader draws
//                 anything past about 22 degrees as layered rock, so a steep
//                 bank IS a rock cliff with no extra geometry.
//   3. ribbon  -- a strip of quads following the route at the water's surface,
//                 carrying how far along it each vertex is, so the shader can
//                 scroll the flow one way and break it into whitewater where
//                 the bed steepens.
// =====================================================================
const RIV = {
  paths: [],            // [{ pts: [{x,z,y,w,grad}], len }]
  vb: null, ib: null, count: 0, pipe: null, bind: null,
  built: false, mask: null, maskNX: 0, maskNZ: 0, maskCell: 96,
};
const RIVER_TRY = 34;              // springs attempted per world
const RIVER_MIN_LEN = 14;          // samples; shorter routes are gullies, not rivers
const RIVER_STEP = 46;             // world units between route samples
const RIVER_VF = 8;                // pos3, u, v, grad, depth, bank

function rivRng(seed) {
  let a = (seed >>> 0) || 1;
  return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}

// ---- 1. routing ------------------------------------------------------------
// Walk downhill from a spring. At each step look around a ring for the lowest
// neighbour; if nothing is lower we are in a bowl, so stop. The route is forced
// monotonically downhill afterwards, because a river that climbs is not a river.
function rivRoute(sx, sz, rnd) {
  const T = terrain, sea = T.LV.water;
  const pts = [];
  let x = sx, z = sz;
  let heading = rnd() * Math.PI * 2;
  const MAX_STEPS = 420;                               // about 19000 units of river
  for (let step = 0; step < MAX_STEPS; step++) {
    const e = T.height(x, z);
    pts.push({ x, z, e });
    if (e <= sea + 0.004) break;                       // reached the sea
    if (x < 120 || z < 120 || x > WORLD_W - 120 || z > WORLD_H - 120) break;
    // the lowest point on a ring ahead, with a bias to keep going the way we
    // were going so the river meanders instead of zig-zagging
    let bestA = null, bestE = Infinity;
    for (let k = 0; k < 16; k++) {
      const a = (k / 16) * Math.PI * 2;
      let da = Math.abs(((a - heading + Math.PI * 3) % (Math.PI * 2)) - Math.PI);
      if (da > 1.9) continue;                          // never double back
      const nx = x + Math.cos(a) * RIVER_STEP, nz = z + Math.sin(a) * RIVER_STEP;
      if (nx < 60 || nz < 60 || nx > WORLD_W - 60 || nz > WORLD_H - 60) continue;
      const ne = T.height(nx, nz) + da * 0.00012;      // gentle straightening bias
      if (ne < bestE) { bestE = ne; bestA = a; }
    }
    if (bestA == null || bestE >= e + 0.0009) break;    // a bowl: the river ends here
    // A river that has stopped descending has become a marsh. Look back over
    // the last stretch: if it has barely dropped, end it here rather than
    // letting it wander across a plain for twenty thousand units.
    if (step > 40) {
      const back = pts[pts.length - 41];
      if (back && back.e - e < 0.006) break;
    }
    heading = bestA;
    x += Math.cos(bestA) * RIVER_STEP;
    z += Math.sin(bestA) * RIVER_STEP;
  }
  if (pts.length < RIVER_MIN_LEN) return null;
  // force it downhill: the water surface can never rise along the route
  let run = pts[0].e;
  for (const q of pts) { run = Math.min(run, q.e); q.wy = run; }
  return pts;
}

// ---- 2. carving ------------------------------------------------------------
// Cut the bed and stand the banks up. Depth and width both wander along the
// route, so a river is a gorge in one reach and a shallow braid in the next,
// which is where the varying cliff heights come from.
function rivCarve(pts, rnd) {
  const T = terrain, HS = T.heightScale || 420, sea = T.LV.water;
  const phase = rnd() * 100, phase2 = rnd() * 100;
  const n = pts.length;
  for (let i = 0; i < n; i++) {
    const q = pts[i];
    const u = i / (n - 1);
    // wider and calmer toward the mouth, narrow and cut-in up in the hills
    const wob = Math.sin(u * 9 + phase) * 0.5 + Math.sin(u * 23 + phase2) * 0.28;
    const halfW = (26 + 54 * u) * (1 + wob * 0.35);
    // how far the banks stand over the water, in world units
    const gorge = clamp(0.5 + wob, 0, 1.6);
    const bankH = (18 + 150 * gorge) * (1 - 0.55 * u);
    const depth = (7 + 16 * gorge) / HS;
    q.w = halfW;
    q.bank = bankH;
    // the bed sits below the running surface
    const bedE = Math.max(0.002, q.wy - depth);
    T.carveChannel(q.x, q.z, halfW, Math.max(10, halfW * 0.55), bedE, bankH / HS, q.wy);
  }
  // gradient along the route, for whitewater
  for (let i = 0; i < n; i++) {
    const a = pts[Math.max(0, i - 1)], b = pts[Math.min(n - 1, i + 1)];
    const d = Math.hypot(b.x - a.x, b.z - a.z) || 1;
    pts[i].grad = Math.max(0, (a.wy - b.wy) * HS / d);
  }
}

// ---- build -----------------------------------------------------------------
function rivBuild(seed) {
  RIV.paths.length = 0;
  RIV.built = false;
  if (!terrain || !terrain.carveChannel) return 0;
  const T = terrain, sea = T.LV.water;
  const rnd = rivRng((seed | 0) ^ 0x9E3779B9);
  // springs: high ground, spread out, biased to the steep flanks where a river
  // actually starts
  const springs = [];
  for (let k = 0; k < RIVER_TRY * 40 && springs.length < RIVER_TRY; k++) {
    const x = 300 + rnd() * (WORLD_W - 600), z = 300 + rnd() * (WORLD_H - 600);
    const e = T.height(x, z);
    if (e < sea + 0.16) continue;                      // not high enough to run anywhere
    let tooClose = false;
    for (const s of springs) if (Math.hypot(s.x - x, s.z - z) < 2600) { tooClose = true; break; }
    if (tooClose) continue;
    springs.push({ x, z, e });
  }
  springs.sort((a, b) => b.e - a.e);
  let made = 0;
  for (const s of springs) {
    if (made >= 7) break;
    const pts = rivRoute(s.x, s.z, rnd);
    if (!pts) continue;
    rivCarve(pts, rnd);
    RIV.paths.push({ pts });
    made++;
  }
  // a coarse mask so the rest of the game can ask "is there a river here"
  rivBuildMask();
  return made;
}
function rivBuildMask() {
  const cell = RIV.maskCell;
  const nx = Math.ceil(WORLD_W / cell) + 1, nz = Math.ceil(WORLD_H / cell) + 1;
  const m = new Float32Array(nx * nz);
  for (const p of RIV.paths) for (const q of p.pts) {
    const r = q.w + 20;
    const i0 = Math.max(0, Math.floor((q.x - r) / cell)), i1 = Math.min(nx - 1, Math.ceil((q.x + r) / cell));
    const j0 = Math.max(0, Math.floor((q.z - r) / cell)), j1 = Math.min(nz - 1, Math.ceil((q.z + r) / cell));
    for (let j = j0; j <= j1; j++) for (let i = i0; i <= i1; i++) {
      const d = Math.hypot(i * cell - q.x, j * cell - q.z);
      if (d < r) m[j * nx + i] = Math.max(m[j * nx + i], q.wy);
    }
  }
  RIV.mask = m; RIV.maskNX = nx; RIV.maskNZ = nz;
}
// The running surface height at a point, or null if there is no river here.
function riverSurfaceAt(x, z) {
  if (!RIV.mask) return null;
  const cell = RIV.maskCell;
  const i = clamp(Math.round(x / cell), 0, RIV.maskNX - 1);
  const j = clamp(Math.round(z / cell), 0, RIV.maskNZ - 1);
  const v = RIV.mask[j * RIV.maskNX + i];
  return v > 0 ? v : null;
}

// ---- 3. the ribbon ---------------------------------------------------------
function rivBuildMesh() {
  if (!RIV.paths.length) { RIV.count = 0; RIV.built = true; return 0; }
  const HS = terrain.heightScale || 420;
  const verts = [], idx = [];
  let base = 0;
  for (const p of RIV.paths) {
    const pts = p.pts;
    let along = 0;
    for (let i = 0; i < pts.length; i++) {
      const q = pts[i];
      const a = pts[Math.max(0, i - 1)], b = pts[Math.min(pts.length - 1, i + 1)];
      let tx = b.x - a.x, tz = b.z - a.z;
      const tl = Math.hypot(tx, tz) || 1;
      tx /= tl; tz /= tl;
      const px = -tz, pz = tx;                         // across the flow
      if (i > 0) along += Math.hypot(q.x - pts[i - 1].x, q.z - pts[i - 1].z);
      const y = q.wy * HS + 0.6;
      const w = q.w;
      const g = q.grad || 0;
      const dep = Math.min(1, (q.bank || 20) / 140);
      // left and right edge of the water
      verts.push(q.x - px * w, y, q.z - pz * w, -1, along, g, dep, 1);
      verts.push(q.x + px * w, y, q.z + pz * w,  1, along, g, dep, 1);
      // and a centre line, so the surface can bulge and the mesh has interior
      verts.push(q.x, y + 0.5, q.z, 0, along, g, dep, 0);
    }
    for (let i = 0; i < pts.length - 1; i++) {
      const a = base + i * 3, b = base + (i + 1) * 3;
      // left half
      idx.push(a, b, a + 2, a + 2, b, b + 2);
      // right half
      idx.push(a + 2, b + 2, a + 1, a + 1, b + 2, b + 1);
    }
    base += pts.length * 3;
  }
  const vd = new Float32Array(verts), id = new Uint32Array(idx);
  if (RIV.vb) RIV.vb.destroy();
  if (RIV.ib) RIV.ib.destroy();
  RIV.vb = dev.createBuffer({ size: Math.max(16, vd.byteLength), usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST });
  dev.queue.writeBuffer(RIV.vb, 0, vd);
  RIV.ib = dev.createBuffer({ size: Math.max(16, id.byteLength), usage: GPUBufferUsage.INDEX | GPUBufferUsage.COPY_DST });
  dev.queue.writeBuffer(RIV.ib, 0, id);
  RIV.count = id.length;
  RIV.built = true;
  return id.length / 3;
}

const WGSL_RIVER_SRC = `
struct VO { @builtin(position) pos: vec4<f32>, @location(0) wpos: vec3<f32>,
            @location(1) uv: vec2<f32>, @location(2) grad: f32,
            @location(3) dep: f32, @location(4) edge: f32 };
@vertex fn vs(@location(0) p: vec3<f32>, @location(1) u: f32, @location(2) v: f32,
              @location(3) grad: f32, @location(4) dep: f32, @location(5) edge: f32) -> VO {
  var o: VO;
  o.pos = g.viewProj * vec4<f32>(p, 1.0);
  o.wpos = p; o.uv = vec2<f32>(u, v); o.grad = grad; o.dep = dep; o.edge = edge;
  return o;
}
fn rh(p: vec2<f32>) -> f32 { var p3 = fract(vec3<f32>(p.x, p.y, p.x) * 0.1031); p3 += dot(p3, p3.yzx + vec3<f32>(33.33)); return fract((p3.x + p3.y) * p3.z); }
fn rn(p: vec2<f32>) -> f32 {
  let i = floor(p); let f = fract(p); let k = f * f * (3.0 - 2.0 * f);
  return mix(mix(rh(i), rh(i + vec2<f32>(1.0, 0.0)), k.x), mix(rh(i + vec2<f32>(0.0, 1.0)), rh(i + vec2<f32>(1.0, 1.0)), k.x), k.y);
}
@fragment fn fs(i: VO) -> @location(0) vec4<f32> {
  let t = g.params.x;
  let day = g.params.z;
  let L = normalize(g.lightDir.xyz);
  let V = normalize(g.camPos.xyz - i.wpos);
  // Everything scrolls along +v, which is downstream. One direction, always:
  // that is the whole point of a river.
  let speed = 26.0 + i.grad * 130.0;
  let sv = i.uv.y - t * speed;
  let across = i.uv.x;
  // three layers of ripple at different rates so the surface does not read as
  // one sliding texture
  let n1 = rn(vec2<f32>(across * 3.0, sv * 0.055));
  let n2 = rn(vec2<f32>(across * 7.0 + 3.1, sv * 0.13 + 11.0));
  let n3 = rn(vec2<f32>(across * 15.0, sv * 0.31 + 5.0));
  let rip = n1 * 0.5 + n2 * 0.32 + n3 * 0.18;
  // the normal, tilted by the ripple, so the sun glints down the length of it
  let N = normalize(vec3<f32>((rip - 0.5) * 0.55, 1.0, (n2 - 0.5) * 0.35));
  // colour: shallow green at the banks, deeper blue-green down the middle
  let mid = 1.0 - abs(across);
  let shallow = vec3<f32>(0.26, 0.52, 0.45);
  let deep = vec3<f32>(0.06, 0.24, 0.30);
  var col = mix(shallow, deep, clamp(mid * (0.35 + 0.65 * i.dep), 0.0, 1.0));
  col *= 0.35 + 0.65 * day;
  // sky in the surface
  let fres = 0.04 + 0.96 * pow(1.0 - clamp(dot(N, V), 0.0, 1.0), 5.0);
  let sky = mix(vec3<f32>(0.07, 0.09, 0.13), vec3<f32>(0.52, 0.64, 0.76), day);
  col = mix(col, sky, fres * 0.55);
  col += vec3<f32>(1.0, 0.96, 0.88) * pow(max(dot(reflect(-L, N), V), 0.0), 90.0) * 1.3 * day;
  // Whitewater: where the bed steepens, and along the banks where the water
  // drags. Broken into travelling streaks rather than a wash.
  let steep = clamp(i.grad * 2.2, 0.0, 1.0);
  let bank = smoothstep(0.55, 0.98, abs(across));
  let streak = smoothstep(0.52, 0.88, rn(vec2<f32>(across * 5.0, sv * 0.22)) * 0.6 + n3 * 0.5);
  let foam = clamp(steep * streak * 1.5 + bank * streak * 0.8 + steep * 0.35, 0.0, 1.0);
  col = mix(col, vec3<f32>(0.90, 0.94, 0.94) * (0.4 + 0.6 * day), foam);
  let d = distance(i.wpos, g.camPos.xyz);
  let f = clamp(1.0 - exp(-(d * g.params.y) * (d * g.params.y)), 0.0, 1.0);
  col = mix(col, g.fogCol.rgb, f);
  // clear at the edges so the water meets the bank instead of ending at a line
  let a = clamp(0.62 + 0.38 * mid + foam * 0.5, 0.0, 0.97);
  return vec4<f32>(col, mix(a, 1.0, f));
}`;

function rivInit() {
  if (RIV.pipe) return;
  const m = dev.createShaderModule({ code: WGSL_COMMON + WGSL_RIVER_SRC });
  RIV.pipe = dev.createRenderPipeline({
    layout: 'auto',
    vertex: { module: m, entryPoint: 'vs', buffers: [{ arrayStride: RIVER_VF * 4, attributes: [
      { shaderLocation: 0, offset: 0,  format: 'float32x3' },
      { shaderLocation: 1, offset: 12, format: 'float32' },
      { shaderLocation: 2, offset: 16, format: 'float32' },
      { shaderLocation: 3, offset: 20, format: 'float32' },
      { shaderLocation: 4, offset: 24, format: 'float32' },
      { shaderLocation: 5, offset: 28, format: 'float32' }] }] },
    fragment: { module: m, entryPoint: 'fs', targets: [{ format: fmt, blend: {
      color: { srcFactor: 'src-alpha', dstFactor: 'one-minus-src-alpha' },
      alpha: { srcFactor: 'one', dstFactor: 'one-minus-src-alpha' } } }] },
    primitive: { topology: 'triangle-list', cullMode: 'none' },
    depthStencil: { format: 'depth24plus', depthWriteEnabled: false, depthCompare: 'less' },
    multisample: { count: SAMPLES },
  });
  RIV.bind = dev.createBindGroup({ layout: RIV.pipe.getBindGroupLayout(0), entries: [{ binding: 0, resource: { buffer: gBuf } }] });
}
function rivDraw(pass) {
  if (!RIV.count || !RIV.pipe) return;
  pass.setPipeline(RIV.pipe); pass.setBindGroup(0, RIV.bind);
  pass.setVertexBuffer(0, RIV.vb); pass.setIndexBuffer(RIV.ib, 'uint32');
  pass.drawIndexed(RIV.count);
}
