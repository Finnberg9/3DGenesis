# =====================================================================
# THE HORROR PASS: WHAT A MOUTH DOES WHEN IT IS NOT BITING
#
# Reference: xeno sculpts and arthropod horror. What makes those read as
# frightening is almost never polygon count -- it is that the mouth is ALIVE
# when nothing is happening. Saliva hangs off it and breaks. A tongue lolls
# out and drags. There is a second set of jaws further in that you only see
# when the first set opens. Tendrils move on their own around the lips.
#
# All four are geometry on the existing part primitives, driven by the clock
# and the gape the jaw already publishes, so they cost nothing new per frame
# and they animate for free. Every one of them is gated on `!e.lod`, so a
# creature across the valley draws none of it.
#
#   DROOL     strands hanging off the tooth line, swaying on their own phase,
#             stretching and thinning as they go, each ending in a bead --
#             and one bead per mouth falling free on a loop, because saliva
#             that never breaks is a rubber band.
#   TONGUE    a real tongue in segments that lolls further out the wider the
#             gape and drags sideways as it goes.
#   INNER JAW a second, smaller set of jaws deep in the throat that thrusts
#             forward as the mouth closes. Only visible when the mouth is
#             open, which is exactly what makes it land.
#   TENDRILS  cilia at the corners of the mouth, each on its own phase.
#
# Herbivore beaks get none of it. A duck bill with a lolling tongue and an
# inner jaw is a comedy, not a horror.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, ('ANCHOR %d/%d' % (n, cnt), a[:110]); return s.replace(a, b)

p = 'g3.html'; s = open(p, encoding='utf-8').read()

s = sub1(s, "function dinoJawHard(g0, c, e, S) {",
r"""// ---- the wet half of a mouth ------------------------------------------------
const SPIT = [0.74, 0.80, 0.72];        // saliva: pale, cold, slightly green
const SPIT_D = [0.58, 0.64, 0.56];
const GORE = [0.42, 0.06, 0.05];        // the inside of things
// One strand of saliva, hanging and swinging from where it is anchored.
// Thins as it falls and ends in a bead, because a strand of even thickness
// reads as wire.
// Built from cones and balls only. The jaw draws through a wrapper that swaps
// two axes and offers exactly sp/cn/ball, so a helper that reaches for tube()
// works in the palette icon and throws in the game -- which is precisely what
// the first cut of this did.
function droolStrand(g, x, y, z, len, ph, t, r0) {
  let p = [x, y, z];
  const N = 4, R = r0 || 0.036;
  for (let i = 0; i < N; i++) {
    const u = (i + 1) / N;
    // the swing grows toward the free end, which is what makes it hang
    const sx = Math.sin(t * 1.6 + ph + u * 2.4) * 0.09 * u;
    const sz = Math.cos(t * 1.27 + ph * 1.7 + u * 2.0) * 0.07 * u;
    const q = [p[0] + sx * 0.4, p[1] - len / N, p[2] + sz * 0.4];
    const d = v3.sub(q, p), L = v3.len(d) || 1e-4, dn = v3.mul(d, 1 / L);
    g.cn(p[0], p[1], p[2], dn[0], dn[1], dn[2], R * (1 - 0.5 * (u - 1 / N)), L * 1.06,
         u > 0.6 ? SPIT_D : SPIT);
    p = q;
  }
  g.ball(p[0], p[1], p[2], R * 1.7, SPIT);
}
// Saliva across a mouth: a few strands on their own phases, plus one bead
// that has already broken off and is falling. Saliva that never parts is a
// rubber band, and the eye notices.
function drool(g, e, x, y, halfW, n, len, seed) {
  if (e.lod) return;
  const t = e.t;
  for (let i = 0; i < n; i++) {
    const f = n === 1 ? 0 : (i / (n - 1)) * 2 - 1;
    const ph = seed + i * 2.399;
    // each strand runs its own slow stretch-and-snap cycle
    const cyc = (t * 0.33 + i * 0.41 + seed * 0.11) % 1;
    const grow = cyc < 0.82 ? 0.35 + cyc * 1.0 : 0.15;         // snaps back short
    droolStrand(g, x, y, f * halfW, len * grow, ph, t, 0.034);
  }
  // the bead that let go, falling and repeating
  const d = (t * 0.55 + seed * 0.37) % 1;
  g.ball(x + 0.05, y - len * (0.4 + d * 1.5), (seed % 1 - 0.5) * halfW * 1.2, 0.05 * (1 - d * 0.35), SPIT);
}
// A tongue that lolls: segments, drooping further and dragging sideways the
// wider the mouth is open.
function lollTongue(g, e, x0, y0, len, wide, open) {
  const t = e.t, out = 0.25 + open * 1.25;
  let p = [x0, y0, 0];
  const N = 5;
  for (let i = 0; i < N; i++) {
    const u = (i + 1) / N;
    const drag = Math.sin(t * 1.1 + e.seed + u * 1.6) * 0.16 * u * out;
    const q = [p[0] + (len * out) / N, p[1] - u * u * 0.30 * out, p[2] + drag * 0.5];
    const d = v3.sub(q, p), L = v3.len(d) || 1e-4, dn = v3.mul(d, 1 / L);
    const m = v3.mul(v3.add(p, q), 0.5), w = wide * (1 - 0.32 * u);
    g.sp(m[0], m[1], m[2], dn[0], dn[1], dn[2], w, L * 0.58, w * 1.25,
         i > 2 ? colMul(TONGUE, 0.82) : TONGUE);
    p = q;
  }
  g.sp(p[0], p[1], p[2], 1, 0, 0, wide * 0.5, wide * 0.55, wide * 0.7, colMul(TONGUE, 0.7));
  // and it is wet
  if (!e.lod && open > 0.25) droolStrand(g, p[0], p[1] - wide * 0.4, p[2], 0.34 * open, e.seed * 3.1, t, 0.028);
}
// A second set of jaws, further in. It thrusts forward as the first set
// closes, so a bite reads as two bites.
function innerJaw(g, e, x0, y0, scale, open) {
  if (e.lod) return;
  const push = (0.22 + e.chomp * 0.9) * scale;
  const x = x0 + push, gap = (0.06 + open * 0.10) * scale;
  const s = scale;
  g.sp(x, y0 + gap, 0, 1, 0.1, 0, 0.16 * s, 0.11 * s, 0.20 * s, colMul(GORE, 1.35));
  g.sp(x, y0 - gap, 0, 1, -0.1, 0, 0.15 * s, 0.10 * s, 0.19 * s, colMul(GORE, 1.15));
  for (let i = 0; i < 3; i++) {
    const z = (i - 1) * 0.10 * s;
    g.cn(x + 0.10 * s, y0 + gap * 0.4, z, 1, -0.5, 0, 0.022 * s, 0.11 * s, IVORY);
    g.cn(x + 0.10 * s, y0 - gap * 0.4, z, 1, 0.5, 0, 0.020 * s, 0.10 * s, IVORY);
  }
}
// Cilia round the lips, each on its own phase so they never move as a block.
function lipTendrils(g, e, x0, y0, halfW, n, len, back) {
  if (e.lod) return;
  for (let i = 0; i < n; i++) {
    for (const sg of [1, -1]) {
      const u = n === 1 ? 0.5 : i / (n - 1);
      const ph = e.seed * 2.1 + i * 1.7 + (sg > 0 ? 0 : 0.9);
      let p = [x0 - u * back, y0, sg * halfW * (0.7 + u * 0.35)];
      let d = [-0.25, -0.75, sg * 0.4];
      const N = 3, L = len * (0.7 + 0.5 * (1 - u));
      for (let k = 0; k < N; k++) {
        const w = Math.sin(e.t * 1.9 + ph + k * 0.8) * 0.20;
        d = v3.norm([d[0] - 0.12 + w * 0.3, d[1] - 0.10, d[2] + w * sg * 0.5]);
        const q = v3.add(p, v3.mul(d, L / N));
        g.cn(p[0], p[1], p[2], d[0], d[1], d[2], 0.032 * (1 - k * 0.22), (L / N) * 1.08, colMul(GORE, 1.5 + k * 0.2));
        p = q;
      }
    }
  }
}

function dinoJawHard(g0, c, e, S) {""")

# ---- wire it into the hard jaws --------------------------------------------
s = sub1(s, """  // tongue along the floor of the mouth
  j.sp(0.1, 0.24, 0, 0.1, 1, 0, 0.16, 0.5, S.wide * 0.5, TONGUE);""",
"""  // The wet half. A grinding beak gets none of it: a duck bill with an inner
  // jaw and a lolling tongue is a comedy, not a horror.
  const horror = !S.grind && !S.beak;
  if (horror) {
    lollTongue(j, e, -0.05, 0.26, S.len * 0.62, S.wide * 0.30, open);
    innerJaw(g, e, -0.20, 0.34, 0.9 + S.wide, open);
    drool(g, e, S.len * 0.34, 0.30 - S.curve * 0.4, S.wide * 0.72, 3, 0.55 + open * 0.5, (e.seed || 0) + S.len);
    lipTendrils(g, e, S.len * 0.20, 0.30, S.wide * 0.88, 3, 0.42, S.len * 0.45);
  } else {
    // tongue along the floor of the mouth
    j.sp(0.1, 0.24, 0, 0.1, 1, 0, 0.16, 0.5, S.wide * 0.5, TONGUE);
  }""")

# ---- and into the two hand-built carnivore mouths ---------------------------
s = sub1(s, """    for (const s of [1, -1]) g.cn(-0.34 - o * 0.5, 0.62, s * 0.62, 1, 0.2, 0, 0.1, 0.5, IVORY);
  } },""",
"""    for (const s of [1, -1]) g.cn(-0.34 - o * 0.5, 0.62, s * 0.62, 1, 0.2, 0, 0.1, 0.5, IVORY);
    lollTongue(g, e, -0.1, 0.30, 0.66, 0.16, o);
    innerJaw(g, e, -0.24, 0.34, 1.0, o);
    drool(g, e, 0.24, 0.40, 0.55, 3, 0.52 + o * 0.6, (e.seed || 0) + 1.7);
    lipTendrils(g, e, 0.18, 0.36, 0.62, 2, 0.34, 0.5);
  } },""")
s = sub1(s, """    for (let i = 0; i < 4; i++) {
      const z = (i - 1.5) * 0.28, y = 0.52 + (1.5 - Math.abs(i - 1.5)) * 0.06;
      g.cn(-0.28 - o * 0.5, y, z, 1, 0.1, 0, 0.07, 0.26, IVORY);
    }
  } },""",
"""    for (let i = 0; i < 4; i++) {
      const z = (i - 1.5) * 0.28, y = 0.52 + (1.5 - Math.abs(i - 1.5)) * 0.06;
      g.cn(-0.28 - o * 0.5, y, z, 1, 0.1, 0, 0.07, 0.26, IVORY);
    }
    drool(g, e, 0.18, 0.40, 0.42, 2, 0.40 + o * 0.5, (e.seed || 0) + 0.9);
    lipTendrils(g, e, 0.14, 0.34, 0.48, 2, 0.26, 0.4);
  } },""")

open(p, 'w', encoding='utf-8').write(s)
print('horror: mouths ok')
