// =====================================================================
// START SCREEN: no box. Text drifts down into place over a dark, layered
// rainforest silhouette with drifting mist, and now and then a pair of eyes
// opens in the undergrowth, blinks, and follows your cursor. Clicking goes
// straight into the creature builder; finishing the design starts the game.
// =====================================================================
const SS = { cv: null, g: null, layers: null, eyes: [], nextEye: 1.5, mx: 0.5, my: 0.5, t: 0, raf: 0, w: 0, h: 0, dpr: 1 };
function ssRng(seed) { let s = seed >>> 0; return () => { s = (s + 0x6D2B79F5) >>> 0; let t = s; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
// one silhouette layer: trunks, lianas, fronds and a band of undergrowth
function ssLayer(W, H, depth, col, seed) {
  const cv = document.createElement('canvas'); cv.width = W; cv.height = H;
  const g = cv.getContext('2d'); const r = ssRng(seed);
  g.fillStyle = col; g.strokeStyle = col;
  const nT = Math.round(5 + depth * 7);
  for (let i = 0; i < nT; i++) {                                // trunks, leaning a little
    const x = r() * W, w = (6 + r() * 16) * (0.5 + depth) * (W / 1600), lean = (r() - 0.5) * 60 * depth;
    g.beginPath(); g.moveTo(x - w * 1.8, H); g.quadraticCurveTo(x - w * 0.6, H * 0.8, x - w * 0.5 + lean * 0.3, H * 0.55);
    g.lineTo(x - w * 0.35 + lean, -10); g.lineTo(x + w * 0.35 + lean, -10); g.lineTo(x + w * 0.5 + lean * 0.3, H * 0.55);
    g.quadraticCurveTo(x + w * 0.6, H * 0.8, x + w * 1.8, H); g.closePath(); g.fill();
    // buttress flares
    for (let b = 0; b < 2; b++) { const s = b ? 1 : -1; g.beginPath(); g.moveTo(x, H * 0.72); g.quadraticCurveTo(x + s * w * 1.2, H * 0.88, x + s * w * 3.2, H); g.lineTo(x + s * w * 0.4, H); g.fill(); }
  }
  g.lineWidth = Math.max(1, 1.6 * depth * (W / 1600));
  for (let i = 0; i < nT * 2; i++) {                            // hanging lianas
    const x = r() * W, len = H * (0.25 + r() * 0.5 * depth);
    g.beginPath(); g.moveTo(x, -5); g.bezierCurveTo(x + (r() - 0.5) * 80, len * 0.4, x + (r() - 0.5) * 80, len * 0.8, x + (r() - 0.5) * 40, len); g.stroke();
  }
  const frond = (x, y, len, ang, droop) => {                   // palm / fern frond
    g.beginPath();
    const n = 14;
    const pts = [];
    for (let k = 0; k <= n; k++) { const u = k / n; const a = ang + droop * u * u; pts.push([x + Math.cos(a) * len * u, y + Math.sin(a) * len * u]); }
    for (let k = 1; k < n; k++) {
      const [px, py] = pts[k], u = k / n, lw = len * 0.2 * Math.sin(u * Math.PI);
      const a = Math.atan2(pts[k + 1][1] - py, pts[k + 1][0] - px);
      for (const s of [-1, 1]) {
        g.moveTo(px, py); g.lineTo(px + Math.cos(a + s * 1.1) * lw, py + Math.sin(a + s * 1.1) * lw + lw * 0.4);
        g.lineTo(pts[k + 1][0], pts[k + 1][1]);
      }
    }
    g.fill();
    g.beginPath(); g.moveTo(x, y); for (const p of pts) g.lineTo(p[0], p[1]); g.stroke();
  };
  const nF = Math.round(4 + depth * 8);
  for (let i = 0; i < nF; i++) {                                // fronds bursting from the undergrowth
    const x = r() * W, y = H * (0.62 + r() * 0.3), n = 4 + (r() * 4 | 0);
    for (let k = 0; k < n; k++) frond(x, y, (60 + r() * 110) * (0.6 + depth) * (W / 1600), -Math.PI / 2 + (k / (n - 1) - 0.5) * 2.4, (k / (n - 1) - 0.5) * 1.6);
  }
  const base = H * (0.78 - depth * 0.1);                        // lumpy undergrowth band
  g.beginPath(); g.moveTo(0, H);
  for (let x = 0; x <= W + 40; x += 30) {
    const y = base - (Math.sin(x * 0.013 + seed) * 0.5 + 0.5) * 50 * (0.5 + depth) - r() * 40 * depth;
    g.quadraticCurveTo(x - 15, y - 30 * r(), x, y);
  }
  g.lineTo(W, H); g.closePath(); g.fill();
  return cv;
}
function ssBuild() {
  const cv = SS.cv; if (!cv) return;
  SS.dpr = Math.min(window.devicePixelRatio || 1, 2);
  const W = Math.max(2, Math.floor(cv.clientWidth * SS.dpr)), H = Math.max(2, Math.floor(cv.clientHeight * SS.dpr));
  if (W === SS.w && H === SS.h && SS.layers) return;
  cv.width = W; cv.height = H; SS.w = W; SS.h = H;
  SS.layers = [
    { cv: ssLayer(W, H, 0.15, '#0b1a17', 11), sway: 0.3 },
    { cv: ssLayer(W, H, 0.45, '#07120f', 23), sway: 0.7 },
    { cv: ssLayer(W, H, 0.75, '#040a08', 37), sway: 1.2 },
    { cv: ssLayer(W, H, 1.0, '#010302', 51), sway: 2.0 },
  ];
}
function ssSpawnEye() {
  const r = Math.random;
  const near = r() < 0.4;
  const size = (near ? 5 + r() * 5 : 2.5 + r() * 3) * SS.dpr;
  const palette = [[255, 190, 60], [210, 255, 90], [255, 70, 40], [120, 255, 200]];
  const c = palette[(r() * palette.length) | 0];
  SS.eyes.push({
    x: (0.06 + r() * 0.88) * SS.w, y: (0.55 + r() * 0.33) * SS.h,
    s: size, gap: size * (2.6 + r() * 1.4), col: c, slit: r() < 0.5,
    t0: SS.t, life: 3 + r() * 4, blinkAt: SS.t + 0.8 + r() * 1.5, layer: near ? 2 : 1,
  });
}
function ssDrawEyes(g, layer) {
  for (const e of SS.eyes) {
    if (e.layer !== layer) continue;
    const age = SS.t - e.t0;
    const fade = Math.min(1, age / 0.7, (e.life - age) / 0.6);
    if (fade <= 0) continue;
    // blinking: the lids close for ~0.15 s
    let open = 1;
    const bt = SS.t - e.blinkAt;
    if (bt > 0 && bt < 0.16) open = Math.abs(bt - 0.08) / 0.08;
    if (bt >= 0.16) e.blinkAt = SS.t + 1.2 + Math.random() * 2.2;
    // pupils turn toward the cursor
    const lx = (SS.mx * SS.w - e.x), ly = (SS.my * SS.h - e.y), ll = Math.hypot(lx, ly) || 1;
    for (const s of [-1, 1]) {
      const cx = e.x + s * e.gap * 0.5, cy = e.y;
      g.save(); g.translate(cx, cy); g.scale(1, Math.max(0.06, open) * 0.62);
      const grd = g.createRadialGradient(0, 0, 0, 0, 0, e.s * 3);
      grd.addColorStop(0, `rgba(${e.col[0]},${e.col[1]},${e.col[2]},${0.35 * fade})`); grd.addColorStop(1, 'rgba(0,0,0,0)');
      g.fillStyle = grd; g.beginPath(); g.arc(0, 0, e.s * 3, 0, 6.283); g.fill();
      g.fillStyle = `rgba(${e.col[0]},${e.col[1]},${e.col[2]},${0.95 * fade})`;
      g.beginPath(); g.arc(0, 0, e.s, 0, 6.283); g.fill();
      g.fillStyle = `rgba(0,0,0,${fade})`;
      const px = lx / ll * e.s * 0.35, py = ly / ll * e.s * 0.35;
      g.beginPath();
      if (e.slit) g.ellipse(px, py, e.s * 0.18, e.s * 0.85, 0, 0, 6.283); else g.arc(px, py, e.s * 0.45, 0, 6.283);
      g.fill();
      g.restore();
    }
  }
}
function ssFrame(now) {
  const st = document.getElementById('start');
  if (!st || st.style.display === 'none' || !SS.cv) { SS.raf = 0; return; }
  SS.raf = requestAnimationFrame(ssFrame);
  const t = now / 1000, dt = Math.min(0.05, t - (SS.t || t)); SS.t = t;
  ssBuild();
  const g = SS.g, W = SS.w, H = SS.h;
  // sky: near-black green with a faint moon glow high up
  const sky = g.createLinearGradient(0, 0, 0, H);
  sky.addColorStop(0, '#0a1714'); sky.addColorStop(0.55, '#06100d'); sky.addColorStop(1, '#010303');
  g.fillStyle = sky; g.fillRect(0, 0, W, H);
  const moon = g.createRadialGradient(W * 0.72, H * 0.12, 0, W * 0.72, H * 0.12, H * 0.5);
  moon.addColorStop(0, 'rgba(150,190,170,0.16)'); moon.addColorStop(1, 'rgba(0,0,0,0)');
  g.fillStyle = moon; g.fillRect(0, 0, W, H);
  SS.eyes = SS.eyes.filter(e => SS.t - e.t0 < e.life);
  if (SS.t > SS.nextEye) { ssSpawnEye(); SS.nextEye = SS.t + 1.4 + Math.random() * 3.2; }
  for (let i = 0; i < SS.layers.length; i++) {
    const L = SS.layers[i];
    const dx = Math.sin(t * 0.35 + i) * L.sway * SS.dpr + (SS.mx - 0.5) * -10 * i * SS.dpr;
    g.drawImage(L.cv, dx, 0);
    // mist between layers, drifting
    const mist = g.createLinearGradient(0, H * 0.5, 0, H);
    const a = 0.05 + 0.03 * Math.sin(t * 0.2 + i * 1.7);
    mist.addColorStop(0, 'rgba(60,90,80,0)'); mist.addColorStop(0.6, `rgba(60,90,80,${a})`); mist.addColorStop(1, 'rgba(60,90,80,0)');
    g.fillStyle = mist; g.fillRect(0, 0, W, H);
    if (i === 1 || i === 2) ssDrawEyes(g, i);
  }
  void dt;
}
function ssInit() {
  SS.cv = document.getElementById('startbg');
  if (!SS.cv) return;
  SS.g = SS.cv.getContext('2d');
  addEventListener('mousemove', (e) => { SS.mx = e.clientX / Math.max(1, innerWidth); SS.my = e.clientY / Math.max(1, innerHeight); });
  addEventListener('resize', () => { SS.w = 0; });
  // text drifts down into place, line by line
  const items = document.querySelectorAll('#start .fl');
  items.forEach((el, i) => { el.style.animationDelay = (0.25 + i * 0.09).toFixed(2) + 's'; });
  if (!SS.raf) SS.raf = requestAnimationFrame(ssFrame);
}
function ssShow() { const st = document.getElementById('start'); if (st) { st.style.display = 'flex'; if (!SS.raf) SS.raf = requestAnimationFrame(ssFrame); } }

// ---------------------------------------------------------------- reset world
let resetArm = 0;
function resetWorldClick() {
  const b = document.getElementById('resetbtn');
  const now = performance.now();
  if (now > resetArm) {                       // first click arms it: no browser dialogs
    resetArm = now + 3000;
    if (b) { b.textContent = 'Click again to reset'; b.classList.add('armed'); }
    setTimeout(() => { if (performance.now() > resetArm && b) { b.textContent = 'Reset World'; b.classList.remove('armed'); } }, 3100);
    return;
  }
  resetArm = 0;
  if (b) { b.textContent = 'Reset World'; b.classList.remove('armed'); }
  REMAINS.length = 0; FIGHT.blood.length = 0; FIGHT.splatN = 0; FIGHT.splats.fill(undefined);
  const keep = started && PROG.last ? C.cloneDesign(PROG.last) : null;
  Promise.resolve(rebuildWorld()).then(() => { if (keep) { try { becomeDesigned(keep); } catch (e) { console.warn(e); } } });
}

// ---------------------------------------------------------------- death screen
function showDeath(dead) {
  const el = document.getElementById('deathfx');
  if (!el) return;
  const cause = dead ? dead.deathCause : '';
  const why = cause === 'drowned' ? 'You drowned.' : cause === 'predation' ? 'You were killed.' :
              cause === 'oldage' ? 'You died of old age.' : cause === 'toxin' ? 'You were poisoned.' :
              cause === 'starvation' ? 'You starved.' : '';
  const sub = el.querySelector('.sub'); if (sub) sub.textContent = why + ' Your line continues in your nearest kin.';
  showDeath.t0 = performance.now();
  deathTick();
  if (SND.ctx && SND.on) { sndThump(0.6); setTimeout(() => sndThump(0.4), 380); }
}
// driven from the frame loop (and a timer fallback) so it never depends on CSS animation timing
function deathTick() {
  const el = document.getElementById('deathfx');
  if (!el || showDeath.t0 == null) return;
  const k = (performance.now() - showDeath.t0) / 4200;
  if (k >= 1) { el.style.opacity = '0'; el.style.visibility = 'hidden'; showDeath.t0 = null; return; }
  const a = k < 0.14 ? k / 0.14 : k > 0.78 ? (1 - k) / 0.22 : 1;
  el.style.visibility = 'visible'; el.style.opacity = a.toFixed(3);
  const big = el.querySelector('.big'); if (big) big.style.transform = 'scale(' + (1.18 - 0.18 * Math.min(1, k * 1.3)).toFixed(3) + ')';
  clearTimeout(deathTick._t); deathTick._t = setTimeout(deathTick, 50);
}
