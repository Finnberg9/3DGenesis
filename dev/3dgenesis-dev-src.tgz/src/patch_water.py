# THE UNDERWATER WORLD
#  - no tree grows in water (the biome map calls the tidal fringe shallow/marsh,
#    which used to put mangroves and palms out in the sea)
#  - underwater light: per-channel absorption along the wet part of the view
#    ray, sunlight falling off with depth, and caustics on the sea floor
#  - the water surface seen from below: Snell's window and a rippling ceiling
#  - sea-floor flora: kelp, sea grass, coral heads, sea fans, shells and urchins
#  - shoals of small fish, and the bubbles a diver trails
# See src/seafloor.js and src/sealife.js.
def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
p='g3.html'; s=open(p,encoding='utf-8').read()

# ---------------------------------------------------------------- no trees in water
s=sub1(s,"""      const b = terrain.biomeAt(x, y);
      let dens = (FOREST_DENS[b] || 0) * density;
      if (!dens) continue;""","""      const b = terrain.biomeAt(x, y);
      // Nothing with a trunk grows in water. The biome map calls the tidal
      // fringe 'shallow' and 'marsh', so biome alone put mangroves and palms
      // out in the sea; the height against the water line is what decides.
      if (terrain.height(x, y) <= terrain.LV.water + 0.0015) continue;
      let dens = (FOREST_DENS[b] || 0) * density;
      if (!dens) continue;""")
s=sub1(s,"""                        desert: 0.03, tundra: 0.04, rock: 0.02, scree: 0, snow: 0, shallow: 0.05, deep: 0 };""",
         """                        desert: 0.03, tundra: 0.04, rock: 0.02, scree: 0, snow: 0, shallow: 0.03, deep: 0 };""")

# ---------------------------------------------------------------- underwater light
s=sub1(s,"""fn shade(col: vec3<f32>, nrm: vec3<f32>, wpos: vec3<f32>) -> vec3<f32> {""",
"""// Caustics. Two ripple fields crossing at an angle; where their crests
// coincide the surface acts as a lens and focuses the sun into the bright
// moving filaments you see on a sea floor. A third, slower field breaks up the
// regularity so it does not read as a grid.
fn caustic(p: vec2<f32>, t: f32) -> f32 {
  let a = sin(p.x * 0.085 + t * 0.85) + sin(p.y * 0.097 - t * 0.66);
  let b = sin((p.x + p.y) * 0.061 + t * 1.10) + sin((p.x - p.y) * 0.073 - t * 0.81);
  let c = sin(p.x * 0.029 - t * 0.47) + sin(p.y * 0.026 + t * 0.55);
  let v = abs(a) * abs(b) * 0.25 * (0.55 + 0.45 * abs(c) * 0.5);
  return pow(clamp(v, 0.0, 1.0), 3.5);
}
// Per-unit extinction. Water eats red first: red is gone in about 60 units,
// green carries 170 and blue 250, which is why everything deep goes blue.
const WATER_EXT = vec3<f32>(0.0168, 0.0058, 0.0040);
fn waterMurk(day: f32, depth: f32) -> vec3<f32> {
  return mix(vec3<f32>(0.016, 0.052, 0.062), vec3<f32>(0.052, 0.150, 0.165), day) * exp(-depth * 0.006);
}
fn shade(col: vec3<f32>, nrm: vec3<f32>, wpos: vec3<f32>) -> vec3<f32> {""")

s=sub1(s,"""  let d = distance(wpos, g.camPos.xyz);
  let f = clamp(1.0 - exp(-(d * g.params.y) * (d * g.params.y)), 0.0, 1.0);
  return mix(lit, g.fogCol.rgb, f);
}""","""  let d = distance(wpos, g.camPos.xyz);
  // ---- water ---------------------------------------------------------------
  // Only the stretch of the view ray that actually runs through water absorbs,
  // so a fish seen from the bank greens out with its own depth rather than with
  // how far off it is, and the air fog is charged only for the dry stretch.
  var uw = 0.0;
  if (g.camPos.w < 0.5) {
    let seaY = g.params.w;
    let camUW = g.camPos.y < seaY;
    let ptUW = wpos.y < seaY;
    if (camUW && ptUW) {
      uw = d;
    } else if (ptUW) {
      uw = d * clamp((seaY - wpos.y) / max(1e-3, g.camPos.y - wpos.y), 0.0, 1.0);
    } else if (camUW) {
      uw = d * clamp((seaY - g.camPos.y) / max(1e-3, wpos.y - g.camPos.y), 0.0, 1.0);
    }
    if (ptUW) {
      // the sun is spent on the way down, so the floor darkens with depth
      let shaft = exp(-(seaY - wpos.y) * 0.0075);
      lit *= 0.15 + 0.85 * shaft;
      // and what is left of it dances on anything facing up
      lit += sunCol * caustic(wpos.xz, g.params.x) * clamp(N.y, 0.0, 1.0) * day * shaft * shd * 0.6;
    }
    if (uw > 0.0) {
      let trans = exp(-uw * WATER_EXT);
      let murk = waterMurk(day, max(0.0, seaY - min(g.camPos.y, wpos.y)));
      lit = lit * trans + murk * (vec3<f32>(1.0) - trans);
    }
  }
  let dAir = max(0.0, d - uw);
  let f = clamp(1.0 - exp(-(dAir * g.params.y) * (dAir * g.params.y)), 0.0, 1.0);
  return mix(lit, g.fogCol.rgb, f);
}""")

# ---------------------------------------------------------------- the surface from below
s=sub1(s,"""  // waves: several travelling ripples, calmer in the shallows
  let calm = clamp(depth / 25.0, 0.25, 1.0);""",
"""  // Seen from below the surface is a mirror everywhere except a bright disc
  // straight overhead: past about 48 degrees light coming from the sky is
  // totally internally reflected. That disc is Snell's window, and the ripples
  // make its edge crawl.
  if (g.camPos.y < sea) {
    let up = clamp(-V.y, 0.0, 1.0);
    let rip = (wnoise(i.wpos.xz * 0.07 + vec2<f32>(t * 0.45, t * -0.30)) - 0.5)
            + (wnoise(i.wpos.xz * 0.19 - vec2<f32>(t * 0.30, t * 0.50)) - 0.5) * 0.5;
    let win = smoothstep(0.46, 0.86, up + rip * 0.24);
    let sky = mix(vec3<f32>(0.05, 0.08, 0.12), vec3<f32>(0.66, 0.78, 0.90), day);
    let below = mix(vec3<f32>(0.020, 0.060, 0.070), vec3<f32>(0.090, 0.215, 0.235), day);
    var uwl = mix(below, sky, win);
    // the sun burning through, smeared along the ripples
    let sunUp = clamp(dot(normalize(vec3<f32>(L.x, abs(L.y), L.z)),
                          normalize(vec3<f32>(-V.x, abs(V.y), -V.z))), 0.0, 1.0);
    uwl += vec3<f32>(1.0, 0.95, 0.84) * pow(sunUp, 22.0) * day * win * 1.5;
    uwl += vec3<f32>(0.8, 0.9, 1.0) * smoothstep(0.55, 0.95, abs(rip) * 2.0) * win * day * 0.18;
    // the water between the eye and the ceiling absorbs like anything else
    let tr = exp(-dist * vec3<f32>(0.0168, 0.0058, 0.0040));
    let far = mix(vec3<f32>(0.016, 0.052, 0.062), vec3<f32>(0.052, 0.150, 0.165), day);
    uwl = uwl * tr + far * (vec3<f32>(1.0) - tr);
    return vec4<f32>(uwl, 0.97);
  }
  // waves: several travelling ripples, calmer in the shallows
  let calm = clamp(depth / 25.0, 0.25, 1.0);""")

# ---------------------------------------------------------------- sea-floor flora
s=sub1(s,"function folInit() {\n",
        open('src/seafloor.js',encoding='utf-8').read()+"\n"+open('src/sealife.js',encoding='utf-8').read()+"\nfunction folInit() {\n")
s=sub1(s,"const TREE_VARIANTS = 3, COVER_KINDS = 9, COVER_VARIANTS = 2;",
         "const TREE_VARIANTS = 3, COVER_KINDS = 14, COVER_VARIANTS = 2;")
s=sub1(s,"  for (let k = 0; k < COVER_KINDS; k++) { FOL.cover[k] = []; for (let v = 0; v < COVER_VARIANTS; v++) FOL.cover[k][v] = folUpload(k >= 6 ? buildRockCover(k, v) : buildCoverMesh(k, v)); }",
         "  for (let k = 0; k < COVER_KINDS; k++) { FOL.cover[k] = []; for (let v = 0; v < COVER_VARIANTS; v++) FOL.cover[k][v] = folUpload(k >= 9 ? buildSeaCover(k, v) : k >= 6 ? buildRockCover(k, v) : buildCoverMesh(k, v)); }")
# placement: underwater cells get sea cover instead of being skipped
s=sub1(s,"""    const e = T.height(x, z);
    if (e < T.LV.water - 0.004 && T.biomeAt(x, z) !== 'shallow' && T.biomeAt(x, z) !== 'marsh') continue;
    const opts = COVER_BY_BIOME[T.biomeAt(x, z)];
    if (!opts) continue;""","""    const e = T.height(x, z);
    const gy = groundAt(x, z);
    let opts;
    if (e < T.LV.water) {
      // under water the sea floor has its own flora, by depth and by warmth
      opts = seaCoverAt(x, z, T.LV.water * HEIGHT_SCALE - gy);
    } else {
      opts = COVER_BY_BIOME[T.biomeAt(x, z)];
    }
    if (!opts) continue;""")
s=sub1(s,"    put(g, x, groundAt(x, z) - 0.3, z, ((h >>> 3) & 255) / 40, s, [1, 1, 1]);",
         "    put(g, x, gy - 0.3, z, ((h >>> 3) & 255) / 40, s, [1, 1, 1]);")
# kelp is tall: keep it out of water it would stick out of
s=sub1(s,"""    const g = FOL.cover[kind][(h >>> 26) & 1];
    const s = 0.7 + ((h >>> 20) & 63) / 70;""","""    const g = FOL.cover[kind][(h >>> 26) & 1];
    let s = 0.7 + ((h >>> 20) & 63) / 70;
    if (kind === SEA_KIND_KELP) {
      // a kelp bed should not poke out of the sea: shrink it to the water column
      const room = T.LV.water * HEIGHT_SCALE - gy;
      s = Math.min(s, room / 105);
      if (s < 0.28) continue;
    }""")

# ---------------------------------------------------------------- shoals and bubbles
s=sub1(s,"""  if (plantCount) dev.queue.writeBuffer(plantVB, 0, plantData, 0, plantCount * INST_FLOATS);""",
"""  try { seaLifeInstances(camX, player.camY, camZ, t); } catch (e) { console.warn(e); }
  if (plantCount) dev.queue.writeBuffer(plantVB, 0, plantData, 0, plantCount * INST_FLOATS);""")
s=sub1(s,"""  objReset();
  toast('New world, seed ' + seed + '. You are a newborn again.', 3600);""",
"""  objReset();
  seaLifeReset();
  toast('New world, seed ' + seed + '. You are a newborn again.', 3600);""")
# ---------------------------------------------------------------- test surface
# The headless harness could build a creature but had no way to leave the menu,
# so every automated screenshot was of the main menu. Expose the two calls it
# needs, plus the sea-life state, so a run can actually get into the water.
s=sub1(s,"""  rebuild: () => rebuildWorld(),""","""  rebuild: () => rebuildWorld(),
  beginPlay: () => menuStart(),
  get sea() { return SEA; },
  get seaShoals() { return SEA.shoals.length; },
  get seaBubbles() { return SEA.bub.length; },
  get folCount() { return FOL.count; },""")
open(p,'w',encoding='utf-8').write(s)
print('water ok')
