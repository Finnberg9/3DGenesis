# =====================================================================
# FOOD IS GONE
#
# Hunger was a second fight the player never asked for, running underneath
# the one they did: you could win an exchange and still lose the match to a
# bar you were not looking at. It is out.
#
#   * Nothing edible. No eat key, no food prompt, no bites, no reach check on
#     a bush, no carrion meal, no poison, no illness.
#   * You do not starve. The player's body no longer spends energy at all, so
#     the only number that can kill you is the one a fight moves.
#   * The island's own metabolism is left alone. Wildlife in free roam still
#     eats, grows and dies the way it always did -- that is the campaign's
#     ecosystem, and a match has no wildlife in it to care.
#
# What replaces food is in patch_shroom.py: mushrooms you pick up and spend.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, ('ANCHOR %d/%d' % (n, cnt), a[:110]); return s.replace(a, b)

p = 'g3.html'; s = open(p, encoding='utf-8').read()

# ---------------------------------------------------------------- 1. the player never starves
# The player's body is a fighter, not an animal on a food budget. Zeroing the
# drain at the one place the player's own step applies it is enough: the core
# still charges every other creature normally.
s = sub1(s, """      if (c.energy <= 0 || c.age >= c.maxAge) {""",
"""      // The body the player is steering does not run on food any more. Held
      // full rather than exempted from the loop, so every other rule that
      // reads energy (mating, the brain's own inputs) still gets a number.
      if (world.playerRef === c && p.storage) c.energy = p.storage;
      if (c.energy <= 0 || c.age >= c.maxAge) {""")

# ---------------------------------------------------------------- 2. no eating
# tryEat and eatPrompt stay as names because the key binding and the action
# panel both call them; they just have nothing to offer any more. The scan,
# the bite, the carrion and the poison paths below them are now dead code that
# nothing reaches, and they go with the food art next.
s = sub1(s, """function tryEat() {
  const c = player.c;
  if (!c || !c.alive || player.spectator) return { ok: false, why: 'nobody' };""",
"""function tryEat() {
  // There is no food. The key is kept bound because it is the pick-up key
  // now (see the mushrooms), and this is what it answers when there is
  // nothing under your nose.
  return { ok: false, why: 'nofood', msg: 'There is nothing to eat. Fight.' };
}
function tryEatLegacy() {
  const c = player.c;
  if (!c || !c.alive || player.spectator) return { ok: false, why: 'nobody' };""")
s = sub1(s, """function eatPrompt() {
  const c = player.c;
  if (!c || !c.alive || player.spectator) return null;""",
"""function eatPrompt() { return null; }
function eatPromptLegacy() {
  const c = player.c;
  if (!c || !c.alive || player.spectator) return null;""")

# ---------------------------------------------------------------- 3. no illness
# Sickness only ever came from something you swallowed, so with nothing to
# swallow it can only be a stale flag left on a body. Cleared, permanently.
s = sub1(s, """function sickTick(dt) {""",
"""function sickTick(dt) {
  // Nothing can make you ill any more: the only sources were poison and rot.
  // Held at zero rather than deleted so the vignette, the stamina multiplier
  // and the HUD line all keep reading a real number.
  if (SICK.t !== 0 || SICK.sev !== 0) { SICK.t = 0; SICK.sev = 0; SICK.dur = 0; SICK.src = ''; SICK.msgT = 0; }
  sickFxTick(dt);
  return;
}
function sickTickLegacy(dt) {""")
# the vignette fade is the one part of sickTick that still has a job
s = sub1(s, """  const want = SICK.t > 0 ? clamp(0.20 + 0.45 * SICK.sev, 0, 0.72) * (0.84 + 0.16 * Math.sin(simT * 2.1)) : 0;
  SICK.fx += (want - SICK.fx) * Math.min(1, Math.max(0, dt) * 3);
  if (el) el.style.opacity = SICK.fx.toFixed(3);""",
"""  const want = SICK.t > 0 ? clamp(0.20 + 0.45 * SICK.sev, 0, 0.72) * (0.84 + 0.16 * Math.sin(simT * 2.1)) : 0;
  SICK.fx += (want - SICK.fx) * Math.min(1, Math.max(0, dt) * 3);
  if (el) el.style.opacity = SICK.fx.toFixed(3);
}
// the fade is the only part of the old tick that still has a job
function sickFxTick(dt) {
  const el = document.getElementById('sickfx');
  SICK.fx += (0 - SICK.fx) * Math.min(1, Math.max(0, dt) * 3);
  if (el) el.style.opacity = SICK.fx.toFixed(3);""")

# ---------------------------------------------------------------- 4. the panel loses its food half
s = sub1(s, """      (SICK.t > 0 ? `<br><span style="color:#c9d64a">ill from ${SICK.src} &middot; ${Math.ceil(SICK.t)} s &middot; stamina -${Math.round((1 - sickStamMul()) * 100)}%</span>` : '');""",
             """      '';""")

open(p, 'w', encoding='utf-8').write(s)
print('nofood ok')
