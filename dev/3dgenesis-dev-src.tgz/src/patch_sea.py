# Sea life: gills and lungs decide where you can breathe, water animals start in
# the water and never drown there, water-only bodies suffocate ashore, the body
# menu is split into land / air / sea, its shapes are plain grey, and NEW GAME
# really does build a new world.
def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
p='g3.html'; s=open(p,encoding='utf-8').read()
s=sub1(s,"  world.params.bodyScale = BODY_SCALE;","  world.params.bodyScale = BODY_SCALE;\n  world.playerRef = player.c;    // the one animal allowed to make its own bad decisions")

# ---------------------------------------------------------------- breathing
# default from the body plan: a pure swimming form breathes water, anything
# that walks breathes air. patch_core then lets grown gills/lungs override it.
s=sub1(s,"    ph.aquaticForm = aquaticForm ? 1 : 0;","""    ph.aquaticForm = aquaticForm ? 1 : 0;
    // Breathing. A body with no legs and real fins is a water animal: it takes
    // oxygen from the water and cannot breathe air. Anything that walks
    // breathes air and drowns with its head under. Gills and lungs are parts,
    // so a body can grow either, and one with both is amphibious.
    // This is deliberately a shape test, not a strength test: a calf must be
    // the same kind of animal as its mother, and finEff grows with the body.
    ph.waterBreath = (designed && genome.dx)
      ? (((genome.dx.legs || 0) === 0 && (genome.dx.arms || 0) === 0 && stat.fins > 0) ? 1 : 0)
      : ((aquaticForm && stat.legs <= 0.05 && stat.fins > 0.15) ? 1 : 0);
    ph.airBreath = ph.waterBreath ? 0 : 1;
    // grown gills or lungs override the body plan; a body with both is amphibious
    if (designed && genome.dx) {
      if (genome.dx.gill) ph.waterBreath = 1;
      if (genome.dx.lung) ph.airBreath = 1;
    }
    if (!ph.waterBreath && !ph.airBreath) ph.airBreath = 1;
    if (ph.waterBreath) ph.canSwim = 1;   // a water animal swims at any age, calf or adult""")

# ---- the sim: drown under water without gills, suffocate ashore without lungs
s=sub1(s,"""      if (!p.canSwim && !p.canFly && terrain.isWater(c.x, c.y) && waterDepth(terrain, c.x, c.y) > headHeight(world, p) - (c.jumpLv || 0) * 8) {
        c.energy -= p.storage * 0.12 * dt; c._drown = true;
      } else c._drown = false;""","""      const underNow = !p.canFly && terrain.isWater(c.x, c.y) &&
        waterDepth(terrain, c.x, c.y) > headHeight(world, p) - (c.jumpLv || 0) * 8;
      const cantBreathe = underNow ? !p.waterBreath : !p.airBreath;
      if (cantBreathe) { c.energy -= p.storage * 0.12 * dt; c._drown = underNow ? 1 : 2; }
      else c._drown = 0;""")
s=sub1(s,"""        c.deathCause = c.age >= c.maxAge ? 'oldage' : c._drown ? 'drowned' : (inHazard ? 'toxin' : 'starvation');""",
         """        c.deathCause = c.age >= c.maxAge ? 'oldage' : c._drown === 1 ? 'drowned' : c._drown === 2 ? 'suffocated' : (inHazard ? 'toxin' : 'starvation');""")

# ---- a water-only animal does not wander onto dry land (the player may, and
# suffocates for it: that is their choice, not the AI's)
s=sub1(s,"""        const blocked = (bx, by) => {
          if (terrain.isDeep(bx, by)) return !p.canSwim;""","""        const blocked = (bx, by) => {
          if (!p.airBreath && c !== world.playerRef && !terrain.isWater(bx, by)) return true;   // gills only: the shoreline is a wall
          if (terrain.isDeep(bx, by)) return !p.canSwim;""")
s=sub1(s,"""      const reachable = (tx, ty) => {
        if (p.canFly) return true;""","""      const reachable = (tx, ty) => {
        if (p.canFly) return true;
        if (!p.airBreath && c !== world.playerRef && !terrain.isWater(tx, ty)) return false;   // gills only: never leave the water""")
# and the safety net that shoves finless creatures out of the deep must not
# shove a water animal onto the beach
s=sub1(s,"      if (!p.canSwim && !p.canFly && terrain.isDeep(c.x, c.y)) {","      if (!p.canSwim && !p.canFly && p.airBreath && terrain.isDeep(c.x, c.y)) {")

# ---------------------------------------------------------------- the HUD
s=sub1(s,"      drownMsgT = 2.2; toast('Drowning! You have no fins. Get your head above water.', 2000);",
         "      drownMsgT = 2.2;\n      toast(c._drown === 2 ? 'Suffocating! You breathe water. Get back in the sea, or grow lungs.'\n                          : 'Drowning! Get your head above water, or grow gills.', 2000);")
s=sub1(s,"  const why = cause === 'drowned' ? 'You drowned.' : cause === 'predation' ? 'You were killed.' :",
         "  const why = cause === 'drowned' ? 'You drowned.' : cause === 'suffocated' ? 'You suffocated out of water.' : cause === 'predation' ? 'You were killed.' :")

# ---------------------------------------------------------------- spawning
# mark the player so the movement rule above can tell it apart, and put a water
# animal in the water instead of on the island
s=sub1(s,"""  if (terrain.isDeep(x, y) && !C.develop(g).canSwim) { const sp2 = terrain.nearestShallow(x, y, false); if (sp2) { x = sp2[0]; y = sp2[1]; } }
  const me = C.makeCreature(g, x, y, 400);
  world.creatures.push(me);""","""  const phMe = C.develop(g);
  if (!phMe.airBreath) { const wp = nearestSwimmable(x, y); if (wp) { x = wp[0]; y = wp[1]; } }
  else if (terrain.isDeep(x, y) && !phMe.canSwim) { const sp2 = terrain.nearestShallow(x, y, false); if (sp2) { x = sp2[0]; y = sp2[1]; } }
  const me = C.makeCreature(g, x, y, 400);
  me._isPlayer = 1;
  world.creatures.push(me);""")
s=sub1(s,"""    const kin = C.makeCreature(kg, kx, ky, 400);
    for (const q of kin.cellState) q.grow = 1;
    kin._growthAvg = 1;
    kin.ph = C.develop(kg, kin.cellState);
    kin.energy = kin.ph.storage;
    kin.age = C.maturity(kin.ph) + 2;
    world.creatures.push(kin);
  }
  player.c = me;""","""    if (!phMe.airBreath) { const wp3 = nearestSwimmable(kx, ky); if (wp3) { kx = wp3[0]; ky = wp3[1]; } }
    const kin = C.makeCreature(kg, kx, ky, 400);
    for (const q of kin.cellState) q.grow = 1;
    kin._growthAvg = 1;
    kin.ph = C.develop(kg, kin.cellState);
    kin.energy = kin.ph.storage;
    kin.age = C.maturity(kin.ph) + 2;
    world.creatures.push(kin);
  }
  player.c = me;""")
s=sub1(s,"function becomeDesigned(des) {","""// nearest water deep enough to swim in (spiral search, world units)
function nearestSwimmable(x, y) {
  if (terrain.isDeep(x, y)) return [x, y];
  for (let r = 60; r <= 6000; r *= 1.5) {
    for (let a = 0; a < 16; a++) {
      const ang = (a / 16) * Math.PI * 2;
      const nx = clamp(x + Math.cos(ang) * r, 1, WORLD_W - 1), ny = clamp(y + Math.sin(ang) * r, 1, WORLD_H - 1);
      if (terrain.isDeep(nx, ny)) return [nx, ny];
    }
  }
  return null;
}
function becomeDesigned(des) {""")

# ---------------------------------------------------------------- new game
# NEW GAME builds a whole new world, then opens the builder on it
s=sub1(s,"  if (it.id === 'continue') { becomeDesigned(C.cloneDesign(PROG.last)); menuStart(); return; }",
"""  if (it.id === 'continue') { menuFresh(() => { becomeDesigned(C.cloneDesign(PROG.last)); menuStart(); }); return; }""")
s=sub1(s,"  if (it.id === 'new') { const st = document.getElementById('start'); if (st) st.style.display = 'none'; openEditor('start'); return; }",
"""  if (it.id === 'new') { menuFresh(() => { stopMenuMusic(true); const st = document.getElementById('start'); if (st) st.style.display = 'none'; openEditor('start'); }); return; }""")
s=sub1(s,"""    if (t.dataset.load != null) { const s = (PROG.saved || [])[+t.dataset.load]; if (s && s.design) { becomeDesigned(C.cloneDesign(s.design)); menuStart(); } return; }""",
"""    if (t.dataset.load != null) { const s = (PROG.saved || [])[+t.dataset.load]; if (s && s.design) menuFresh(() => { becomeDesigned(C.cloneDesign(s.design)); menuStart(); }); return; }""")
s=sub1(s,"function menuStart() {","""// Build a brand new island before starting: a new game is a new world, not the
// one that was generated while the menu was up. Runs at most once per menu.
let menuBusy = false;
function menuFresh(then) {
  if (menuBusy) return;
  menuBusy = true;
  const big = document.getElementById('mmBig');
  const was = big ? big.textContent : '';
  if (big) big.textContent = 'BUILDING A WORLD';
  REMAINS.length = 0; FIGHT.blood.length = 0; FIGHT.splatN = 0; FIGHT.splats.fill(undefined);
  const lock = document.getElementById('seedLock'); if (lock) lock.checked = false;
  Promise.resolve(rebuildWorld()).catch((e) => { console.warn(e); }).then(() => {
    menuBusy = false;
    if (big) big.textContent = was;
    then();
  });
}
function menuStart() {""")

# ---------------------------------------------------------------- body menu
# three groups (land / air / sea) and plain grey shapes
s=sub1(s,"""    const planLocked = ED.mode === 'game';
    html += '<div class="edgrid">';
    for (let p = 0; p < C.PLANS.length; p++) html += `<div class="edtile plan${ED.des.plan === p ? ' cur' : ''}${planLocked && ED.des.plan !== p ? ' locked' : ''}" data-plan="${p}">${tileHTML('plan' + p, !planLocked || ED.des.plan === p)}</div>`;
    html += '</div>';""","""    const planLocked = ED.mode === 'game';
    for (const grp of PLAN_GROUPS) {
      const list = grp.plans.filter(p => p < C.PLANS.length);
      if (!list.length) continue;
      html += `<div class="edpl">${grp.label}</div><div class="edgnote">${grp.note}</div><div class="edgrid">`;
      for (const p of list) html += `<div class="edtile plan${ED.des.plan === p ? ' cur' : ''}${planLocked && ED.des.plan !== p ? ' locked' : ''}" data-plan="${p}" title="${PLAN_NAMES[p] || ''}">${tileHTML('plan' + p, !planLocked || ED.des.plan === p)}<span class="edcname2">${PLAN_NAMES[p] || ''}</span></div>`;
      html += '</div>';
    }""")
s=sub1(s,"const VIS_CATS = [","""// The body shapes, grouped by where they live. Sea shapes have no legs: they
// breathe water and cannot leave it until they take lungs or legs from a kill.
const PLAN_NAMES = ['blob', 'quadruped', 'biped', 'serpent', 'crawler', 'glider', 'fish', 'tank', 'runner', 'grazer',
                    'theropod', 'raptor', 'sauropod', 'horned', 'armoured', 'plated', 'duckbill', 'sail-back',
                    'pterosaur', 'shark', 'whale', 'plesiosaur'];
const PLAN_GROUPS = [
  { label: 'land', note: 'walks and runs. breathes air.', plans: [1, 2, 8, 9, 0, 3, 4, 10, 11, 12, 13, 14, 15, 16, 17] },
  { label: 'air', note: 'wings: flight once they beat your weight.', plans: [5, 7, 18] },
  { label: 'sea', note: 'no legs: breathes water, starts in the sea and cannot come ashore without lungs.', plans: [6, 19, 20, 21] },
];
const VIS_CATS = [""")
s=sub1(s,"  .edtile.locked { cursor: not-allowed; }","""  .edtile.locked { cursor: not-allowed; }
  .edgnote{font-size:11px;color:#7fb9c9;margin:-2px 0 6px}
  .edcname2{position:absolute;left:0;right:0;bottom:0;padding:3px 4px;font-size:10.5px;text-align:center;
    color:#dff4f0;background:linear-gradient(180deg,rgba(6,20,32,0),rgba(6,20,32,.85))}""")

# ---- plain grey shapes: strip every part and force one flat grey, so the tile
# shows the skeleton's silhouette and nothing else
s=sub1(s,"""      d.parts = (d.parts || []).filter(q => { const sim = C.ITEM_SIM[q.id]; return sim && (sim.t === 'FIN' || sim.t === 'WING'); });
      d.col = { base: [0.62, 0.63, 0.64], coat: [0.78, 0.79, 0.80], detail: [0.45, 0.46, 0.48], pat: 0, skin: 0 };""",
"""      d.parts = (d.parts || []).filter(q => { const sim = C.ITEM_SIM[q.id]; return sim && (sim.t === 'FIN' || sim.t === 'WING'); });
      d.col = { base: [0.66, 0.67, 0.68], coat: [0.66, 0.67, 0.68], detail: [0.66, 0.67, 0.68], pat: 0, skin: 0 };
      GREY_THUMB = [0.66, 0.67, 0.68];""")
s=sub1(s,"""    // frame whatever was emitted""","""    GREY_THUMB = null;
    // frame whatever was emitted""")
s=sub1(s,"""function itemColor(id, c, dcol) {
  if (c) return c;""","""let GREY_THUMB = null;     // body-shape tiles: one flat grey, whatever the part says
function itemColor(id, c, dcol) {
  if (GREY_THUMB) return GREY_THUMB;
  if (c) return c;""")

# ---------------------------------------------------------------- placement
# terrain gains the mirror of nearestShallow: the nearest water a gill-breather
# can live in. Founders and calves of water species are placed with it, so a
# whale is never born on a hillside.
s=sub1(s,"""      // nearest point that a non-swimmer can legally occupy (spiral search)""",
"""      // nearest water deep enough for a gill-breather (spiral search)
      nearestDeep(x, y) {
        if (terrain.isDeep(x, y)) return null;
        for (let r = 60; r <= 6000; r *= 1.5) {
          for (let a = 0; a < 16; a++) {
            const ang = (a / 16) * TAU;
            const nx = clamp(x + Math.cos(ang) * r, 1, w - 1), ny = clamp(y + Math.sin(ang) * r, 1, h - 1);
            if (terrain.isDeep(nx, ny)) return [nx, ny];
          }
        }
        return null;
      },
      // nearest point that a non-swimmer can legally occupy (spiral search)""")
s=sub1(s,"""      const founder = makeCreature(g, x, y, 30 + rng() * 10);""",
"""      const founder = makeCreature(g, x, y, 30 + rng() * 10);
      if (!founder.ph.airBreath) {                       // a water species belongs in the water
        const wet = terrain.nearestDeep(founder.x, founder.y);
        if (wet) { founder.x = wet[0]; founder.y = wet[1]; }
      }""")
s=sub1(s,"""    if (terrain && !baby.ph.canSwim && !baby.ph.canFly) {
      const spot = terrain.nearestShallow(x, y, false);
      if (spot) { baby.x = spot[0]; baby.y = spot[1]; }
    }""",
"""    if (terrain && !baby.ph.airBreath) {
      const wet = terrain.nearestDeep(x, y);
      if (wet) { baby.x = wet[0]; baby.y = wet[1]; }
    } else if (terrain && !baby.ph.canSwim && !baby.ph.canFly) {
      const spot = terrain.nearestShallow(x, y, false);
      if (spot) { baby.x = spot[0]; baby.y = spot[1]; }
    }""")

# ---------------------------------------------------------------- diving
s=sub1(s,"// =====================================================================\n// FLIGHT:", open('src/swim.js',encoding='utf-8').read()+"\n// =====================================================================\n// FLIGHT:")
s=sub1(s,"function updateFlight(dt) { flightTick(dt); rearTick(dt); }","function updateFlight(dt) { flightTick(dt); rearTick(dt); swimTick(dt); }")
# the body sits at the depth you swam to, not pinned to the surface
s=sub1(s,"  if (inWater && p.canSwim) groundY = Math.max(groundY, LVw * HEIGHT_SCALE - p.radius * 0.8 * S);",
"""  if (inWater && p.canSwim) {
    groundY = Math.max(groundY, LVw * HEIGHT_SCALE - p.radius * 0.8 * S);
    if (c === player.c && !player.spectator && (player.dive || 0) > 0)
      groundY = Math.max(surf + p.radius * 0.55 * S, groundY - player.dive);
  }""")
# a swimmer at the surface is not drowning: only one that has actually gone under
s=sub1(s,"""      const underNow = !p.canFly && terrain.isWater(c.x, c.y) &&
        waterDepth(terrain, c.x, c.y) > headHeight(world, p) - (c.jumpLv || 0) * 8;""",
"""      const deepHere = terrain.isWater(c.x, c.y) &&
        waterDepth(terrain, c.x, c.y) > headHeight(world, p) - (c.jumpLv || 0) * 8;
      // a swimmer floats at the surface with its head out; it is only under
      // when it has actually dived (the game sets _sub for the one you steer)
      const underNow = !p.canFly && deepHere && (!p.canSwim || !!c._sub);""")
# depth on the HUD, next to the flight readout
s=sub1(s,"      (p.canFly ? flightHud() : '') +","      (p.canFly ? flightHud() : '') + swimHud() +")

open(p,'w',encoding='utf-8').write(s)
print('sea ok')
