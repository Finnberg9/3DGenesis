# Combat v2: stamina, guard/parry, dodge, lock-on, telegraphed strikes,
# knockback, stagger, bleeding wounds and blood. See src/fight.js.
def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
p='g3.html'; s=open(p,encoding='utf-8').read()

# ---------------------------------------------------------------- core
# Wounds: a hit worth more than a tenth of the victim's reserve opens a
# bleeding wound that keeps draining energy for a while (stacks, capped).
s=sub1(s,"""  function onHit(victim, attacker, dmg) {
    if (!victim || !attacker) return;
    victim.hurtT = HURT_TIME;""","""  const BLEED_FRAC = 0.10;   // a hit above this share of storage opens a wound
  const BLEED_MAX_T = 14;    // seconds a stacked wound can keep bleeding
  function onHit(victim, attacker, dmg) {
    if (!victim || !attacker) return;
    if (dmg > 0) victim.hurtT = HURT_TIME;
    const st = victim.ph && victim.ph.storage > 0 ? victim.ph.storage : 100;
    if (dmg > st * BLEED_FRAC) {
      // total drain of a wound is ~35% of the hit that caused it
      const t = Math.min(BLEED_MAX_T, (victim.bleedT || 0) + 6);
      victim.bleedR = Math.min(st * 0.02, (victim.bleedR || 0) * 0.5 + dmg * 0.35 / 6);
      victim.bleedT = t;
    }""")
# the game can intercept hits on one creature (the player) to defer them
s=sub1(s,"""  function retaliate(world, att, foe, flags) {
    const a = att.ph, d = foe.ph;
    const ratio = clamp(a.mass / Math.max(0.01, d.mass), 0.15, 2.5);
    const dmg = Math.max(a.attack - d.defense * 0.6, d.storage * 0.03 * ratio, 1);
    foe.energy -= dmg;""","""  // world.hitFilter(victim, attacker, dmg) -> dmg to apply now, or null to
  // skip this exchange (the caller resolves it later its own way).
  function filterHit(world, victim, att, dmg) {
    const f = world.hitFilter;
    return typeof f === 'function' ? f(victim, att, dmg) : dmg;
  }
  function retaliate(world, att, foe, flags) {
    const a = att.ph, d = foe.ph;
    const ratio = clamp(a.mass / Math.max(0.01, d.mass), 0.15, 2.5);
    let dmg = Math.max(a.attack - d.defense * 0.6, d.storage * 0.03 * ratio, 1);
    dmg = filterHit(world, foe, att, dmg);
    if (dmg === null) return;
    foe.energy -= dmg;""")
s=sub1(s,"""    let dmg = a.attack - d.defense * 0.6; if (dmg <= 0) dmg = 1;
    prey.energy -= dmg;
    onHit(prey, att, dmg);""","""    let dmg = a.attack - d.defense * 0.6; if (dmg <= 0) dmg = 1;
    dmg = filterHit(world, prey, att, dmg);
    if (dmg === null) return;
    prey.energy -= dmg;
    onHit(prey, att, dmg);""")
s=sub1(s,"""      if (c.hurtT > 0) c.hurtT = Math.max(0, c.hurtT - dt);""","""      if (c.hurtT > 0) c.hurtT = Math.max(0, c.hurtT - dt);
      if (c.bleedT > 0) {
        c.bleedT = Math.max(0, c.bleedT - dt);
        c.energy -= (c.bleedR || 0) * dt;
        if (c.bleedT <= 0) c.bleedR = 0;
      }""")

# ---------------------------------------------------------------- game code
code=open('src/fight.js',encoding='utf-8').read()
s=sub1(s,"function stepSim(dt) {\n", code+"\nfunction stepSim(dt) {\n")
# the old ring is replaced by the arc in fight.js
i=s.index("// A flat ring of markers on the ground at exactly the distance your attacks and")
j=s.index("const bodyByMesh = new Map();")
s=s[:i]+s[j:]
s=sub1(s,"""  drawBirths(t);
  for (const c of world.creatures) {""","""  drawBirths(t);
  drawFight(t);
  for (const c of world.creatures) {""")
# lock-on target wins over the nearest-in-front pick when it is in reach
s=sub1(s,"""  player.target = pickTarget();""","""  player.target = pickTarget();
  if (FIGHT.lock && FIGHT.lock.alive && player.c && player.c.alive &&
      Math.hypot(FIGHT.lock.x - player.c.x, FIGHT.lock.y - player.c.y) <= interactRange(player.c.ph) + FIGHT.lock.ph.radius)
    player.target = FIGHT.lock;""")
# attacks: committed on press, land at the strike frame
i=s.index("function tryAttack() {")
j=s.index("function blockedFor(p, lv0, bx, by) {")
s=s[:i]+"function tryAttack() { fightStartSwing(); }\n\n"+s[j:]
# per-frame hook, knockback after your own movement, predation credit
s=sub1(s,"""function stepSim(dt) {
  if (player.atkCD > 0) player.atkCD = Math.max(0, player.atkCD - dt);""","""function stepSim(dt) {
  if (player.atkCD > 0) player.atkCD = Math.max(0, player.atkCD - dt);
  fightTick(dt);""")
s=sub1(s,"""    c.x = px; c.y = py;
    movePlayer(c, dt);
  }""","""    c.x = px; c.y = py;
    movePlayer(c, dt);
  }
  fightApplyKnocks(dt);
  if (c && !c.alive && c._fatalBy && c.deathCause !== 'predation') c.deathCause = 'predation';""")
s=sub1(s,"""      const diet = by.ph.carnivory > 0.5 ? 'a carnivore' : 'an animal';
      toast('Hit by ' + diet + ' for ' + (c._lastDmg || 0).toFixed(0) + '. You cannot eat for 5 s.', 1600);""","""      toast(fightHitMsg(c, by), 1600);""")
# movement: dodge override, guard/stagger slow-down, stamina-gated sprint
s=sub1(s,"""  const len = Math.hypot(fx, fz);
  if (len < 1e-6) { c.vx = 0; c.vy = 0; return; }
  const inWater = terrain.isWater(c.x, c.y);""","""  let len = Math.hypot(fx, fz);
  const dodgeV = fightDodgeVel(c);
  if (dodgeV) { fx = dodgeV[0]; fz = dodgeV[1]; len = Math.hypot(fx, fz); }
  FIGHT.sprinting = false;
  if (len < 1e-6) { c.vx = 0; c.vy = 0; return; }
  const inWater = terrain.isWater(c.x, c.y);""")
s=sub1(s,"""  const sprint = !!keys['shift'] || (!airborne && !!keys[' '] && !!keys['w']);
  if (sprint) sp *= (1 + C.GAIT_BOOST);
  sp *= PLAYER_SPEED;
  c.vx = (fx / len) * sp; c.vy = (fz / len) * sp;""","""  // a shift press only becomes a sprint once it is held past the dodge tap window
  const shiftHeld = !!keys['shift'] && (FIGHT.shiftT0 < 0 || simT - FIGHT.shiftT0 > SHIFT_TAP);
  const sprint = !dodgeV && (shiftHeld || (!airborne && !!keys[' '] && !!keys['w'])) && fightCanSprint();
  FIGHT.sprinting = sprint;
  if (sprint) sp *= (1 + C.GAIT_BOOST);
  sp *= PLAYER_SPEED * (dodgeV ? 1 : fightSpeedMul());
  if (dodgeV) { c.vx = fx; c.vy = fz; }
  else { c.vx = (fx / len) * sp; c.vy = (fz / len) * sp; }""")
# input
s=sub1(s,"""    const k = e.key.toLowerCase();
    keys[k] = true;""","""    const k = e.key.toLowerCase();
    if (!e.repeat) {
      if (k === 'q' && started) FIGHT.blockT0 = simT;
      if (k === 'shift') FIGHT.shiftT0 = simT;
      if (k === 'z' && started) tryDodge();
      if (k === 't' && started) toggleLock();
    }
    keys[k] = true;""")
s=sub1(s,"""  addEventListener('keyup', (e) => { keys[e.key.toLowerCase()] = false; });""","""  addEventListener('keyup', (e) => {
    const k = e.key.toLowerCase();
    // shift tapped (not held) is a dodge roll
    if (k === 'shift' && started && !ED.open && FIGHT.shiftT0 >= 0 && simT - FIGHT.shiftT0 <= SHIFT_TAP) tryDodge();
    if (k === 'shift') FIGHT.shiftT0 = -1;
    keys[k] = false;
  });""")
s=sub1(s,"""  canvas.addEventListener('mousedown', (e) => {
    if (ED.open || !pointerLocked) return;
    if (e.button === 0) tryAttack();""","""  canvas.addEventListener('mousedown', (e) => {
    if (e.button === 1 && !ED.open && started) { e.preventDefault(); toggleLock(); return; }
    if (ED.open || !pointerLocked) return;
    if (e.button === 0) tryAttack();""")
# HUD: stamina bar, damage vignette, controls help
s=sub1(s,"""  <span class="k">growth</span><span class="bar"><i id="v-g" style="width:0%;background:linear-gradient(90deg,#3a8,#35e0d8)"></i></span>""","""  <span class="k">growth</span><span class="bar"><i id="v-g" style="width:0%;background:linear-gradient(90deg,#3a8,#35e0d8)"></i></span>
  <span class="k">stamina</span><span class="bar"><i id="v-s" style="width:100%;background:linear-gradient(90deg,#c90,#fd6)"></i></span>""")
s=sub1(s,"""<canvas id="gpu"></canvas>""","""<canvas id="gpu"></canvas>
<div id="hurtfx" style="position:fixed;inset:0;pointer-events:none;opacity:0;z-index:4;background:radial-gradient(ellipse at center,rgba(0,0,0,0) 45%,rgba(120,0,0,.55) 80%,rgba(70,0,0,.9) 100%)"></div>""")
s=sub1(s,"""    <b>left click</b> / <b>F</b> attack &nbsp;·&nbsp; <b>X</b> switch attack""","""    <b>Q</b> guard &nbsp;·&nbsp; <b>Z</b> / tap <b>shift</b> dodge &nbsp;·&nbsp; <b>T</b> / <b>middle click</b> lock on<br>
    guard or dodge as an attacker's marker turns <span style="color:#ffd84a">yellow</span> to parry<br>
    <b>left click</b> / <b>F</b> attack &nbsp;·&nbsp; <b>X</b> switch attack""")
s=sub1(s,"<b>shift</b> sprint (burns energy)","hold <b>shift</b> sprint (stamina)")
s=sub1(s,"<b>space</b> jump &nbsp;·&nbsp; <b>space + W</b> or <b>shift</b> sprint","<b>space</b> jump &nbsp;·&nbsp; <b>space + W</b> sprint")
s=sub1(s,"""    inner ring = your attack reach (<span style="color:#f04c38">red</span> target,""","""    ground arc = where your selected attack lands, refilling as it recovers (<span style="color:#f04c38">red</span> target,""")
s=sub1(s,"""        '<div class="keys"><span class="hit">F</span> ' + MOVE_DEF[playerMove(mp)].label + ' <span>X</span> switch ' +""","""        '<div class="keys"><span class="hit">F</span> ' + MOVE_DEF[playerMove(mp)].label + ' <span>X</span> switch ' +
        '<span>Q</span> guard <span>Z</span> dodge <span>T</span> ' + (FIGHT.lock === tgt ? 'unlock ' : 'lock ') +""")
open(p,'w',encoding='utf-8').write(s)
print('fight ok')
s=open(p,encoding='utf-8').read()
s=sub1(s,"""  HEIGHT_SCALE, WORLD_W, WORLD_H,
};""","""  HEIGHT_SCALE, WORLD_W, WORLD_H,
  get FIGHT() { return FIGHT; }, get simT() { return simT; },
  dodge: () => tryDodge(), lock: () => toggleLock(),
  fightFilter: (v, a, d) => fightHitFilter(v, a, d),
};""")
open(p,'w',encoding='utf-8').write(s)
print('fight api ok')
