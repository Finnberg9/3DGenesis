# =====================================================================
# THE LOADOUT SCREEN
#
# The builder was a bright blue box with green buttons and rounded frames
# around everything -- a settings dialog with an animal in it. This makes it
# what it actually is: the screen where you look at the thing you are about to
# take into a fight.
#
# The read is a weapon-loadout screen: near black, hairline rules instead of
# boxed frames, nothing rounded, no gradients pretending to be glass, flat
# stencil type with wide letter-spacing, one hot accent (dried blood) against
# bone. Panels have no edges -- they bleed off into the dark and are separated
# by single-pixel rules, which is what stops it reading as a web form.
#
# Over the top: a vignette, a fine grain, and a slow horizontal scan. All
# three are pure CSS, cost nothing, and are what makes a flat dark panel feel
# like a screen in a room rather than a div.
#
# The whole thing is an OVERRIDE BLOCK appended after the editor's stylesheet
# rather than forty separate edits to it. Same selectors, later in the sheet,
# so it wins on order; the original rules stay readable underneath as the
# structure this is a skin over.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, ('ANCHOR %d/%d' % (n, cnt), a[:110]); return s.replace(a, b)

p = 'g3.html'; s = open(p, encoding='utf-8').read()

SKIN = r"""
  /* ================= LOADOUT SKIN =================================== */
  /* Everything below re-skins the editor. Structure is unchanged: this is
     colour, weight, edges and type. */
  #edRoot {
    --bone:    #d3cbba;          /* type, and the silhouettes */
    --bone-d:  #8b8474;          /* secondary type */
    --bone-f:  #5d5850;          /* disabled / hairlines on dark */
    --ink:     #08080a;          /* the dark everything sits on */
    --ink-2:   #0e0e11;
    --rule:    rgba(196,186,166,.13);
    --rule-2:  rgba(196,186,166,.26);
    --blood:   #8e2318;          /* the one hot accent */
    --blood-l: #c2402c;
    --amber:   #c8912f;
    color: var(--bone);
    letter-spacing: .02em;
  }
  /* grain + vignette + a slow scan, over the whole screen, under the cursor */
  #edVig { position: absolute; inset: 0; pointer-events: none; z-index: 5; mix-blend-mode: multiply;
    background:
      radial-gradient(ellipse 120% 92% at 50% 44%, rgba(255,255,255,0) 38%, rgba(0,0,0,.55) 82%, rgba(0,0,0,.86) 100%); }
  #edGrain { position: absolute; inset: 0; pointer-events: none; z-index: 6; opacity: .055; mix-blend-mode: overlay;
    background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='160' height='160'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='3'/></filter><rect width='160' height='160' filter='url(%23n)'/></svg>");
    background-size: 160px 160px; }
  #edScan { position: absolute; inset: 0; pointer-events: none; z-index: 7; opacity: .30;
    background: repeating-linear-gradient(180deg, rgba(0,0,0,.30) 0 1px, rgba(0,0,0,0) 1px 3px); }

  /* ---- type and buttons ---- */
  #edRoot button {
    font-size: 11.5px; font-weight: 600; letter-spacing: .16em; text-transform: uppercase;
    color: var(--bone-d); background: rgba(255,255,255,.022);
    border: 1px solid var(--rule); border-radius: 0; padding: 8px 14px;
    transition: color .12s, border-color .12s, background .12s;
  }
  #edRoot button:hover { color: var(--bone); background: rgba(255,255,255,.055); border-color: var(--rule-2); }
  #edRoot button:active { background: rgba(0,0,0,.4); }
  #edRoot button:disabled { color: var(--bone-f); background: none; border-color: rgba(196,186,166,.07); opacity: 1; }
  #edRoot button.warn { color: #c98a7c; border-color: rgba(190,70,50,.34); background: rgba(120,28,18,.16); }
  #edRoot button.warn:hover { color: #f0c0b4; border-color: var(--blood-l); background: rgba(150,36,22,.30); }
  /* a toggle reads as a lit tally on the left edge, not as a green pill */
  #edRoot button.on { color: var(--bone); background: rgba(255,255,255,.06);
    border-color: var(--rule-2); box-shadow: inset 3px 0 0 var(--blood-l); }

  /* ---- the top strip: a rule under it, not a box round it ---- */
  #edTop { top: 0; left: 0; right: 0; max-width: none; border-radius: 0; border: 0;
    border-bottom: 1px solid var(--rule); box-shadow: none;
    padding: 9px 14px; gap: 7px;
    background: linear-gradient(180deg, rgba(6,6,8,.92) 0%, rgba(6,6,8,.72) 70%, rgba(6,6,8,0) 100%); }
  #edTop button.go { font-size: 13px; letter-spacing: .34em; padding: 9px 30px 9px 34px;
    color: var(--bone); background: rgba(142,35,24,.20);
    border: 1px solid rgba(194,64,44,.55); box-shadow: inset 0 0 22px rgba(142,35,24,.28); }
  #edTop button.go:hover { color: #fff; background: rgba(170,42,28,.45); border-color: var(--blood-l);
    box-shadow: inset 0 0 26px rgba(194,64,44,.5), 0 0 22px rgba(142,35,24,.28); }
  #edTop button.go.blocked { filter: none; color: var(--bone-f); background: none; border-color: rgba(196,186,166,.10); box-shadow: none; }
  #edTop input, #edRoot input[type=text] { background: rgba(0,0,0,.35); border: 1px solid var(--rule); border-radius: 0;
    color: var(--bone); font-family: inherit; font-size: 12px; letter-spacing: .08em; padding: 7px 10px; }
  #edTop input::placeholder { color: var(--bone-f); letter-spacing: .12em; text-transform: uppercase; font-size: 11px; }

  /* ---- the right column: an edge, not a frame ---- */
  #edPal { top: 0; right: 0; bottom: 0; width: 396px; border-radius: 0; border: 0;
    border-left: 1px solid var(--rule); box-shadow: none; padding: 14px 16px 12px;
    background: linear-gradient(270deg, rgba(8,8,10,.95) 0%, rgba(8,8,10,.90) 62%, rgba(8,8,10,.74) 100%); }
  #edTabTitle { margin: 14px 2px 2px; font-size: 12px; letter-spacing: .34em; color: var(--bone);
    font-weight: 600; text-align: center; }
  #edTabHint { color: var(--bone-f) !important; font-size: 10.5px; letter-spacing: .10em; text-transform: uppercase; text-align: center; }
  #edPal > div:first-child { border-bottom: 1px solid var(--rule); padding-bottom: 10px; }
  #edGrid::-webkit-scrollbar { width: 6px } #edGrid::-webkit-scrollbar-thumb { background: rgba(196,186,166,.18); border-radius: 0 }
  .edgrid { gap: 1px; }
  /* group headers: a rule with a word sitting on it */
  .edpl { font-size: 10.5px; letter-spacing: .30em; color: var(--bone-d); margin: 20px 0 2px;
    padding-bottom: 5px; border-bottom: 1px solid var(--rule); }
  .edgnote { color: var(--bone-f); font-size: 10.5px; letter-spacing: .06em; margin: 4px 0 8px; }

  /* ---- tiles ---- */
  .edtile { border-radius: 0; background: #0b0b0e; border: 1px solid rgba(196,186,166,.08);
    box-shadow: none; transition: background .10s, border-color .10s; }
  .edtile:hover { border-color: var(--rule-2); background: #131317; transform: none; }
  .edtile.cur { border: 1px solid rgba(194,64,44,.75); background: #16100f;
    box-shadow: inset 0 0 0 1px rgba(142,35,24,.28), inset 0 -26px 34px -20px rgba(194,64,44,.45); }
  .edtile.locked img { filter: grayscale(1) brightness(.45); opacity: .5; }
  .edlock { border-radius: 0; background: rgba(0,0,0,.72); color: var(--bone-d); left: 0; top: 0; padding: 4px; }
  .edcost { border-radius: 0; height: 17px; font-size: 10px; font-weight: 700; letter-spacing: .06em;
    color: var(--bone); background: rgba(0,0,0,.7); border: 1px solid var(--rule); right: 0; bottom: 0; }
  .edcname2 { background: linear-gradient(180deg, rgba(0,0,0,0), rgba(0,0,0,.85)) !important;
    color: var(--bone-d) !important; letter-spacing: .10em; text-transform: uppercase; font-size: 9.5px; }
  /* body shapes: bone-white silhouettes on black. A black silhouette on a
     black screen is an empty square, so the shape is shown the way a loadout
     screen shows a weapon -- lit against the dark. */
  .edtile.silho { background: #060608; }
  .edtile.silho img { filter: brightness(0) invert(.86) sepia(.42) saturate(.55) contrast(1.05); opacity: .80; }
  .edtile.silho:hover { background: #0d0d10; }
  .edtile.silho:hover img { opacity: 1; }
  .edtile.silho.cur { background: #120c0b; }
  .edtile.silho.cur img { filter: brightness(0) invert(.92) sepia(.55) saturate(1.1) contrast(1.05); opacity: 1; }
  .edtile.silho.locked img { filter: brightness(0) invert(.48); opacity: .30; }

  /* ---- the stat block, bottom left: a readout, not a card ---- */
  #edStats { left: 0; bottom: 0; width: 352px; border-radius: 0; border: 0;
    border-top: 1px solid var(--rule); border-right: 1px solid var(--rule);
    padding: 14px 18px 16px; font-size: 12px;
    background: linear-gradient(0deg, rgba(8,8,10,.95) 0%, rgba(8,8,10,.86) 70%, rgba(8,8,10,.62) 100%); }
  .edcapl { font-size: 10.5px; letter-spacing: .30em; color: var(--bone-d); }
  .edcapl b { font-size: 20px; color: var(--bone); font-weight: 600; letter-spacing: .02em; }
  .edcapl b.over { color: var(--blood-l); }
  .edbar { height: 2px; border-radius: 0; background: rgba(196,186,166,.12); border: 0; margin: 8px 0 6px; }
  .edbar i { background: var(--bone-d); }
  .edbar i.over { background: var(--blood-l); }
  .edkills { font-size: 10px; letter-spacing: .10em; text-transform: uppercase; color: var(--bone-f); }
  .edst { border-bottom: 1px solid rgba(196,186,166,.07); color: var(--bone-d); padding: 4px 0;
    font-size: 11.5px; letter-spacing: .06em; }
  .edst b { color: var(--bone); font-weight: 600; }
  .edst.big { color: var(--bone); font-size: 11px; letter-spacing: .20em; text-transform: uppercase;
    border-bottom: 1px solid var(--rule); }
  .edst i.up { color: #9db07a; } .edst i.dn { color: var(--blood-l); }
  .edmoves span { color: var(--bone-f); font-size: 10px; letter-spacing: .26em; }
  .edmoves button { border-radius: 0; font-size: 10.5px; letter-spacing: .14em; padding: 5px 11px;
    color: var(--bone-d); background: rgba(255,255,255,.03); border: 1px solid var(--rule); }
  .edmoves button:hover { color: var(--bone); background: rgba(255,255,255,.07); border-color: var(--rule-2); }
  .edwarn { color: var(--amber); font-size: 11px; letter-spacing: .04em; }

  /* ---- the rest of the furniture ---- */
  #edInsp, #edSavedBox, #edTip { border-radius: 0; border: 1px solid var(--rule);
    background: rgba(8,8,10,.96); box-shadow: 0 0 0 1px rgba(0,0,0,.6); }
  #edInsp { left: 0; top: 0; border-left: 0; border-top: 0; }
  .edih b { color: var(--bone); font-weight: 600; letter-spacing: .10em; text-transform: uppercase; font-size: 13px; }
  .edih span, .edhint, .edsl, .edchk { color: var(--bone-d); }
  .edhint { font-size: 11px; letter-spacing: .05em; color: var(--bone-f); }
  .edsl input[type=range] { accent-color: var(--bone-d); }
  .edsw .sw { border-radius: 0; border: 1px solid rgba(196,186,166,.30); box-shadow: none; }
  .edsw .sw:hover { border-color: var(--bone); transform: none; outline: 1px solid var(--bone); }
  .edsw input[type=color], .edrow input[type=color] { border-radius: 0; border: 1px solid var(--rule); background: #0b0b0e; }
  .edsvi { border-radius: 0; background: #0b0b0e; }
  #edHelp { border-radius: 0; background: linear-gradient(180deg, rgba(8,8,10,0), rgba(8,8,10,.82));
    color: var(--bone-f); font-size: 10.5px; letter-spacing: .12em; text-transform: uppercase;
    padding: 10px 18px 12px; max-width: 60vw; }
  #edFlash { border-radius: 0; background: rgba(18,6,4,.96); border: 1px solid rgba(194,64,44,.55);
    color: #e8cdc4; font-size: 12px; letter-spacing: .08em; }
  #edTip b { color: var(--bone); letter-spacing: .08em; text-transform: uppercase; font-size: 12px; }
  #edTip .c { color: var(--bone-f); letter-spacing: .10em; }
  #edTip .lk { color: var(--amber); }
  #edOpenBtn { border-radius: 0; color: var(--bone); background: rgba(8,8,10,.86);
    border: 1px solid var(--rule); font: 600 11px/1 'IBM Plex Mono', monospace; letter-spacing: .18em;
    text-transform: uppercase; padding: 9px 14px; }
  #edOpenBtn:hover { border-color: var(--rule-2); background: rgba(20,20,24,.9); }
  /* the loot picker that appears over a kill */
  #picker .popt2 { border-radius: 0; background: #0b0b0e; border: 1px solid rgba(196,186,166,.10); }
  #picker .popt2:hover { border-color: var(--rule-2); background: #131317; }
  #picker .popt2 span { color: var(--bone-d); letter-spacing: .08em; text-transform: uppercase; font-size: 10px; }
  #picker .popt2 em { color: var(--amber); } #picker .popt2.own em { color: var(--bone-f); }
"""

s = sub1(s, "  #picker { pointer-events: auto; }", "  #picker { pointer-events: auto; }\n" + SKIN)

# the three overlays. Appended inside the editor root so they cover the panels
# as well as the world behind them, and marked aria-hidden: they are texture.
s = sub1(s, """  root.innerHTML = `
  <div id="edTop" class="edp">""",
"""  root.innerHTML = `
  <div id="edVig" aria-hidden="true"></div><div id="edGrain" aria-hidden="true"></div><div id="edScan" aria-hidden="true"></div>
  <div id="edTop" class="edp">""")

open(p, 'w', encoding='utf-8').write(s)
print('loadout: skin ok')
