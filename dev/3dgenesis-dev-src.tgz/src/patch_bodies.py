# =====================================================================
# FOURTEEN SHAPES, AND NOTHING ELSE
#
# Thirty body plans, most of them reconstructions of the same animal with the
# neck a bit longer. "They are a lot too similar and too dinosaur looking."
#
# The picker offers FOURTEEN: ten that walk and four that fly. Every one of
# them has to be recognisable as a black shape at fifty paces and has to be
# obviously not the one next to it. Reference: Monsters Inc proportions --
# one feature allowed to be absurdly oversized and the rest built around it --
# with the wrongness of the xeno sculpts rather than the charm.
#
#   LAND
#     LURKER      one enormous body, a face across the whole front, legs you
#                 can barely see under it
#     MAW         a head bigger than the animal carrying it. A walking mouth.
#     HOLLOW      tall, gaunt and vertical, arms that reach the ground, a
#                 head far too small for the frame
#     CENTIPEDE   very long, very low, segmented, legs all the way down
#     SCORPION    wide armoured carapace, pincers, a tail over its own back
#     STILTWALKER a tiny body carried absurdly high on thin legs
#     CRAB        flat and far wider than it is long, legs splayed around it
#     BRUTE       shoulders and arms, almost no hips, knuckles on the floor
#     MANTIS      upright and narrow, folded blades, a long abdomen behind
#     HYDRA       a low heavy body under one enormous neck
#
#   AIR
#     FLIT        small, light and quick
#     MOTHWING    enormous wings on almost nothing, and no legs at all: it
#                 does not walk, and a match will not take it for that reason
#     SKIMMER     wings that are its arms, folded to move on the ground
#     DRAKE       long neck, long tail, four legs and a wingspan over all of it
#
# The other sixteen plans stay in the table. Renumbering would turn every
# saved design into a different animal; they are simply not offered.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, ('ANCHOR %d/%d' % (n, cnt), a[:110]); return s.replace(a, b)

p = 'g3.html'; s = open(p, encoding='utf-8').read()

# ---------------------------------------------------------------- 1. the new skeletons
s = sub1(s, """    { a: 2.05, b: 0.54, seg: 18, prof: 'tube',   arch: 0.00, droop: 0.00, wide: 0,    neck: 0.55, nx: 0.80, ny: 0.55, ns: 3, head: 0.46, snx: 0.68, snr: 0.50, tail: 2.3, tailR: 0.34, ts: 10, stand: 0.62, flex: 1 }, // 29 wyrm
  ];""",
"""    { a: 2.05, b: 0.54, seg: 18, prof: 'tube',   arch: 0.00, droop: 0.00, wide: 0,    neck: 0.55, nx: 0.80, ny: 0.55, ns: 3, head: 0.46, snx: 0.68, snr: 0.50, tail: 2.3, tailR: 0.34, ts: 10, stand: 0.62, flex: 1 }, // 29 wyrm
    // ---- the offered set --------------------------------------------------
    // One oversized feature each, and the rest of the body built around it.
    { a: 1.00, b: 1.34, seg: 9,  prof: 'round',  arch: 0.12, droop: 0.00, wide: 0.58, neck: 0.00, nx: 0.95, ny: 0.15, ns: 2, head: 0.96, snx: 0.30, snr: 0.96, tail: 0.0, tailR: 0.20, ts: 3, stand: 0.52 },  // 30 lurker
    { a: 0.82, b: 0.58, seg: 9,  prof: 'insect', arch: 0.00, droop: 0.12, wide: 0.22, neck: 0.08, nx: 0.95, ny: 0.20, ns: 2, head: 1.18, snx: 0.98, snr: 0.88, tail: 0.7, tailR: 0.16, ts: 5, stand: 0.72 },  // 31 maw
    { a: 0.76, b: 0.42, seg: 11, prof: 'tube',   arch: 0.32, droop: 0.06, wide: 0,    neck: 0.95, nx: 0.50, ny: 0.94, ns: 4, head: 0.24, snx: 0.42, snr: 0.28, tail: 0.2, tailR: 0.10, ts: 3, stand: 2.35 },  // 32 hollow
    { a: 2.30, b: 0.38, seg: 19, prof: 'tube',   arch: 0.00, droop: 0.00, wide: 0.12, neck: 0.10, nx: 0.95, ny: 0.25, ns: 2, head: 0.34, snx: 0.55, snr: 0.38, tail: 1.5, tailR: 0.18, ts: 8, stand: 0.52, flex: 1 }, // 33 centipede
    { a: 0.54, b: 0.40, seg: 9,  prof: 'round',  arch: 0.10, droop: 0.00, wide: 0,    neck: 0.55, nx: 0.55, ny: 0.92, ns: 3, head: 0.26, snx: 0.72, snr: 0.24, tail: 0.8, tailR: 0.11, ts: 5, stand: 1.05 },  // 34 flit
    { a: 0.58, b: 0.50, seg: 9,  prof: 'insect', arch: 0.05, droop: 0.00, wide: 0.16, neck: 0.14, nx: 0.85, ny: 0.45, ns: 2, head: 0.28, snx: 0.40, snr: 0.32, tail: 0.6, tailR: 0.13, ts: 4, stand: 0.42 },  // 35 mothwing
    { a: 1.45, b: 0.78, seg: 13, prof: 'animal', arch: 0.14, droop: 0.04, wide: 0.10, neck: 2.10, nx: 0.48, ny: 0.90, ns: 7, head: 0.44, snx: 0.86, snr: 0.42, tail: 2.5, tailR: 0.28, ts: 10, stand: 1.55 },  // 36 drake
  ];""")

# ---------------------------------------------------------------- 2. hides
s = sub1(s, """    { base: [0.22, 0.26, 0.32], coat: [0.56, 0.60, 0.64], detail: [0.36, 0.72, 0.74], pat: 1 },  // 29 wyrm
  ];""",
"""    { base: [0.22, 0.26, 0.32], coat: [0.56, 0.60, 0.64], detail: [0.36, 0.72, 0.74], pat: 1 },  // 29 wyrm
    { base: [0.34, 0.20, 0.26], coat: [0.68, 0.52, 0.52], detail: [0.90, 0.78, 0.28], pat: 3 },  // 30 lurker
    { base: [0.18, 0.18, 0.20], coat: [0.46, 0.42, 0.40], detail: [0.84, 0.24, 0.18], pat: 0 },  // 31 maw
    { base: [0.30, 0.30, 0.34], coat: [0.62, 0.62, 0.62], detail: [0.14, 0.14, 0.16], pat: 0 },  // 32 hollow
    { base: [0.20, 0.22, 0.18], coat: [0.48, 0.52, 0.42], detail: [0.76, 0.58, 0.14], pat: 1 },  // 33 centipede
    { base: [0.38, 0.34, 0.26], coat: [0.74, 0.70, 0.58], detail: [0.86, 0.52, 0.18], pat: 2 },  // 34 flit
    { base: [0.28, 0.24, 0.34], coat: [0.64, 0.58, 0.70], detail: [0.92, 0.84, 0.44], pat: 2 },  // 35 mothwing
    { base: [0.24, 0.20, 0.18], coat: [0.52, 0.46, 0.40], detail: [0.80, 0.32, 0.14], pat: 1 },  // 36 drake
  ];""")
s = sub1(s, """  const PLAN_SKIN = [1, 3, 1, 1, 3, 4, 1, 2, 4, 0,  1, 2, 1, 1, 4, 1, 1, 1, 2, 0, 0, 0,
  //                 scorpion stilt hydra mantis crab brute drifter wyrm
                     4, 1, 1, 4, 4, 3, 0, 1];""",
"""  const PLAN_SKIN = [1, 3, 1, 1, 3, 4, 1, 2, 4, 0,  1, 2, 1, 1, 4, 1, 1, 1, 2, 0, 0, 0,
  //                 scorpion stilt hydra mantis crab brute drifter wyrm
                     4, 1, 1, 4, 4, 3, 0, 1,
  //                 lurker maw hollow centipede flit mothwing drake
                     0, 4, 0, 4, 2, 2, 1];""")

open(p, 'w', encoding='utf-8').write(s)
print('bodies: skeletons ok')

# ---------------------------------------------------------------- 3. what each is born as
s = open(p, encoding='utf-8').read()
s = sub1(s, """      // ---- mythical ------------------------------------------------------
      case 22: // scorpion""",
"""      // ---- the offered set -----------------------------------------------
      case 30: // lurker: a face across the whole front of one enormous body
        eyeAt('e_big', 1.45, 0.22, 0.62, 0.30); eyeAt('e_round', 0.75, 0.55, 0.40, 0.55);
        mouthAt('m_maw', 1.65);
        put('d_frill', -a * 0.30, b * 1.15, b * 0.30, -0.2, 1, 0.3, 1.1, true);
        // stubby legs, barely clear of the belly
        limb('l_thick',  a * 0.34, -b * 0.55,  b * 0.62,  a * 0.42, -st, b * 0.86, 0.06, 0.02, 0.02, 't_pad', 1.5);
        limb('l_thick', -a * 0.36, -b * 0.55,  b * 0.62, -a * 0.44, -st, b * 0.86, -0.06, 0.02, 0.02, 't_pad', 1.5);
        break;
      case 31: // maw: the head is the animal, the body is what carries it
        eyeAt('e_cluster', 0.55, 0.85, 0.20, 0.34); eyeAt('e_slit', 0.40, 0.62, 0.50, 0.46);
        mouthAt('m_rex', 1.35);
        put('s_plate', -a * 0.30, b * 0.95, b * 0.35, -0.2, 1, 0.4, 0.95, true);
        legRow('l_thin', [0.10, -0.38], { out: 0.80, rake: 1.0, reach: 1.5, knee: 0.7, th: 0.95, tip: 't_talon' });
        tailPut('s_knob', 0.9);
        break;
      case 32: // hollow: vertical, gaunt, arms to the floor, a head far too small
        eyeAt('e_round', 0.55, 0.45, 0.30, 0.50); mouthAt('m_hook', 0.7);
        put('d_antenna', head.x - hr * 0.2, head.y + hr, hr * 0.3, -0.2, 1, 0.3, 1.2, true);
        put('s_spike', -a * 0.05, b * 1.15, b * 0.25, 0, 1, 0.3, 0.8, true);
        limb('l_thin', -a * 0.20, -b * 0.30, b * 0.42, -a * 0.10, -st, b * 0.40, 0.30, 0.10, 0.02, 't_pad', 0.62);
        // Arms that hang almost to the floor -- but only almost. A limb that
        // reaches the ground is a LEG to classifyLimbs, and the walking
        // physics reads the same function, so an arm planted on the soil
        // would quietly become a fifth and sixth leg. classifyLimbs calls a
        // limb a leg when its foot is within 72% of the mean foot depth, so
        // the arm has to hang clearly shorter than that, not merely shorter.
        limb('l_thin',  a * 0.35,  b * 0.55,  b * 0.52,  a * 0.55, -st * 0.42, b * 0.78, 0.18, -0.34, 0.10, 't_claw', 0.55);
        break;
      case 33: // centipede: very long, very low, legs the whole way down
        eyeAt('e_bug', 0.85, 0.35, 0.45, 0.60); mouthAt('m_hook', 0.85);
        put('d_antenna', head.x + hr * 0.25, head.y + hr, hr * 0.30, 0.35, 1, 0.3, 1.25, true);
        legRow('l_thin', [0.70, 0.42, 0.14, -0.14, -0.42, -0.70], { out: 0.80, rake: 0.75, reach: 1.15, knee: 0.55, th: 0.7, tip: 't_talon' });
        tailPut('s_spike', 1.1);
        break;
      case 34: // flit: small, light, quick
        eyeAt('e_big', 1.05, 0.45, 0.35, 0.58); mouthAt('m_beak', 0.85);
        put('w_feather', a * 0.05, b * 0.62, b * 0.58, 0, 0.7, 0.7, 1.15, true);
        put('d_crest', head.x - hr * 0.25, head.y + hr, 0, -0.3, 1, 0, 0.8, false);
        limb('l_thin', -a * 0.10, -b * 0.35, b * 0.38, -a * 0.02, -st, b * 0.46, 0.24, 0.05, 0.03, 't_talon', 0.55);
        break;
      case 35: // mothwing: enormous wings on almost nothing. It does not walk.
        eyeAt('e_cluster', 1.0, 0.40, 0.42, 0.58); mouthAt('m_grazer', 0.7);
        put('d_antenna', head.x + hr * 0.2, head.y + hr, hr * 0.32, 0.3, 1, 0.35, 1.5, true);
        put('w_bat', a * 0.10, b * 0.55, b * 0.45, 0, 0.55, 0.85, 2.4, true);
        put('w_insect', -a * 0.35, b * 0.40, b * 0.42, -0.2, 0.5, 0.85, 1.5, true);
        break;
      case 36: // drake: neck, tail, four legs and a wingspan over all of it
        eyeAt('e_slit', 0.95, 0.50, 0.32, 0.58); mouthAt('m_spino', 1.05);
        put('h_curved', head.x - hr * 0.3, head.y + hr * 0.9, hr * 0.35, -0.3, 1, 0.35, 1.0, true);
        // a wingspan that actually beats its own weight: lift is wing area
        // against mass, and a drake is heavy
        put('w_bat', a * 0.05, b * 0.72, b * 0.50, 0, 0.7, 0.72, 3.4, true);
        put('w_bat', -a * 0.20, b * 0.55, b * 0.52, -0.15, 0.6, 0.78, 2.2, true);
        put('f_dorsal', -a * 0.25, b * 1.10, 0, 0, 1, 0, 0.9, false);
        limb('l_leg',  a * 0.46, -b * 0.30,  b * 0.58,  a * 0.52, -st, b * 0.72, 0.14, 0, 0.04, 't_talon', 1.0);
        limb('l_leg', -a * 0.48, -b * 0.30,  b * 0.58, -a * 0.54, -st, b * 0.72, -0.14, 0, 0.04, 't_talon', 1.1);
        tailPut('s_spike', 1.2);
        break;
      // ---- mythical ------------------------------------------------------
      case 22: // scorpion""")

# ---------------------------------------------------------------- 4. only these are offered
s = sub1(s, """  { label: 'land', note: 'walks and runs. breathes air.',
    plans: [22, 25, 27, 23, 24, 26, 28, 1, 2, 8, 9, 0, 3, 4, 10, 11, 12, 13, 14, 15, 16, 17] },
  { label: 'air', note: 'wings: flight once they beat your weight.', plans: [5, 7, 18] },
  { label: 'sea', note: 'no legs: breathes water, starts in the sea and cannot come ashore without lungs.', plans: [29, 6, 19, 20, 21] },""",
"""  // Ten that walk and four that fly. The other sixteen plans are still in the
  // table -- renumbering would turn every saved design into a different
  // animal -- they are just not offered.
  { label: 'land', note: 'ten shapes. every one of them walks.',
    plans: [30, 31, 32, 33, 22, 23, 26, 27, 25, 24] },
  { label: 'air', note: 'wings. the moth has no legs at all and cannot enter a match.',
    plans: [34, 35, 18, 36] },""")
s = sub1(s, """                    'scorpion', 'stilt-walker', 'hydra', 'mantis', 'crab', 'brute', 'drifter', 'wyrm'];""",
"""                    'scorpion', 'stilt-walker', 'hydra', 'mantis', 'crab', 'brute', 'drifter', 'wyrm',
                    'lurker', 'maw', 'hollow', 'centipede', 'flit', 'mothwing', 'drake'];""")

open(p, 'w', encoding='utf-8').write(s)
print('bodies: designs and picker ok')
