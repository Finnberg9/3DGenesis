# =====================================================================
# SPAWNED IN THE AIR, AND THE CAGE FLOOR.
#
# 1. CRITICAL. Entering a match dropped you out of the sky and the landing
#    killed you. The fall tracker remembers the ground height under your last
#    position (`player._gWas`) and treats any drop in it as the ground falling
#    away beneath you -- which is what makes walking off a ledge a fall rather
#    than a teleport. Entering a match REBUILDS THE ISLAND and then puts you in
#    a cage on the ring, so the remembered height belongs to a world that no
#    longer exists. The difference between the two worlds was read as a fall
#    from that height, you were lifted into the air by it, and the landing
#    killed you. (It then read as "THE FOG KILLED YOU", because that was the
#    headline for any death with no killer.)
#
#    Fixed in two layers: the tracker is cleared explicitly wherever the player
#    is moved or the world is rebuilt, AND it notices by itself when the player
#    has moved further than anything could have walked, so a teleport added
#    later cannot bring the bug back.
#
# 2. The death screen names what actually killed you.
#
# 3. The cage floor is steel across the whole bay, not a plate on sand.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, (a[:100], n); return s.replace(a, b)
p = 'g3.html'; s = open(p, encoding='utf-8').read()

# ---------------------------------------------------------------- 1. the tracker
s = sub1(s, """// Water you fall into takes the impact, as long as it is deep enough to take
// the animal rather than just wet its feet.""",
"""// Forget where the ground was. Every discontinuous move of the player -- a
// match spawn, a respawn, a teleport, an island rebuilt under their feet --
// has to call this, or the height remembered from the old position is read as
// the ground dropping away by that much and the player is dropped from it.
function fallResetGround() {
  player.jumpY = 0; player.jumpV = 0; player.grounded = true;
  player._gWas = null; player._gAt = null; player._fallTop = null;
  if (player.c) player.c.jumpLv = 0;
}
// Water you fall into takes the impact, as long as it is deep enough to take
// the animal rather than just wet its feet.""")
s = sub1(s, """  const c = player.c;
  const gNow = groundAt(c.x, c.y);
  // The ground dropping away under you is a fall, not a teleport. Whatever it
  // dropped becomes height you are now standing on nothing above.
  if (player._gWas != null && player.grounded) {""",
"""  const c = player.c;
  const gNow = groundAt(c.x, c.y);
  // A move no animal could have made in this frame is a teleport, not a step,
  // and nothing about the ground it left behind means anything here. This
  // catches every way the player can be relocated, including ones added
  // later, so the tracker cannot be left holding another world's height.
  if (player._gAt) {
    const maxStep = Math.max(24, (c.ph.speedLand || 40) * 2.5 * dt + 8);
    if (Math.hypot(c.x - player._gAt[0], c.y - player._gAt[1]) > maxStep) {
      player._gWas = null; player._fallTop = null;
      player.jumpY = 0; player.jumpV = 0; player.grounded = true;
    }
  }
  // The ground dropping away under you is a fall, not a teleport. Whatever it
  // dropped becomes height you are now standing on nothing above.
  if (player._gWas != null && player.grounded) {""")
s = sub1(s, """    const drop = player._gWas - gNow;
    if (drop > walkDrop) { player.jumpY += drop; player.grounded = false; }
  }
  player._gWas = gNow;""",
"""    const drop = player._gWas - gNow;
    if (isFinite(drop) && drop > walkDrop) { player.jumpY += drop; player.grounded = false; }
  }
  player._gWas = gNow;
  player._gAt = [c.x, c.y];""")

# the seams, named explicitly rather than left to the heuristic
s = sub1(s, "  if (player.c) { player.c.x = bay.x; player.c.y = bay.z; player.c._spawnT = simT; }",
"""  if (player.c) { player.c.x = bay.x; player.c.y = bay.z; player.c._spawnT = simT; }
  // You are put down in your cage, not dropped into it.
  fallResetGround();""")
s = sub1(s, "  teleport(x, z) { if (player.c) { player.c.x = clamp(x, 1, WORLD_W - 1); player.c.y = clamp(z, 1, WORLD_H - 1); } player.camX = x; player.camZ = z; },",
            "  teleport(x, z) { if (player.c) { player.c.x = clamp(x, 1, WORLD_W - 1); player.c.y = clamp(z, 1, WORLD_H - 1); } player.camX = x; player.camZ = z; fallResetGround(); },")
s = sub1(s, """async function rebuildWorld() {
  running = false;""",
"""async function rebuildWorld() {
  running = false;
  // The ground under the player is about to become a different island.
  try { fallResetGround(); } catch (e) { /* before the player exists */ }""")
open(p, 'w', encoding='utf-8').write(s)
print('fall tracker reset ok')

# and once more when the world build has finished and the player has been placed
s = open(p, encoding='utf-8').read()
s = sub1(s, """function becomeDesigned(des, opts) {""",
"""function becomeDesigned(des, opts) {
  // A new body, usually somewhere else: nothing the old one knew about the
  // ground applies to it.
  try { fallResetGround(); } catch (e) { /* not yet playing */ }""")
open(p, 'w', encoding='utf-8').write(s)
print('becomeDesigned reset ok')

# ---------------------------------------------------------------- 2. the death screen
s = open(p, encoding='utf-8').read()
s = sub1(s, "    BR.deadChoice = { killer: killerSlot, t: BR.t };",
            "    BR.deadChoice = { killer: killerSlot, t: BR.t, cause: k ? null : (cause || 'the island') };")
s = sub1(s, """  el.innerHTML = '<h3>' + (k ? k.name.toUpperCase() + ' KILLED YOU' : 'THE FOG KILLED YOU') + '</h3>' +
    '<p>' + (k ? 'Join their pack and come back as their young: you fight for them, they cannot hurt you, and if they win, you win. Or watch the rest of the match.'
               : 'Nothing to join. The fog takes no packs.') + '</p>' +""",
"""  // Name what actually killed you. Everything with no killer used to be
  // reported as the fog, which meant a fall, a drowning or starvation all lied
  // about themselves.
  const CAUSE_HEAD = { fall: 'THE FALL KILLED YOU', drowned: 'YOU DROWNED', starved: 'YOU STARVED',
                       'the fog': 'THE FOG KILLED YOU', 'the island': 'THE ISLAND KILLED YOU' };
  const CAUSE_BODY = { fall: 'Nothing to join. The ground takes no packs.',
                       drowned: 'Nothing to join. The water takes no packs.',
                       starved: 'Nothing to join. Hunger takes no packs.',
                       'the fog': 'Nothing to join. The fog takes no packs.',
                       'the island': 'Nothing to join. The island takes no packs.' };
  const cz = dc.cause || 'the island';
  el.innerHTML = '<h3>' + (k ? k.name.toUpperCase() + ' KILLED YOU' : (CAUSE_HEAD[cz] || 'THE ISLAND KILLED YOU')) + '</h3>' +
    '<p>' + (k ? 'Join their pack and come back as their young: you fight for them, they cannot hurt you, and if they win, you win. Or watch the rest of the match.'
               : (CAUSE_BODY[cz] || 'Nothing to join. The island takes no packs.')) + '</p>' +""")
open(p, 'w', encoding='utf-8').write(s)
print('death cause ok')

# ---------------------------------------------------------------- 3. the cage floor
# The plate was exactly the cage's half-width, so it stopped at the inside of
# the bars and every bay had a ring of beach showing inside it and under the
# gate. It now runs out past the bars, and sits a shade proud of the pad so the
# two surfaces cannot fight over the same depth.
s = open(p, encoding='utf-8').read()
s = sub1(s, "  brBox(m, 0, -11, 0, R, 11, R, BR_PLATE, MAT_STEEL);",
"""  const FLOOR = R * 1.24;
  brBox(m, 0, -10.7, 0, FLOOR, 11, FLOOR, BR_PLATE, MAT_STEEL);
  // a raised kerb around the plate, so the floor reads as a built thing
  // sitting on the ground rather than a texture painted onto it
  for (const sx of [-1, 1]) {
    brBox(m, sx * FLOOR, 0.25, 0, 0.55, 0.55, FLOOR, BR_STEEL_D, MAT_STEEL);
    brBox(m, 0, 0.25, sx * FLOOR, FLOOR, 0.55, 0.55, BR_STEEL_D, MAT_STEEL);
  }""")
open(p, 'w', encoding='utf-8').write(s)
print('cage floor ok')

# ---------------------------------------------------------------- test surface
s = open(p, encoding='utf-8').read()
s = sub1(s, "    kill: (slot, by) => brOnPlayerKilled(slot, by),",
            "    kill: (slot, by, cause) => brOnPlayerKilled(slot, by, cause),\n    get slot() { return BR.slot; },\n    resetFall: () => fallResetGround(),")
open(p, 'w', encoding='utf-8').write(s)
print('spawn test surface ok')
