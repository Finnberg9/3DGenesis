# Skeletons left by the dead (src/remains.js), hooked to the core's death record.
def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
p='g3.html'; s=open(p,encoding='utf-8').read()
s=sub1(s,"  function recordDeath(world, c) {\n","  function recordDeath(world, c) {\n    if (typeof world.onDeath === 'function') { try { world.onDeath(c); } catch (e) { /* visuals must never break the sim */ } }\n")
s=sub1(s,"function stepSim(dt) {\n", open('src/remains.js',encoding='utf-8').read()+"\nfunction stepSim(dt) {\n")
s=sub1(s,"  world.hitFilter = fightHitFilter;","  world.hitFilter = fightHitFilter;\n  world.onDeath = onWorldDeath;")
s=sub1(s,"  drawFight(t);\n","  drawFight(t);\n  drawRemains(t);\n")
s=sub1(s,"  get GFX() { return GFX; },","  get REMAINS() { return REMAINS; }, remainsAdd: (c) => remainsAdd(c),\n  get GFX() { return GFX; },")
open(p,'w',encoding='utf-8').write(s)
print('remains ok')
