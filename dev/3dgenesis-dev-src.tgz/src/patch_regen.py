# =====================================================================
# HEALTH COMES BACK
#
# Ten seconds after the last thing that hurt you, health returns at 10 a
# second. Without it a match is a war of attrition decided by the first
# scrap you lost, and the whole point of the fog closing is to force the LAST
# fight to matter.
#
# The delay is a countdown on the body rather than a timestamp compared
# against a clock, because there are three clocks in this page (real time,
# simulation time and biological time) and a regeneration rule that reads the
# wrong one is a rule that behaves differently at different sim speeds. A
# countdown fed the same dt the movement gets cannot drift.
#
# It applies to everything alive, not just the player: a match where you
# regenerate and the other forty-nine do not is not a fight, it is a cheat.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, ('ANCHOR %d/%d' % (n, cnt), a[:110]); return s.replace(a, b)

p = 'g3.html'; s = open(p, encoding='utf-8').read()

s = sub1(s, """  function hpHeal(c, amt) {""",
"""  // ---- regeneration --------------------------------------------------------
  const HEAL_DELAY = 10;        // seconds after the last hit before it starts
  const HEAL_RATE = 10;         // health a second once it does
  // Every path that takes health off a body goes through hpHurt, so arming
  // the delay here means nothing can wound you without resetting it -- a fall,
  // the fog, drowning, a spike, a bite. One place, no exceptions to forget.
  function hpTick(c, dt) {
    if (!c || !c.alive || !(dt > 0)) return;
    if (c._healWait > 0) {
      // Spend the delay out of THIS frame's dt and heal with whatever is
      // left over, rather than throwing the remainder away. Dropping it made
      // the rate depend on the frame rate, and left a float residue on the
      // boundary that silently ate an extra tick.
      const use = Math.min(c._healWait, dt);
      c._healWait -= use;
      if (c._healWait < 1e-9) c._healWait = 0;
      dt -= use;
      if (!(dt > 0)) return;
    }
    const max = hpMaxC(c);
    if (hpOf(c) >= max) return;
    c.hp = Math.min(max, c.hp + HEAL_RATE * dt);
  }
  function hpHeal(c, amt) {""")
s = sub1(s, """  function hpHurt(c, dmg) {
    hpOf(c);
    c.hp -= Math.max(0, dmg || 0);""",
"""  function hpHurt(c, dmg) {
    hpOf(c);
    const d = Math.max(0, dmg || 0);
    if (d > 0) c._healWait = HEAL_DELAY;      // the clock restarts on every wound
    c.hp -= d;""")
# one call site, in the loop every living thing already goes through, so the
# player, the bots and the island's animals are all on the same rule
s = sub1(s, "      if (c.hurtT > 0) c.hurtT = Math.max(0, c.hurtT - dt);",
            "      if (c.hurtT > 0) c.hurtT = Math.max(0, c.hurtT - dt);\n      hpTick(c, dt);")
s = sub1(s, "    hpMaxOf, hpMaxC, hpOf, hpFrac, hpHurt, hpHeal, weaponQ, strikeDamage, counterDamage,",
            "    hpMaxOf, hpMaxC, hpOf, hpFrac, hpHurt, hpHeal, hpTick, HEAL_DELAY, HEAL_RATE,\n    weaponQ, strikeDamage, counterDamage,")

# the HUD says so, because a bar that starts moving on its own with no
# explanation reads as a bug
s = sub1(s, "      (p.canFly ? flightHud() : '') + swimHud() + spellHudHtml() +",
"""      (p.canFly ? flightHud() : '') + swimHud() +
      (c._healWait > 0 && C.hpFrac(c) < 0.999
        ? `<br><span style="color:#c98a7c">wounded &middot; healing in ${Math.ceil(c._healWait)}s</span>`
        : (C.hpFrac(c) < 0.999 ? '<br><span style="color:#8fbf7a">healing</span>' : '')) +
      spellHudHtml() +""")

open(p, 'w', encoding='utf-8').write(s)
print('regen ok')
