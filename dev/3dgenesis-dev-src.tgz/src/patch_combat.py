# Combat: a creature under attack cannot eat or heal for 5 s after the last
# hit; herbivores flee their attacker, carnivores turn and fight back.
def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
s=open('g3.html',encoding='utf-8').read()
s=sub1(s,"""  function resolveAttack(world, att, prey, flags) {
    const a = att.ph, d = prey.ph;
    let dmg = a.attack - d.defense * 0.6; if (dmg <= 0) dmg = 1;
    prey.energy -= dmg;""","""  // ---- being attacked ---------------------------------------------------
  const HURT_TIME = 5;      // seconds after the last hit during which nothing can be eaten
  const FOE_TIME = 7;       // how long a victim keeps reacting to its attacker
  function onHit(victim, attacker, dmg) {
    if (!victim || !attacker) return;
    victim.hurtT = HURT_TIME;
    victim.foe = attacker; victim.foeT = FOE_TIME;
    // meat eaters turn and fight; everything else runs
    victim.react = (victim.ph.carnivory > 0.5) ? 'fight' : 'flee';
    victim._hitSeq = (victim._hitSeq || 0) + 1;
    victim._lastDmg = dmg || 0; victim._lastHitBy = attacker;
    attacker._strikeSeq = (attacker._strikeSeq || 0) + 1;
  }
  // A cornered carnivore's counter-attack. Floored at a slice of the target's
  // own reserve (scaled by size ratio) so a fight back is a real threat, not
  // the 1-damage trickle of the plain exchange.
  function retaliate(world, att, foe, flags) {
    const a = att.ph, d = foe.ph;
    const ratio = clamp(a.mass / Math.max(0.01, d.mass), 0.15, 2.5);
    const dmg = Math.max(a.attack - d.defense * 0.6, d.storage * 0.03 * ratio, 1);
    foe.energy -= dmg;
    att.energy -= (d.counter || 0) * 0.5; if (att.energy < 0) att.energy = 0;
    onHit(foe, att, dmg);
    if (foe.energy <= 0 && foe.alive) {
      foe.alive = false; foe.deathCause = 'predation'; recordDeath(world, foe);
      if (!(att.hurtT > 0)) att.energy = Math.min(a.storage, att.energy + Math.max(6, (d.mass * 8) * 0.6));
    }
  }
  function resolveAttack(world, att, prey, flags) {
    const a = att.ph, d = prey.ph;
    let dmg = a.attack - d.defense * 0.6; if (dmg <= 0) dmg = 1;
    prey.energy -= dmg;
    onHit(prey, att, dmg);""")
s=sub1(s,"""      const gain = (d.mass * 8 + Math.max(0, prey.energy + d.mass * 2)) * 0.6;
      att.energy = Math.min(a.storage, att.energy + Math.max(6, gain));""","""      const gain = (d.mass * 8 + Math.max(0, prey.energy + d.mass * 2)) * 0.6;
      if (!(att.hurtT > 0)) att.energy = Math.min(a.storage, att.energy + Math.max(6, gain));""")
# timers
s=sub1(s,"""      const p = c.ph; c.cooldown = Math.max(0, c.cooldown - dt); c.reproCD = Math.max(0, c.reproCD - bdt); c.age += bdt;""",
"""      const p = c.ph; c.cooldown = Math.max(0, c.cooldown - dt); c.reproCD = Math.max(0, c.reproCD - bdt); c.age += bdt;
      if (c.hurtT > 0) c.hurtT = Math.max(0, c.hurtT - dt);
      if (c.foe) { c.foeT -= dt; if (c.foeT <= 0 || !c.foe.alive) { c.foe = null; c.react = null; } }""")
# steering: react to the attacker above every other desire
s=sub1(s,"""      let dirx = _dx, diry = _dy;

      // resolve hunting""","""      if (c.foe) {
        const fx = c.foe.x - c.x, fy = c.foe.y - c.y;
        if (c.react === 'fight') addDir(fx, fy, 4.2);
        else addDir(-fx, -fy, 5.0);
      }
      let dirx = _dx, diry = _dy;

      // resolve hunting""")
s=sub1(s,"""      // forage consume (plant or carrion)
      if (bestFood) {""","""      // fight back
      if (c.foe && c.react === 'fight' && c.cooldown <= 0 && c.foe.alive) {
        const fdx = c.foe.x - c.x, fdy = c.foe.y - c.y;
        const rr = p.radius + c.foe.ph.radius + reachEff + 10;
        if (fdx * fdx + fdy * fdy < rr * rr) { retaliate(world, c, c.foe, flags); c.cooldown = 0.9; }
      }
      // forage consume (plant or carrion) -- never while under attack
      if (bestFood && !(c.hurtT > 0)) {""")
s=sub1(s,"(c.fear > 0.3 ? 1.15 : 1) * tMul;","(c.fear > 0.3 ? 1.15 : 1) * (c.foe && c.react === 'flee' ? 1.2 : 1) * tMul;")
s=sub1(s,"""    makeRNG, gauss, clamp, PART,""","""    onHit, HURT_TIME,
    makeRNG, gauss, clamp, PART,""")
# ---- player side
s=sub1(s,"""  // the thing you hit flinches
  startAnim(best, 'flinch', 0.35);
  best.energy -= dmg;""","""  // the thing you hit flinches, and remembers you
  startAnim(best, 'flinch', 0.35);
  best.energy -= dmg;
  C.onHit(best, c, dmg);""")
s=sub1(s,"""  best.alive = false; best.deathCause = 'predation';
  const gain = (best.ph.mass * 8 + best.ph.mass * 2) * 0.6;
  c.energy = Math.min(p.storage, c.energy + Math.max(6, gain));""","""  best.alive = false; best.deathCause = 'predation';
  const gain = (best.ph.mass * 8 + best.ph.mass * 2) * 0.6;
  if (c.hurtT > 0) toast('Killed it, but you are still under attack and cannot feed on it.', 2400);
  else c.energy = Math.min(p.storage, c.energy + Math.max(6, gain));""")
s=sub1(s,"""function tryEat() {
  const c = player.c;
  if (!c || !c.alive) return;""","""function tryEat() {
  const c = player.c;
  if (!c || !c.alive) return;
  if (c.hurtT > 0) { toast('Under attack: you cannot eat for another ' + c.hurtT.toFixed(1) + ' s.', 1400); return; }""")
# feedback when something hits you, and strike animations for attackers
s=sub1(s,"""  world.step(dt);
  if (alive && c.alive) {""","""  world.step(dt);
  if (c && c._hitSeq !== player._seenHit) {
    const by = c._lastHitBy;
    if (player._seenHit != null && c.alive && by) {
      startAnim(c, 'flinch', 0.35);
      const diet = by.ph.carnivory > 0.5 ? 'a carnivore' : 'an animal';
      toast('Hit by ' + diet + ' for ' + (c._lastDmg || 0).toFixed(0) + '. You cannot eat for 5 s.', 1600);
    }
    player._seenHit = c._hitSeq;
  }
  if (alive && c.alive) {""")
s=sub1(s,"""function drawCreature(c, t, camDist) {
  const p = c.ph;""","""function drawCreature(c, t, camDist) {
  const p = c.ph;
  if (c._strikeSeq !== c._seenStrike) {
    if (c._seenStrike != null && c !== player.c) startAnim(c, bestMove(p, tallyParts(p)), 0.5);
    c._seenStrike = c._strikeSeq;
  }""")
open('g3.html','w',encoding='utf-8').write(s)
print('combat ok')
