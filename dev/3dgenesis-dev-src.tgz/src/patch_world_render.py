def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
p='g3.html'; s=open(p,encoding='utf-8').read()
# Doubled on each axis (four times the area). Viable because the terrain is
# chunked and culled now: see patch_chunk.py. Without that this would be 5.7M
# triangles drawn every frame.
s=sub1(s,"const WORLD_W = 12800, WORLD_H = 8000, TILE = 48;","const WORLD_W = 51200, WORLD_H = 32000, TILE = 48;")
s=sub1(s,"const HEIGHT_SCALE = 420;","const HEIGHT_SCALE = 2000;")
# 28 rather than 24: on a map four times the area that is a 17% coarser
# silhouette for a 27% cut in triangles, and the terrain shader adds its own
# fine detail (fbm bump, rock strata) on top of the mesh anyway.
s=sub1(s,"const GRID_STEP = 16; ","const GRID_STEP = 28; ")
s=sub1(s,"const FAR = 5200; ","const FAR = 14000;")
s=sub1(s,"const NEAR = 0.6;","const NEAR = 1.0;")
s=sub1(s,"const FOG_DENSITY = 1 / 2600;","const FOG_DENSITY = 1 / 6600;")
s=sub1(s,"const FLY_CLIMB = 190; ","const FLY_CLIMB = 320; ")
s=sub1(s,"const FLY_CEIL = 620; ","const FLY_CEIL = 1500;")
s=sub1(s,"const THIRD_MAX = 1200,","const THIRD_MAX = 1600,")
s=sub1(s,"player.camY = 600; player.spectator = true;","player.camY = 2600; player.spectator = true;")
s=sub1(s,"{ w: WORLD_W, h: WORLD_H, tileSize: TILE, seed }","{ w: WORLD_W, h: WORLD_H, tileSize: TILE, seed, featureScale: 2, heightScale: HEIGHT_SCALE, maxSlope: 1, baseRelief: 0.35, plantArea: 0.5 }",2)
open(p,'w',encoding='utf-8').write(s)
print('world render ok')
s=open(p,encoding='utf-8').read()
s=sub1(s,"const NEARR = TREE_LOD * TREE_LOD, FARR = 3000 * 3000;","const NEARR = TREE_LOD * TREE_LOD, FARR = 3600 * 3600;")
open(p,'w',encoding='utf-8').write(s)
