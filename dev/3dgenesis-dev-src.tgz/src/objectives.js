// =====================================================================
// OBJECTIVES: a chain of goals that gives a life on the island a direction.
// One goal is active at a time; finishing it pays out permanent genome space
// and reveals the next. The chain runs from surviving your first days to
// making your species rule the island.
// =====================================================================
const OBJ_REWARD = 2;          // genome space per completed goal (kept across worlds)
const OBJS = { idx: 0, c: { eaten: 0, kills: 0, predKills: 0, bigKills: 0, nights: 0 }, startGen: 0, startUnlocked: 0, high: false, wasNight: false, doneAll: false, shown: -1 };
function objSpeciesRank() {
  const c = player.c; if (!c || !world) return { mine: 0, top: 0 };
  const m = new Map();
  for (const o of world.creatures) if (o.alive) m.set(o.speciesId, (m.get(o.speciesId) || 0) + 1);
  let top = 0; for (const v of m.values()) top = Math.max(top, v);
  return { mine: m.get(c.speciesId) || 0, top };
}
const OBJ_LIST = [
  { title: 'Feed', text: 'Eat five times. Plants, fruit, or the dead.', goal: 5, val: () => OBJS.c.eaten },
  { title: 'Grow', text: 'Survive long enough to reach full size.', goal: 1, val: () => (player.c ? clamp((player.c._growthAvg || 0) / 0.95, 0, 1) : 0) },
  { title: 'First blood', text: 'Kill another animal.', goal: 1, val: () => OBJS.c.kills },
  { title: 'Endure the dark', text: 'Live through a whole night.', goal: 1, val: () => OBJS.c.nights },
  { title: 'Adapt', text: 'Take four new body parts from your kills.', goal: 4, val: () => PROG.unlocked.size - OBJS.startUnlocked },
  { title: 'Continue the line', text: 'Mate, and live on as your offspring.', goal: 1, val: () => player.generation - OBJS.startGen },
  { title: 'Above the canopy', text: 'Reach the bare rock high on a mountain.', goal: 1, val: () => (OBJS.high ? 1 : 0) },
  { title: 'Hunt the hunter', text: 'Kill a meat eater.', goal: 1, val: () => OBJS.c.predKills },
  { title: 'Giant slayer', text: 'Kill three animals heavier than you.', goal: 3, val: () => OBJS.c.bigKills },
  { title: 'Dynasty', text: 'Reach the fifth generation of your line.', goal: 5, val: () => player.generation - OBJS.startGen },
  { title: 'Apex', text: 'Make your species the most numerous on the island (at least 12 alive).', goal: 1,
    val: () => { const r = objSpeciesRank(); return r.mine >= 12 && r.mine >= r.top ? 1 : Math.min(0.95, r.mine / Math.max(12, r.top)); } },
];
function objReset() {
  OBJS.idx = 0; OBJS.c = { eaten: 0, kills: 0, predKills: 0, bigKills: 0, nights: 0 };
  OBJS.startGen = player.generation || 0; OBJS.startUnlocked = PROG.unlocked.size; OBJS.high = false; OBJS.wasNight = false; OBJS.doneAll = false; OBJS.shown = -1;
  objRender();
}
function objOnEat() { OBJS.c.eaten++; }
function objOnKill(prey) {
  OBJS.c.kills++;
  if (prey && prey.ph && prey.ph.carnivory > 0.5) OBJS.c.predKills++;
  if (prey && prey.ph && player.c && player.c.ph && prey.ph.mass > player.c.ph.mass) OBJS.c.bigKills++;
}
let objAcc = 0;
function objTick(dt) {
  objAcc += dt; if (objAcc < 0.4) return; objAcc = 0;
  const c = player.c;
  if (!c || !c.alive || !world || player.spectator) return;
  if (OBJS.world !== world) { OBJS.world = world; objReset(); }
  // world events watched here rather than hooked
  const night = (world.light != null ? world.light : 1) < 0.22;
  if (OBJS.wasNight && (world.light || 0) > 0.55) { OBJS.c.nights++; OBJS.wasNight = false; }
  if (night) OBJS.wasNight = true;
  if (!OBJS.high) { const e = terrain.height(c.x, c.y); if (e >= terrain.LV.rock || terrain.biomeAt(c.x, c.y) === 'scree' || terrain.biomeAt(c.x, c.y) === 'snow') OBJS.high = true; }
  if (OBJS.doneAll) return;
  const o = OBJ_LIST[OBJS.idx];
  if (o.val() >= o.goal) {
    PROG.bonus = (PROG.bonus || 0) + OBJ_REWARD; saveProgress();
    toast('Goal complete: ' + o.title + '. +' + OBJ_REWARD + ' genome space.', 4200);
    OBJS.idx++;
    if (OBJS.idx >= OBJ_LIST.length) { OBJS.doneAll = true; OBJS.idx = OBJ_LIST.length - 1; toast('Your kind rules the island.', 6000); }
  }
  objRender();
}
function objRender() {
  let el = document.getElementById('objective');
  if (!el) {
    el = document.createElement('div'); el.id = 'objective';
    document.body.appendChild(el);
    const st = document.createElement('style');
    st.textContent = '#objective{position:fixed;top:14px;left:50%;transform:translateX(-50%);min-width:360px;max-width:560px;padding:10px 18px 12px;border-radius:14px;' +
      'background:linear-gradient(180deg,rgba(8,20,18,.78),rgba(4,12,12,.82));border:1px solid rgba(120,170,140,.35);color:#d8efe4;font:14px ui-monospace,Menlo,Consolas,monospace;pointer-events:none;z-index:40;text-align:center}' +
      '#objective .ot{font-size:12px;letter-spacing:.14em;text-transform:uppercase;color:#9fd8b8}#objective .ox{margin-top:4px;font-size:15px}' +
      '#objective .ob{margin:8px auto 0;height:6px;border-radius:3px;background:rgba(255,255,255,.08);overflow:hidden;max-width:320px}#objective .ob i{display:block;height:100%;background:linear-gradient(90deg,#6fbf8f,#d8f0a0)}' +
      '#objective .on{margin-top:4px;font-size:12px;color:#9fb8ac}';
    document.head.appendChild(st);
  }
  if (!started || !player.c || ED.open) { el.style.display = 'none'; return; }
  const o = OBJ_LIST[OBJS.idx];
  const v = clamp(o.val() / o.goal, 0, 1);
  el.style.display = 'block';
  el.innerHTML = OBJS.doneAll ? '<div class="ot">all goals complete</div><div class="ox">Your kind rules the island.</div>'
    : `<div class="ot">goal ${OBJS.idx + 1} / ${OBJ_LIST.length} &middot; ${o.title}</div><div class="ox">${o.text}</div>` +
      `<div class="ob"><i style="width:${(v * 100).toFixed(0)}%"></i></div>` +
      (o.goal > 1 ? `<div class="on">${Math.min(o.goal, Math.floor(o.val()))} / ${o.goal}</div>` : '');
}
