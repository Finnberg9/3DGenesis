# THE DRAGON, THE FLOWER-FACE, AND THE RELIEF THAT WAS UNDER A PIXEL
#
# Three things owed from the 2026-09-25 (late) session, in the order they were
# owed, plus the global wetness hook.
#
#  1. The sire has failed to read as a dragon for three sessions. Looking at the
#     full-viewport render rather than the 192 px tile finally says why: the
#     neck is a STRAIGHT ray of eight balls from shoulder to skull. Length is
#     not the problem. A single unbroken curve from body to head is what the eye
#     calls a bird, and no amount of extra length changes the classification --
#     it just makes a longer bird. A dragon's neck reverses curvature: up and
#     back out of the shoulder, then forward and down into the skull. That is
#     two arcs, and the count of arcs is the cue (rule S1: the silhouette is
#     read as a class before it is read as a shape).
#     `narc` bows the chain one way over its first half and the other way over
#     its second, leaving both ENDS exactly where they were, so every part
#     anchor still finds the head where it expects it.
#
#  2. Bloom's mandible reads as detached because the petals are three times the
#     size of the skull behind them, so there is no head for them to be part
#     of -- and because nothing joins them: they begin in free air at the part
#     origin. A base collar fixes the join for every user of m_bloom; the head
#     has to grow and the mouth has to shrink for the proportion.
#     Its legs were 0.95 units long and 1.55 thick under a body of radius 0.88:
#     buried. Longer, thinner, and further out.
#
#  3. `ribs` is real in the field and invisible in the mesh. The marching grid
#     step is chosen from the thinnest limb, which on a ribbed torso gives about
#     two cells per rib -- and two cells cannot carry a notch. The fix is a per
#     design grid multiplier, so a high-`ribs` plan is meshed on a finer lattice
#     and only that plan pays for it.
#
#  4. wetness was purely per-covering, so a scaled animal was exactly as wet at
#     midnight in the rain as at noon in a drought. fogCol.w was dead (every
#     shader reads fogCol.rgb), so it becomes the global wetness channel: dew at
#     night and near water in the world, and a standing film in the builder so
#     the skin can actually be judged. Fur sheds it, plate holds a film, bare
#     dermis soaks -- so the global term is weighted by covering, not added flat.
import re, sys
p = 'g3.html'
s = open(p, encoding='utf-8').read()
def sub1(t, a, b):
    if t.count(a) != 1:
        print('SIRE PATCH: anchor %r found %d times' % (a[:70], t.count(a))); sys.exit(1)
    return t.replace(a, b, 1)

# ---------------------------------------------------------------- 1. narc
s = sub1(s, """    for (let i = 1; i <= P.ns; i++) {
      const u = i / (P.ns + 1);
      // Thickness comes off the BODY, not a flat 0.34: on a big animal a
      // constant-width neck vanishes, which is why the long-necked plans all
      // rendered as a snout stuck on a log.
      const r = neckLen > 0.12 ? (0.30 + 0.55 * b) * (1 - 0.34 * u) * (1 + NK * 0.10) : 0.0001;
      balls.push({ x: nx0 + (hx - nx0) * u, y: ny0 + (hy - ny0) * u, z: 0, r, g: 'neck', hide: neckLen <= 0.12 });
    }""",
r"""    // ---- narc: the neck is an S, not a ray ---------------------------------
    // A straight chain of balls from shoulder to skull reads as a bird at any
    // length, because the eye classifies on the NUMBER OF ARCS before it looks
    // at proportion. One arc is a swan. Two is a dragon. narc bows the chain
    // one way over its first half and back over its second; both endpoints are
    // untouched, so the head lands exactly where every part anchor, the bite
    // reach and the look-at code already expect it, and narc 0 reproduces the
    // old straight neck to the byte.
    // neckR thickens the whole chain and neckTap sets how fast it narrows into
    // the skull: a heavy animal needs a neck that is visibly carrying the head,
    // and a constant-width tube reads as a hose.
    const narc = P.narc || 0;
    const ntap = P.neckTap == null ? 0.34 : P.neckTap;
    const nRm = P.neckR == null ? 1 : P.neckR;
    const ndx = hx - nx0, ndy = hy - ny0;
    const nlen = Math.hypot(ndx, ndy) || 1;
    const npx = -ndy / nlen, npy = ndx / nlen;      // perpendicular, in the body plane
    for (let i = 1; i <= P.ns; i++) {
      const u = i / (P.ns + 1);
      // Thickness comes off the BODY, not a flat 0.34: on a big animal a
      // constant-width neck vanishes, which is why the long-necked plans all
      // rendered as a snout stuck on a log.
      const r = neckLen > 0.12 ? (0.30 + 0.55 * b) * (1 - ntap * u) * (1 + NK * 0.10) * nRm : 0.0001;
      const bow = narc * nlen * 0.42 * Math.sin(2 * Math.PI * u);
      balls.push({ x: nx0 + ndx * u + npx * bow, y: ny0 + ndy * u + npy * bow, z: 0, r, g: 'neck', hide: neckLen <= 0.12 });
    }""")

# ---------------------------------------------------------------- 2. tailBase
# A tail that leaves the hips at the same width it ends is a rope. Mass at the
# root is what makes it read as the counterweight of a big animal, and it is
# also the only thing that lets a long tail survive foreshortening: the near
# third stays legible when the far two thirds have collapsed to a line.
s = sub1(s, "      const r = tl > 0.05 ? Math.max(0.03, tr0 * (1 - 0.78 * u)) : 0.0001;",
r"""      // tailTap: how fast the tail loses width along its length. 0.78 is the
      // old fixed value. A whip wants it high; a counterweight wants it low,
      // because a tail that has thinned to a thread by half its length has no
      // mass left to read as mass however long it is.
      const ttap = P.tailTap == null ? 0.78 : P.tailTap;
      const troot = 1 + (P.tailBase || 0) * Math.exp(-(u / 0.34) * (u / 0.34));
      const r = tl > 0.05 ? Math.max(0.03, tr0 * (1 - ttap * u) * troot) : 0.0001;""")

# ---------------------------------------------------------------- 3. the sire
OLD46 = ("{ a: 1.02, b: 0.86, seg: 11, prof: 'animal', arch: 0.42, droop: 0.04, wide: 0.26, "
         "neck: 1.95, nx: 0.56, ny: 0.72,  ns: 8, head: 0.46, snx: 1.20, snr: 0.40, "
         "tail: 2.2, tailR: 0.30, ts: 11, stand: 1.95, hump: 0.80, waist: 0.22, waistAt: 0.30, "
         "crook: 0.25, view: [0.26, 0.30, 0.92] , blend: 0.52, ribs: 0.24, keel: 0.78}")
NEW46 = ("{ a: 1.00, b: 0.94, seg: 11, prof: 'animal', arch: 0.46, droop: 0.04, wide: 0.30, "
         "neck: 1.30, nx: 0.50, ny: 0.66,  ns: 8, head: 0.54, snx: 1.30, snr: 0.46, "
         "tail: 3.0, tailR: 0.36, ts: 11, stand: 1.85, hump: 0.78, waist: 0.20, waistAt: 0.30, "
         "crook: 0.20, narc: 0.40, neckR: 1.45, neckTap: 0.54, tailBase: 1.35, tailTap: 0.52, "
         "view: [0.58, 0.26, 0.77] , blend: 0.52, ribs: 0.24, keel: 0.86}")
s = sub1(s, OLD46, NEW46)

# ---------------------------------------------------------------- 4. bloom
OLD38 = ("{ a: 1.00, b: 0.88, seg: 11, prof: 'animal', arch: 0.34, droop: 0.02, wide: 0.58, "
         "neck: 0.52, nx: 0.94, ny: -0.26, ns: 2, head: 0.64, snx: 1.05, snr: 0.62, "
         "tail: 0.0, tailR: 0.14, ts: 4, stand: 1.32, hump: 0.78, waist: 0.16, waistAt: 0.22, "
         "crook: 0.5 , blend: 0.45, ribs: 0.20, keel: 0.38}")
NEW38 = ("{ a: 1.00, b: 0.88, seg: 11, prof: 'animal', arch: 0.34, droop: 0.02, wide: 0.58, "
         "neck: 0.76, nx: 0.96, ny: -0.18, ns: 2, head: 0.86, snx: 0.72, snr: 0.74, "
         "tail: 0.0, tailR: 0.14, ts: 4, stand: 2.05, hump: 0.78, waist: 0.16, waistAt: 0.22, "
         "crook: 0.5 , blend: 0.45, ribs: 0.20, keel: 0.38}")
s = sub1(s, OLD38, NEW38)

# the mouth was 1.35 on a base size of 1.05, against a skull of 0.64: the petals
# were three times the head and there was nothing for them to belong to.
s = sub1(s, """        eyeAt('e_pit', 0.9, 0.80, -0.10, 0.34);
        mouthAt('m_bloom', 2.60);""",
         """        eyeAt('e_pit', 0.9, 0.72, -0.05, 0.40);
        mouthAt('m_bloom', 1.15);""")
# legs: 0.95 long and 1.55 thick under a body of radius 0.88 is a stump. The
# stand is 2.05 now, so give them the reach and take the bulk off.
s = sub1(s,
  """        limb('l_thick',  a * 0.40, -b * 0.42,  b * 0.66,  a * 0.50, -st, b * 0.88, 0.08, 0.06, 0.04, 't_pad', 1.55);
        limb('l_thick', -a * 0.34, -b * 0.42,  b * 0.62, -a * 0.44, -st, b * 0.84, -0.08, 0.06, 0.04, 't_pad', 1.35);""",
  """        limb('l_thick',  a * 0.44, -b * 0.30,  b * 0.70,  a * 0.62, -st, b * 1.06, 0.30, 0.10, 0.10, 't_pad', 1.02);
        limb('l_thick', -a * 0.36, -b * 0.30,  b * 0.66, -a * 0.52, -st, b * 1.00, -0.26, 0.10, 0.10, 't_pad', 0.86);""")

# ---------------------------------------------------------------- 5. the collar
# Whatever its size, the mandible began in free air at the part origin. A short
# collar of hard plate around the base, sunk back toward the skull, is what
# turns four blades in front of a head into a head that opens.
s = sub1(s, """      // the throat behind them: soft, short, and it does not grow when they open
      g.sp(-0.02, 0.30, 0, 0, 1, 0, 0.19, 0.26, 0.19, lip);""",
r"""      // The collar. Sunk BACK from the part origin so it overlaps the snout it
      // is mounted on: without it the four blades hang in free air in front of
      // a head, which is what "the mandible looks detached" means.
      for (let i = 0; i < 6; i++) {
        const an = (i / 6) * Math.PI * 2;
        const cy = 0.30 + Math.sin(an) * 0.26, cz = Math.cos(an) * 0.26;
        g.sp(-0.26, cy, cz, 1, 0, 0, 0.15, 0.24, 0.15, colMul(hard, 0.88));
      }
      g.ball(-0.34, 0.30, 0, 0.26, colMul(hard, 0.80));
      // the throat behind them: soft, short, and it does not grow when they open
      g.sp(-0.02, 0.30, 0, 0, 1, 0, 0.19, 0.26, 0.19, lip);""")

# ---------------------------------------------------------------- 6. the grid
# A rib 0.2 deep needs more than two cells across it or the marcher rounds it
# away. The step is picked from the thinnest LIMB, which has nothing to do with
# the torso's relief, so a ribbed plan needs its own multiplier -- and only a
# ribbed plan pays the triangle count for it.
s = sub1(s, "function meshPrims(prims, quality) {",
            "function meshPrims(prims, quality, fine) {")
s = sub1(s, """  const maxCells = [64, 96, 124][clamp(quality | 0, 0, 2)], minCells = [36, 48, 56][clamp(quality | 0, 0, 2)];
  let step = minR * (quality >= 2 ? 0.5 : quality ? 0.6 : 0.8);""",
r"""  // `fine` (1 = unchanged) shrinks the cell for designs whose surface carries
  // relief the limb radius knows nothing about. The cell caps move with it, or
  // the clamp below immediately undoes the refinement.
  const F2 = Math.min(Math.max(+fine || 1, 1), 1.7);
  const maxCells = [64, 96, 124][clamp(quality | 0, 0, 2)] * F2, minCells = [36, 48, 56][clamp(quality | 0, 0, 2)] * F2;
  let step = minR * (quality >= 2 ? 0.5 : quality ? 0.6 : 0.8) / F2;""")
# main-thread and worker paths both carry it
s = sub1(s, "  try { m = meshPrims(d.prims, d.q); } catch (x) { err = String((x && x.stack) || x); }",
            "  try { m = meshPrims(d.prims, d.q, d.fine); } catch (x) { err = String((x && x.stack) || x); }")
s = sub1(s, "  try { m = meshPrims(creaturePrims(des, G), quality); } catch (e) { console.error(e); m = null; }",
r"""  let pr0 = null;
  try { pr0 = creaturePrims(des, G); } catch (e) { console.error(e); }
  try { m = pr0 ? meshPrims(pr0, quality, pr0.fine) : null; } catch (e) { console.error(e); m = null; }""")
s = sub1(s, "    slot.w.postMessage({ id, prims, q: job.q });",
            "    slot.w.postMessage({ id, prims, q: job.q, fine: prims.fine || 1 });")
# and creaturePrims declares it
s = sub1(s, """  // part flesh
  const mouth = mouthPart(des);""",
r"""  // How much relief this body carries that the grid would otherwise miss. A
  // rib notch is a fraction of the torso radius, and the step is sized off the
  // thinnest limb, so the two are unrelated and ribs has to ask for its own.
  out.fine = 1 + 1.6 * Math.min(0.42, (sk.plan && sk.plan.ribs) || 0) + 0.28 * ((sk.plan && sk.plan.keel) ? 1 : 0);
  // part flesh
  const mouth = mouthPart(des);""")

# ---------------------------------------------------------------- 7. global wet
# fogCol.w was dead in every shader. It is the global surface wetness now.
s = sub1(s, """  var wet = 1.0;            // how much fluid this covering carries, 0..1""",
r"""  var wet = 1.0;            // how much fluid this covering carries, 0..1
  var shed = 1.0;           // how much of the WORLD's wetness this covering keeps""")
s = sub1(s, "    aniso = 0.62; wet = 1.0; cavity = smoothstep(0.0, 0.22, sh.y);",
            "    aniso = 0.62; wet = 1.0; shed = 1.0; cavity = smoothstep(0.0, 0.22, sh.y);")
s = sub1(s, "    amp = 0.035; gloss = 0.55; fuzz = 0.25; aniso = 0.35; wet = 0.30; cavity = smoothstep(0.0, 0.3, sh.y);",
            "    amp = 0.035; gloss = 0.55; fuzz = 0.25; aniso = 0.35; wet = 0.30; shed = 0.55; cavity = smoothstep(0.0, 0.3, sh.y);")
s = sub1(s, "    amp = 0.012; gloss = 0.25; fuzz = 0.55; aniso = 0.0; wet = 0.12; cavity = 1.0;",
            "    amp = 0.012; gloss = 0.25; fuzz = 0.55; aniso = 0.0; wet = 0.12; shed = 0.30; cavity = 1.0;")
s = sub1(s, "    amp = 0.1; gloss = 2.2; aniso = 0.18; wet = 0.85; cavity = smoothstep(0.0, 0.055, e);",
            "    amp = 0.1; gloss = 2.2; aniso = 0.18; wet = 0.85; shed = 0.90; cavity = smoothstep(0.0, 0.055, e);")
s = sub1(s, "    amp = 0.012; gloss = 1.0; aniso = 0.0; wet = 1.0; cavity = 0.5 + h;",
            "    amp = 0.012; gloss = 1.0; aniso = 0.0; wet = 1.0; shed = 1.0; cavity = 0.5 + h;")
s = sub1(s, "  let wetLevel = clamp(wet * (0.55 + 0.45 * pool), 0.0, 1.0);",
r"""  // The world's own wetness -- dew, night, standing water, and the builder's
  // display film -- weighted by what this covering does with fluid. Fur sheds
  // it, plate holds a film, bare dermis soaks. It can only ever ADD, so a
  // covering that is already wet by nature is unchanged.
  let wetW = clamp(g.fogCol.w, 0.0, 1.0) * shed;
  let wetC = max(wet, wetW);
  let wetLevel = clamp(wetC * (0.55 + 0.45 * pool), 0.0, 1.0);""")

# gArr[27] carries it. In the world: dew that builds through the night and burns
# off with the light, plus a lift near standing water. In the builder: a steady
# film, because the skin cannot be judged dry.
s = sub1(s, "  gArr[24] = fog[0]; gArr[25] = fog[1]; gArr[26] = fog[2]; gArr[27] = 1;",
r"""  gArr[24] = fog[0]; gArr[25] = fog[1]; gArr[26] = fog[2];
  // Global surface wetness. Dew condenses once the light goes and burns off as
  // it returns, the canopy holds what falls through it, and anything standing
  // near open water is in the damp. world.wet, when a weather system sets it,
  // overrides upward and never downward.
  {
    const dew = Math.pow(1 - clamp(lt2, 0, 1), 1.3) * 0.62 + can * 0.14;
    const nearWater = clamp((terrain.LV.water * HEIGHT_SCALE + 2.5 - player.camY) * 0.22, 0, 0.30);
    gArr[27] = clamp(Math.max(dew + nearWater, +world.wet || 0), 0, 1);
  }""")
s = sub1(s, "  gArr[24] = 0.52; gArr[25] = 0.60; gArr[26] = 0.52; gArr[27] = 1;",
            "  gArr[24] = 0.52; gArr[25] = 0.60; gArr[26] = 0.52; gArr[27] = 0.55;")

open(p, 'w', encoding='utf-8').write(s)
print('sire: narc, tailBase, bloom, collar, grid, global wet ok')

# ---------------------------------------------------------------- 8. the wing
# The sire's body got deeper (b 0.86 -> 0.94, wide 0.26 -> 0.30), which swallowed
# the wing root: the membrane panels ended up inside the torso and only the
# leading spar came out of it. Mount it further out and higher, so the four
# panels clear the shoulder and the hand is readable from the front quarter.
s = open(p, encoding='utf-8').read()
s = sub1(s, "        put('w_bat', a * 0.08, b * 0.76, b * 0.50, 0, 0.7, 0.72, 3.6, true);",
            "        put('w_bat', a * 0.10, b * 0.86, b * 0.80, 0, 0.94, 0.34, 3.6, true);")
open(p, 'w', encoding='utf-8').write(s)
print('sire: wing clears the shoulder ok')

# ---------------------------------------------------------------- 9. the jaw
# The last thing on the sire that was fighting the word "dragon" was its mouth.
# m_bloom is the flower-face: four unlatching mandibles. It is the right mouth
# for the bloom and it is an ALIEN cue wherever else it lands, because the one
# thing every reading of a dragon has in common is a long hinged jaw with teeth
# down it. m_rex is that jaw, and the sire is the plan with the skull to carry
# it. (m_bloom stays in the game and stays on the bloom and the husk.)
s = open(p, encoding='utf-8').read()
s = sub1(s, """      case 46: // SIRE. Short body, long neck, long tail, and a real wing on it.
        eyeAt('e_slit', 0.95, 0.48, 0.34, 0.56);
        mouthAt('m_bloom', 1.05);""",
r"""      case 46: // SIRE. Short body, long neck, long tail, and a real wing on it.
        eyeAt('e_slit', 0.95, 0.52, 0.30, 0.58);
        mouthAt('m_rex', 1.10);""")
open(p, 'w', encoding='utf-8').write(s)
print('sire: a hinged jaw instead of the flower-face ok')

# ---------------------------------------------------------------- 10. m_jaws
# Standing failure in test_horror_steps, from before today: the lip tendrils on
# m_jaws reach 0.055 units outside the jaw's own envelope. Small, but the guard
# exists because an earlier inner jaw escaped by nearly two units, and a guard
# that is allowed to stay red stops being a guard. m_jaws is the narrowest mouth
# that carries tendrils (halfW 0.30 against m_maw's much wider skull), so the
# spread is what has to come in, not the tolerance.
s = open(p, encoding='utf-8').read()
s = sub1(s, "    lipTendrils(g, e, 0.14, 0.28, 0.30, 2, 0.14, 0.30);\n  } },\n  m_maw:",
            "    lipTendrils(g, e, 0.14, 0.28, 0.23, 2, 0.11, 0.30);\n  } },\n  m_maw:")
open(p, 'w', encoding='utf-8').write(s)
print('sire: m_jaws lip tendrils stay inside the jaw ok')

# ---------------------------------------------------------------- 11. saliva that falls
# Chasing the m_jaws guard found a real bug, not a tolerance problem.
#
# There are two jaw frames in the game. The dinosaur jaws built by dinoJawHard
# use +x along the muzzle and +y up. The hand-built mouths -- m_jaws, m_maw --
# use +x UP and +y along the muzzle: their own chomp opens the two halves apart
# along x and their teeth point along -x and +x.
#
# drool(), droolStrand() and lipTendrils() were written in the first frame and
# hang their strands along -y. Called from m_jaws and m_maw that is not down,
# it is BACKWARD, into the skull -- saliva drifting back through the animal's
# own head. The other three mouths pass the guard only because their envelopes
# are big enough to swallow the error.
#
# So the three helpers take a frame now: f along the muzzle, u up, s across.
# The default is exactly the old vectors, so every dinosaur jaw is unchanged to
# the byte, and the two hand-built mouths pass the frame they actually use --
# with their first two arguments swapped into (along, up) order to match.
s = open(p, encoding='utf-8').read()
OLD_DROOL = """function drool(g, e, x, y, halfW, n, len, seed) {
  if (!gore(e)) return;
  const t = e.t;
  for (let i = 0; i < n; i++) {
    const f = n === 1 ? 0 : (i / (n - 1)) * 2 - 1;
    const ph = seed + i * 2.399;
    // each strand runs its own slow stretch-and-snap cycle
    const cyc = (t * 0.33 + i * 0.41 + seed * 0.11) % 1;
    const grow = cyc < 0.82 ? 0.30 + cyc * 0.85 : 0.12;        // snaps back short
    // hung off the lip line itself, not out of the middle of the muzzle
    droolStrand(g, x, y, f * halfW, len * grow, ph, t, 0.020);
  }
  // The bead that let go. It falls a SHORT way and is small: the first cut
  // sent it a length and a half clear of the jaw, where it read as an
  // unrelated object floating beside the head.
  const d = (t * 0.55 + seed * 0.37) % 1;
  g.ball(x + 0.03, y - len * (0.10 + d * 0.55), (seed % 1 - 0.5) * halfW * 0.8, 0.026 * (1 - d * 0.4), SPIT);
}
"""
NEW_DROOL = r"""// The frame a mouth is drawn in: f along the muzzle, u up, s across. Omitted,
// it is the dinosaur-jaw frame these helpers were originally written in.
const JAW_F_DEFAULT = { f: [1, 0, 0], u: [0, 1, 0], s: [0, 0, 1] };
const jawPt = (F, af, au, as2) => [
  F.f[0] * af + F.u[0] * au + F.s[0] * as2,
  F.f[1] * af + F.u[1] * au + F.s[1] * as2,
  F.f[2] * af + F.u[2] * au + F.s[2] * as2];
function drool(g, e, x, y, halfW, n, len, seed, F0) {
  if (!gore(e)) return;
  const F = F0 || JAW_F_DEFAULT;
  const t = e.t;
  for (let i = 0; i < n; i++) {
    const f = n === 1 ? 0 : (i / (n - 1)) * 2 - 1;
    const ph = seed + i * 2.399;
    // each strand runs its own slow stretch-and-snap cycle
    const cyc = (t * 0.33 + i * 0.41 + seed * 0.11) % 1;
    const grow = cyc < 0.82 ? 0.30 + cyc * 0.85 : 0.12;        // snaps back short
    // hung off the lip line itself, not out of the middle of the muzzle
    droolStrand(g, x, y, f * halfW, len * grow, ph, t, 0.020, F);
  }
  // The bead that let go. It falls a SHORT way and is small: the first cut
  // sent it a length and a half clear of the jaw, where it read as an
  // unrelated object floating beside the head.
  const d = (t * 0.55 + seed * 0.37) % 1;
  const bp = jawPt(F, x + 0.03, y - len * (0.10 + d * 0.55), (seed % 1 - 0.5) * halfW * 0.8);
  g.ball(bp[0], bp[1], bp[2], 0.026 * (1 - d * 0.4), SPIT);
}
"""
s = sub1(s, OLD_DROOL, NEW_DROOL)

OLD_STRAND = """function droolStrand(g, x, y, z, len, ph, t, r0) {
  let p = [x, y, z];
  const N = 6, R = r0 || 0.020;
  for (let i = 0; i < N; i++) {
    const u = (i + 1) / N;
    // the swing grows toward the free end, which is what makes it hang
    const sx = Math.sin(t * 1.6 + ph + u * 2.4) * 0.05 * u;
    const sz = Math.cos(t * 1.27 + ph * 1.7 + u * 2.0) * 0.04 * u;
    const q = [p[0] + sx * 0.35, p[1] - len / N, p[2] + sz * 0.35];"""
NEW_STRAND = """function droolStrand(g, x, y, z, len, ph, t, r0, F0) {
  const F = F0 || JAW_F_DEFAULT;
  let p = jawPt(F, x, y, z);
  const N = 6, R = r0 || 0.020;
  for (let i = 0; i < N; i++) {
    const u = (i + 1) / N;
    // the swing grows toward the free end, which is what makes it hang
    const sx = Math.sin(t * 1.6 + ph + u * 2.4) * 0.05 * u;
    const sz = Math.cos(t * 1.27 + ph * 1.7 + u * 2.0) * 0.04 * u;
    const st = jawPt(F, sx * 0.35, -len / N, sz * 0.35);
    const q = [p[0] + st[0], p[1] + st[1], p[2] + st[2]];"""
s = sub1(s, OLD_STRAND, NEW_STRAND)

OLD_TEND = """function lipTendrils(g, e, x0, y0, halfW, n, len, back) {
  if (!gore(e)) return;
  for (let i = 0; i < n; i++) {
    for (const sg of [1, -1]) {
      const u = n === 1 ? 0.5 : i / (n - 1);
      const ph = e.seed * 2.1 + i * 1.7 + (sg > 0 ? 0 : 0.9);
      let p = [x0 - u * back, y0, sg * halfW * (0.7 + u * 0.35)];
      let d = [-0.25, -0.75, sg * 0.4];
      const N = 3, L = len * (0.7 + 0.5 * (1 - u));
      for (let k = 0; k < N; k++) {
        const w = Math.sin(e.t * 1.9 + ph + k * 0.8) * 0.20;
        d = v3.norm([d[0] - 0.12 + w * 0.3, d[1] - 0.10, d[2] + w * sg * 0.5]);
        const q = v3.add(p, v3.mul(d, L / N));
        g.cn(p[0], p[1], p[2], d[0], d[1], d[2], 0.032 * (1 - k * 0.22), (L / N) * 1.08, colMul(GORE, 1.5 + k * 0.2));
        p = q;
      }
    }
  }
}"""
NEW_TEND = """function lipTendrils(g, e, x0, y0, halfW, n, len, back, F0) {
  if (!gore(e)) return;
  const F = F0 || JAW_F_DEFAULT;
  for (let i = 0; i < n; i++) {
    for (const sg of [1, -1]) {
      const u = n === 1 ? 0.5 : i / (n - 1);
      const ph = e.seed * 2.1 + i * 1.7 + (sg > 0 ? 0 : 0.9);
      let p = jawPt(F, x0 - u * back, y0, sg * halfW * (0.7 + u * 0.35));
      let d = [-0.25, -0.75, sg * 0.4];
      const N = 3, L = len * (0.7 + 0.5 * (1 - u));
      for (let k = 0; k < N; k++) {
        const w = Math.sin(e.t * 1.9 + ph + k * 0.8) * 0.20;
        d = v3.norm([d[0] - 0.12 + w * 0.3, d[1] - 0.10, d[2] + w * sg * 0.5]);
        const dw = jawPt(F, d[0], d[1], d[2]);
        const q = v3.add(p, v3.mul(dw, L / N));
        g.cn(p[0], p[1], p[2], dw[0], dw[1], dw[2], 0.032 * (1 - k * 0.22), (L / N) * 1.08, colMul(GORE, 1.5 + k * 0.2));
        p = q;
      }
    }
  }
}"""
s = sub1(s, OLD_TEND, NEW_TEND)

# m_jaws and m_maw: their own frame, and their arguments in (along, up) order.
JF = "JAW_F_UP"
s = sub1(s, "const JAW_F_DEFAULT = { f: [1, 0, 0], u: [0, 1, 0], s: [0, 0, 1] };",
            "const JAW_F_DEFAULT = { f: [1, 0, 0], u: [0, 1, 0], s: [0, 0, 1] };\n"
            "// m_jaws and m_maw open along x and run along y: x is UP for them.\n"
            "const JAW_F_UP = { f: [0, 1, 0], u: [1, 0, 0], s: [0, 0, 1] };")
s = sub1(s, "    drool(g, e, 0.22, 0.26, 0.34, 2, 0.26 + o * 0.28, (e.seed || 0) + 0.9);\n"
            "    lipTendrils(g, e, 0.14, 0.28, 0.23, 2, 0.11, 0.30);",
            "    drool(g, e, 0.26, 0.22, 0.34, 2, 0.26 + o * 0.28, (e.seed || 0) + 0.9, " + JF + ");\n"
            "    lipTendrils(g, e, 0.28, 0.14, 0.23, 2, 0.11, 0.24, " + JF + ");")
s = sub1(s, "    drool(g, e, 0.30, 0.24, 0.46, 2, 0.30 + o * 0.34, (e.seed || 0) + 1.7);\n"
            "    lipTendrils(g, e, 0.20, 0.30, 0.60, 2, 0.28, 0.45);",
            "    drool(g, e, 0.24, 0.30, 0.46, 2, 0.30 + o * 0.34, (e.seed || 0) + 1.7, " + JF + ");\n"
            "    lipTendrils(g, e, 0.30, 0.20, 0.60, 2, 0.28, 0.36, " + JF + ");")
open(p, 'w', encoding='utf-8').write(s)
print('sire: saliva falls down instead of backward through the skull ok')
