def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
s=open('g3.html',encoding='utf-8').read()
wg=open('src/wgsl_skin.js',encoding='utf-8').read()
s=sub1(s,"""// Unlit geometry with vertex colour (the editor's sky dome)""",wg+"""
// Unlit geometry with vertex colour (the editor's sky dome)""")
s=sub1(s,"let terrainPipe, instPipe, waterPipe, bodyPipe, unlitPipe, tubePipe, overPipe, bindG;",
         "let terrainPipe, instPipe, waterPipe, bodyPipe, unlitPipe, tubePipe, overPipe, skinPipe, skinBind, skinInstVB, bindG;")
s=sub1(s,"""  const bm = dev.createShaderModule({ code: WGSL_BODY });""","""  const skm = dev.createShaderModule({ code: WGSL_SKIN });
  skinPipe = dev.createRenderPipeline({
    layout: 'auto',
    vertex: { module: skm, entryPoint: 'vs', buffers: [
      { arrayStride: 56, attributes: [
        { shaderLocation: 0, offset: 0,  format: 'float32x3' },
        { shaderLocation: 1, offset: 12, format: 'float32x3' },
        { shaderLocation: 2, offset: 24, format: 'float32'   },
        { shaderLocation: 3, offset: 28, format: 'float32x2' },
        { shaderLocation: 4, offset: 36, format: 'float32'   },
        { shaderLocation: 5, offset: 40, format: 'float32x3' },
        { shaderLocation: 6, offset: 52, format: 'float32'   }] },
      { arrayStride: BINST_FLOATS * 4, stepMode: 'instance', attributes: [
        { shaderLocation: 7,  offset: 0,  format: 'float32x3' },
        { shaderLocation: 8,  offset: 12, format: 'float32'   },
        { shaderLocation: 9,  offset: 16, format: 'float32'   },
        { shaderLocation: 10, offset: 20, format: 'float32x3' },
        { shaderLocation: 11, offset: 32, format: 'float32x3' },
        { shaderLocation: 12, offset: 44, format: 'float32x3' },
        { shaderLocation: 13, offset: 56, format: 'float32'   },
        { shaderLocation: 14, offset: 64, format: 'float32x3' },
        { shaderLocation: 15, offset: 76, format: 'float32'   }] } ] },
    fragment: { module: skm, entryPoint: 'fs', targets: [{ format: fmt }] },
    primitive: { topology: 'triangle-list', cullMode: 'none' },
    depthStencil: depthState, multisample: MS,
  });
  boneBuf = dev.createBuffer({ size: boneData.byteLength, usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST });
  skinInstVB = dev.createBuffer({ size: skinInstData.byteLength, usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST });
  const bm = dev.createShaderModule({ code: WGSL_BODY });""",1)
s=sub1(s,"""    over:    dev.createBindGroup({ layout: overPipe.getBindGroupLayout(0),    entries: [{ binding: 0, resource: { buffer: gBuf } }] }),""",
"""    over:    dev.createBindGroup({ layout: overPipe.getBindGroupLayout(0),    entries: [{ binding: 0, resource: { buffer: gBuf } }] }),""")
s=sub1(s,"""function makeBindGroups() {
  bindG = {""","""function makeBindGroups() {
  skinBind = dev.createBindGroup({ layout: skinPipe.getBindGroupLayout(0), entries: [
    { binding: 0, resource: { buffer: gBuf } }, { binding: 1, resource: { buffer: boneBuf } }] });
  bindG = {""")
# world frame: reset skin draws, pump the bake queue, draw skins after bodies
s=sub1(s,"""  instCount = 0; spikeCount = 0; tubeN = 0;
  bodyBatches.length = 0;""","""  instCount = 0; spikeCount = 0; tubeN = 0;
  resetSkinFrame();
  pumpDesignMeshes(6);
  bodyBatches.length = 0;""")
s=sub1(s,"""  pass.setPipeline(waterPipe); pass.setBindGroup(0, bindG.water);
  pass.setVertexBuffer(0, waterVB); pass.draw(6);""","""  flushSkinDraws(pass);
  pass.setPipeline(waterPipe); pass.setBindGroup(0, bindG.water);
  pass.setVertexBuffer(0, waterVB); pass.draw(6);""")
open('g3.html','w',encoding='utf-8').write(s)
print('skin ok')
