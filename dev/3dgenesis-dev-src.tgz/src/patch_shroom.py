# =====================================================================
# MUSHROOMS: FOUR SPELLS YOU CARRY AND SPEND
#
# What replaces food. Big glowing caps stand on the ground across the island.
# Walk onto one, press E, and it goes in your pouch. Press its number and it
# goes off. They do not survive the match, so there is no metagame to grind:
# what you are carrying is what this round gave you.
#
#   1  POWER   yellow   30s   every hit you land does double damage
#   2  WARD    green    20s   nothing can hurt you at all
#   3  VEIL    purple   30s   small, quiet and very hard to see
#   4  RAGE    red      20s   half again the damage, half again the health,
#                             a third bigger and a third faster
#
# You glow the colour of whatever is running, and for VEIL and RAGE the body
# really does change size and speed rather than the HUD claiming it did.
#
# Placement is the same trick the carcass field uses: one candidate per cell,
# rolled out of the world seed, so every player in a match finds the same
# mushrooms in the same places without a byte crossing the network.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, ('ANCHOR %d/%d' % (n, cnt), a[:110]); return s.replace(a, b)

p = 'g3.html'; s = open(p, encoding='utf-8').read()

# ---------------------------------------------------------------- 1. health becomes buffable
# RAGE raises maximum health. hpOf already carries the same FRACTION across a
# change of maximum, so raising the ceiling heals you in proportion and
# dropping it back takes exactly that away again -- no bookkeeping, and no way
# for the buff to leave you at full health when it ends.
s = sub1(s, """  function hpOf(c) {
    if (!c) return 0;
    const max = hpMaxOf(c.ph);""",
"""  // A creature's real ceiling: its body, times whatever is currently running
  // on it. One function, so nothing can read a stale maximum.
  function hpMaxC(c) { return hpMaxOf(c && c.ph) * (c && c.hpMul > 0 ? c.hpMul : 1); }
  function hpOf(c) {
    if (!c) return 0;
    const max = hpMaxC(c);""")
s = sub1(s, """  function hpFrac(c) { const m = hpMaxOf(c && c.ph); return m > 0 ? clamp(hpOf(c) / m, 0, 1) : 0; }""",
             """  function hpFrac(c) { const m = hpMaxC(c); return m > 0 ? clamp(hpOf(c) / m, 0, 1) : 0; }""")
s = sub1(s, """  function hpHeal(c, amt) {
    const max = hpMaxOf(c && c.ph);""",
"""  function hpHeal(c, amt) {
    const max = hpMaxC(c);""")
s = sub1(s, "    hpMaxOf, hpOf, hpFrac, hpHurt, hpHeal, weaponQ, strikeDamage, counterDamage,",
            "    hpMaxOf, hpMaxC, hpOf, hpFrac, hpHurt, hpHeal, weaponQ, strikeDamage, counterDamage,")

# ---------------------------------------------------------------- 2. the spells themselves
s = sub1(s, "// ---------------------------------------------------------------- your swing",
r"""// =====================================================================
// SPELLS
// =====================================================================
const SPELL_DEF = {
  power: { n: 1, name: 'POWER', dur: 30, col: [1.00, 0.80, 0.12], blurb: 'double damage',
           hud: 'every hit you land is doubled' },
  ward:  { n: 2, name: 'WARD',  dur: 20, col: [0.24, 1.00, 0.42], blurb: 'untouchable',
           hud: 'nothing can hurt you' },
  veil:  { n: 3, name: 'VEIL',  dur: 30, col: [0.66, 0.32, 1.00], blurb: 'small and unseen',
           hud: 'small, quiet and very hard to see' },
  rage:  { n: 4, name: 'RAGE',  dur: 20, col: [1.00, 0.20, 0.14], blurb: 'bigger, faster, stronger',
           hud: 'x1.5 damage and health, bigger and faster' },
};
const SPELL_IDS = ['power', 'ward', 'veil', 'rage'];
const SPELL_BY_N = { 1: 'power', 2: 'ward', 3: 'veil', 4: 'rage' };
const SPELL_CARRY = 3;              // of each kind. A pouch, not a warehouse.
// What is in the pouch and what is running. Deliberately NOT in PROG: a spell
// is a thing this round gave you, and it does not leave with you.
const SPELL = { bag: { power: 0, ward: 0, veil: 0, rage: 0 }, on: {}, owner: null };
function spellReset(why) {
  for (const k of SPELL_IDS) SPELL.bag[k] = 0;
  SPELL.on = {};
  SPELL.owner = player.c || null;
  spellApply();
  if (why) toast(why, 2200);
}
function spellActive(k) { return (SPELL.on[k] || 0) > 0; }
function spellLeft(k) { return Math.max(0, SPELL.on[k] || 0); }
// Multipliers, read by the fight and the renderer. One place each, so a buff
// cannot be applied twice or forgotten in one of two code paths.
function spellDamageMul() { return (spellActive('power') ? 2 : 1) * (spellActive('rage') ? 1.5 : 1); }
function spellSizeMul()   { return (spellActive('veil') ? 0.45 : 1) * (spellActive('rage') ? 1.35 : 1); }
function spellSpeedMul()  { return (spellActive('veil') ? 1.12 : 1) * (spellActive('rage') ? 1.30 : 1); }
function spellHpMul()     { return spellActive('rage') ? 1.5 : 1; }
function spellInvuln()    { return spellActive('ward'); }
// How visible you are to everything else. VEIL is the stealth spell: a small
// body that makes no noise is one the island's senses have to work for.
function spellSeenMul()   { return spellActive('veil') ? 0.25 : 1; }
// The colour you are giving off right now: the strongest thing running, so a
// stack reads as its headline effect rather than as brown.
function spellGlow() {
  let best = null, bestT = 0;
  for (const k of SPELL_IDS) {
    const t = spellLeft(k);
    if (t > 0 && t > bestT * 0.0001 && (!best || SPELL_DEF[k].n > SPELL_DEF[best].n)) { best = k; bestT = t; }
  }
  if (!best) return null;
  // pulse, and flash faster as it runs out, so the end is never a surprise
  const t = spellLeft(best);
  const urg = t < 4 ? 6.5 : 2.0;
  const amt = (0.55 + 0.45 * (0.5 + 0.5 * Math.sin(simT * urg))) * (t < 1 ? t : 1);
  return { col: SPELL_DEF[best].col, amt, id: best };
}
// Push the buffs that live on the creature itself onto the creature.
function spellApply() {
  const c = player.c;
  if (!c) return;
  c.hpMul = spellHpMul();
  C.hpOf(c);                 // re-reads the ceiling and carries the fraction
}
function spellTake(id) {
  if (!SPELL_DEF[id]) return { ok: false, why: 'unknown' };
  if (SPELL.bag[id] >= SPELL_CARRY) {
    toast('You are already carrying ' + SPELL_CARRY + ' ' + SPELL_DEF[id].name + '. Spend one first.', 1800);
    return { ok: false, why: 'full' };
  }
  SPELL.bag[id]++;
  toast('Picked up ' + SPELL_DEF[id].name + ' · press ' + SPELL_DEF[id].n + ' to use it · ' + SPELL_DEF[id].blurb, 2600);
  // a bright two-note chime, so a pickup is audible without looking
  if (SND.ctx && SND.on) { sndNoiseBurst(1800, 14, 0.10, 0.16, 0, 1.0); setTimeout(() => { if (SND.ctx && SND.on) sndNoiseBurst(2700, 16, 0.12, 0.14, 0, 1.0); }, 70); }
  return { ok: true, n: SPELL.bag[id] };
}
function spellUse(id) {
  const c = player.c;
  if (!SPELL_DEF[id]) return { ok: false, why: 'unknown' };
  if (!c || !c.alive || player.spectator) return { ok: false, why: 'nobody' };
  if (!SPELL.bag[id]) { toast('No ' + SPELL_DEF[id].name + ' to spend.', 1200); return { ok: false, why: 'none' }; }
  if (spellActive(id)) { toast(SPELL_DEF[id].name + ' is already running · ' + Math.ceil(spellLeft(id)) + 's left.', 1400); return { ok: false, why: 'running' }; }
  SPELL.bag[id]--;
  SPELL.on[id] = SPELL_DEF[id].dur;
  spellApply();
  toast(SPELL_DEF[id].name + '! ' + SPELL_DEF[id].hud + ' · ' + SPELL_DEF[id].dur + 's', 3000);
  return { ok: true };
}
function spellTick(dt) {
  // a different body is a different pouch
  if (SPELL.owner !== player.c) { SPELL.owner = player.c; SPELL.on = {}; spellApply(); }
  let changed = false;
  for (const k of SPELL_IDS) {
    if (!(SPELL.on[k] > 0)) continue;
    SPELL.on[k] -= dt;
    if (SPELL.on[k] <= 0) {
      delete SPELL.on[k]; changed = true;
      toast(SPELL_DEF[k].name + ' has worn off.', 1800);
    }
  }
  if (changed) spellApply();
  else if (player.c && player.c.hpMul !== spellHpMul()) spellApply();
}
function spellHudHtml() {
  const rows = [];
  for (const k of SPELL_IDS) {
    const D = SPELL_DEF[k], t = spellLeft(k), n = SPELL.bag[k];
    if (!n && !(t > 0)) continue;
    const c = D.col, css = 'rgb(' + Math.round(c[0] * 255) + ',' + Math.round(c[1] * 255) + ',' + Math.round(c[2] * 255) + ')';
    rows.push('<span class="sp" style="border-color:' + css + ';color:' + css + '">' +
      '<b>' + D.n + '</b> ' + D.name + (n ? ' ×' + n : '') +
      (t > 0 ? ' <i>' + Math.ceil(t) + 's</i>' : '') + '</span>');
  }
  return rows.length ? '<div class="spells">' + rows.join('') + '</div>' : '';
}

// ---------------------------------------------------------------- your swing""")

open(p, 'w', encoding='utf-8').write(s)
print('shroom: spells ok')
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, ('ANCHOR %d/%d' % (n, cnt), a[:110]); return s.replace(a, b)

p = 'g3.html'; s = open(p, encoding='utf-8').read()

# ---------------------------------------------------------------- 3. the field
s = sub1(s, "function carcHash(a, b, c) {",
r"""// ---- the mushroom field -----------------------------------------------------
// One candidate per cell, present or not and of a kind, rolled straight out of
// the world seed. Nothing is stored for a cell until you are near it, so the
// whole island costs what the handful in front of you costs, and two players
// in the same match walk onto the same mushrooms.
const SHROOM_CELL = 760;        // one candidate per cell
const SHROOM_ODDS = 0.42;       // ...and this many cells actually hold one
const SHROOM_R = 2600;          // built out to here, dropped again beyond it
const SHROOM_REGROW = 150;      // seconds before a picked cap comes back
const SHROOM = { cells: new Map(), live: [], seed: 0, t: 0 };
function shroomReset() { SHROOM.cells.clear(); SHROOM.live.length = 0; }
function shroomCell(ix, iz) {
  const key = ix + ',' + iz;
  if (SHROOM.cells.has(key)) return SHROOM.cells.get(key);
  const h = carcHash(ix, iz, SHROOM.seed ^ 0x5eed);
  let ent = null;
  if ((h & 1023) / 1024 < SHROOM_ODDS) {
    const r = carcRng(h);
    const x = (ix + 0.18 + r() * 0.64) * SHROOM_CELL;
    const z = (iz + 0.18 + r() * 0.64) * SHROOM_CELL;
    // never in the sea, never on a cliff: it has to be somewhere you can stand
    if (x > 60 && z > 60 && x < WORLD_W - 60 && z < WORLD_H - 60 && !terrain.isWater(x, z)) {
      const id = SHROOM_IDS[(h >>> 11) % SHROOM_IDS.length];
      ent = { x, z, id, y: 0, taken: 0, rot: r() * 6.283, s: 0.85 + r() * 0.45, built: false };
    }
  }
  SHROOM.cells.set(key, ent);
  return ent;
}
function shroomUpdate(dt) {
  if (!world || !terrain) return;
  SHROOM.seed = (world.seed | 0) >>> 0;
  SHROOM.t += dt;
  if (SHROOM.t < 0.3 && SHROOM.live.length) return;
  SHROOM.t = 0;
  const cx = player.camX, cz = player.camZ;
  const i0 = Math.floor((cx - SHROOM_R) / SHROOM_CELL), i1 = Math.floor((cx + SHROOM_R) / SHROOM_CELL);
  const j0 = Math.floor((cz - SHROOM_R) / SHROOM_CELL), j1 = Math.floor((cz + SHROOM_R) / SHROOM_CELL);
  const live = [];
  for (let i = i0; i <= i1; i++) for (let j = j0; j <= j1; j++) {
    const e = shroomCell(i, j);
    if (!e) continue;
    if (Math.hypot(e.x - cx, e.z - cz) > SHROOM_R) continue;
    if (!e.built) { e.y = groundAt(e.x, e.z); e.built = true; }
    // a picked cap comes back, so a long match does not end on a stripped map
    if (e.taken > 0 && simT - e.taken > SHROOM_REGROW) e.taken = 0;
    live.push(e);
  }
  SHROOM.live = live;
}
// The one in reach, if any.
function shroomAt() {
  const c = player.c;
  if (!c || !c.alive || player.spectator) return null;
  const rr = Math.max(26, interactRange(c.ph) * 0.9);
  let best = null, bd = Infinity;
  for (const e of SHROOM.live) {
    if (e.taken) continue;
    const d = Math.hypot(e.x - c.x, e.z - c.y);
    if (d < rr && d < bd) { bd = d; best = e; }
  }
  return best;
}
function shroomTake() {
  const e = shroomAt();
  if (!e) return { ok: false, why: 'none' };
  const r = spellTake(e.id);
  if (r.ok) e.taken = simT;
  return r;
}
function carcHash(a, b, c) {""")

# the ids list has to exist before the field uses it
s = sub1(s, "const SPELL_IDS = ['power', 'ward', 'veil', 'rage'];",
            "const SPELL_IDS = ['power', 'ward', 'veil', 'rage'];\nconst SHROOM_IDS = SPELL_IDS;")

# ---------------------------------------------------------------- 4. the cap itself
s = sub1(s, "const BRMESH = { cage: null, gate: null, signpost: null, digits: [], ready: false };",
r"""// A mushroom: a pale stem and a heavy glowing cap, built once and drawn with a
// per-instance tint so one mesh covers all four kinds. Deliberately oversized
// -- it has to read as a thing you can go and get from across a valley.
const SHROOM_STEM = [0.72, 0.70, 0.66];
function buildShroomMesh() {
  const m = folMB();
  const H = 15, CAP = 13;
  // stem: a slightly bellied tube, tapering into the cap
  const pts = [], rad = [];
  for (let i = 0; i <= 5; i++) {
    const u = i / 5;
    pts.push([0, u * H, 0]);
    rad.push(2.6 - 1.1 * u + 1.3 * Math.sin(u * Math.PI) * 0.5);
  }
  folTube(m, pts, rad, 9, SHROOM_STEM, H, 0.0, 0.7);
  // cap: rings of a squashed dome, lit rather than shaded, so it glows
  const RINGS = 6, SIDES = 14;
  const ringY = (k) => H + Math.cos((k / RINGS) * Math.PI * 0.5) * CAP * 0.52;
  const ringR = (k) => Math.sin((k / RINGS) * Math.PI * 0.5) * CAP;
  let prev = null;
  for (let k = 0; k <= RINGS; k++) {
    const y = ringY(k), r = ringR(k), ring = [];
    for (let sI = 0; sI < SIDES; sI++) {
      const a = sI / SIDES * Math.PI * 2;
      const px = Math.cos(a) * r, pz = Math.sin(a) * r;
      const nr = fnorm([px, CAP * 0.5, pz]);
      ring.push(folV(m, [px, y, pz], nr, [1, 1, 1], 0, MAT_GLOW));
    }
    if (prev) for (let sI = 0; sI < SIDES; sI++) {
      const a = prev[sI], b2 = prev[(sI + 1) % SIDES], c2 = ring[(sI + 1) % SIDES], d2 = ring[sI];
      m.i.push(a, b2, c2, a, c2, d2);
    }
    prev = ring;
  }
  // gills under the rim, darker, so the cap has an underside from below
  const yU = H + CAP * 0.30;
  const hub = folV(m, [0, yU - 2.2, 0], [0, -1, 0], [0.45, 0.45, 0.45], 0, MAT_GLOW);
  let rim = [];
  for (let sI = 0; sI < SIDES; sI++) {
    const a = sI / SIDES * Math.PI * 2;
    rim.push(folV(m, [Math.cos(a) * CAP * 0.97, yU, Math.sin(a) * CAP * 0.97], [0, -1, 0], [0.62, 0.62, 0.62], 0, MAT_GLOW));
  }
  for (let sI = 0; sI < SIDES; sI++) m.i.push(hub, rim[(sI + 1) % SIDES], rim[sI]);
  return m;
}
// Queue the mushrooms in view. Same bucket path the cages and the trees use.
function shroomPut(put, camX, camZ) {
  if (!BRMESH.shroom) return;
  for (const e of SHROOM.live) {
    if (e.taken) continue;
    const d = Math.hypot(e.x - camX, e.z - camZ);
    if (d > SHROOM_R) continue;
    const col = SPELL_DEF[e.id].col;
    put(BRMESH.shroom, e.x, e.y, e.z, e.rot, e.s, col);
  }
}
const BRMESH = { cage: null, gate: null, signpost: null, digits: [], shroom: null, ready: false };""")
s = sub1(s, "  BRMESH.cage = folUpload(buildCageMesh());",
            "  BRMESH.cage = folUpload(buildCageMesh());\n  BRMESH.shroom = folUpload(buildShroomMesh());")
# the mushrooms are not part of a match, so they are built whether or not one is on
s = sub1(s, "function brPutCages(put, camX, camZ) {\n  if (!BR.on || !BRMESH.ready) return;",
            "function brPutCages(put, camX, camZ) {\n  if (!BR.on || !BRMESH.ready) return;")
s = sub1(s, "  brPutCages(put, camX, camZ);\n  for (const tr of world.forest.trees) {",
            "  brPutCages(put, camX, camZ);\n  shroomPut(put, camX, camZ);\n  for (const tr of world.forest.trees) {")

open(p, 'w', encoding='utf-8').write(s)
print('shroom: field and mesh ok')
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, ('ANCHOR %d/%d' % (n, cnt), a[:110]); return s.replace(a, b)

p = 'g3.html'; s = open(p, encoding='utf-8').read()

# ---------------------------------------------------------------- 5. the effects actually apply
# damage out
s = sub1(s, "  let dmg = C.strikeDamage(p, best.ph, MD.dmg);",
            "  let dmg = C.strikeDamage(p, best.ph, MD.dmg) * spellDamageMul();")
# damage in: WARD is absolute, and it is said out loud so it never looks like a miss
s = sub1(s, """  C.hpHurt(c, dmg);
  if (c.hp <= 0) c._fatalBy = att;""",
"""  if (spellInvuln()) {
    fightMsg('WARD holds. Nothing gets through.', 900);
    FIGHT.hurtFx = Math.min(1, FIGHT.hurtFx + 0.06);
    c._lastBlocked = true;
    return;
  }
  C.hpHurt(c, dmg);
  if (c.hp <= 0) c._fatalBy = att;""")
# the fog is damage too, and WARD is damage-proof
s = sub1(s, """    C.hpHurt(p.c, BR_ZONE_DPS * f * dt);""",
"""    if (p.slot === BR.slot && spellInvuln()) continue;
    C.hpHurt(p.c, BR_ZONE_DPS * f * dt);""")
# size: the body you see is the body the spell made
s = sub1(s, "  const S = BODY_SCALE;\n", "  const S = BODY_SCALE * (c === player.c ? spellSizeMul() : 1);\n")
# speed
s = sub1(s, "  sp *= PLAYER_SPEED * (dodgeV ? 1 : fightSpeedMul()) * (1 - 0.75 * (player.rear || 0));",
            "  sp *= PLAYER_SPEED * (dodgeV ? 1 : fightSpeedMul()) * (1 - 0.75 * (player.rear || 0)) * spellSpeedMul();")
# the glow: the whole hide takes the spell's colour, pulsing
s = sub1(s, """function creatureBase(c) {
  const rgbv = C.hueToRGB(isFinite(c.ph.hue) ? c.ph.hue : 0.3, 0.52, 0.52);
  return [rgbv[0] / 255, rgbv[1] / 255, rgbv[2] / 255];
}""",
"""function creatureBase(c) {
  const rgbv = C.hueToRGB(isFinite(c.ph.hue) ? c.ph.hue : 0.3, 0.52, 0.52);
  const base = [rgbv[0] / 255, rgbv[1] / 255, rgbv[2] / 255];
  // Whatever spell is running, you are lit up in its colour. Only ever the
  // body the player is steering: a rival's buff shows on their own screen.
  if (c === player.c) {
    const g = spellGlow();
    if (g) {
      const k = 0.78 * g.amt;
      return [base[0] * (1 - k) + g.col[0] * k, base[1] * (1 - k) + g.col[1] * k, base[2] * (1 - k) + g.col[2] * k];
    }
  }
  return base;
}""")
# VEIL: a small quiet body is genuinely harder for the island to notice
s = sub1(s, "function fightTick(dt) {\n  world.hitFilter = fightHitFilter;",
"""function fightTick(dt) {
  world.hitFilter = fightHitFilter;
  spellTick(dt);
  shroomUpdate(dt);""")

# ---------------------------------------------------------------- 6. keys
s = sub1(s, "    if (k === 'e') tryEat();",
"""    if (k === 'e') { const r = shroomTake(); if (!r.ok && r.why === 'none') toast('Nothing to pick up here.', 900); }
    if (k >= '1' && k <= '4' && started && !player.picker) { spellUse(SPELL_BY_N[k]); e.preventDefault(); }""")
# picking one up has to take it off the ground THIS frame, not in forty units'
# time when the instance list happens to rebuild
s = sub1(s, """function shroomTake() {
  const e = shroomAt();
  if (!e) return { ok: false, why: 'none' };
  const r = spellTake(e.id);
  if (r.ok) e.taken = simT;
  return r;
}""",
"""function shroomTake() {
  const e = shroomAt();
  if (!e) return { ok: false, why: 'none' };
  const r = spellTake(e.id);
  if (r.ok) { e.taken = simT; FOL.key = ''; }   // force the instance list to drop it now
  return r;
}""")
# and a regrown one has to come back the same way
s = sub1(s, "    if (e.taken > 0 && simT - e.taken > SHROOM_REGROW) e.taken = 0;",
            "    if (e.taken > 0 && simT - e.taken > SHROOM_REGROW) { e.taken = 0; FOL.key = ''; }")

# ---------------------------------------------------------------- 7. the HUD, and the prompt
s = sub1(s, "      (p.canFly ? flightHud() : '') + swimHud() +",
            "      (p.canFly ? flightHud() : '') + swimHud() + spellHudHtml() +")
s = sub1(s, """  #brChoice{""",
"""  .spells{margin-top:4px;display:flex;flex-wrap:wrap;gap:4px}
  .spells .sp{display:inline-block;padding:1px 6px 2px;border:1px solid;border-radius:5px;
    font:600 11px/1.3 system-ui,sans-serif;letter-spacing:.03em;background:rgba(0,0,0,.30)}
  .spells .sp b{font-weight:800;opacity:.85;margin-right:3px}
  .spells .sp i{font-style:normal;opacity:.75}
  #brChoice{""")

# the action panel says what is at your feet
s = sub1(s, """  const act = $('act');
  if (act) {
    const tgt = player.target, me = player.c;""",
"""  const act = $('act');
  if (act) {
    const sh = shroomAt();
    if (sh) {
      const D = SPELL_DEF[sh.id], cc = D.col;
      const css = 'rgb(' + Math.round(cc[0] * 255) + ',' + Math.round(cc[1] * 255) + ',' + Math.round(cc[2] * 255) + ')';
      act.innerHTML = '<div class="acth" style="color:' + css + '">' + D.name + ' MUSHROOM</div>' +
        '<div class="keys"><span class="ok">E</span> take it &middot; ' + D.blurb + ' for ' + D.dur + 's</div>';
      act.style.display = 'block';
      return;
    }
    const tgt = player.target, me = player.c;""")

# ---------------------------------------------------------------- 8. a round is a round
# The pouch does not leave the match, and the field belongs to the world that
# is being torn down.
s = sub1(s, "    world.rarityCap = (opts && opts.rarityCap) || 'ultra';\n    if (typeof CARC !== 'undefined') { CARC.cells.clear(); CARC.live.length = 0; CARC.q.length = 0; }",
            "    world.rarityCap = (opts && opts.rarityCap) || 'ultra';\n    if (typeof CARC !== 'undefined') { CARC.cells.clear(); CARC.live.length = 0; CARC.q.length = 0; }\n    if (typeof SHROOM !== 'undefined') shroomReset();")
s = sub1(s, "  brSpawnBots();\n  BR.net.ready();",
            "  brSpawnBots();\n  spellReset();          // nothing carries into a match\n  BR.net.ready();")
s = sub1(s, "function brStop() {\n  try { brNamesHide(0); } catch (e) { /* the layer may not exist yet */ }",
            "function brStop() {\n  try { brNamesHide(0); } catch (e) { /* the layer may not exist yet */ }\n  try { spellReset(); } catch (e) { /* the pouch is cosmetic once the match is over */ }")

# ---------------------------------------------------------------- 9. test surface
s = sub1(s, "  pick: (i) => choosePicked(i),","""  pick: (i) => choosePicked(i),
  spell: {
    bag: () => Object.assign({}, SPELL.bag),
    on: () => { const o = {}; for (const k of SPELL_IDS) if (spellLeft(k) > 0) o[k] = +spellLeft(k).toFixed(2); return o; },
    give: (id, n) => { SPELL.bag[id] = Math.min(SPELL_CARRY, (SPELL.bag[id] | 0) + (n == null ? 1 : n)); return SPELL.bag[id]; },
    use: (id) => spellUse(id),
    tick: (dt) => spellTick(dt),
    reset: () => spellReset(),
    muls: () => ({ dmg: spellDamageMul(), size: spellSizeMul(), speed: spellSpeedMul(),
                   hp: spellHpMul(), invuln: spellInvuln(), seen: spellSeenMul() }),
    near: () => { const e = shroomAt(); return e ? { id: e.id, dist: Math.round(Math.hypot(e.x - player.c.x, e.z - player.c.y)) } : null; },
    field: () => SHROOM.live.filter(e => !e.taken).map(e => ({ id: e.id, x: Math.round(e.x), z: Math.round(e.z) })),
    take: () => shroomTake(),
    // walk the player onto the nearest uncollected cap, so a test can pick one up
    walkTo: () => {
      let best = null, bd = Infinity;
      for (const e of SHROOM.live) { if (e.taken) continue;
        const d = Math.hypot(e.x - player.c.x, e.z - player.c.y); if (d < bd) { bd = d; best = e; } }
      if (!best) return null;
      window.__G3D.teleport(best.x, best.z);
      return { id: best.id };
    },
  },""")

open(p, 'w', encoding='utf-8').write(s)
print('shroom: wiring ok')

# a few plain readouts the checks need, alongside the rest of the surface
s = open(p, encoding='utf-8').read()
s = sub1(s, "  spell: {\n    bag: () => Object.assign({}, SPELL.bag),",
"""  hp: () => C.hpOf(player.c),
  hpMax: () => C.hpMaxC(player.c),
  hurtMe: (n) => { const c = player.c; if (!c) return 0; if (spellInvuln()) return C.hpOf(c); C.hpHurt(c, n); return C.hpOf(c); },
  spell: {
    bag: () => Object.assign({}, SPELL.bag),""")
open(p, 'w', encoding='utf-8').write(s)
print('shroom: readouts ok')

# Screenshots are far too slow under software rendering to be a check, so the
# render path is verified by asking it what it would queue.
s = open(p, encoding='utf-8').read()
s = sub1(s, "    take: () => shroomTake(),",
"""    take: () => shroomTake(),
    // what the renderer would actually queue this frame: mesh present, one
    // instance per standing cap, each with its own colour
    drawn: () => {
      let n = 0; const cols = [];
      shroomPut((mesh, x, y, z, rot, sc, tint) => { n++; if (cols.length < 4) cols.push(tint.map(v => +v.toFixed(2))); },
                player.camX, player.camZ);
      return { mesh: !!BRMESH.shroom, n, cols };
    },""")
open(p, 'w', encoding='utf-8').write(s)
print('shroom: draw probe ok')
