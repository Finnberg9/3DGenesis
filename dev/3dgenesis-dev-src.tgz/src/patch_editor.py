def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
s=open('g3.html',encoding='utf-8').read()
css=open('src/editor.css',encoding='utf-8').read()
code=open('src/editor_scene.js',encoding='utf-8').read()+"\n"+open('src/editor.js',encoding='utf-8').read()+"\n"+open('src/editor_ui.js',encoding='utf-8').read()
# styles: before the first </style>
i=s.index('</style>'); s=s[:i]+css+s[i:]
# editor code before the boot section
s=sub1(s,"// ================================================================== boot\n", code+"\n// ================================================================== boot\n")
# loop: render the editor instead of the world while it is open (the sim is paused)
s=sub1(s,"""  const dt = lastT ? (now - lastT) / 1000 : 0.016;
  lastT = now;
  try { tick(dt); }""","""  const dt = lastT ? (now - lastT) / 1000 : 0.016;
  lastT = now;
  if (ED.open) {
    try { renderEditor(now / 1000); } catch (e) { console.error(e); }
    requestAnimationFrame(loop);
    return;
  }
  try { tick(dt); }""")
# game input stands down while editing
s=sub1(s,"""  addEventListener('keydown', (e) => {
    // Only a field you are actually TYPING into may swallow keys.""","""  addEventListener('keydown', (e) => {
    if (ED.open) return;
    // Only a field you are actually TYPING into may swallow keys.""")
s=sub1(s,"""  canvas.addEventListener('mousedown', (e) => {
    downX = e.clientX; downY = e.clientY; moved = 0;""","""  canvas.addEventListener('mousedown', (e) => {
    if (ED.open) return;
    downX = e.clientX; downY = e.clientY; moved = 0;""")
s=sub1(s,"""  addEventListener('mouseup', (e) => {
    const wasDrag = moved > 6;""","""  addEventListener('mouseup', (e) => {
    if (ED.open) { dragging = false; return; }
    const wasDrag = moved > 6;""")
s=sub1(s,"""  addEventListener('mousemove', (e) => {
    if (pointerLocked) {""","""  addEventListener('mousemove', (e) => {
    if (ED.open) return;
    if (pointerLocked) {""")
s=sub1(s,"""  canvas.addEventListener('mousedown', (e) => {
    if (!pointerLocked) return;""","""  canvas.addEventListener('mousedown', (e) => {
    if (ED.open || !pointerLocked) return;""")
s=sub1(s,"""  addEventListener('wheel', (e) => {
    if (e.target !== canvas) return;               // let the control panel scroll normally""","""  addEventListener('wheel', (e) => {
    if (ED.open) return;
    if (e.target !== canvas) return;               // let the control panel scroll normally""")
# picker takes 1-9, B opens the editor
s=sub1(s,"if (player.picker && k >= '0' && k <= '4') { choosePicked(+k); e.preventDefault(); return; }",
         "if (player.picker && k >= '0' && k <= '9') { choosePicked(+k); e.preventDefault(); return; }\n    if (k === 'b' && started) { openEditor(player.c && player.c.alive ? 'game' : 'start'); e.preventDefault(); return; }")
# the old graft picker is replaced by the part-unlock picker
s=sub1(s,"function renderPicker() {\n  const el = $('picker');\n  if (!el) return;\n  const pk = player.picker;\n  if (!pk) { el.style.display = 'none'; return; }\n  const DESC",
         "function renderPickerOld() {\n  const el = $('picker');\n  if (!el) return;\n  const pk = player.picker;\n  if (!pk) { el.style.display = 'none'; return; }\n  const DESC")
s=sub1(s,"function choosePicked(i) {\n  const pk = player.picker;\n  if (!pk) return;\n  if (i === 0) { player.picker = null; renderPicker(); toast('Took nothing.', 1200); return; }",
         "function choosePickedOld(i) {\n  const pk = player.picker;\n  if (!pk) return;\n  if (i === 0) { player.picker = null; renderPicker(); toast('Took nothing.', 1200); return; }")
# kills unlock parts and grow genome space; eating a corpse is just food now
s=sub1(s,"  if (!offerTraits(best.genome, 'You killed it')) toast('Killed it.', 2000);","  edOnKill(best);")
s=sub1(s,"""    if (!offerTraits(bestC.genome, 'You fed on the corpse (+' + gain.toFixed(0) + ')'))
      toast('Ate carrion. +' + gain.toFixed(0) + ' energy.', 1800);""","""    toast('Ate carrion. +' + gain.toFixed(0) + ' energy.', 1800);""")
# HUD: genome/kills line and an editor button
s=sub1(s,"""  <div id="v-stats" class="k"></div>""","""  <div id="v-stats" class="k"></div>
  <div id="v-genome" class="k"></div>""")
s=sub1(s,"""<button id="ptab">controls</button>""","""<button id="ptab">controls</button>
<button id="edOpenBtn" title="edit your creature (B)">edit creature (B)</button>""")
s=sub1(s,"""function updateHUD() {
  const c = player.c;""","""function updateHUD() {
  edHudLine();
  const c = player.c;""")
# start screen: create or random
s=sub1(s,"""  <div class="arch">
    <div class="alab">choose what you are born as</div>
    <button data-arch="random">random</button><button data-arch="grazer">grazer</button
    ><button data-arch="runner">runner</button><button data-arch="brute">brute</button
    ><button data-arch="hunter">hunter</button><button data-arch="swimmer">swimmer</button
    ><button data-arch="flier">flier</button>
  </div>""","""  <div class="arch">
    <div class="alab">how do you want to be born</div>
    <button data-act="create" class="big">create your creature</button><button data-act="last" id="startLast" style="display:none">play my last creature</button><button data-arch="random">random creature</button>
  </div>""")
s=sub1(s,"""    <b>Tab</b> controls panel<br>""","""    <b>Tab</b> controls panel &nbsp;·&nbsp; <b>B</b> creature editor, any time<br>""")
s=sub1(s,"""  startEl.addEventListener('click', (e) => {
    const btn = e.target && e.target.closest ? e.target.closest('[data-arch]') : null;""","""  const lastBtn = $('startLast'); if (lastBtn && PROG.last) lastBtn.style.display = '';
  const edb = $('edOpenBtn');
  if (edb) edb.addEventListener('click', () => { if (started) openEditor(player.c && player.c.alive ? 'game' : 'start'); });
  startEl.addEventListener('click', (e) => {
    const act = e.target && e.target.closest ? e.target.closest('[data-act]') : null;
    if (act) {
      e.stopPropagation();
      const a = act.getAttribute('data-act');
      if (a === 'create') { openEditor('start'); return; }
      if (a === 'last' && PROG.last) { becomeDesigned(C.cloneDesign(PROG.last)); beginPlay(); return; }
    }
    const btn = e.target && e.target.closest ? e.target.closest('[data-arch]') : null;""")
s=sub1(s,"""  #start .arch button:hover{background:#12332e;border-color:#35e0d8}""","""  #start .arch button:hover{background:#12332e;border-color:#35e0d8}
  #start .arch button.big{font-size:17px;font-weight:700;padding:13px 24px;color:#06231a;background:linear-gradient(180deg,#b8ff8e,#54d35a);border-color:#d6ffc0}""")
# test surface
s=sub1(s,"""  absorbFrom: (prey) => absorbPartFrom(prey),""","""  absorbFrom: (prey) => absorbPartFrom(prey),
  get ED() { return ED; }, get PROG() { return PROG; },
  openEditor: (m) => openEditor(m), closeEditor: (a) => closeEditor(a),
  startAnim: (c, k, d) => startAnim(c, k, d), sndDbg: { voxCall: (c, w) => voxCall(c, w), roar: () => playerRoar(), get SND() { return SND; }, get SFX() { return SFX; }, voxOf: (c) => voxOf(c) }, setMove: (m) => { player.moveSel = m; },
  meshDbg: { designGeo, creaturePrims, meshPrims, get skinDraws() { return skinDraws.length; }, get boneN() { return boneN; }, get pool() { return meshPool ? meshPool.length : (meshPoolBroken ? -1 : 0); }, get FOL() { return FOL; } },
  edAddPart: (id, hit) => edAddPart(id, hit), edAddLimb: (id, hit) => edAddLimb(id, hit), edSetTip: (l, id) => edSetTip(l, id),
  edBodyHit: (x, y) => edBodyHit(x, y), edProject: (p) => edProject(p), edPick: (x, y) => edPick(x, y),
  limbWorld: (l) => limbWorld(l), partWorld: (p) => partWorld(p), onKill: (c) => edOnKill(c),
  becomeDesigned: (d) => becomeDesigned(d), designFromGenome: (g) => designFromGenome(g),""")
open('g3.html','w',encoding='utf-8').write(s)
print('editor ok')
