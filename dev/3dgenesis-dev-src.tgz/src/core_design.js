  // =====================================================================
  // CREATURE DESIGNS (v10)
  // A design is a hand-built body: one of ten base body plans, a set of parts
  // placed freely on the skin, and jointed limbs. It is still a real genome:
  // compileDesign() turns it into ordinary body-tree nodes (so upkeep, mass,
  // speciation, growth and cell starvation all work unchanged) plus a small
  // table of extras for the effects the old part vocabulary had no word for
  // (claws, hands, hooves, armour plates). Everything here is pure math, no
  // DOM, so the simulation can develop, mutate and breed designed animals.
  //
  // Units: body-local, in multiples of the creature's own radius R.
  // x = forward, y = up, z = lateral. Mirroring is z -> -z.
  // =====================================================================
  // Sim meaning of every placeable item. `t` is the body-tree node type the
  // item compiles to, `w` its tissue weight (node size), `cost` its genome
  // space. Optional extras: atk, def, reach, sense, spd (land speed fraction),
  // fin (extra swim surface), grab (hands), sweep (tail weapon).
  const ITEM_SIM = {
    m_beak:     { t: 'MOUTH', mode: 'herb', w: 0.7, cost: 1 },
    m_grazer:   { t: 'MOUTH', mode: 'herb', w: 0.8, cost: 1 },
    m_trunk:    { t: 'MOUTH', mode: 'herb', w: 0.9, cost: 2, reach: 6 },
    m_jaws:     { t: 'MOUTH', mode: 'carn', w: 0.8, cost: 2 },
    m_maw:      { t: 'MOUTH', mode: 'carn', w: 1.0, cost: 3, atk: 3 },
    m_hook:     { t: 'MOUTH', mode: 'scav', w: 0.8, cost: 2 },
    e_round:    { t: 'EYE', w: 0.6, cost: 1 },
    e_big:      { t: 'EYE', w: 0.9, cost: 2, sense: 8 },
    e_slit:     { t: 'EYE', w: 0.7, cost: 1 },
    e_stalk:    { t: 'EYE', w: 0.7, cost: 2, sense: 14 },
    e_cluster:  { t: 'EYE', w: 0.9, cost: 2, sense: 10 },
    e_bug:      { t: 'EYE', w: 0.8, cost: 2, sense: 12 },
    h_straight: { t: 'HORN', w: 0.7, cost: 2 },
    h_curved:   { t: 'HORN', w: 0.8, cost: 2 },
    h_ram:      { t: 'HORN', w: 0.9, cost: 3, def: 4 },
    h_antler:   { t: 'HORN', w: 0.9, cost: 3, reach: 4 },
    h_rhino:    { t: 'HORN', w: 1.1, cost: 3, atk: 3 },
    h_tusk:     { t: 'HORN', w: 0.8, cost: 2, atk: 2 },
    s_spike:    { t: 'SPIKE', w: 0.6, cost: 1 },
    s_quills:   { t: 'SPIKE', w: 0.7, cost: 2 },
    s_plate:    { t: 'SPIKE', w: 0.8, cost: 2, def: 3 },
    s_shell:    { t: 'SPIKE', w: 1.2, cost: 3, def: 8, spd: -0.04 },
    s_knob:     { t: 'SPIKE', w: 0.5, cost: 1 },
    s_club:     { t: 'SPIKE', w: 0.7, cost: 2, atk: 4, sweep: 1 },
    l_leg:      { t: 'LIMB', w: 1.0, cost: 2, limb: 1 },
    l_thick:    { t: 'LIMB', w: 1.3, cost: 3, def: 2, limb: 1 },
    l_thin:     { t: 'LIMB', w: 0.75, cost: 1, limb: 1 },
    l_spring:   { t: 'LIMB', w: 1.1, cost: 3, limb: 1, spring: 1, spd: 0.03 },
    t_paw:      { t: 'TIP', w: 0.3, cost: 1, spd: 0.03, tip: 1 },
    t_hoof:     { t: 'TIP', w: 0.3, cost: 1, spd: 0.06, tip: 1 },
    t_talon:    { t: 'TIP', w: 0.3, cost: 1, atk: 3, tip: 1 },
    t_hand:     { t: 'TIP', w: 0.35, cost: 2, reach: 8, grab: 1, tip: 1 },
    t_claw:     { t: 'TIP', w: 0.4, cost: 2, atk: 5, tip: 1 },
    t_pincer:   { t: 'TIP', w: 0.5, cost: 2, atk: 6, tip: 1 },
    t_flipper:  { t: 'TIP', w: 0.4, cost: 1, fin: 0.45, tip: 1 },
    t_pad:      { t: 'TIP', w: 0.3, cost: 1, spd: 0.02, def: 1, tip: 1 },
    f_fin:      { t: 'FIN', w: 0.8, cost: 2 },
    f_dorsal:   { t: 'FIN', w: 0.7, cost: 2 },
    f_fluke:    { t: 'FIN', w: 1.0, cost: 2 },
    w_bat:      { t: 'WING', w: 1.6, cost: 3 },
    w_feather:  { t: 'WING', w: 1.7, cost: 3 },
    w_insect:   { t: 'WING', w: 1.3, cost: 2 },
    d_antenna:  { t: 'EYE', w: 0.25, cost: 1, sense: 10 },
    d_crest:    { t: 'ORN', w: 0.3, cost: 1 },
    d_frill:    { t: 'ORN', w: 0.5, cost: 1, def: 2 },
    d_gills:    { t: 'FIN', w: 0.4, cost: 1 },
    d_gland:    { t: 'GLAND', w: 0.8, cost: 2 },
  };
  // Parts that must never be duplicated: placing a second one replaces the first.
  const ITEM_SINGLE = { MOUTH: 1 };

  // Ten base body plans. Numbers are the rest-pose skeleton in R units:
  // a/b = spine half-length / body radius, seg = spine balls, prof = girth
  // profile, arch/droop = spine curve, wide = extra lateral mass, neck/nx/ny =
  // neck length and direction, head/snx/snr = head and snout, tail/tailR/ts =
  // tail length, root thickness and ball count, flex = the whole body is a
  // flexible chain (undulates instead of being one rigid skin).
  const PLANS = [
    { a: 1.25, b: 0.80, seg: 11, prof: 'animal', arch: 0.13, droop: 0.07, wide: 0,    neck: 0.40, nx: 0.75, ny: 0.72, ns: 3, head: 0.50, snx: 0.62, snr: 0.62, tail: 1.3, tailR: 0.30, ts: 7, stand: 1.35 },
    { a: 1.10, b: 0.78, seg: 11, prof: 'animal', arch: 0.16, droop: 0.02, wide: 0,    neck: 1.90, nx: 0.42, ny: 0.92, ns: 7, head: 0.40, snx: 0.72, snr: 0.58, tail: 0.7, tailR: 0.22, ts: 5, stand: 2.25 },
    { a: 1.05, b: 0.82, seg: 11, prof: 'animal', arch: 0.10, droop: 0.12, wide: 0,    neck: 0.75, nx: 0.62, ny: 0.80, ns: 4, head: 0.50, snx: 0.70, snr: 0.60, tail: 1.9, tailR: 0.36, ts: 9, stand: 1.60 },
    { a: 1.95, b: 0.50, seg: 18, prof: 'tube',   arch: 0.00, droop: 0.00, wide: 0,    neck: 0.10, nx: 0.95, ny: 0.30, ns: 2, head: 0.52, snx: 0.62, snr: 0.62, tail: 2.2, tailR: 0.40, ts: 10, stand: 0.45, flex: 1 },
    { a: 0.85, b: 0.95, seg: 9,  prof: 'round',  arch: 0.10, droop: 0.00, wide: 0.30, neck: 0.00, nx: 0.8,  ny: 0.3,  ns: 2, head: 0.46, snx: 0.45, snr: 0.55, tail: 0.0, tailR: 0.30, ts: 4, stand: 0.95 },
    { a: 1.45, b: 0.62, seg: 13, prof: 'insect', arch: 0.06, droop: 0.00, wide: 0,    neck: 0.10, nx: 0.9,  ny: 0.4,  ns: 2, head: 0.44, snx: 0.50, snr: 0.55, tail: 0.0, tailR: 0.25, ts: 4, stand: 1.05 },
    { a: 1.65, b: 0.70, seg: 13, prof: 'fish',   arch: 0.05, droop: 0.00, wide: 0,    neck: 0.00, nx: 0.9,  ny: 0.2,  ns: 2, head: 0.55, snx: 0.55, snr: 0.62, tail: 1.1, tailR: 0.34, ts: 6, stand: 0.80 },
    { a: 0.95, b: 0.72, seg: 11, prof: 'animal', arch: 0.14, droop: 0.05, wide: 0,    neck: 0.55, nx: 0.62, ny: 0.85, ns: 3, head: 0.46, snx: 0.62, snr: 0.50, tail: 0.8, tailR: 0.24, ts: 6, stand: 1.10 },
    { a: 1.20, b: 1.02, seg: 11, prof: 'animal', arch: 0.10, droop: 0.04, wide: 0.42, neck: 0.20, nx: 0.85, ny: 0.45, ns: 2, head: 0.56, snx: 0.55, snr: 0.72, tail: 0.5, tailR: 0.32, ts: 5, stand: 1.00 },
    { a: 1.30, b: 0.85, seg: 11, prof: 'blob',   arch: 0.22, droop: 0.00, wide: 0.45, neck: 0.10, nx: 0.9,  ny: 0.5,  ns: 2, head: 0.50, snx: 0.40, snr: 0.62, tail: 0.4, tailR: 0.40, ts: 4, stand: 0.62 },
  ];
  const BODY_RANGE = { len: [0.6, 1.6], girth: [0.7, 1.45], neck: [0, 2.2], tail: [0, 1.8] };
  function planProfile(kind, u) {
    switch (kind) {
      case 'tube':   return 0.78 + 0.22 * Math.sin(Math.PI * clamp(0.15 + u * 0.8, 0, 1)) - (u > 0.9 ? (u - 0.9) * 2 : 0);
      case 'round':  return 0.35 + 0.65 * Math.sin(Math.PI * clamp(u, 0, 1));
      case 'insect': { const a = Math.exp(-Math.pow((u - 0.22) / 0.16, 2)), t = Math.exp(-Math.pow((u - 0.62) / 0.12, 2)), h = Math.exp(-Math.pow((u - 0.9) / 0.08, 2));
                       return clamp(0.28 + a * 0.72 + t * 0.52 + h * 0.3, 0.2, 1.0); }
      case 'fish':   return clamp(0.18 + 0.82 * Math.pow(Math.sin(Math.PI * clamp(u * 0.92 + 0.04, 0, 1)), 0.8) * (0.55 + 0.45 * u), 0.12, 1.0);
      case 'blob':   return 0.55 + 0.45 * Math.sin(Math.PI * clamp(u, 0, 1));
      default: {
        const chest = Math.exp(-Math.pow((u - 0.72) / 0.21, 2));
        const haunch = Math.exp(-Math.pow((u - 0.30) / 0.23, 2));
        const base = 0.30 + 0.28 * Math.sin(Math.PI * clamp(u * 1.04, 0, 1));
        return clamp(base + chest * 0.32 + haunch * 0.24, 0.12, 1.05);
      }
    }
  }
  const SKIN_REACH = 1.55, SKIN_ISO = 0.5;
  // Rest-pose skeleton for a design. The number and order of balls depends
  // only on the plan, never on the body sliders, so part anchors (which store
  // a ball index) survive any slider change.
  function buildDesignSkeleton(d) {
    const P = PLANS[clamp(d.plan | 0, 0, PLANS.length - 1)];
    const bd = d.body || {};
    const L = clamp(numOr(bd.len, 1), BODY_RANGE.len[0], BODY_RANGE.len[1]);
    const Gm = clamp(numOr(bd.girth, 1), BODY_RANGE.girth[0], BODY_RANGE.girth[1]);
    const Nm = clamp(numOr(bd.neck, 1), BODY_RANGE.neck[0], BODY_RANGE.neck[1]);
    const Tm = clamp(numOr(bd.tail, 1), BODY_RANGE.tail[0], BODY_RANGE.tail[1]);
    const a = P.a * L, b = P.b * Gm;
    const balls = [];
    for (let i = 0; i < P.seg; i++) {
      const u = i / (P.seg - 1);
      balls.push({ x: -a + 2 * a * u, y: (P.arch * Math.sin(Math.PI * u) - P.droop * (1 - u)) * b, z: 0,
                   r: b * planProfile(P.prof, u), g: 'body' });
    }
    // lateral mass for broad plans (always 3 pairs so indices stay fixed)
    for (const u of [0.28, 0.5, 0.72]) {
      const w = P.wide || 0;
      const r = w > 0 ? b * planProfile(P.prof, u) * 0.72 : 0.0001;
      const x = -a + 2 * a * u, y = (P.arch * Math.sin(Math.PI * u) - P.droop * (1 - u)) * b - b * 0.12;
      balls.push({ x, y, z:  b * w, r, g: 'body', hide: w <= 0 });
      balls.push({ x, y, z: -b * w, r, g: 'body', hide: w <= 0 });
    }
    const NK = P.neck * Nm;
    const neckLen = NK * 2.6;
    const hx = a * 0.78 + neckLen * P.nx, hy = b * 0.30 + neckLen * P.ny;
    const nx0 = a * 0.70, ny0 = b * 0.22;
    for (let i = 1; i <= P.ns; i++) {
      const u = i / (P.ns + 1);
      const r = neckLen > 0.12 ? (0.34 - 0.10 * u) * (1 + NK * 0.15) : 0.0001;
      balls.push({ x: nx0 + (hx - nx0) * u, y: ny0 + (hy - ny0) * u, z: 0, r, g: 'neck', hide: neckLen <= 0.12 });
    }
    const headIdx = balls.length;
    const hr = P.head;
    balls.push({ x: hx, y: hy, z: 0, r: hr, g: 'head' });
    balls.push({ x: hx + hr * P.snx, y: hy - hr * 0.18, z: 0, r: hr * P.snr, g: 'head' });
    const tailStart = balls.length;
    const tl = P.tail * Tm;
    const tr0 = P.tailR * Gm;
    let tx = -a * 0.92, ty = b * 0.08;
    const seg = tl / P.ts;
    for (let i = 1; i <= P.ts; i++) {
      const u = i / P.ts;
      tx -= seg * Math.cos(0.12 + 0.18 * u);
      ty -= seg * Math.sin(0.12 + 0.18 * u) * 0.6;
      const r = tl > 0.05 ? Math.max(0.03, tr0 * (1 - 0.78 * u)) : 0.0001;
      balls.push({ x: tx, y: ty, z: 0, r, g: 'tail', hide: tl <= 0.05 });
    }
    const sk = { balls, a, b, headIdx, tailStart, tailLen: tl, neckLen, NK, plan: P, flex: !!P.flex };
    buildBodyPrims(sk);
    return sk;
  }
  // ---- signed-distance skin -------------------------------------------------
  // The skin is a smooth union of tapered capsules ("round cones") running
  // through the skeleton: spine, lateral mass, neck, head and snout, and the
  // tail. A round cone is continuous by construction, so no slider setting can
  // open a gap, and a smooth minimum blends each joint into its neighbour.
  // Radii are the balls' visible radii (the old metaball iso sat at ~0.8 r).
  const VISR = { body: 0.92, neck: 0.86, head: 0.8, tail: 0.95 };
  function smin(a, b, k) {
    if (k <= 0) return Math.min(a, b);
    const h = Math.max(k - Math.abs(a - b), 0) / k;
    return Math.min(a, b) - h * h * k * 0.25;
  }
  // exact signed distance to a round cone (sphere-swept segment, radius ra at a
  // tapering to rb at b), after Inigo Quilez
  function sdRoundCone(px, py, pz, ax, ay, az, bx, by, bz, ra, rb) {
    const bax = bx - ax, bay = by - ay, baz = bz - az;
    const l2 = bax * bax + bay * bay + baz * baz;
    if (l2 < 1e-10) { const dx = px - ax, dy = py - ay, dz = pz - az; return Math.sqrt(dx * dx + dy * dy + dz * dz) - Math.max(ra, rb); }
    const rr = ra - rb, a2 = l2 - rr * rr, il2 = 1 / l2;
    const pax = px - ax, pay = py - ay, paz = pz - az;
    const y = pax * bax + pay * bay + paz * baz, z = y - l2;
    const xx = pax * l2 - bax * y, xy = pay * l2 - bay * y, xz = paz * l2 - baz * y;
    const x2 = xx * xx + xy * xy + xz * xz, y2 = y * y * l2, z2 = z * z * l2;
    const k = Math.sign(rr) * rr * rr * x2;
    if (Math.sign(z) * a2 * z2 > k) return Math.sqrt(x2 + z2) * il2 - rb;
    if (Math.sign(y) * a2 * y2 < k) return Math.sqrt(x2 + y2) * il2 - ra;
    return (Math.sqrt(x2 * a2 * il2) + y * rr) * il2 - ra;
  }
  function primDist(q, x, y, z) {
    return q.t === 's' ? Math.hypot(x - q.ax, y - q.ay, z - q.az) - q.ra
                       : sdRoundCone(x, y, z, q.ax, q.ay, q.az, q.bx, q.by, q.bz, q.ra, q.rb);
  }
  function buildBodyPrims(sk) {
    const B = sk.balls, P = sk.plan;
    const live = (i) => B[i] && !B[i].hide;
    const vr = (i) => B[i].r * (VISR[B[i].g] || 0.9);
    const body = [], tail = [];
    const cone = (i, j, out, k) => {
      if (!live(i) || !live(j)) return;
      out.push({ t: 'c', ax: B[i].x, ay: B[i].y, az: B[i].z, bx: B[j].x, by: B[j].y, bz: B[j].z, ra: vr(i), rb: vr(j), k, i, j });
    };
    const sph = (i, out, k) => { if (live(i)) out.push({ t: 's', ax: B[i].x, ay: B[i].y, az: B[i].z, ra: vr(i), k, i, j: i }); };
    const kb = 0.32 * sk.b;
    for (let i = 0; i + 1 < P.seg; i++) cone(i, i + 1, body, kb);
    const nearestSpine = (x, y, z) => {
      let bi = 0, bd = Infinity;
      for (let i = 0; i < P.seg; i++) { const d = Math.hypot(B[i].x - x, B[i].y - y, B[i].z - z); if (d < bd) { bd = d; bi = i; } }
      return bi;
    };
    for (let i = P.seg; i < P.seg + 6; i++) if (live(i)) { sph(i, body, kb * 1.4); cone(i, nearestSpine(B[i].x, B[i].y, B[i].z), body, kb * 1.4); }
    const chain = [];
    for (let i = P.seg + 6; i < sk.headIdx; i++) if (live(i)) chain.push(i);
    chain.push(sk.headIdx);
    let prev = nearestSpine(B[chain[0]].x, B[chain[0]].y, B[chain[0]].z);
    for (const i of chain) { cone(prev, i, body, 0.18); prev = i; }
    sph(sk.headIdx, body, 0.22);
    cone(sk.headIdx, sk.headIdx + 1, body, 0.2);
    // tail: from the rump through every tail ball
    if (sk.tailLen > 0.05) {
      const t0 = { x: -sk.a * 0.92, y: sk.b * 0.08, z: 0 };
      const r0 = B[sk.tailStart].r * 1.15 * VISR.tail;
      tail.push({ t: 'c', ax: t0.x, ay: t0.y, az: t0.z, bx: B[sk.tailStart].x, by: B[sk.tailStart].y, bz: B[sk.tailStart].z, ra: r0, rb: vr(sk.tailStart), k: 0.25, i: sk.tailStart, j: sk.tailStart, bone: 'tail0' });
      for (let i = sk.tailStart; i + 1 < sk.tailStart + P.ts; i++) cone(i, i + 1, tail, 0.12);
    }
    sk.prims = body; sk.tailPrims = tail;
  }
  function sdfSkin(sk, x, y, z, withTail) {
    let d = 1e9;
    const L = sk.prims;
    for (let n = 0; n < L.length; n++) d = smin(d, primDist(L[n], x, y, z), L[n].k);
    if (withTail) { const T = sk.tailPrims; for (let n = 0; n < T.length; n++) d = smin(d, primDist(T[n], x, y, z), T[n].k); }
    return d;
  }
  // kept for callers that still think in fields: inside > 0.5, outside < 0.5
  function skinField(sk, x, y, z) { return SKIN_ISO - sdfSkin(sk, x, y, z, false); }
  function nearestBall(sk, x, y, z, allowTail) {
    let best = 0, bd = Infinity;
    const B = sk.balls;
    for (let i = 0; i < B.length; i++) {
      const k = B[i];
      if (k.hide || (!allowTail && k.g === 'tail')) continue;
      const d = Math.hypot(x - k.x, y - k.y, z - k.z) - k.r;
      if (d < bd) { bd = d; best = i; }
    }
    return best;
  }
  function fieldNormal(sk, x, y, z, withTail) {
    const e = 0.004;
    const gx = sdfSkin(sk, x + e, y, z, withTail) - sdfSkin(sk, x - e, y, z, withTail);
    const gy = sdfSkin(sk, x, y + e, z, withTail) - sdfSkin(sk, x, y - e, z, withTail);
    const gz = sdfSkin(sk, x, y, z + e, withTail) - sdfSkin(sk, x, y, z - e, withTail);
    const l = Math.hypot(gx, gy, gz);
    return l > 1e-9 ? [gx / l, gy / l, gz / l] : [0, 1, 0];
  }
  // Ray against the whole skin (tail included) by sphere tracing the distance
  // field. Returns {p, n, b, t} or null.
  function raySkin(sk, ox, oy, oz, dx, dy, dz, tMax) {
    let t = 0;
    let d0 = sdfSkin(sk, ox, oy, oz, true);
    if (d0 < 0) return null;                 // started inside the body
    for (let it = 0; it < 256 && t < tMax; it++) {
      const px = ox + dx * t, py = oy + dy * t, pz = oz + dz * t;
      const d = sdfSkin(sk, px, py, pz, true);
      if (d < 0.0015) {
        return { t, p: [px, py, pz], n: fieldNormal(sk, px, py, pz, true), b: nearestBall(sk, px, py, pz, true) };
      }
      t += Math.max(d * 0.85, 0.002);
    }
    return null;
  }
  // Pull a point back onto the surface along its own normal.
  function snapToSkin(sk, p, n) {
    const L = 1.4;
    return raySkin(sk, p[0] + n[0] * L, p[1] + n[1] * L, p[2] + n[2] * L, -n[0], -n[1], -n[2], L * 2.4);
  }
  // Anchor stored on a part: ball index + offset from that ball's centre in
  // units of its radius, so a slider that fattens the ball moves the part out
  // with the skin.
  function anchorPos(sk, part) {
    const k = sk.balls[clamp(part.b | 0, 0, sk.balls.length - 1)];
    const o = part.o || [0, 0, 0];
    const r = Math.max(0.05, k.r);
    return [k.x + o[0] * r, k.y + o[1] * r, k.z + o[2] * r];
  }
  function setAnchor(sk, part, p, n, b) {
    const k = sk.balls[b];
    const r = Math.max(0.05, k.r);
    part.b = b; part.o = [(p[0] - k.x) / r, (p[1] - k.y) / r, (p[2] - k.z) / r]; part.n = [n[0], n[1], n[2]];
  }
  // Re-seat every anchor on the current skeleton (after a slider change).
  function reseatDesign(d) {
    const sk = buildDesignSkeleton(d);
    const fix = (pt) => {
      const p = anchorPos(sk, pt);
      const n = pt.n || [0, 1, 0];
      const k = sk.balls[pt.b | 0];
      if (k && k.g === 'tail') return;             // tail anchors are sphere offsets already
      const h = snapToSkin(sk, p, n);
      if (h) setAnchor(sk, pt, h.p, h.n, h.b);
    };
    for (const pt of d.parts || []) fix(pt);
    for (const lb of d.limbs || []) fix(lb);
    return sk;
  }

  // Legs are limbs whose foot reaches down to walking height; every other
  // limb is an arm. Stand height is the mean reach of the legs, so stretching
  // the legs genuinely lifts the body off the ground.
  function classifyLimbs(d, sk) {
    const out = [];
    for (const lb of d.limbs || []) {
      const root = anchorPos(sk, lb);
      const f = lb.f || [0, -1, 0], k = lb.k || [0, -0.5, 0];
      const L1 = Math.hypot(k[0], k[1], k[2]);
      const L2 = Math.hypot(f[0] - k[0], f[1] - k[1], f[2] - k[2]);
      out.push({ lb, root, footY: root[1] + f[1], L1, L2, leg: false });
    }
    const P = sk.plan;
    let cand = out.filter(o => o.footY < -0.45);
    let stand = P.stand;
    if (cand.length) {
      stand = cand.reduce((s, o) => s + (-o.footY), 0) / cand.length;
      cand = cand.filter(o => -o.footY >= stand * 0.72);
      // stand on the SHORTEST leg: every foot then reaches the ground (longer legs
      // bend at the knee) instead of short legs dangling in the air
      if (cand.length) stand = cand.reduce((m, o) => Math.min(m, -o.footY), Infinity) * 0.97;
      for (const o of cand) o.leg = true;
    } else {
      // no legs: the belly rests on the ground
      let low = 0;
      for (const k of sk.balls) if (!k.hide && k.g !== 'tail') low = Math.min(low, k.y - k.r * 0.85);
      stand = -low;
    }
    return { limbs: out, stand: clamp(stand, 0.3, 5), legs: out.filter(o => o.leg).length };
  }

  function designCost(d) {
    let c = 0;
    for (const pt of d.parts || []) c += (ITEM_SIM[pt.id] || { cost: 1 }).cost;
    for (const lb of d.limbs || []) {
      c += (ITEM_SIM[lb.id] || { cost: 2 }).cost;
      if (lb.tip && ITEM_SIM[lb.tip.id]) c += ITEM_SIM[lb.tip.id].cost;
    }
    return c;
  }
  function cloneDesign(d) { return d ? JSON.parse(JSON.stringify(d)) : null; }

  // Turn a design into body-tree nodes, body-plan genes and extras.
  function compileDesign(g) {
    const d = g.design;
    const sk = buildDesignSkeleton(d);
    const cls = classifyLimbs(d, sk);
    const groups = {};     // type|mode -> sizes[]
    const add = (type, size, mode) => {
      const key = type + '|' + (mode || '');
      (groups[key] || (groups[key] = { type, mode: mode || null, sizes: [] })).sizes.push(size);
    };
    const dx = { atk: 0, def: 0, reach: 0, sense: 0, spd: 0, fin: 0, grab: 0, sweep: 0, claw: 0, legs: 0, arms: 0, spring: 0 };
    const extra = (s, scale) => {
      if (!s) return;
      dx.atk += (s.atk || 0) * scale; dx.def += (s.def || 0) * scale; dx.reach += (s.reach || 0) * scale;
      dx.sense += (s.sense || 0) * scale; dx.fin += (s.fin || 0) * scale; dx.grab += (s.grab || 0);
      dx.sweep += (s.sweep || 0);
    };
    let mouth = null;
    for (const pt of d.parts || []) {
      const s = ITEM_SIM[pt.id];
      if (!s) continue;
      const sz = clamp(numOr(pt.s, 1), 0.3, 3);
      if (s.t === 'MOUTH') { mouth = { s, sz }; continue; }
      add(s.t, s.w * sz);
      extra(s, sz);
      dx.spd += (s.spd || 0);
    }
    for (const o of cls.limbs) {
      const s = ITEM_SIM[o.lb.id] || ITEM_SIM.l_leg;
      const th = clamp(numOr(o.lb.th, 1), 0.5, 2);
      const lenF = clamp((o.L1 + o.L2) / 1.6, 0.35, 2.2);
      add(o.leg ? 'LEG' : 'ARM', s.w * lenF * (0.7 + 0.3 * th));
      extra(s, 1);
      if (o.leg) { dx.legs++; if (s.spring) dx.spring++; } else dx.arms++;
      if (o.lb.tip && ITEM_SIM[o.lb.tip.id]) {
        const ts = ITEM_SIM[o.lb.tip.id];
        const tsz = clamp(numOr(o.lb.tip.s, 1), 0.4, 2.5);
        add('TIP', ts.w * tsz);
        // weapons on the ground are worth less than weapons you swing
        extra(ts, tsz * (o.leg ? 0.45 : 1));
        if (o.leg) dx.spd += (ts.spd || 0) * 0.5; else if (ts.atk) dx.claw += 1;
      }
    }
    if (dx.legs > 0) dx.spd = dx.spd / Math.max(1, dx.legs / 2);   // per-pair, not per-foot
    // body tree: CORE, GUT, MOUTH, TAIL, then one node per (type,mode) group,
    // split into chunks of <= MAX_RADIAL so repeat/radial stay in range
    const core = newCore();
    const gut = newNode('GUT', () => 0.5); gut.size = 0.8; gut.repeat = 1;
    core.children.push(gut);
    if (mouth) { const m = newNode('MOUTH', () => 0.5); m.mode = mouth.s.mode; m.size = mouth.s.w * mouth.sz; m.repeat = 1; core.children.push(m); extra(mouth.s, mouth.sz); }
    if (sk.tailLen > 0.05) { const t = newNode('TAIL', () => 0.5); t.size = clamp(sk.tailLen * 0.55, 0.2, 2.5); t.repeat = 1; core.children.push(t); }
    for (const key of Object.keys(groups).sort()) {
      const gp = groups[key];
      for (let i = 0; i < gp.sizes.length; i += MAX_RADIAL) {
        const chunk = gp.sizes.slice(i, i + MAX_RADIAL);
        const avg = chunk.reduce((a, b) => a + b, 0) / chunk.length;
        const nd = newNode(gp.type, () => 0.5);
        nd.mode = gp.mode; nd.size = clamp(avg, 0.05, 6);
        nd.repeat = chunk.length; nd.radial = chunk.length > 1 ? chunk.length : 0;
        nd.dn = chunk.length;                        // exact count, read by develop()
        core.children.push(nd);
      }
    }
    g.body = core;
    const EL = clamp(sk.a / Math.max(0.2, sk.b), PLAN.elong[0], PLAN.elong[1]);
    g.elong = EL;
    g.neck = clamp(sk.NK, PLAN.neck[0], PLAN.neck[1]);
    g.legLen = clamp((cls.stand - 0.55) / 0.62, PLAN.legLen[0], PLAN.legLen[1]);
    if (sk.flex) dx.spd += 0.45;                     // slithering: the whole body is the stride
    dx.stand = cls.stand; dx.a = sk.a; dx.b = sk.b;
    g.dx = dx;
    return g;
  }

  // Small heritable drift for designed lineages: sizes, colours and joint
  // positions wander, and occasionally a part is lost or duplicated.
  function jitterDesign(d, rng, rate) {
    const r = clamp(numOr(rate, 0.5), 0, 1);
    const jc = (c) => c ? c.map(v => clamp(v + gauss(rng) * 0.025 * r, 0, 1)) : c;
    for (const pt of d.parts || []) {
      if (rng() < r * 0.5) pt.s = clamp(numOr(pt.s, 1) * Math.exp(gauss(rng) * 0.05), 0.3, 3);
      if (rng() < r * 0.3) pt.c = jc(pt.c);
    }
    for (const lb of d.limbs || []) {
      if (rng() < r * 0.4) {
        const k = 1 + gauss(rng) * 0.03;
        lb.k = lb.k.map(v => v * k); lb.f = lb.f.map(v => v * k);
      }
      if (lb.tip && rng() < r * 0.3) lb.tip.s = clamp(numOr(lb.tip.s, 1) * Math.exp(gauss(rng) * 0.05), 0.4, 2.5);
    }
    if (d.col) {
      if (rng() < r * 0.4) d.col.base = jc(d.col.base);
      if (rng() < r * 0.3) d.col.coat = jc(d.col.coat);
    }
    if (d.body && rng() < r * 0.25) {
      for (const k of ['len', 'girth', 'neck', 'tail']) {
        if (rng() < 0.5) d.body[k] = clamp(numOr(d.body[k], 1) + gauss(rng) * 0.04, BODY_RANGE[k][0], BODY_RANGE[k][1]);
      }
      reseatDesign(d);
    }
    // rare diet switch, and now and then a new ornament
    if (rng() < r * 0.012 && DESIGN_API.swapMouth) DESIGN_API.swapMouth(d, rng);
    if ((d.parts || []).length < 30 && rng() < r * 0.012 && DESIGN_API.addOrnaments) DESIGN_API.addOrnaments(d, rng, 1);
    const parts = d.parts || [];
    // rare loss of one non-mouth part (and its mirror twin)
    if (parts.length > 2 && rng() < r * 0.03) {
      const i = (rng() * parts.length) | 0;
      const pt = parts[i];
      if (pt && ITEM_SIM[pt.id] && ITEM_SIM[pt.id].t !== 'MOUTH') {
        d.parts = parts.filter(q => q !== pt && !(pt.m && q.m === pt.m));
      }
    }
    // rare duplication: a copy of a part slides a little along the skin
    if (parts.length && parts.length < 40 && rng() < r * 0.03) {
      const src = parts[(rng() * parts.length) | 0];
      if (src && ITEM_SIM[src.id] && ITEM_SIM[src.id].t !== 'MOUTH') {
        const sk = buildDesignSkeleton(d);
        const p = anchorPos(sk, src);
        const q = [p[0] + (rng() - 0.5) * 0.4, p[1] + (rng() - 0.3) * 0.2, p[2]];
        const h = snapToSkin(sk, q, src.n || [0, 1, 0]);
        if (h) {
          const cp = JSON.parse(JSON.stringify(src)); cp.m = 0;
          setAnchor(sk, cp, h.p, h.n, h.b);
          d.parts.push(cp);
        }
      }
    }
    return d;
  }
  const DESIGN_API = {
    ITEM_SIM, ITEM_SINGLE, PLANS, BODY_RANGE, planProfile, buildDesignSkeleton, skinField, raySkin, snapToSkin,
    anchorPos, setAnchor, reseatDesign, classifyLimbs, designCost, cloneDesign, compileDesign, jitterDesign,
    nearestBall, fieldNormal, SKIN_REACH, SKIN_ISO, sdfSkin, sdRoundCone, primDist, smin,
  };
