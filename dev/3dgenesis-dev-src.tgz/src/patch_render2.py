def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
s=open('g3.html',encoding='utf-8').read()
rd=open('src/render_design.js',encoding='utf-8').read()
rd += '\n' + open('src/mesh_build.js',encoding='utf-8').read() + '\n' + open('src/render_mesh.js',encoding='utf-8').read()
rg=open('src/render_game.js',encoding='utf-8').read()
s=sub1(s,"// ================================================================ player\n", rd+"\n"+rg+"\n// ================================================================ player\n")
s=sub1(s,"""  const far = camDist > 900;
""","""  const far = camDist > 900;
  if (c.genome && c.genome.design) {
    drawDesignedCreature(c, t, camDist, {
      R, wx, wz, dirW, bodyY, yaw, far, phase0, gaitAmt, armSwing, tailSwing, flinch,
      bite: an && (an.kind === 'bite' || an.kind === 'gore') ? Math.max(0, an.s) : 0,
      hover: groundY - surf, swimming: inWater && !!p.canSwim, groundAt, anim: an,
    });
    return;
  }
""")
s=sub1(s,"""function bodyExtent(c) {
""","""function bodyExtent(c) {
  const de = designExtentOf(c);
  if (de != null) return de * (c.ph.radius || 4) * BODY_SCALE;
""")
s=sub1(s,"""  if ((n.LEG || 0) >= 2 && p.mass > 1.2) out.push('claw');""","""  if (((n.LEG || 0) >= 2 && p.mass > 1.2) || p.dClaw) out.push('claw');
  if (p.dSweep && !out.includes('sweep')) out.push('sweep');""")
# designed skins: grid fine enough for the thinnest part (flag f on the balls)
s=sub1(s,"""  const span = Math.max(maxX - minX, maxY - minY, maxZ - minZ);
  if (!(span > 0)) return null;
  const step = span / MESH_RES;""","""  const span = Math.max(maxX - minX, maxY - minY, maxZ - minZ);
  if (!(span > 0)) return null;
  let step = span / MESH_RES;
  if (skel[0] && skel[0].f) {
    let minR = Infinity; for (const k of skel) minR = Math.min(minR, k.r);
    step = Math.max(span / 88, Math.min(step, minR * 0.5));
  }""")
s=sub1(s,"""    meshQueue.push({ key, skel: skel.map(k => ({ x: k.x, y: k.y, z: k.z, r: k.r, w: k.w })) });""",
       """    meshQueue.push({ key, skel: skel.map(k => ({ x: k.x, y: k.y, z: k.z, r: k.r, w: k.w, f: k.f })) });""")
s=sub1(s,"""  for (const k of skel) {
    s += (k.x * 12 | 0) + ',' + (k.y * 12 | 0) + ',' + (k.z * 12 | 0) + ',' + (k.r * 14 | 0) + ';';
  }""","""  if (skel[0] && skel[0].f) s += 'F';
  for (const k of skel) {
    s += (k.x * 12 | 0) + ',' + (k.y * 12 | 0) + ',' + (k.z * 12 | 0) + ',' + (k.r * 14 | 0) + ';';
  }""")
open('g3.html','w',encoding='utf-8').write(s)
print('render2 ok')
