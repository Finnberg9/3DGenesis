import sys
def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
s=open('g3.html',encoding='utf-8').read()

# ---- part vocabulary: arms, limb tips and ornaments (design-only, never produced by random mutation)
s=sub1(s,"""    GLAND: { upkeep: 0.20, maxRepeat: 4 },
  };""","""    GLAND: { upkeep: 0.20, maxRepeat: 4 },
    // v10 design-only tissue: never added by random mutation (not in APPENDAGE_TYPES)
    ARM:   { upkeep: 0.18, maxRepeat: 8 },
    TIP:   { upkeep: 0.08, maxRepeat: 8 },
    ORN:   { upkeep: 0.05, maxRepeat: 8 },
  };""")

# ---- cloneGenome carries the design
s=sub1(s,"""      elong: planOf(g, 'elong'), neck: planOf(g, 'neck'), legLen: planOf(g, 'legLen'),
    };
  }""","""      elong: planOf(g, 'elong'), neck: planOf(g, 'neck'), legLen: planOf(g, 'legLen'),
      design: g.design ? JSON.parse(JSON.stringify(g.design)) : undefined,
      dx: g.dx ? Object.assign({}, g.dx) : undefined,
    };
  }""")

# ---- mutate: designed genomes drift through their design, then recompile
s=sub1(s,"""  function mutate(world, genome, rng, rate) {
    const g = cloneGenome(genome);
""","""  function mutate(world, genome, rng, rate) {
    const g = cloneGenome(genome);
    if (g.design) {
      jitterDesign(g.design, rng, rate);
      compileDesign(g);
      g.brain = mutateBrain(world, g.brain, rng, rate);
      if (rng() < rate) { g.hue = (g.hue + gauss(rng) * 0.06) % 1; if (g.hue < 0) g.hue += 1; }
      if (rng() < rate) g.scale = clamp((g.scale || 1) * Math.exp(gauss(rng) * 0.10), 0.12, 16);
      if (rng() < rate) g.life = clamp((g.life || 1) * Math.exp(gauss(rng) * 0.12), 0.5, 4);
      return g;
    }
""")

# ---- crossover: a designed parent passes its design on whole
s=sub1(s,"""  function crossover(ga, gb, rng) {
    const body = trimToCap(normalizeGenome(crossBody(ga.body, gb.body, rng)));""","""  function crossover(ga, gb, rng) {
    if (ga.design || gb.design) {
      const src = (ga.design && gb.design) ? (rng() < 0.5 ? ga : gb) : (ga.design ? ga : gb);
      const gmean2 = (a, b) => Math.sqrt((a != null ? a : 1) * (b != null ? b : 1));
      const child = {
        body: null, brain: crossoverBrain(ga.brain, gb.brain, rng), hue: rng() < 0.5 ? ga.hue : gb.hue,
        scale: gmean2(ga.scale, gb.scale), life: gmean2(ga.life, gb.life),
        design: JSON.parse(JSON.stringify(src.design)),
      };
      return compileDesign(child);
    }
    const body = trimToCap(normalizeGenome(crossBody(ga.body, gb.body, rng)));""")

# ---- develop: designed path accumulates the compiled nodes directly
s=sub1(s,"""        case 'MOUTH': stat.mouthSize += size; if (mode === 'carn') stat.mouthCarn += size; else if (mode === 'scav') stat.mouthScav += size; break;
      }
    }""","""        case 'MOUTH': stat.mouthSize += size; if (mode === 'carn') stat.mouthCarn += size; else if (mode === 'scav') stat.mouthScav += size; break;
      }
    }
    const designed = !!(genome.design && genome.dx);""")
s=sub1(s,"""    place(genome.body, 0, 0, 0, 0, 0, undefined, 0);""","""    let growMean = 1;
    if (designed) {
      // A designed body grows as one piece: every node is sized by its own
      // cell's growth (all cells share one rate), and the stat total for a
      // node is its exact part count times its mean size. No layout pass --
      // the renderer places designed parts from the design itself.
      const nodes = collectNodes(genome.body, 0, []).map(e => e.node);
      let gs = 0, gn = 0, legW = 0, legN = 0;
      for (let i = 0; i < nodes.length; i++) {
        const nd = nodes[i];
        const cs = cellOf(i);
        if (cs && !cs.alive) continue;
        const gr = cs ? cs.grow : 1;
        gs += gr; gn++;
        const cnt = Math.max(1, nd.dn || nd.repeat || 1);
        const eff = nd.size * gr;
        if (nd.type === 'LEG') { legW += eff * cnt; legN += cnt; stat.mass += eff * cnt; stat.upkeep += PART.LEG.upkeep * eff * cnt; }
        else accumOne(nd.type, nd.mode, eff, cnt);
        for (let k = 0; k < cnt && parts.length < 240; k++) parts.push({ type: nd.type, mode: nd.mode, x: 0, y: 0, r: 4 + eff * 7, size: eff, lg: 0 });
      }
      // more than four legs gives diminishing stride, not a free multiplier
      stat.legs += legN > 4 ? legW * Math.sqrt(4 / legN) : legW;
      growMean = gn ? gs / gn : 1;
      stat.fins += (genome.dx.fin || 0) * growMean;
    } else
    place(genome.body, 0, 0, 0, 0, 0, undefined, 0);""")

# body-plan section: designed overrides and extras
s=sub1(s,"""    const rt = Math.sqrt(EL);
    ph.bodyRX = ph.radius * rt; ph.bodyRY = ph.radius / rt;
    ph.standH = ph.radius * (0.55 + 0.62 * LL);            // body centre above ground""","""    const rt = Math.sqrt(EL);
    ph.bodyRX = ph.radius * rt; ph.bodyRY = ph.radius / rt;
    ph.standH = ph.radius * (0.55 + 0.62 * LL);            // body centre above ground
    if (designed) {
      const X = genome.dx, gm = growMean;
      ph.designed = 1;
      ph.upkeep *= 0.8;   // designed bodies carry many small decorative parts; keep them as viable as evolved ones
      ph.bodyRX = ph.radius * (X.a || rt); ph.bodyRY = ph.radius * (X.b || 1 / rt);
      ph.standH = ph.radius * (X.stand || (0.55 + 0.62 * LL));
      ph.attack += (X.atk || 0) * gm;
      ph.defense = clamp(ph.defense + (X.def || 0) * gm, 0, 400);
      ph.counter += (X.def || 0) * 0.3 * gm;
      ph.reach = clamp(ph.reach + (X.reach || 0) * gm, 8, 150);
      ph.sense = clamp(ph.sense + (X.sense || 0) * gm, 95, 480);
      ph.speedLand = clamp(ph.speedLand * clamp(1 + (X.spd || 0), 0.5, 1.8), 1.5, 160);
      ph.dClaw = (X.claw || 0) > 0 ? 1 : 0;
      ph.dSweep = (X.sweep || 0) > 0 ? 1 : 0;
      ph.dGrab = X.grab || 0;
      ph.dLegs = X.legs || 0; ph.dArms = X.arms || 0; ph.dSpring = X.spring || 0;
    }""")

# ---- export
s=sub1(s,"""  const API = {
    makeRNG,""","""  const API = {
    ...DESIGN_API,
    makeRNG,""")
# insert design module before API
core=open('src/core_design.js',encoding='utf-8').read()
s=sub1(s,"""  const API = {
    ...DESIGN_API,""",core+"""
  const API = {
    ...DESIGN_API,""")
open('g3.html','w',encoding='utf-8').write(s)
print('core patched')
