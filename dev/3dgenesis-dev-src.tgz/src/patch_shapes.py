# =====================================================================
# THE FOURTEEN, REBUILT ON THE NEW ANATOMY
#
# Every one of these now uses the three things the skeleton could not say
# before: a back that peaks over the shoulders, a waist that splits one mass
# into two, and a head slung LOW AND FORWARD instead of perched on top.
#
# The heads are the big one. Every plan in this game had a positive `ny` --
# the skull sitting above the shoulders like a horse -- and that single number
# is most of why they read as farm animals rather than as things that hunt.
# Nearly all of these are negative now.
#
# Plans 22-27 are rewritten in place: they are a day old and nothing outside
# this session has saved a design on them. Plan 18 is NOT touched -- it is old
# enough to be in somebody's saved creatures -- so the pterosaur-shaped flier
# is a new plan (37) and 18 simply stops being offered.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, ('ANCHOR %d/%d' % (n, cnt), a[:110]); return s.replace(a, b)

p = 'g3.html'; s = open(p, encoding='utf-8').read()

ROWS = [
 # ---- land ----------------------------------------------------------------
 (22, "{ a: 1.20, b: 0.66, seg: 11, prof: 'insect', arch: 0.34, droop: 0.00, wide: 0.52, neck: 0.30, nx: 0.80, ny: -0.42, ns: 2, head: 0.40, snx: 0.55, snr: 0.44, tail: 2.2, tailR: 0.26, ts: 9, stand: 0.90, tailUp: 1.0, hump: 0.62, waist: 0.40, waistAt: 0.30, waistW: 0.11 }, // 22 scorpion: carapace over a pinched waist, head slung under the front"),
 (23, "{ a: 0.70, b: 0.30, seg: 9,  prof: 'round',  arch: 0.44, droop: 0.06, wide: 0,    neck: 0.34, nx: 0.72, ny: -0.62, ns: 2, head: 0.24, snx: 0.80, snr: 0.26, tail: 0.30, tailR: 0.09, ts: 4, stand: 3.90, hump: 0.85 }, // 23 stilt-walker: a hunched scrap of a body on absurd legs, head hanging off the front"),
 (24, "{ a: 1.34, b: 0.82, seg: 12, prof: 'animal', arch: 0.40, droop: 0.12, wide: 0.20, neck: 2.60, nx: 0.86, ny: -0.12, ns: 9, head: 0.30, snx: 0.70, snr: 0.38, tail: 1.9, tailR: 0.22, ts: 9, stand: 1.25, hump: 0.55, waist: 0.26, waistAt: 0.38 }, // 24 hydra: the neck runs FORWARD at body height, not up"),
 (25, "{ a: 1.18, b: 0.42, seg: 11, prof: 'insect', arch: 0.38, droop: 0.00, wide: 0,    neck: 0.70, nx: 0.62, ny: -0.34, ns: 3, head: 0.26, snx: 0.55, snr: 0.30, tail: 1.8, tailR: 0.26, ts: 8, stand: 2.05, hump: 0.80, waist: 0.58, waistAt: 0.34, waistW: 0.10 }, // 25 mantis: thorax, hard waist, long abdomen, head down"),
 (26, "{ a: 0.98, b: 0.74, seg: 9,  prof: 'round',  arch: 0.26, droop: 0.00, wide: 0.92, neck: 0.16, nx: 0.90, ny: -0.70, ns: 2, head: 0.32, snx: 0.45, snr: 0.40, tail: 0.3, tailR: 0.18, ts: 4, stand: 1.05, hump: 0.35, waist: 0.30, waistAt: 0.22 }, // 26 crab: a shell with the head tucked in under its leading edge"),
 (27, "{ a: 1.05, b: 0.92, seg: 11, prof: 'animal', arch: 0.66, droop: 0.20, wide: 0.30, neck: 0.44, nx: 0.68, ny: -0.52, ns: 2, head: 0.58, snx: 0.62, snr: 0.60, tail: 0.5, tailR: 0.24, ts: 4, stand: 2.00, hump: 0.95, waist: 0.32, waistAt: 0.26 }, // 27 brute: shoulders that tower over the hips, head hanging between them"),
 (30, "{ a: 1.05, b: 1.26, seg: 9,  prof: 'round',  arch: 0.46, droop: 0.06, wide: 0.54, neck: 0.34, nx: 0.78, ny: -0.60, ns: 3, head: 0.78, snx: 0.55, snr: 0.78, tail: 0.0, tailR: 0.20, ts: 3, stand: 0.90, hump: 0.88 }, // 30 lurker: a boulder of a back with a face hanging off the front of it"),
 (31, "{ a: 0.76, b: 0.46, seg: 9,  prof: 'insect', arch: 0.34, droop: 0.00, wide: 0.20, neck: 0.46, nx: 0.84, ny: -0.80, ns: 3, head: 1.22, snx: 1.00, snr: 0.86, tail: 0.8, tailR: 0.16, ts: 5, stand: 1.15, hump: 0.85 }, // 31 maw: a skull far too big, carried low and forward on a small humped body"),
 (32, "{ a: 0.72, b: 0.32, seg: 11, prof: 'tube',   arch: 0.60, droop: 0.16, wide: 0,    neck: 0.80, nx: 0.58, ny: -0.40, ns: 4, head: 0.22, snx: 0.50, snr: 0.24, tail: 0.25, tailR: 0.09, ts: 3, stand: 2.70, hump: 0.95, waist: 0.46, waistAt: 0.34, waistW: 0.12 }, // 32 hollow: vertical, pinched, shoulders up at the top and a tiny head off the front"),
 (33, "{ a: 2.40, b: 0.32, seg: 19, prof: 'tube',   arch: 0.14, droop: 0.00, wide: 0.14, neck: 0.14, nx: 0.94, ny: -0.22, ns: 2, head: 0.34, snx: 0.62, snr: 0.34, tail: 1.6, tailR: 0.17, ts: 8, stand: 0.50, flex: 1, hump: 0.30 }, // 33 centipede: very long, very low, the head level with the ground"),
 # ---- air ------------------------------------------------------------------
 (34, "{ a: 0.54, b: 0.38, seg: 9,  prof: 'round',  arch: 0.22, droop: 0.00, wide: 0,    neck: 0.50, nx: 0.62, ny: 0.55,  ns: 3, head: 0.24, snx: 0.80, snr: 0.22, tail: 0.9, tailR: 0.10, ts: 5, stand: 1.10, hump: 0.45 }, // 34 flit: small and alert, the one head in the set that is still held up"),
 (35, "{ a: 0.54, b: 0.46, seg: 9,  prof: 'insect', arch: 0.10, droop: 0.00, wide: 0.16, neck: 0.12, nx: 0.85, ny: -0.30, ns: 2, head: 0.26, snx: 0.42, snr: 0.30, tail: 0.7, tailR: 0.12, ts: 4, stand: 0.40, waist: 0.48, waistAt: 0.40, waistW: 0.11 }, // 35 mothwing: a pinched body that is almost all wing mount"),
 (36, "{ a: 1.48, b: 0.72, seg: 13, prof: 'animal', arch: 0.44, droop: 0.06, wide: 0.10, neck: 2.20, nx: 0.62, ny: 0.34,  ns: 7, head: 0.42, snx: 0.90, snr: 0.38, tail: 2.6, tailR: 0.27, ts: 10, stand: 1.60, hump: 0.70, waist: 0.22, waistAt: 0.34 }, // 36 drake: a raised shoulder, a neck that arcs up and then forward, a long tail"),
]
for idx, row in ROWS:
    import re
    # `{ a:` pins this to the PLANS table: the colour table's rows carry the
    # same trailing comment and start with `{ base:`.
    m = re.search(r"^    \{ a:[^\n]*\},\s*// %d\b[^\n]*$" % idx, s, re.M)
    assert m, 'no row for plan %d' % idx
    s = s[:m.start()] + '    ' + row + s[m.end():]

# a pterosaur-shaped flier of our own, so plan 18 (old enough to be in saved
# creatures) is left exactly as it is and simply stops being offered
s = sub1(s, "  ];\n  const BODY_RANGE =",
"""    { a: 0.90, b: 0.50, seg: 9,  prof: 'animal', arch: 0.30, droop: 0.00, wide: 0,    neck: 0.95, nx: 0.70, ny: -0.10, ns: 4, head: 0.44, snx: 1.25, snr: 0.30, tail: 0.30, tailR: 0.12, ts: 4, stand: 1.00, hump: 0.60 }, // 37 skimmer: a long beaked skull carried out level on a folded frame
  ];
  const BODY_RANGE =""")

open(p, 'w', encoding='utf-8').write(s)
print('shapes: fourteen rebuilt ok')

# ---------------------------------------------------------------- the new flier is offered, the old one is not
s = open(p, encoding='utf-8').read()
s = sub1(s, "  { label: 'air', note: 'wings. the moth has no legs at all and cannot enter a match.',\n    plans: [34, 35, 18, 36] },",
            "  { label: 'air', note: 'wings. the moth has no legs at all and cannot enter a match.',\n    plans: [34, 35, 37, 36] },")
s = sub1(s, "                    'lurker', 'maw', 'hollow', 'centipede', 'flit', 'mothwing', 'drake'];",
            "                    'lurker', 'maw', 'hollow', 'centipede', 'flit', 'mothwing', 'drake', 'skimmer'];")
# hide and skin for the new plan
s = sub1(s, "    { base: [0.24, 0.20, 0.18], coat: [0.52, 0.46, 0.40], detail: [0.80, 0.32, 0.14], pat: 1 },  // 36 drake",
            "    { base: [0.24, 0.20, 0.18], coat: [0.52, 0.46, 0.40], detail: [0.80, 0.32, 0.14], pat: 1 },  // 36 drake\n    { base: [0.30, 0.28, 0.24], coat: [0.62, 0.58, 0.50], detail: [0.78, 0.40, 0.20], pat: 1 },  // 37 skimmer")
s = sub1(s, "                     0, 4, 0, 4, 2, 2, 1];", "                     0, 4, 0, 4, 2, 2, 1, 2];")
# and it is born with the wings that are its arms
s = sub1(s, "      case 36: // drake", """      case 37: // skimmer: the wings ARE the arms, folded to move on the ground
        eyeAt('e_big', 0.85, 0.42, 0.34, 0.55); mouthAt('m_spino', 1.0);
        put('d_crest', head.x - hr * 0.25, head.y + hr, 0, -0.35, 1, 0, 1.5, false);
        put('w_bat', a * 0.05, b * 0.55, b * 0.55, 0, 0.6, 0.8, 2.3, true);
        limb('l_thin', -a * 0.12, -b * 0.35, b * 0.42, -a * 0.02, -st, b * 0.50, 0.26, 0.05, 0.03, 't_talon', 0.7);
        break;
      case 36: // drake""")
open(p, 'w', encoding='utf-8').write(s)
print('shapes: the new flier ok')
