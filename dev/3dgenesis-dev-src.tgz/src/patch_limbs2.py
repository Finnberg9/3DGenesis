# =====================================================================
# THE BALL PROBLEM
#
# Three complaints, one shared cause: every joint was a SPHERE, and a sphere
# next to a sphere next to a sphere is a string of beads however you size it.
#
# 1. "way too much knuckles, it looks like a bunch of round balls"
#    Joints are now CAPS, not balls: ellipsoids squashed hard along the bone,
#    so a knee reads as a crease across the limb rather than a marble threaded
#    onto it. The ankle ball is gone entirely -- that was a third bead per limb
#    doing nothing a taper could not do. Swell is also thickness-compensated:
#    a heavy limb gets a proportionally smaller knuckle, because the same
#    ratio that reads as bone on a thin leg reads as a boulder on a thick one.
#
# 2. "some creatures the arms are embedded into their bodies"
#    A limb anchor sits on the nominal surface of ONE skeleton ball. The skin
#    the game actually draws is the smooth union of the whole chain, which
#    bulges well past any single ball wherever two of them overlap -- so an
#    anchor that is exactly on the surface in the editor's terms is buried
#    under it in the mesh. The hip is now slid outward along its own normal
#    until it clears that bulge, and the upper bone starts there.
#
# 3. "some limbs are too skinny to create"
#    Literal: the mesher picks its grid from the model's overall span, so a
#    shaft thinner than about a cell does not survive the surface extraction
#    at all. Shafts were cut to 0.55/0.66 of their old radius, which put the
#    thin classes under that floor. They are back up, with a hard minimum tied
#    to the body's size so no limb can be thinner than the grid can carry.
#
# Also: the torso was reading as a pile of boulders. The spine chain is a
# string of cones, which crease nicely, but SIX satellite spheres (shoulder
# and hip masses) were bolted onto it with a tight blend, and those are what
# looked like rocks. They are melted in now; the creases between chain
# segments, which are the ones that make the body look sectioned, stay.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, ('ANCHOR %d/%d' % (n, cnt), a[:120]); return s.replace(a, b)

p = 'g3.html'; s = open(p, encoding='utf-8').read()

# ---------------------------------------------------------------- 1. the torso
# Melt the bolt-on masses, keep the creases between spine segments.
s = sub1(s, "    const kb = 0.20 * sk.b;", "    const kb = 0.26 * sk.b;")
s = sub1(s,
    "for (let i = P.seg; i < P.seg + 6; i++) if (live(i)) { sph(i, body, kb * 1.4); cone(i, nearestSpine(B[i].x, B[i].y, B[i].z), body, kb * 1.4); }",
    "// These are shoulder and hip masses, not separate animals. Blended hard so\n"
    "    // they read as muscle over the ribcage instead of boulders glued on.\n"
    "    for (let i = P.seg; i < P.seg + 6; i++) if (live(i)) { sph(i, body, kb * 3.0); cone(i, nearestSpine(B[i].x, B[i].y, B[i].z), body, kb * 3.0); }")

# ---------------------------------------------------------------- 2. the limb the GAME draws
# How big is this animal, all in? The mesher's cell size comes from the overall
# bounding span, so the minimum shaft that survives extraction scales with this
# and not with the torso.

# ---------------------------------------------------------------- 2b. limbs may not fuse
# The skin is ONE smooth union over every primitive in the creature, so two legs
# whose shafts pass within a shaft's width of each other are not two legs any
# more -- they are a single trunk with one foot on the end of it. No amount of
# blend tuning fixes that, because the merge is geometric: the surfaces overlap.
#
# So it is a hard rule, enforced before anything is drawn. Every pair of limbs
# is measured along its whole length and pushed apart until there is real space
# between them; a pair that cannot be separated far enough (the body is not wide
# enough to put them anywhere else) is thinned until it clears instead. Drawn
# geometry only -- bone pivots, reach and stance are untouched, so gait, footfall
# and the ground the creature stands on are all exactly as they were.
s = sub1(s, "  // limbs\n  G.cls.limbs.forEach((o, li) => {",
r"""  // -- no two limbs may merge into one --------------------------------------
  const SEP = [], THIN = [], HIP = [];
  {
    const LG = 1.26;                 // clear space wanted, in combined shaft radii
    const NL = G.cls.limbs.length;
    const PP = [], RR = [];
    for (const o of G.cls.limbs) {
      const lb = o.lb, rq = limbRadii(lb), rt = o.root;
      // a foot pad is much wider than the shaft it sits on, and two pads
      // touching read as one foot, so the pad sets the clearance at that end
      // measure the radius the limb is actually DRAWN at, including the grid
      // floor below -- a thin leg is fattened to survive surface extraction, and
      // separating it as if it were still thin is how two of them ended up
      // welded together after this pass had already run and passed
      let rad = Math.max(rq.r0 * 0.95, 0.030 * G._limbScale);
      const tv = lb.tip && VIS[lb.tip.id];
      if (tv) rad = Math.max(rad, tv.size * clamp(lb.tip.s || 1, 0.4, 2.5) * rq.th * 0.45);
      // The hip is slid out of the torso before anything else (see below). That
      // move is part of the drawn limb, so it has to be part of what the
      // separation pass measures -- otherwise two limbs are parted correctly
      // and then pushed back into each other on the way out of the body.
      const hb = B[clamp(lb.b | 0, 0, B.length - 1)];
      let nOut = [0, 1, 0];
      if (hb) { const dd = v3.sub(rt, [hb.x, hb.y, hb.z]); if (v3.len(dd) > 1e-4) nOut = v3.norm(dd); }
      const br = hb ? Math.max(0.05, hb.r) : 0.5;
      const hip = v3.add(rt, v3.mul(nOut, Math.min(br * 0.62, br * 0.30 + rq.r0 * 0.85)));
      HIP.push(hip);
      PP.push([hip, v3.add(rt, lb.k), v3.add(rt, lb.f)]);
      RR.push(rad); SEP.push([0, 0, 0]); THIN.push(1);
    }
    const SN = 7;
    const ptAt = (P, u) => (u <= 1 ? v3.lerp(P[0], P[1], u) : v3.lerp(P[1], P[2], u - 1));
    const gap = (i, j) => {                       // closest approach, and which way to part
      let best = Infinity, bv = null;
      for (let a = 0; a <= SN; a++) {
        const pa = v3.add(ptAt(PP[i], (a / SN) * 2), SEP[i]);
        for (let b = 0; b <= SN; b++) {
          const pb = v3.add(ptAt(PP[j], (b / SN) * 2), SEP[j]);
          const d = v3.sub(pa, pb), L = v3.len(d);
          if (L < best) { best = L; bv = d; }
        }
      }
      return { best, bv };
    };
    // Room to move is set by the whole animal, not the torso: a stilt-walker is
    // mostly leg, and a cap measured off its small body left its legs with
    // nowhere to go and welded together anyway.
    const capL = 0.26 * G._limbScale;
    for (let pass = 0; pass < 8; pass++) {
      for (let i = 0; i < NL; i++) for (let j = i + 1; j < NL; j++) {
        const { best, bv } = gap(i, j);
        const need = (RR[i] + RR[j]) * LG;
        if (!bv || best >= need) continue;
        // part along the line between the closest points; if they are exactly
        // coincident, part left and right, which is where a pair belongs
        let dir = best > 1e-4 ? v3.mul(bv, 1 / best)
                              : [0, 0, PP[i][0][2] >= PP[j][0][2] ? 1 : -1];
        dir = [dir[0] * 0.55, dir[1] * 0.18, dir[2]];   // sideways first, never up the leg
        const dl = v3.len(dir); if (dl < 1e-4) continue;
        dir = v3.mul(dir, 1 / dl);
        const push = (need - best) * 0.5;
        SEP[i] = v3.add(SEP[i], v3.mul(dir, push));
        SEP[j] = v3.sub(SEP[j], v3.mul(dir, push));
      }
      for (let i = 0; i < NL; i++) {
        const L = v3.len(SEP[i]);
        if (L > capL) SEP[i] = v3.mul(SEP[i], capL / L);
      }
    }
    // Anything that still touches after it has been moved as far as it may go
    // is thinned until it clears. A thin leg is a worse leg than a fat one, but
    // a leg is better than half of a fused trunk.
    for (let pass = 0; pass < 3; pass++) {
      for (let i = 0; i < NL; i++) for (let j = i + 1; j < NL; j++) {
        const { best } = gap(i, j);
        const need = (RR[i] * THIN[i] + RR[j] * THIN[j]) * LG;
        if (best >= need || need <= 1e-6) continue;
        const f = Math.max(0.42, best / need);
        THIN[i] = Math.min(THIN[i], f); THIN[j] = Math.min(THIN[j], f);
      }
    }
  }

  // limbs
  G.cls.limbs.forEach((o, li) => {""")

s = sub1(s, "  const out = [];\n  for (const q of sk.prims)",
"""  const out = [];
  if (!(G._limbScale > 0)) {
    let reach = 0;
    for (const o of G.cls.limbs) { const f = o.lb.f || [0, -1, 0]; reach = Math.max(reach, Math.hypot(f[0], f[1], f[2])); }
    G._limbScale = Math.max(1.2, 2 * sk.a, 2 * sk.b, 1.6 * reach);
  }
  for (const q of sk.prims)""")
s = sub1(s, """    const root = o.root, knee = v3.add(root, lb.k), foot = v3.add(root, lb.f);
    // Knuckles with bone between them. The shafts are thin, the joints swell
    // well past them, and the blend at each joint is tight so it creases
    // rather than melting into the bone.
    // Swell enough to read as a knuckle, not so much that a thick leg becomes a
    // string of beads -- which is exactly what 1.85/2.05 did to the heavy classes.
    const SH = 0.66;
    out.push({ t: 's', ax: root[0], ay: root[1], az: root[2], ra: r0 * 1.38, k: 0.09 * th, bone: up, col });
    out.push({ t: 'c', ax: root[0], ay: root[1], az: root[2], bx: knee[0], by: knee[1], bz: knee[2], ra: r0 * SH, rb: r1 * SH, k: 0.03, bone: up, col });
    // the knee itself, which did not exist before
    out.push({ t: 's', ax: knee[0], ay: knee[1], az: knee[2], ra: r1 * 1.52, k: 0.05 * th, bone: up, col });
    out.push({ t: 'c', ax: knee[0], ay: knee[1], az: knee[2], bx: foot[0], by: foot[1], bz: foot[2], ra: r1 * SH, rb: r2 * SH, k: 0.03, bone: lo, col });
    out.push({ t: 's', ax: foot[0], ay: foot[1], az: foot[2], ra: r2 * 1.35, k: 0.05 * th, bone: lo, col });""",
"""    const sep = SEP[li], thin = THIN[li];
    (G._limbBones || (G._limbBones = []))[li] = [up, lo];   // so a test can check the drawn result
    const root0 = o.root;
    const knee = v3.add(v3.add(root0, lb.k), sep), foot = v3.add(v3.add(root0, lb.f), sep);

    // -- clear the torso ------------------------------------------------------
    // The anchor is on one skeleton ball's nominal surface. The skin is the
    // smooth union of the whole chain and bulges past that wherever balls
    // overlap, so the anchor is usually INSIDE the visible body and the top of
    // the limb disappears into it. The hip was slid out along its own normal in
    // the pass above, which is also where it was measured for separation. Only
    // the drawn hip moves: the knee, the foot and every bone pivot stay where
    // they were, so gait and stance are untouched.
    const root = v3.add(HIP[li], sep);

    // -- caps, not balls ------------------------------------------------------
    // A sphere at every joint is a string of beads. These are ellipsoids
    // squashed along the bone, so a joint reads as a knuckle crossways and a
    // crease lengthways. The swell is divided down as the limb gets thicker:
    // the ratio that looks skeletal on a thin leg looks like a boulder on a
    // thick one. The ankle ball is gone; the taper does that job.
    const cap = (amt) => 1 + (amt - 1) / (0.55 + 0.45 * clamp(th, 0.5, 2.2));
    const HIPW = cap(1.34), KNEEW = cap(1.42);
    // and no shaft may be thinner than the mesher's grid can carry, or the limb
    // is simply not extracted -- which is what "too skinny to create" was
    // The floor has to be measured against the WHOLE model, not the torso: the
    // mesher sizes its grid from the overall bounding span, so a stilt-walker
    // with a small body and enormous legs gets a coarse grid and loses any
    // shaft thinner than a cell. That is why the thin classes came out as
    // threads of beads with the bone missing between them.
    const SH = 0.82 * thin, RMIN = 0.030 * G._limbScale * thin;
    const s0 = Math.max(r0 * SH, RMIN), s1 = Math.max(r1 * SH, RMIN * 0.88), s2 = Math.max(r2 * SH, RMIN * 0.76);
    const dU = v3.norm(v3.sub(knee, root)), dL = v3.norm(v3.sub(foot, knee));
    const perp = (d) => { let e = v3.norm(v3.cross(d, [0, 0, 1])); if (!isFinite(e[0]) || v3.len(e) < 0.5) e = [1, 0, 0]; return e; };
    const ex0 = perp(dU), ex1 = perp(dL);
    out.push({ t: 'e', ax: root[0], ay: root[1], az: root[2], ex: ex0, ey: dU, ez: v3.cross(ex0, dU),
               rx: r0 * HIPW * thin, ry: r0 * HIPW * thin * 0.54, rz: r0 * HIPW * thin, k: 0.14 * th, bone: up, col });
    out.push({ t: 'c', ax: root[0], ay: root[1], az: root[2], bx: knee[0], by: knee[1], bz: knee[2], ra: s0, rb: s1, k: 0.03, bone: up, col });
    // the knee: a cap across the bone, not a marble threaded onto it
    out.push({ t: 'e', ax: knee[0], ay: knee[1], az: knee[2], ex: ex0, ey: dU, ez: v3.cross(ex0, dU),
               rx: r1 * KNEEW * thin, ry: r1 * KNEEW * thin * 0.44, rz: r1 * KNEEW * thin * 0.86, k: 0.04 * th, bone: up, col });
    out.push({ t: 'c', ax: knee[0], ay: knee[1], az: knee[2], bx: foot[0], by: foot[1], bz: foot[2], ra: s1, rb: s2, k: 0.03, bone: lo, col });
    void ex1; void dL;""")

# the flesh on the upper bone follows the moved hip
s = sub1(s, "      const m = v3.lerp(root, knee, 0.26), ey = v3.norm(ud);",
            "      const m = v3.lerp(root, knee, 0.30), ey = v3.norm(ud);")

# ---------------------------------------------------------------- 3. the instanced path
# The palette icons and distant crowd draw through drawLimbTube. Same numbers,
# so an icon and the creature it buys agree.
s = sub1(s, "const LIMB_SHAFT = 0.55;     // how much of the old thickness the bone keeps\nconst LIMB_HIP = 1.55, LIMB_KNEE = 1.70, LIMB_ANKLE = 1.35;   // joint swell",
            "const LIMB_SHAFT = 0.78;     // how much of the old thickness the bone keeps\nconst LIMB_HIP = 1.26, LIMB_KNEE = 1.34, LIMB_ANKLE = 1.10;   // joint swell")

open(p, 'w', encoding='utf-8').write(s)
print('limbs2: caps not balls, hips clear of the torso, shafts above the grid floor')
