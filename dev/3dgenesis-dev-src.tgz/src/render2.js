// =====================================================================
// RENDER 2: sun shadows, post-processing, render scale with sharpening,
// automatic resolution, and view-frustum culling.
//
// Frame: [shadow depth passes] -> scene (MSAA, at render scale) -> half-res
// AO + sun shafts -> quarter-res bloom (bright, blur H, blur V) -> final
// composite to the screen (sharpened upscale, AO, shafts, bloom, grade).
// Everything scales with the graphics preset; the auto resolution keeps the
// frame rate up by lowering the render scale when frames run long.
// =====================================================================
const R2 = {
  descOf: new Map(), ok: false,
  shadowTex: null, shadowArr: null, shadowViews: [], shadowSize: 0, shadowSmp: null,
  gL: [], lightArr: [new Float32Array(68), new Float32Array(68)], lvp: [new Float32Array(16), new Float32Array(16)],
  p: {}, bL: [{}, {}],
  sw: 0, sh: 0, sceneMs: null, sceneDepth: null, sceneRes: null, fxTex: null, bloomA: null, bloomB: null,
  post: null, postBuf: null, postArr: new Float32Array(16), linSmp: null, bg: null,
  dyn: 1, auto: true, ftAvg: 16.7, lastT: 0, lastChange: 0, fps: 60,
  planes: new Float32Array(24),
};
const SHADOW_CFG = [{ n: 0, size: 1024 }, { n: 1, size: 1024 }, { n: 2, size: 2048 }, { n: 2, size: 4096 }];
const SHADOW_R0 = 380, SHADOW_R1 = 2400;

// ---------------------------------------------------------------- frustum culling
function r2Frustum(m) {
  const P = R2.planes;
  const rows = (r) => [m[r], m[4 + r], m[8 + r], m[12 + r]];
  const r0 = rows(0), r1 = rows(1), r2 = rows(2), r3 = rows(3);
  const set = (i, a) => { const l = Math.hypot(a[0], a[1], a[2]) || 1; P[i * 4] = a[0] / l; P[i * 4 + 1] = a[1] / l; P[i * 4 + 2] = a[2] / l; P[i * 4 + 3] = a[3] / l; };
  set(0, [r3[0] + r0[0], r3[1] + r0[1], r3[2] + r0[2], r3[3] + r0[3]]);
  set(1, [r3[0] - r0[0], r3[1] - r0[1], r3[2] - r0[2], r3[3] - r0[3]]);
  set(2, [r3[0] + r1[0], r3[1] + r1[1], r3[2] + r1[2], r3[3] + r1[3]]);
  set(3, [r3[0] - r1[0], r3[1] - r1[1], r3[2] - r1[2], r3[3] - r1[3]]);
  set(4, [r2[0], r2[1], r2[2], r2[3]]);
  set(5, [r3[0] - r2[0], r3[1] - r2[1], r3[2] - r2[2], r3[3] - r2[3]]);
}
// sphere (world x, y, z, radius) intersects the view
function r2InView(x, y, z, r) {
  const P = R2.planes;
  for (let i = 0; i < 6; i++) if (P[i * 4] * x + P[i * 4 + 1] * y + P[i * 4 + 2] * z + P[i * 4 + 3] < -r) return false;
  return true;
}
// horizontal view cone for systems cached by yaw only (foliage): true if a
// thing at (dx, dz) from the camera, radius r, could be on screen
function r2InCone(dx, dz, d, r, fx, fz) {
  if (d < 380) return true;                         // close: always (shadows, peripheral vision)
  const aspect = canvas ? canvas.width / Math.max(1, canvas.height) : 1.8;
  const half = Math.atan(Math.tan(1.15 / 2) * aspect) + 0.3 + Math.asin(Math.min(1, r / d));
  return (dx * fx + dz * fz) / d > Math.cos(Math.min(Math.PI, half));
}

// ---------------------------------------------------------------- matrices
function m4ortho(l, r, b, t, n, f, o) {
  o.fill(0);
  o[0] = 2 / (r - l); o[5] = 2 / (t - b); o[10] = 1 / (n - f);
  o[12] = -(r + l) / (r - l); o[13] = -(t + b) / (t - b); o[14] = n / (n - f); o[15] = 1;
  return o;
}
const _lv = new Float32Array(16), _lp = new Float32Array(16);
// light view-projection for one cascade, centred ahead of the camera and
// snapped to its texel grid so shadows do not crawl as you move
function r2LightVP(c, R, cx, cz, out) {
  const L = [gArr[20], gArr[21], gArr[22]];
  const ll = Math.hypot(L[0], L[1], L[2]) || 1; L[0] /= ll; L[1] /= ll; L[2] /= ll;
  const texel = (2 * R) / Math.max(256, R2.shadowSize);
  cx = Math.round(cx / texel) * texel; cz = Math.round(cz / texel) * texel;
  const cy = groundAt(cx, cz);
  const D = R * 2 + 2500;
  m4look(cx + L[0] * D, cy + L[1] * D, cz + L[2] * D, cx, cy, cz, _lv);
  m4ortho(-R, R, -R, R, 1, D * 2, _lp);
  m4mul(_lp, _lv, out);
}

// ---------------------------------------------------------------- resources
function r2Tex(w, h, format, usage, samples) {
  return dev.createTexture({ size: [Math.max(1, w), Math.max(1, h)], format, sampleCount: samples || 1, usage });
}
function r2EnsureShadow() {
  const cfg = SHADOW_CFG[clamp(GFX.shadow | 0, 0, 3)];
  const size = cfg.size;
  if (R2.shadowTex && R2.shadowSize === size) return false;
  if (R2.shadowTex) R2.shadowTex.destroy();
  R2.shadowTex = dev.createTexture({ size: [size, size, 2], format: 'depth32float', usage: GPUTextureUsage.RENDER_ATTACHMENT | GPUTextureUsage.TEXTURE_BINDING });
  R2.shadowArr = R2.shadowTex.createView({ dimension: '2d-array' });
  R2.shadowViews = [0, 1].map(l => R2.shadowTex.createView({ dimension: '2d', baseArrayLayer: l, arrayLayerCount: 1 }));
  R2.shadowSize = size;
  if (!R2.shadowSmp) R2.shadowSmp = dev.createSampler({ compare: 'less', magFilter: 'linear', minFilter: 'linear' });
  return true;
}
function r2ShadowEntries() {
  r2EnsureShadow();
  return [{ binding: 8, resource: R2.shadowArr }, { binding: 9, resource: R2.shadowSmp }];
}
function r2SceneScale() {
  return clamp((GFX.res || 1) * (R2.auto ? R2.dyn : 1), 0.45, 1.5);
}
function r2EnsureScene() {
  const s = r2SceneScale();
  const w = Math.max(64, Math.round(canvas.width * s)), h = Math.max(64, Math.round(canvas.height * s));
  if (R2.sceneRes && R2.sw === w && R2.sh === h) return;
  for (const k of ['sceneMs', 'sceneDepth', 'sceneRes', 'fxTex', 'bloomA', 'bloomB']) if (R2[k]) R2[k].destroy();
  const RA = GPUTextureUsage.RENDER_ATTACHMENT, TB = GPUTextureUsage.TEXTURE_BINDING;
  R2.sceneMs = r2Tex(w, h, fmt, RA, SAMPLES);
  R2.sceneDepth = r2Tex(w, h, 'depth24plus', RA | TB, SAMPLES);
  R2.sceneRes = r2Tex(w, h, fmt, RA | TB);
  R2.fxTex = r2Tex(w >> 1, h >> 1, 'rgba8unorm', RA | TB);
  R2.bloomA = r2Tex(w >> 2, h >> 2, fmt, RA | TB);
  R2.bloomB = r2Tex(w >> 2, h >> 2, fmt, RA | TB);
  R2.sw = w; R2.sh = h;
  r2PostBinds();
}
// depth-only copies of the scene pipelines, rendering into the shadow map
function r2CasterPipe(src) {
  const d = R2.descOf.get(src);
  if (!d) return null;
  return dev.createRenderPipeline({
    layout: 'auto', vertex: d.vertex,
    primitive: { topology: 'triangle-list', cullMode: 'none' },
    depthStencil: { format: 'depth32float', depthWriteEnabled: true, depthCompare: 'less', depthBias: 3, depthBiasSlopeScale: 2.5, depthBiasClamp: 0 },
    multisample: { count: 1 },
  });
}
function r2BuildPipelines() {
  try {
    R2.p.terrain = r2CasterPipe(terrainPipe);
    R2.p.inst = r2CasterPipe(instPipe);
    R2.p.tube = r2CasterPipe(tubePipe);
    R2.p.fol = r2CasterPipe(folPipe);
    R2.p.skin = r2CasterPipe(skinPipe);
    R2.p.body = r2CasterPipe(bodyPipe);
    for (let c = 0; c < 2; c++) R2.gL[c] = dev.createBuffer({ size: 272, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });
    const pm = (code) => dev.createShaderModule({ code });
    const fxm = pm(WGSL_POST_FX), blm = pm(WGSL_POST_BLOOM), fnm = pm(WGSL_POST_FINAL);
    const full = (m, fs, format) => dev.createRenderPipeline({ layout: 'auto', vertex: { module: m, entryPoint: 'vs' },
      fragment: { module: m, entryPoint: fs, targets: [{ format }] }, primitive: { topology: 'triangle-list' } });
    R2.post = {
      fx: full(fxm, 'fs', 'rgba8unorm'),
      bright: full(blm, 'fs_bright', fmt), blurH: full(blm, 'fs_blurH', fmt), blurV: full(blm, 'fs_blurV', fmt),
      final: full(fnm, 'fs', fmt),
    };
    R2.postBuf = dev.createBuffer({ size: 64, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });
    R2.linSmp = dev.createSampler({ magFilter: 'linear', minFilter: 'linear', addressModeU: 'clamp-to-edge', addressModeV: 'clamp-to-edge' });
    r2SkyInit();
    R2.ok = true;
  } catch (e) { console.warn('render2 unavailable', e); R2.ok = false; }
}
function r2CasterBinds() {
  for (let c = 0; c < 2; c++) {
    const b = R2.bL[c] = {};
    const mk = (pipe, extra) => pipe ? dev.createBindGroup({ layout: pipe.getBindGroupLayout(0), entries: [{ binding: 0, resource: { buffer: R2.gL[c] } }].concat(extra || []) }) : null;
    b.terrain = mk(R2.p.terrain); b.inst = mk(R2.p.inst); b.tube = mk(R2.p.tube); b.fol = mk(R2.p.fol); b.body = mk(R2.p.body);
    b.skin = mk(R2.p.skin, [{ binding: 1, resource: { buffer: boneBuf } }]);
  }
}
function r2PostBinds() {
  if (!R2.post) return;
  const E = (pipe, list) => dev.createBindGroup({ layout: pipe.getBindGroupLayout(0), entries: list.map((r, i) => ({ binding: i, resource: r })) });
  const U = { buffer: R2.postBuf };
  R2.bg = {
    fx: E(R2.post.fx, [U, R2.sceneDepth.createView()]),
    bright: E(R2.post.bright, [U, R2.sceneRes.createView(), R2.linSmp]),
    blurH: E(R2.post.blurH, [U, R2.bloomA.createView(), R2.linSmp]),
    blurV: E(R2.post.blurV, [U, R2.bloomB.createView(), R2.linSmp]),
    final: E(R2.post.final, [U, R2.sceneRes.createView(), R2.fxTex.createView(), R2.bloomA.createView(), R2.linSmp]),
  };
}

// ---------------------------------------------------------------- per frame
// fills the shadow part of the globals and the per-cascade light uniforms
function r2FrameGlobals() {
  const cfg = SHADOW_CFG[clamp(GFX.shadow | 0, 0, 3)];
  const n = R2.ok ? cfg.n : 0;
  if (R2.ok && r2EnsureShadow()) { makeBindGroups(); }
  const fx = Math.cos(player.yaw), fz = Math.sin(player.yaw);
  const night = (world.light != null ? world.light : 1) < 0.18;
  const nn = night ? Math.min(n, 1) : n;
  if (nn > 0) {
    r2LightVP(0, SHADOW_R0, player.camX + fx * SHADOW_R0 * 0.45, player.camZ + fz * SHADOW_R0 * 0.45, R2.lvp[0]);
    r2LightVP(1, SHADOW_R1, player.camX + fx * SHADOW_R1 * 0.4, player.camZ + fz * SHADOW_R1 * 0.4, R2.lvp[1]);
  }
  gArr.set(R2.lvp[0], 32); gArr.set(R2.lvp[1], 48);
  gArr[64] = SHADOW_R0; gArr[65] = nn; gArr[66] = 1 / Math.max(1, R2.shadowSize); gArr[67] = night ? 0.45 : 0.82;
  for (let c = 0; c < nn; c++) {
    const a = R2.lightArr[c];
    a.set(gArr);
    a.set(R2.lvp[c], 0);
    a[19] = 1;                                   // no near-camera foliage dissolve in the shadow pass
    dev.queue.writeBuffer(R2.gL[c], 0, a);
  }
  R2.cascades = nn;
}
function r2ShadowPass(enc, nInst, nPlant) {
  const n = R2.cascades || 0;
  if (!n) return;
  if (!R2.bL[0].fol) r2CasterBinds();
  for (let c = 0; c < n; c++) {
    const b = R2.bL[c];
    const pass = enc.beginRenderPass({ colorAttachments: [], depthStencilAttachment: { view: R2.shadowViews[c], depthClearValue: 1, depthLoadOp: 'clear', depthStoreOp: 'store' } });
    if (R2.p.terrain && terrVB && c === 1) {
      pass.setPipeline(R2.p.terrain); pass.setBindGroup(0, b.terrain);
      pass.setVertexBuffer(0, terrVB); pass.setIndexBuffer(terrIB, 'uint32'); pass.drawIndexed(terrCount);
    }
    if (R2.p.fol && FOL.ready && FOL.batches.length) {
      pass.setPipeline(R2.p.fol); pass.setBindGroup(0, b.fol);
      pass.setVertexBuffer(1, FOL.instBuf);
      for (const bt of FOL.batches) {
        // grass and small cover do not cast into the far cascade
        pass.setVertexBuffer(0, bt.mesh.vb); pass.setIndexBuffer(bt.mesh.ib, 'uint32');
        pass.drawIndexed(bt.mesh.count, bt.count, 0, 0, bt.first);
      }
    }
    if (c === 0) {
      if (R2.p.inst && (nInst || nPlant || spikeCount)) {
        pass.setPipeline(R2.p.inst); pass.setBindGroup(0, b.inst);
        pass.setVertexBuffer(0, sphVB); pass.setIndexBuffer(sphIB, 'uint16');
        if (nPlant) { pass.setVertexBuffer(1, plantVB); pass.drawIndexed(sphCount, nPlant); }
        if (nInst) { pass.setVertexBuffer(1, instVB); pass.drawIndexed(sphCount, nInst); }
        if (spikeCount) { pass.setVertexBuffer(0, coneVB); pass.setIndexBuffer(coneIB, 'uint16'); pass.setVertexBuffer(1, spikeVB); pass.drawIndexed(coneCount, spikeCount); }
      }
      if (R2.p.tube && tubeN) {
        dev.queue.writeBuffer(tubeInstVB, 0, tubeData, 0, tubeN * INST_FLOATS);
        pass.setPipeline(R2.p.tube); pass.setBindGroup(0, b.tube);
        pass.setVertexBuffer(0, tubeVB); pass.setIndexBuffer(tubeIB, 'uint16');
        pass.setVertexBuffer(1, tubeInstVB); pass.drawIndexed(tubeMeshCount, tubeN);
      }
      if (R2.p.body && bodyBatches.length) {
        pass.setPipeline(R2.p.body); pass.setBindGroup(0, b.body);
        pass.setVertexBuffer(1, bodyInstVB);
        for (const bt of bodyBatches) { pass.setVertexBuffer(0, bt.mesh.vb); pass.setIndexBuffer(bt.mesh.ib, 'uint32'); pass.drawIndexed(bt.mesh.count, bt.count, 0, 0, bt.first); }
      }
      if (R2.p.skin && skinDraws.length && boneBuf) {
        dev.queue.writeBuffer(boneBuf, 0, boneData, 0, boneN * 16);
        const nn = Math.min(skinDraws.length, MAX_SKIN_INST);
        for (let i = 0; i < nn; i++) skinInstData.set(skinDraws[i].inst, i * BINST_FLOATS);
        dev.queue.writeBuffer(skinInstVB, 0, skinInstData, 0, nn * BINST_FLOATS);
        pass.setPipeline(R2.p.skin); pass.setBindGroup(0, b.skin);
        pass.setVertexBuffer(1, skinInstVB);
        for (let i = 0; i < nn; i++) { const d = skinDraws[i]; pass.setVertexBuffer(0, d.mesh.vb); pass.setIndexBuffer(d.mesh.ib, 'uint32'); pass.drawIndexed(d.mesh.count, 1, 0, 0, i); }
      }
    }
    pass.end();
  }
}
function r2PostPass(enc, fog) {
  const A = R2.postArr;
  // sun on screen
  const L = [gArr[20], gArr[21], gArr[22]];
  const sx = player.camX + L[0] * 9000, sy = player.camY + L[1] * 9000, sz = player.camZ + L[2] * 9000;
  const m = vpM;
  const cx = m[0] * sx + m[4] * sy + m[8] * sz + m[12], cy = m[1] * sx + m[5] * sy + m[9] * sz + m[13], cw = m[3] * sx + m[7] * sy + m[11] * sz + m[15];
  let su = 0.5, sv = -1, vis = 0;
  if (cw > 0) { su = cx / cw * 0.5 + 0.5; sv = 0.5 - cy / cw * 0.5; vis = clamp(1.4 - Math.max(Math.abs(su - 0.5), Math.abs(sv - 0.5)) * 1.3, 0, 1); }
  const day = gArr[30];
  A[0] = su; A[1] = sv; A[2] = vis; A[3] = GFX.rays ? 0.55 * day : 0;
  A[4] = GFX.ao ? 0.55 : 0; A[5] = GFX.bloom ? 0.55 : 0; A[6] = clamp(0.3 + (1 - r2SceneScale()) * 1.1, 0.25, 0.85); A[7] = (performance.now() % 997) / 997;
  A[8] = NEAR; A[9] = FAR; A[10] = day; A[11] = 0.55;
  A[12] = 1.0 * (0.6 + 0.4 * fog[0]); A[13] = 0.92 * (0.6 + 0.4 * fog[1]); A[14] = 0.72 * (0.6 + 0.4 * fog[2]); A[15] = 1;
  dev.queue.writeBuffer(R2.postBuf, 0, A);
  const run = (pipe, bg, view) => {
    const p = enc.beginRenderPass({ colorAttachments: [{ view, loadOp: 'clear', storeOp: 'store', clearValue: { r: 0, g: 0, b: 0, a: 1 } }] });
    p.setPipeline(pipe); p.setBindGroup(0, bg); p.draw(3); p.end();
  };
  run(R2.post.fx, R2.bg.fx, R2.fxTex.createView());
  if (GFX.bloom) {
    run(R2.post.bright, R2.bg.bright, R2.bloomA.createView());
    run(R2.post.blurH, R2.bg.blurH, R2.bloomB.createView());
    run(R2.post.blurV, R2.bg.blurV, R2.bloomA.createView());
  }
  run(R2.post.final, R2.bg.final, ctx.getCurrentTexture().createView());
}
// automatic resolution: keep frames under ~20 ms by trading render scale
function r2AutoRes() {
  const now = performance.now();
  if (R2.lastT) {
    const ft = Math.min(100, now - R2.lastT);
    R2.ftAvg += (ft - R2.ftAvg) * 0.05;
    R2.fps = 1000 / Math.max(1, R2.ftAvg);
  }
  R2.lastT = now;
  if (!R2.auto || now - R2.lastChange < 1500) return;
  if (R2.ftAvg > 21 && R2.dyn > 0.6) { R2.dyn = Math.max(0.6, R2.dyn - 0.08); R2.lastChange = now; }
  else if (R2.ftAvg < 15.5 && R2.dyn < 1) { R2.dyn = Math.min(1, R2.dyn + 0.05); R2.lastChange = now; }
}
function r2Hud() {
  const el = document.getElementById('gfxfps');
  if (el) el.textContent = Math.round(R2.fps) + ' fps · ' + Math.round(r2SceneScale() * 100) + '%';
}

// ---------------------------------------------------------------- sun, moon, sky
// The sun rises in the east, arcs over and sets in the west once per day. Its
// noon height follows the season: nearly overhead in summer, low in winter.
// The moon runs opposite it and goes through phases over eight days.
const SKY = { pipe: null, buf: null, bg: null, arr: new Float32Array(32), sun: [0, 1, 0], moon: [0, -1, 0], sunUp: 1, moonPhase: 0 };
function r2SunMoon() {
  const P = world.params, bt = world.bt || 0;
  const dl = P.dayLen || 10, yl = P.yearLen || 70;
  const a = (bt / dl) * 2 * Math.PI;                               // matches world.light's day curve
  const season = world.flags && world.flags.seasons === false ? 0.5 : 0.5 + 0.5 * Math.sin((bt / yl) * 2 * Math.PI);
  const maxEl = (32 + 56 * season) * Math.PI / 180;                 // winter noon 32 deg, summer 88 deg
  const sun = [Math.cos(a), Math.sin(a) * Math.sin(maxEl), Math.sin(a) * Math.cos(maxEl)];
  const moon = [-sun[0], -sun[1], -sun[2] * 0.6 + 0.25];
  const ml = Math.hypot(moon[0], moon[1], moon[2]); moon[0] /= ml; moon[1] /= ml; moon[2] /= ml;
  SKY.sun = sun; SKY.moon = moon; SKY.moonPhase = ((bt / (dl * 8)) % 1 + 1) % 1;
  // light for shading and shadows: the sun by day, the moon by night, never grazing
  const src = sun[1] > -0.05 ? sun : moon;
  SKY.sunUp = sun[1] > -0.05 ? 1 : 0;
  const y = Math.max(0.14, src[1]);
  const hl = Math.hypot(src[0], src[2]) || 1, k = Math.sqrt(Math.max(0, 1 - y * y)) / hl;
  gArr[20] = src[0] * k; gArr[21] = y; gArr[22] = src[2] * k; gArr[23] = 0;
}
const WGSL_SKY = `
struct S { sun: vec4<f32>, moon: vec4<f32>, right: vec4<f32>, up: vec4<f32>, fwd: vec4<f32>, fog: vec4<f32>, p: vec4<f32>, q: vec4<f32> };
// p: tanHalfFovY, aspect, time, daylight   q: moon phase, cloud cover, -, -
@group(0) @binding(0) var<uniform> U: S;
struct VO { @builtin(position) pos: vec4<f32>, @location(0) ndc: vec2<f32> };
@vertex fn vs(@builtin(vertex_index) i: u32) -> VO {
  var p = array<vec2<f32>, 3>(vec2<f32>(-1.0, -1.0), vec2<f32>(3.0, -1.0), vec2<f32>(-1.0, 3.0));
  var o: VO; o.pos = vec4<f32>(p[i], 1.0, 1.0); o.ndc = p[i]; return o;
}
fn h2(p: vec2<f32>) -> f32 { var p3 = fract(vec3<f32>(p.x, p.y, p.x) * 0.1031); p3 += dot(p3, p3.yzx + vec3<f32>(33.33)); return fract((p3.x + p3.y) * p3.z); }
fn n2(p: vec2<f32>) -> f32 {
  let i = floor(p); let f = fract(p); let u = f * f * (3.0 - 2.0 * f);
  return mix(mix(h2(i), h2(i + vec2<f32>(1.0, 0.0)), u.x), mix(h2(i + vec2<f32>(0.0, 1.0)), h2(i + vec2<f32>(1.0, 1.0)), u.x), u.y);
}
fn fbm(p0: vec2<f32>) -> f32 { var p = p0; var a = 0.5; var s = 0.0; for (var k = 0; k < 5; k = k + 1) { s += a * n2(p); p = p * 2.02 + vec2<f32>(3.1, 1.7); a *= 0.5; } return s; }
@fragment fn fs(i: VO) -> @location(0) vec4<f32> {
  let dir = normalize(U.fwd.xyz + U.right.xyz * i.ndc.x * U.p.x * U.p.y + U.up.xyz * i.ndc.y * U.p.x);
  let day = U.p.w;
  let sun = normalize(U.sun.xyz);
  let moon = normalize(U.moon.xyz);
  let t = U.p.z;
  let up = max(dir.y, 0.0);
  // base gradient: deep blue overhead, pale at the horizon, near black at night
  let zenD = vec3<f32>(0.20, 0.42, 0.72); let horD = vec3<f32>(0.62, 0.74, 0.84);
  let zenN = vec3<f32>(0.006, 0.012, 0.03); let horN = vec3<f32>(0.03, 0.05, 0.07);
  var col = mix(mix(horN, horD, day), mix(zenN, zenD, day), pow(up, 0.55));
  // sunrise and sunset: orange and red around the sun near the horizon
  let low = 1.0 - smoothstep(0.0, 0.35, abs(sun.y));
  let toward = pow(max(dot(normalize(vec3<f32>(dir.x, 0.0, dir.z)), normalize(vec3<f32>(sun.x, 0.0, sun.z))), 0.0), 3.0);
  col = mix(col, vec3<f32>(0.98, 0.52, 0.24), low * toward * (1.0 - smoothstep(0.0, 0.45, up)) * 0.8);
  // stars
  if (day < 0.5 && dir.y > 0.0) {
    let sp = dir.xz / (dir.y + 0.3) * 220.0;
    let st = h2(floor(sp));
    let tw = 0.6 + 0.4 * sin(t * 3.0 + st * 60.0);
    col += vec3<f32>(smoothstep(0.994, 1.0, st) * tw * (1.0 - day * 2.0) * smoothstep(0.0, 0.2, dir.y));
  }
  // sun disk and glow
  let sd = dot(dir, sun);
  col += vec3<f32>(1.0, 0.85, 0.6) * pow(max(sd, 0.0), 300.0) * 1.2 * step(-0.05, sun.y);
  col += vec3<f32>(1.0, 0.95, 0.8) * smoothstep(0.9993, 0.9996, sd) * 4.0;
  // moon: a disk lit from the side by its phase, with dark maria
  let md = dot(dir, moon);
  if (md > 0.9985 && moon.y > -0.05) {
    let mr = normalize(cross(moon, vec3<f32>(0.0, 1.0, 0.0)));
    let mu = normalize(cross(mr, moon));
    let lp = vec2<f32>(dot(dir - moon, mr), dot(dir - moon, mu)) / 0.055;
    let ph = U.q.x * 6.2831;
    let lit = smoothstep(-0.05, 0.05, lp.x * cos(ph) + sqrt(max(0.0, 1.0 - dot(lp, lp))) * sin(ph));
    let maria = 0.75 + 0.25 * n2(lp * 4.0 + vec2<f32>(5.0));
    col = mix(col, vec3<f32>(0.9, 0.92, 0.88) * maria * (0.15 + 0.85 * lit), smoothstep(0.9985, 0.99875, md));
  }
  col += vec3<f32>(0.5, 0.55, 0.6) * pow(max(md, 0.0), 80.0) * 0.12 * (1.0 - day) * step(-0.05, moon.y);
  // clouds: an fbm layer on a plane high above, drifting with the wind
  if (dir.y > 0.01) {
    let cp = dir.xz / dir.y * 1.4 + vec2<f32>(t * 0.012, t * 0.006);
    let c = fbm(cp);
    let cover = U.q.y;
    let dens = smoothstep(0.62 - cover * 0.3, 0.95 - cover * 0.2, c);
    let thick = fbm(cp + normalize(sun.xz + vec2<f32>(1e-4)) * 0.06);
    let shade = clamp(1.0 - (thick - c) * 3.0, 0.45, 1.0);
    let cday = mix(vec3<f32>(0.05, 0.06, 0.08), vec3<f32>(1.0, 0.98, 0.95), day);
    var ccol = cday * mix(0.6, 1.0, shade);
    ccol = mix(ccol, vec3<f32>(1.0, 0.62, 0.40) * max(day, 0.25), low * toward * 0.6);
    col = mix(col, ccol, dens * smoothstep(0.01, 0.12, dir.y) * 0.92);
  }
  // melt into the fog colour at the horizon so terrain and sky meet cleanly
  col = mix(U.fog.rgb, col, smoothstep(-0.02, 0.18, dir.y));
  return vec4<f32>(col, 1.0);
}`;
function r2SkyInit() {
  const m = dev.createShaderModule({ code: WGSL_SKY });
  SKY.pipe = dev.createRenderPipeline({ layout: 'auto', vertex: { module: m, entryPoint: 'vs' },
    fragment: { module: m, entryPoint: 'fs', targets: [{ format: fmt }] }, primitive: { topology: 'triangle-list' },
    depthStencil: { format: 'depth24plus', depthWriteEnabled: false, depthCompare: 'always' }, multisample: { count: SAMPLES } });
  SKY.buf = dev.createBuffer({ size: 128, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });
  SKY.bg = dev.createBindGroup({ layout: SKY.pipe.getBindGroupLayout(0), entries: [{ binding: 0, resource: { buffer: SKY.buf } }] });
}
function r2DrawSky(pass, fog, aspect) {
  if (!SKY.pipe) return;
  const A = SKY.arr;
  const cp = Math.cos(player.pitch), sp = Math.sin(player.pitch), cy = Math.cos(player.yaw), sy = Math.sin(player.yaw);
  const fwd = [cy * cp, sp, sy * cp];
  let right = [-sy, 0, cy];                      // matches m4look's handedness: +x screen = this
  const up = [right[1] * fwd[2] - right[2] * fwd[1], right[2] * fwd[0] - right[0] * fwd[2], right[0] * fwd[1] - right[1] * fwd[0]];
  A.set([SKY.sun[0], SKY.sun[1], SKY.sun[2], 0, SKY.moon[0], SKY.moon[1], SKY.moon[2], 0,
         right[0], right[1], right[2], 0, up[0], up[1], up[2], 0, fwd[0], fwd[1], fwd[2], 0,
         fog[0], fog[1], fog[2], 1, Math.tan(1.15 / 2), aspect, performance.now() / 1000, clamp(world.light != null ? world.light : 1, 0, 1),
         SKY.moonPhase, 0.35 + 0.3 * (1 - (world.season != null ? world.season : 1)), 0, 0]);
  dev.queue.writeBuffer(SKY.buf, 0, A);
  pass.setPipeline(SKY.pipe); pass.setBindGroup(0, SKY.bg); pass.draw(3);
}
