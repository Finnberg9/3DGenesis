# =====================================================================
# TEN NEW CREATURES, AND THE PARTS THEY NEEDED
#
# Built from dev/CREATURE_RULES.md (researched 2026-09-25). Rules, not
# references: nothing here is a copy of a creature from another game. What was
# taken is structure -- where mass goes, how many joints, what replaces a face,
# how a membrane tears -- and every one of the ten is an invented animal.
#
# The ten, and the ONE structural idea each is built on:
#
#   BLOOM     a bulldozer. All mass forward over the shoulders, nothing behind,
#             and the entire face is a four-part mandible that opens like a
#             flower.                                    (P1, M1, S5-horizontal)
#   KITE      wing-dominant. A starved body hanging under a span four times its
#             own length, torn membrane, a whip for a tail.    (W1-W5, P3, T2)
#   GIBBET    vertical. An enormous shoulder yoke with the hips gone, and the
#             head slung so far below the shoulders it sits in the chest.
#                                                              (P1, H6, S5-tall)
#   CRADLE    a table. A hanging belly sac carried on six long thin legs that
#             visibly cannot carry it.                                  (P3, J2)
#   THRESHER  horizontal two-lobe. Thorax and abdomen with a hard pinch, blade
#             forelimbs, a five-segment metasoma held over the back. (P2,J12,T1)
#   PALL      a lid. Far wider than long, a flat shell over a starved core,
#             eight crooked legs of uneven length, no head above the rim.
#                                                                  (P4, S2, H6)
#   HUSK      a tube that rears. Two thirds on the ground, the front third
#             standing vertical with a radial mouth.                (S1, J11)
#   WRACK     compact four-wing. Short broad wings on a pinched body -- the
#             deliberate opposite of KITE, so the fliers stop being one bird.
#                                                                  (W3, P2, T1)
#   SIRE      the dragon. Body SHORT so the neck and tail can be long ON SCREEN
#             rather than long in the numbers, which is why the drake failed.
#   NULL      a biped with nothing to spare. Crooked hyper-extended legs of
#             clearly different length, head hanging below the shoulder line,
#             no arms at all.                                   (P6, S2, S3, J6)
#
# Mass distribution, limb architecture and head solution differ on all ten.
# Judged on the rendered contact sheet, never on these numbers.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, ('ANCHOR %d/%d' % (n, cnt), a[:110]); return s.replace(a, b)

p = 'g3.html'; s = open(p, encoding='utf-8').read()

# ---------------------------------------------------------------- 1. new parts, sim side
s = sub1(s, "    m_duck:     { t: 'MOUTH', mode: 'herb', w: 0.9, cost: 2, reach: 3 },",
"""    m_duck:     { t: 'MOUTH', mode: 'herb', w: 0.9, cost: 2, reach: 3 },
    // Four mandibles, two upper and two lower, crossed when shut: opening is an
    // unlatching rather than a hinge, and what is inside is soft and small
    // against the hard outer segments. Long reach, because the petals open
    // wider than any jaw.
    m_bloom:    { t: 'MOUTH', mode: 'carn', w: 1.1, cost: 4, atk: 5, reach: 7 },""")
s = sub1(s, "    e_bug:      { t: 'EYE', w: 0.8, cost: 2, sense: 12 },",
"""    e_bug:      { t: 'EYE', w: 0.8, cost: 2, sense: 12 },
    // No eye at all: a sunken field of pits. Senses further than any eye and
    // weighs almost nothing, and the head it sits on has no face.
    e_pit:      { t: 'EYE', w: 0.3, cost: 2, sense: 16 },""")
s = sub1(s, "    s_club:     { t: 'SPIKE', w: 0.7, cost: 2, atk: 4, sweep: 1 },",
"""    s_club:     { t: 'SPIKE', w: 0.7, cost: 2, atk: 4, sweep: 1 },
    // Five hard segments and a telson that widens back out before the needle.
    // A taper straight to a point is an antenna; the re-widening is what reads
    // as a delivery device.
    s_sting:    { t: 'SPIKE', w: 0.9, cost: 3, atk: 7, sweep: 1 },
    // Chiselled plates on edge rather than a cone: flat faces that catch light
    // as planes, so they read as bone through the skin instead of as studs.
    s_blade:    { t: 'SPIKE', w: 0.8, cost: 2, atk: 3, def: 3 },""")
s = sub1(s, "    w_insect:   { t: 'WING', w: 1.3, cost: 2 },",
"""    w_insect:   { t: 'WING', w: 1.3, cost: 2 },
    // A very high aspect ratio span, torn along the trailing edge only. Almost
    // all wing and almost no animal.
    w_ragged:   { t: 'WING', w: 1.5, cost: 3 },""")

open(p, 'w', encoding='utf-8').write(s)
print('horror3: sim parts ok')

# ---------------------------------------------------------------- 2. rarity tiers
s = open(p, encoding='utf-8').read()
# ITEM_TIER is emitted twice (the core bundle and the page copy); both must agree.
s = sub1(s, "  m_spino: 'ultra', h_antler: 'ultra', s_shell: 'ultra', w_bat: 'ultra', w_feather: 'ultra',",
            "  m_spino: 'ultra', h_antler: 'ultra', s_shell: 'ultra', w_bat: 'ultra', w_feather: 'ultra',\n"
            "  s_sting: 'ultra', w_ragged: 'ultra', e_pit: 'ultra',", 2)
s = sub1(s, "  t_hand: 'super', t_pincer: 'super', f_fluke: 'super', w_insect: 'super', d_gland: 'super',",
            "  t_hand: 'super', t_pincer: 'super', f_fluke: 'super', w_insect: 'super', d_gland: 'super',\n"
            "  s_blade: 'super',", 2)
s = sub1(s, "  m_rex: 'alpha',", "  m_rex: 'alpha', m_bloom: 'alpha',", 2)
open(p, 'w', encoding='utf-8').write(s)
print('horror3: rarity ok')

# ---------------------------------------------------------------- 3. new part geometry
s = open(p, encoding='utf-8').read()

s = sub1(s, "  m_hook: { name: 'hooked beak', cat: 'mouth',",
r"""  // ---- the split mandible snout ----------------------------------------
  // Four mandibles: two upper, two lower. Closed they CROSS, so the tips of
  // the uppers sit outside the tips of the lowers and opening is an unlatching
  // rather than a hinge. Open, they splay to four quadrants and what is
  // revealed is a short soft pink throat with two small teeth in it -- small
  // and wet against the hard outer segments, because filling the middle with a
  // second set of fangs is what kills the contrast.
  m_bloom: { name: 'split mandible', cat: 'mouth', size: 0.60, col: 'base',
    use: 'four mandibles that unlatch and splay like a flower: the longest reach of any mouth',
    draw(g, c, e) {
      const o = e.chomp;                       // 0 shut (crossed) .. 1 splayed
      const hard = colMul(c, 0.82), lip = [0.52, 0.22, 0.26], gum = [0.62, 0.30, 0.33];
      // the throat behind them: soft, short, and it does not grow when they open
      g.sp(-0.10, 0.30, 0, 0, 1, 0, 0.30, 0.34, 0.30, lip);
      g.ball(0.16, 0.32, 0, 0.26, gum);
      for (const s2 of [1, -1]) g.cn(0.30, 0.44, s2 * 0.10, 1, -0.1, 0, 0.045, 0.22, IVORY);
      // four petals. Shut, each tip is pulled ACROSS the midline by 0.16.
      const petal = (up, side) => {
        const cross = (1 - o) * 0.16 * -side;           // the interlock
        const splay = o * 0.62;
        const dy = up * (0.30 + splay);
        const dz = side * (0.26 + splay) + cross;
        const d = v3.norm([1.0, dy, dz]);
        // grooved base plate, then the blade, then the terminal hook
        const b0 = [0.10, 0.34 + up * 0.10, side * 0.14];
        const b1 = v3.add(b0, v3.mul(d, 0.52));
        const b2 = v3.add(b0, v3.mul(d, 0.95));
        const across = v3.norm(v3.cross(d, [0, up, 0]));
        g.sp(b0[0] + d[0] * 0.20, b0[1] + d[1] * 0.20, b0[2] + d[2] * 0.20,
             d[0], d[1], d[2], 0.20, 0.30, 0.10, hard, across[0], across[1], across[2]);
        g.sp((b0[0] + b1[0]) / 2 + d[0] * 0.22, (b0[1] + b1[1]) / 2 + d[1] * 0.22,
             (b0[2] + b1[2]) / 2 + d[2] * 0.22, d[0], d[1], d[2], 0.13, 0.34, 0.055, c,
             across[0], across[1], across[2]);
        // the hook, bent back toward the midline whichever way the petal points
        const hk = v3.norm([d[0] * 0.6, d[1] - up * 0.55, d[2] - side * 0.45]);
        g.cn(b1[0], b1[1], b1[2], hk[0], hk[1], hk[2], 0.075, 0.46, IVORY);
        g.cn(b2[0], b2[1], b2[2], d[0], d[1], d[2], 0.05, 0.10, IVORY);
        // inner tooth row along the blade, pointing into the throat
        for (let i = 0; i < 4; i++) {
          const q = v3.lerp(b0, b1, 0.3 + i * 0.22);
          const t = v3.norm([-0.3, -up * 0.8, -side * 0.5]);
          g.cn(q[0], q[1], q[2], t[0], t[1], t[2], 0.028, 0.15, IVORY);
        }
      };
      petal(1, 1); petal(1, -1); petal(-1, 1); petal(-1, -1);
    } },
  m_hook: { name: 'hooked beak', cat: 'mouth',""")

s = sub1(s, "  s_quills: { name: 'quills', cat: 'armor',",
r"""  // ---- the metasoma -----------------------------------------------------
  // Five hard segments, each 0.88 of the one before, then a telson that BREAKS
  // the taper by swelling back out to roughly segment-two width before the
  // needle. A monotonic taper to a point reads as an antenna.
  s_sting: { name: 'stinger tail', cat: 'armor', size: 0.5, col: [0.72, 0.66, 0.54],
    use: 'five armoured segments and a venom bulb: the hardest-hitting tail weapon in the game',
    draw(g, c, e) {
      const curl = 0.34 + Math.sin(e.t * 1.6 + e.seed) * 0.06;
      let pnt = [0, 0.1, 0], d = v3.norm([0.55, 1, 0]);
      let r = 0.30;
      const seg = [];
      for (let i = 0; i < 5; i++) {
        const L = 0.62 * Math.pow(0.9, i);
        d = v3.norm(v3.add(d, [-curl * 0.55, -curl * 0.10, 0]));
        const q = v3.add(pnt, v3.mul(d, L));
        const across = v3.norm(v3.cross(d, [0, 0, 1]));
        // each segment is a flat-sided barrel, not a bead: wide across, short along
        g.sp((pnt[0] + q[0]) / 2, (pnt[1] + q[1]) / 2, (pnt[2] + q[2]) / 2,
             d[0], d[1], d[2], r * 1.02, L * 0.46, r * 0.74, i % 2 ? c : colMul(c, 0.92),
             across[0], across[1], across[2]);
        // the ring between two segments, so the taper reads as segmented
        g.ball(q[0], q[1], q[2], r * 0.72, colMul(c, 0.78));
        seg.push(q); pnt = q; r *= 0.88;
      }
      // telson: back out to segment-two width, then the needle
      const tb = v3.add(pnt, v3.mul(d, 0.22));
      g.sp(tb[0], tb[1], tb[2], d[0], d[1], d[2], 0.245, 0.30, 0.215, colMul(c, 1.06));
      const nd = v3.norm(v3.add(d, [-0.9, -0.7, 0]));
      const nb = v3.add(tb, v3.mul(d, 0.16));
      g.cn(nb[0], nb[1], nb[2], nd[0], nd[1], nd[2], 0.085, 0.86, IVORY);
    } },
  // ---- chiselled plates -------------------------------------------------
  // Flat faces on edge instead of a cone. Each plate is a slab with one hard
  // edge facing out and a shorter counter-plate behind it, and the row leans so
  // no two catch the light at the same angle.
  s_blade: { name: 'bone blades', cat: 'armor', size: 0.36, col: [0.86, 0.82, 0.72],
    use: 'angular plates of bone through the skin: cuts what hits you and turns what does not',
    draw(g, c, e) {
      const base = e.base;
      for (let i = 0; i < 3; i++) {
        const lean = (i - 1) * 0.34, h = 1.5 - Math.abs(i - 1) * 0.42;
        const d = v3.norm([lean * 0.8, 1, lean * 0.35]);
        const across = v3.norm(v3.cross(d, [0, 0, 1]));
        const m = v3.mul(d, h * 0.5);
        // the slab: wide across the row, thin through it, tapering is done by
        // the second shorter slab stacked on it rather than by a cone
        g.sp(m[0], m[1], m[2], d[0], d[1], d[2], 0.30, h * 0.5, 0.075,
             i % 2 ? c : colMul(c, 0.93), across[0], across[1], across[2]);
        const m2 = v3.mul(d, h * 0.82);
        g.sp(m2[0], m2[1], m2[2], d[0], d[1], d[2], 0.15, h * 0.24, 0.055, colMul(c, 1.05),
             across[0], across[1], across[2]);
        // the origin wound: skin retracted where it came through
        const r0 = v3.mul(d, 0.04);
        g.sp(r0[0], r0[1], r0[2], 0, 1, 0, 0.30, 0.07, 0.24, base);
      }
    } },
  s_quills: { name: 'quills', cat: 'armor',""")

s = sub1(s, "  e_stalk: {", r"""  // ---- no eye at all ----------------------------------------------------
  // A sunken field of pits in a shallow dish. There is nothing to meet, so the
  // player cannot tell whether they have been noticed -- which is the point.
  e_pit: { name: 'pit field', cat: 'eyes', size: 0.22, col: [0.14, 0.12, 0.13],
    use: 'senses further than any eye and gives nothing back: a head wearing this has no face',
    draw(g, c, e) {
      g.sp(0, -0.04, 0, 0, 1, 0, 0.62, 0.10, 0.52, colMul(e.base, 0.82));
      const pits = [[0, 0.26], [0.34, 0.12], [-0.34, 0.14], [0.2, -0.28], [-0.22, -0.3],
                    [0.46, -0.1], [-0.48, -0.06]];
      for (let i = 0; i < pits.length; i++) {
        const [u, v] = pits[i];
        const r = 0.11 + (i % 3) * 0.035;
        g.ball(u * 0.6, 0.03, v * 0.6, r, c);
        g.ball(u * 0.6, -0.02, v * 0.6, r * 1.5, colMul(e.base, 0.62));
      }
    } },
  e_stalk: {""")

open(p, 'w', encoding='utf-8').write(s)
print('horror3: mandible, metasoma, blades and the pit field ok')

# ---------------------------------------------------------------- 4. three wings that are not each other
# The four fliers read as one bird because every wing in the game was the same
# leaf with veins in it. Three different wings, built on the three real
# architectures rather than on three sets of numbers:
#
#   w_bat     a hand. Four finger spars, FOUR membrane panels (leading edge,
#             inter-digit, body-to-ankle), a clawed thumb at the WRIST -- the
#             outermost forward bend, which is where the hook belongs and not
#             the elbow -- and tears that start at the trailing margin and run
#             parallel to the spars, never across them.
#   w_ragged  the same architecture starved: aspect ratio near the top of the
#             legible band, one unbroken leading edge, two spars instead of
#             four, and most of the trailing half torn away.
#   w_insect  hard forewing over a folded gossamer hindwing. Short and broad,
#             cross-veined, and it does not have a hand in it at all.
s = open(p, encoding='utf-8').read()

OLD_BAT_START = "  w_bat: { name: 'membrane wing', cat: 'wings', size: 1.0, col: [0.55, 0.36, 0.40], draw(g0, c, e) {"
i0 = s.index(OLD_BAT_START)
i1 = s.index("  w_feather: { name: 'feathered wing'")
HELPER = r"""// A membrane wing is a HAND, and it has four panels, not one. Build only the
// inter-digit panel and the result is an umbrella.
//   propatagium   shoulder -> wrist, the leading edge. Never torn: it is the
//                 load path and the muscle sits in it.
//   dactylopatagia between the finger spars. Thinnest, most translucent, and
//                 where the tears cluster.
//   plagiopatagium last finger back to the hip. The panel that makes it read
//                 as an animal rather than a kite.
function membraneWing(g0, c, e, o2) {
  const { o: O, B } = wingAxes(g0);
  const g = g0.rotated(B[0], B[1], B[2], e.flap);
  const NF = o2.fingers, SPAN = o2.span, CH = o2.chord, TEAR = o2.tear, TH = o2.thick;
  const bone = colMul(c, 0.62), skin = c, thin = colMul(c, 1.14);
  const P = (y, b) => v3.add(v3.mul(O, y), v3.mul(B, b));
  const sh = P(0.04, 0), el = P(0.48 * SPAN, -0.06), wr = P(1.0 * SPAN, 0.03);
  // arm: elbow thicker than wrist, and the wrist is where the hook goes
  g.tube(sh, el, 0.085 * TH, 0.062 * TH, bone, 4);
  g.tube(el, wr, 0.062 * TH, 0.042 * TH, bone, 4);
  // ---- the claw hook at the WRIST, not the elbow -----------------------
  // Two bones so it curves: out along the leading edge, then hooked back.
  {
    const fwd = v3.norm(v3.sub(wr, el));
    const lead = v3.norm(v3.add(v3.mul(fwd, 0.55), v3.mul(B, -0.85)));
    const k1 = v3.add(wr, v3.mul(lead, 0.30 * SPAN));
    const back = v3.norm(v3.add(v3.mul(lead, 0.25), v3.mul(fwd, -0.75)));
    const k2 = v3.add(k1, v3.mul(back, 0.26 * SPAN));
    g.tube(wr, k1, 0.055, 0.036, IVORY, 4);
    g.cn(k1[0], k1[1], k1[2], back[0], back[1], back[2], 0.036, 0.30 * SPAN, IVORY);
    g.ball(k2[0], k2[1], k2[2], 0.018, IVORY);
  }
  // ---- finger spars ----------------------------------------------------
  const tips = [];
  for (let i = 0; i < NF; i++) {
    const u = NF > 1 ? i / (NF - 1) : 0;
    const a2 = 0.10 + u * (o2.fan || 1.35);
    const L = (1.05 - u * 0.18) * SPAN;
    const tip = v3.add(wr, P(Math.cos(a2) * L, Math.sin(a2) * L * CH));
    g.tube(wr, tip, 0.036 * TH, 0.013 * TH, bone, 4);
    tips.push(tip);
  }
  const hip = P(-0.05, 0.95 * CH);        // where the plagiopatagium lands
  // ---- panels ----------------------------------------------------------
  // Each panel is one flat sheet in the wing plane. `bite` pulls the trailing
  // corner in, which is the tear: it runs parallel to the two spars bounding
  // the panel and never across them, and it is capped so a continuous strip
  // of membrane always survives along each spar.
  const sheet = (A, B2, C2, k, bite, col) => {
    const b2 = v3.lerp(B2, A, bite), c2 = v3.lerp(C2, A, bite);
    const mid = v3.mul(v3.add(b2, c2), 0.5);
    const ax = v3.sub(mid, A), span = v3.sub(c2, b2);
    const L = v3.len(ax), W = v3.len(span);
    const q = v3.lerp(A, mid, 0.56);
    g.sp(q[0], q[1], q[2], ax[0], ax[1], ax[2], W * 0.52 * k, L * 0.56, 0.014, col,
         span[0], span[1], span[2]);
  };
  for (let i = 0; i < tips.length - 1; i++) {
    // tears cluster in the distal panels, which take the most flutter
    const dist = tips.length > 1 ? i / (tips.length - 1) : 0;
    sheet(wr, tips[i], tips[i + 1], 1, Math.min(0.40, TEAR * (0.35 + dist)), thin);
  }
  sheet(wr, tips[tips.length - 1], hip, 1.02, Math.min(0.40, TEAR * 0.5), skin);  // plagiopatagium
  sheet(el, wr, hip, 0.92, 0, skin);
  sheet(sh, el, hip, 0.9, 0, colMul(skin, 0.9));
  // propatagium: the leading edge, one unbroken curve, never torn
  { const m = v3.lerp(sh, wr, 0.5), ax = v3.sub(wr, sh);
    const across = v3.norm(v3.add(v3.mul(B, -1), v3.mul(O, 0.1)));
    const w2 = 0.16 * CH * SPAN;
    const q = v3.add(m, v3.mul(across, w2 * 0.6));
    g.sp(q[0], q[1], q[2], ax[0], ax[1], ax[2], w2, v3.len(ax) * 0.5, 0.02, colMul(skin, 0.88),
         across[0], across[1], across[2]); }
}
function w_batDraw(g0, c, e) { membraneWing(g0, c, e, { fingers: 4, span: 1.0, chord: 1.0, tear: 0.30, thick: 1.0, fan: 1.35 }); }
"""
# The helper is a top-level function, not a member of the VIS object literal:
# hoisted above it so every wing entry can call it.
s = sub1(s, "function wingAxes(g) {", HELPER + "\nfunction wingAxes(g) {")
i0 = s.index(OLD_BAT_START)
i1 = s.index("  w_feather: { name: 'feathered wing'")
s = s[:i0] + "  w_bat: { name: 'membrane wing', cat: 'wings', size: 1.0, col: [0.55, 0.36, 0.40], use: 'four panels of skin on a hand, with a claw at the wrist: heavy lift, and it tears', draw: w_batDraw },\n" + s[i1:]

# w_ragged: the same architecture, starved and torn to pieces
s = sub1(s, "  w_feather: { name: 'feathered wing'",
r"""  w_ragged: { name: 'torn membrane', cat: 'wings', size: 1.0, col: [0.42, 0.34, 0.36],
    use: 'an enormous thin span with most of the trailing half gone: it barely holds air, and it holds a lot of it',
    draw(g0, c, e) { membraneWing(g0, c, e, { fingers: 2, span: 1.85, chord: 0.46, tear: 0.62, thick: 0.62, fan: 0.85 }); } },
  w_feather: { name: 'feathered wing'""")

# w_insect: hard forewing over a folded hindwing, short and broad. No hand in it.
i0 = s.index("  w_insect: { name: 'gossamer wings', cat: 'wings'")
i1 = s.index("  // ---------------------------------------------------------------- details")
s = s[:i0] + r"""  w_insect: { name: 'shell wings', cat: 'wings', size: 0.9, col: [0.62, 0.66, 0.44],
    use: 'a hard case over a folded sheet: short, broad and beaten fast, so a heavy body still leaves the ground',
    draw(g0, c, e) {
      const { o: O, B } = wingAxes(g0);
      const g = g0.rotated(B[0], B[1], B[2], e.flap * 1.5);
      const P = (y, b) => v3.add(v3.mul(O, y), v3.mul(B, b));
      const hard = colMul(c, 0.82), sheet = [0.80, 0.84, 0.88];
      // forewing: a hard case, wide and short, held out nearly level
      const fd = v3.norm(P(0.92, 0.36));
      const fa = v3.norm(v3.cross(fd, v3.cross(O, B)));
      const fm = v3.mul(fd, 0.52);
      g.sp(fm[0], fm[1], fm[2], fd[0], fd[1], fd[2], 0.40, 0.58, 0.085, hard, fa[0], fa[1], fa[2]);
      // the seam down the case, and three ribs across it
      g.tube([0, 0, 0], v3.mul(fd, 1.02), 0.055, 0.03, colMul(c, 0.6), 4);
      for (let i = 0; i < 3; i++) {
        const q = v3.mul(fd, 0.26 + i * 0.26);
        g.sp(q[0], q[1], q[2], fa[0], fa[1], fa[2], 0.055, 0.34, 0.06, colMul(c, 0.68),
             fd[0], fd[1], fd[2]);
      }
      // hindwing folded out beneath it: thin, translucent, cross-veined
      const hd = v3.norm(P(0.74, 0.76));
      const ha = v3.norm(v3.cross(hd, v3.cross(O, B)));
      const hm = v3.mul(hd, 0.46);
      g.sp(hm[0], hm[1], hm[2], hd[0], hd[1], hd[2], 0.33, 0.50, 0.012, sheet, ha[0], ha[1], ha[2]);
      for (let i = 0; i < 4; i++) {
        const t = 0.15 + i * 0.22;
        g.tube(v3.mul(hd, t * 0.35), v3.add(v3.mul(hd, t * 0.9), v3.mul(ha, 0.30 - i * 0.05)),
               0.016, 0.008, colMul(sheet, 0.72), 3);
      }
    } },
""" + s[i1:]

open(p, 'w', encoding='utf-8').write(s)
print('horror3: three wings, and none of them is the other two ok')

# ---------------------------------------------------------------- 5. the ten skeletons
s = open(p, encoding='utf-8').read()
ANCH = "    { a: 0.86, b: 0.46, seg: 9,  prof: 'animal', arch: 0.26, droop: 0.00, wide: 0,    neck: 1.05, nx: 0.78, ny: -0.06, ns: 4, head: 0.40, snx: 1.55, snr: 0.26, tail: 0.25, tailR: 0.10, ts: 4, stand: 1.00, hump: 0.55 }, // 37 skimmer: the one long beak, held out level on a folded frame\n  ];"
s = sub1(s, ANCH, ANCH[:-4] + """
    // ---- 2026-09-25: the new ten ------------------------------------------
    // `crook` is new: how hard the leg pass breaks the mirror. 0 keeps a plan
    // byte-identical to what it was, so nothing above this line moves.
    { a: 1.00, b: 0.88, seg: 11, prof: 'animal', arch: 0.34, droop: 0.02, wide: 0.58, neck: 0.52, nx: 0.94, ny: -0.26, ns: 2, head: 0.64, snx: 1.05, snr: 0.62, tail: 0.0, tailR: 0.14, ts: 4, stand: 1.32, hump: 0.78, waist: 0.16, waistAt: 0.22, crook: 0.5 }, // 38 bloom: everything forward, nothing behind, and the face is the mouth
    { a: 0.80, b: 0.28, seg: 9,  prof: 'tube',   arch: 0.12, droop: 0.26, wide: 0,    neck: 0.62, nx: 0.88, ny: -0.24, ns: 3, head: 0.30, snx: 0.78, snr: 0.26, tail: 1.5, tailR: 0.11, ts: 10, stand: 0.90, hump: 0.55, crook: 0.7, view: [0.42, 0.56, 0.72] }, // 39 kite: a starved body hanging under a span four times its length
    { a: 0.78, b: 0.54, seg: 11, prof: 'animal', arch: 0.74, droop: 0.34, wide: 0.54, neck: 0.58, nx: 0.42, ny: -0.92, ns: 2, head: 0.26, snx: 0.40, snr: 0.32, tail: 0.0, tailR: 0.12, ts: 4, stand: 2.85, hump: 0.99, waist: 0.54, waistAt: 0.20, waistW: 0.09, crook: 0.8 }, // 40 gibbet: a shoulder yoke with no hips, head hanging inside the chest
    { a: 1.18, b: 0.96, seg: 11, prof: 'blob',   arch: 0.04, droop: 0.58, wide: 0.64, neck: 0.88, nx: 0.92, ny: -0.30, ns: 2, head: 0.30, snx: 0.62, snr: 0.30, tail: 0.5, tailR: 0.11, ts: 5, stand: 2.00, hump: 0.18, crook: 0.6 }, // 41 cradle: a hanging belly on six legs that cannot carry it
    { a: 1.32, b: 0.58, seg: 13, prof: 'insect', arch: 0.32, droop: 0.00, wide: 0.14, neck: 0.58, nx: 0.82, ny: -0.40, ns: 3, head: 0.26, snx: 0.74, snr: 0.28, tail: 1.9, tailR: 0.22, ts: 9, stand: 1.40, tailUp: 1.0, hump: 0.72, waist: 0.64, waistAt: 0.42, waistW: 0.09, crook: 0.4 }, // 42 thresher: two lobes, blade arms, the metasoma over the back
    { a: 1.20, b: 0.42, seg: 9,  prof: 'round',  arch: 0.14, droop: 0.00, wide: 1.60, neck: 0.66, nx: 0.92, ny: -0.46, ns: 2, head: 0.26, snx: 0.50, snr: 0.26, tail: 0.0, tailR: 0.12, ts: 4, stand: 1.30, hump: 0.30, crook: 1.0 }, // 43 pall: a lid. Wider than it is long, eight crooked legs, nothing above the rim
    { a: 2.05, b: 0.40, seg: 19, prof: 'tube',   arch: 0.58, droop: 0.00, wide: 0.10, neck: 1.35, nx: 0.42, ny: 0.94,  ns: 6, head: 0.34, snx: 0.52, snr: 0.34, tail: 1.0, tailR: 0.14, ts: 7, stand: 0.95, flex: 1, hump: 0.97, crook: 0.5 }, // 44 husk: two thirds on the floor, the front third standing up
    { a: 0.70, b: 0.64, seg: 9,  prof: 'insect', arch: 0.22, droop: 0.00, wide: 0.36, neck: 0.58, nx: 0.84, ny: -0.22, ns: 2, head: 0.36, snx: 0.66, snr: 0.36, tail: 1.7, tailR: 0.20, ts: 8, stand: 0.88, tailUp: 0.85, hump: 0.45, waist: 0.52, waistAt: 0.38, waistW: 0.10, crook: 0.5 }, // 45 wrack: short broad wings on a pinched body: the opposite of the kite
    { a: 1.02, b: 0.86, seg: 11, prof: 'animal', arch: 0.42, droop: 0.04, wide: 0.26, neck: 1.95, nx: 0.56, ny: 0.72,  ns: 8, head: 0.46, snx: 1.20, snr: 0.40, tail: 2.6, tailR: 0.30, ts: 12, stand: 1.95, hump: 0.80, waist: 0.22, waistAt: 0.30, crook: 0.25, view: [0.86, 0.22, 0.46] }, // 46 sire: the body is SHORT so the neck and the tail are long on screen
    { a: 0.70, b: 0.40, seg: 11, prof: 'tube',   arch: 0.54, droop: 0.20, wide: 0.10, neck: 0.98, nx: 0.74, ny: -0.48, ns: 4, head: 0.34, snx: 0.88, snr: 0.28, tail: 2.1, tailR: 0.16, ts: 11, stand: 2.65, hump: 0.94, waist: 0.30, waistAt: 0.26, crook: 1.0 }, // 47 null: two crooked legs, a head below the shoulder line, and nothing else
  ];""")

# hides
ANCH2 = "    { base: [0.30, 0.28, 0.24], coat: [0.62, 0.58, 0.50], detail: [0.78, 0.40, 0.20], pat: 1 },  // 37 skimmer"
s = sub1(s, ANCH2, ANCH2 + """
    { base: [0.26, 0.15, 0.17], coat: [0.58, 0.40, 0.38], detail: [0.86, 0.34, 0.30], pat: 3 },  // 38 bloom
    { base: [0.16, 0.15, 0.18], coat: [0.40, 0.38, 0.42], detail: [0.72, 0.62, 0.56], pat: 0 },  // 39 kite
    { base: [0.22, 0.21, 0.19], coat: [0.50, 0.48, 0.44], detail: [0.88, 0.86, 0.76], pat: 0 },  // 40 gibbet
    { base: [0.28, 0.25, 0.20], coat: [0.60, 0.56, 0.46], detail: [0.72, 0.30, 0.34], pat: 2 },  // 41 cradle
    { base: [0.18, 0.20, 0.17], coat: [0.44, 0.48, 0.40], detail: [0.84, 0.72, 0.22], pat: 1 },  // 42 thresher
    { base: [0.20, 0.19, 0.22], coat: [0.46, 0.44, 0.48], detail: [0.60, 0.68, 0.58], pat: 1 },  // 43 pall
    { base: [0.24, 0.18, 0.16], coat: [0.54, 0.44, 0.38], detail: [0.80, 0.50, 0.24], pat: 1 },  // 44 husk
    { base: [0.19, 0.17, 0.14], coat: [0.46, 0.42, 0.34], detail: [0.66, 0.78, 0.46], pat: 2 },  // 45 wrack
    { base: [0.17, 0.19, 0.16], coat: [0.42, 0.46, 0.40], detail: [0.88, 0.40, 0.18], pat: 1 },  // 46 sire
    { base: [0.21, 0.20, 0.21], coat: [0.48, 0.46, 0.46], detail: [0.90, 0.88, 0.82], pat: 0 },  // 47 null""")

# skins: 0 smooth, 1 scales, 2 feathers, 3 fur, 4 armour plates
s = sub1(s, """  //                 lurker maw hollow centipede flit mothwing drake
                     0, 4, 0, 4, 2, 2, 1, 2];""",
"""  //                 lurker maw hollow centipede flit mothwing drake
                     0, 4, 0, 4, 2, 2, 1, 2,
  //                 bloom kite gibbet cradle thresher pall husk wrack sire null
                     1, 0, 0, 1, 4, 4, 1, 4, 1, 0];""")

# names
s = sub1(s, "                    'lurker', 'maw', 'hollow', 'centipede', 'flit', 'mothwing', 'drake', 'skimmer'];",
"""                    'lurker', 'maw', 'hollow', 'centipede', 'flit', 'mothwing', 'drake', 'skimmer',
                    'bloom', 'kite', 'gibbet', 'cradle', 'thresher', 'pall', 'husk', 'wrack', 'sire', 'null'];""")

open(p, 'w', encoding='utf-8').write(s)
print('horror3: ten skeletons, hides and names ok')

# ---------------------------------------------------------------- 6. what each of the ten is born as
s = open(p, encoding='utf-8').read()

s = sub1(s, "      // ---- the offered set -----------------------------------------------\n      case 30: // lurker",
r"""      // ---- 2026-09-25: the new ten ---------------------------------------
      case 38: // BLOOM. All mass over the shoulders. The face IS the mouth.
        // No eyes on the front of the head at all -- they are pushed up and
        // back onto the skull, above and behind the petals, so the thing you
        // are looking into is a throat.
        eyeAt('e_pit', 0.9, 0.80, -0.10, 0.34);
        mouthAt('m_bloom', 1.35);
        put('s_blade', a * 0.30, b * 1.05, b * 0.34, 0.15, 1, 0.35, 1.05, true);
        put('s_blade', -a * 0.25, b * 0.92, b * 0.30, -0.2, 1, 0.35, 0.75, true);
        // four stumps under a body that overhangs them front and back
        limb('l_thick',  a * 0.40, -b * 0.42,  b * 0.66,  a * 0.50, -st, b * 0.88, 0.08, 0.06, 0.04, 't_pad', 1.55);
        limb('l_thick', -a * 0.34, -b * 0.42,  b * 0.62, -a * 0.44, -st, b * 0.84, -0.08, 0.06, 0.04, 't_pad', 1.35);
        break;
      case 39: // KITE. The wing is the animal.
        eyeAt('e_pit', 0.8, 0.55, 0.30, 0.42); mouthAt('m_hook', 0.9);
        put('w_ragged', a * 0.20, b * 0.70, b * 0.46, 0, 0.62, 0.78, 2.9, true);
        put('w_ragged', -a * 0.30, b * 0.52, b * 0.44, -0.2, 0.5, 0.84, 1.5, true);
        // two hooks, not legs: they hang, they do not walk well
        limb('l_thin', -a * 0.05, -b * 0.42, b * 0.40, a * 0.06, -st, b * 0.52, 0.26, 0.04, 0.05, 't_talon', 0.55);
        tailPut('s_knob', 0.7);
        break;
      case 40: // GIBBET. A shoulder yoke, no hips, and the head inside the chest.
        eyeAt('e_pit', 1.15, 0.10, 0.20, 0.40);
        mouthAt('m_maw', 0.85);
        put('s_blade', a * 0.10, b * 1.25, b * 0.40, 0, 1, 0.4, 1.35, true);
        put('h_curved', -a * 0.30, b * 1.05, b * 0.22, -0.4, 1, 0.3, 0.8, true);
        // the two long front limbs it stands on
        limb('l_thin',  a * 0.24, -b * 0.10,  b * 0.56,  a * 0.30, -st, b * 0.70, 0.34, 0.16, 0.06, 't_claw', 0.80);
        // and the starved pair behind, kept clear of the ground so they stay arms
        limb('l_thin', -a * 0.34,  b * 0.30,  b * 0.48, -a * 0.60, -st * 0.36, b * 0.66, -0.26, -0.30, 0.10, 't_claw', 0.46);
        break;
      case 41: // CRADLE. A belly that hangs, on legs that visibly cannot hold it.
        eyeAt('e_cluster', 0.7, 0.45, 0.42, 0.44); mouthAt('m_hook', 0.8);
        put('s_knob', -a * 0.10, -b * 0.95, b * 0.30, 0, -1, 0.3, 1.2, true);
        legRow('l_thin', [0.44, 0.06, -0.38], { out: 0.78, up: 0.25, rake: 1.25, reach: 2.25, knee: 1.15, th: 0.52, tip: 't_talon' });
        break;
      case 42: // THRESHER. Thorax, hard pinch, abdomen, and the sting over the back.
        eyeAt('e_bug', 0.8, 0.40, 0.44, 0.52); mouthAt('m_hook', 0.9);
        put('s_blade', a * 0.36, b * 1.00, b * 0.26, 0.2, 1, 0.3, 0.95, true);
        // raptorial pair: thick grooved upper arm, thin blade below, hook on the end
        limb('l_thick', a * 0.58, b * 0.18, b * 0.50, a * 1.25, -st * 0.50, b * 0.80, 0.22, -0.34, 0.14, 't_claw', 1.00);
        // one heavy digitigrade hind pair, planted under the mass
        limb('l_leg', -a * 0.30, -b * 0.28, b * 0.54, -a * 0.10, -st, b * 0.70, 0.34, 0.20, 0.05, 't_talon', 1.15);
        tailPut('s_sting', 1.5);
        break;
      case 43: // PALL. A lid on eight crooked legs. Nothing above the rim.
        eyeAt('e_pit', 0.8, -0.35, 0.22, 0.55);
        mouthAt('m_hook', 0.75);
        put('s_shell', 0, b * 1.02, 0, 0, 1, 0, 1.55, false);
        put('s_blade', a * 0.30, b * 0.70, b * 1.00, 0.2, 0.45, 1, 0.8, true);
        put('s_blade', -a * 0.30, b * 0.68, b * 1.00, -0.2, 0.45, 1, 0.8, true);
        legRow('l_thin', [0.62, 0.22, -0.20, -0.58], { out: 0.94, up: 0.05, rake: 1.05, reach: 2.05, knee: 0.95, th: 0.66, tip: 't_talon' });
        break;
      case 44: // HUSK. Two thirds on the floor, the front third standing up.
        eyeAt('e_pit', 0.9, 0.30, 0.38, 0.50); mouthAt('m_bloom', 0.95);
        put('s_blade', a * 0.55, b * 1.05, b * 0.22, 0.3, 1, 0.3, 0.7, true);
        legRow('l_thin', [0.62, 0.36, 0.10, -0.16, -0.42, -0.68], { out: 0.82, rake: 0.7, reach: 1.05, knee: 0.5, th: 0.62, tip: 't_talon' });
        tailPut('s_spike', 0.9);
        break;
      case 45: // WRACK. Short broad wings on a pinched body. Not the kite.
        eyeAt('e_bug', 0.9, 0.42, 0.40, 0.55); mouthAt('m_jaws', 0.85);
        put('w_insect', a * 0.18, b * 0.66, b * 0.50, 0.1, 0.62, 0.78, 1.55, true);
        put('w_insect', -a * 0.22, b * 0.58, b * 0.50, -0.15, 0.55, 0.82, 1.20, true);
        put('d_antenna', head.x + hr * 0.2, head.y + hr, hr * 0.3, 0.3, 1, 0.35, 1.2, true);
        legRow('l_thin', [0.30, -0.22], { out: 0.80, rake: 1.0, reach: 1.45, knee: 0.7, th: 0.68, tip: 't_talon' });
        tailPut('s_sting', 1.2);
        break;
      case 46: // SIRE. Short body, long neck, long tail, and a real wing on it.
        eyeAt('e_slit', 0.95, 0.48, 0.34, 0.56);
        mouthAt('m_bloom', 1.05);
        put('h_curved', head.x - hr * 0.30, head.y + hr * 0.9, hr * 0.38, -0.35, 1, 0.4, 1.15, true);
        put('h_straight', head.x - hr * 0.60, head.y + hr * 0.7, hr * 0.30, -0.6, 0.9, 0.4, 0.75, true);
        put('w_bat', a * 0.08, b * 0.76, b * 0.50, 0, 0.7, 0.72, 3.6, true);
        put('s_blade', -a * 0.40, b * 0.96, b * 0.22, -0.3, 1, 0.3, 0.9, true);
        limb('l_leg',  a * 0.48, -b * 0.28,  b * 0.58,  a * 0.56, -st, b * 0.76, 0.16, 0, 0.05, 't_talon', 1.05);
        limb('l_leg', -a * 0.46, -b * 0.28,  b * 0.58, -a * 0.56, -st, b * 0.76, -0.16, 0, 0.05, 't_talon', 1.20);
        tailPut('s_sting', 1.1);
        break;
      case 47: // NULL. Two crooked legs and a head below the shoulder line.
        eyeAt('e_pit', 0.85, 0.40, 0.34, 0.44); mouthAt('m_maw', 0.95);
        put('s_blade', a * 0.05, b * 1.20, b * 0.20, 0, 1, 0.25, 1.15, true);
        put('s_blade', -a * 0.45, b * 1.00, b * 0.18, -0.4, 1, 0.25, 0.8, true);
        limb('l_thin', -a * 0.10, -b * 0.24, b * 0.46, a * 0.02, -st, b * 0.58, 0.40, 0.22, 0.06, 't_talon', 0.74);
        tailPut('s_spike', 1.0);
        break;
      // ---- the offered set -----------------------------------------------
      case 30: // lurker""")

open(p, 'w', encoding='utf-8').write(s)
print('horror3: ten bodies ok')

# ---------------------------------------------------------------- 7. crooked legs
# Rule S2: if no pair on the body matches, the viewer's "healthy animal"
# classifier never terminates. Rule S3: below about 10% the difference reads as
# a rigging bug, so the jitter has to be big -- but the FOOT HEIGHT is left
# alone, because a foot off the floor reads as broken rather than as crooked,
# and the walk code plants on the shortest leg. So the legs differ in reach,
# rake, bend and thickness -- genuinely different lengths along their own path
# -- while every one of them still touches the ground.
s = open(p, encoding='utf-8').read()
s = sub1(s, "    const a = sk.a, b = sk.b, st = P.stand;\n    switch (pi) {",
r"""    const a = sk.a, b = sk.b, st = P.stand;
    // deterministic per-limb hash, so a plan looks the same every time it is built
    const crookRnd = (i, k) => {
      let h2 = (i * 374761393 + k * 668265263 + pi * 2246822519) >>> 0;
      h2 = Math.imul(h2 ^ (h2 >>> 13), 1274126177) >>> 0;
      return ((h2 ^ (h2 >>> 16)) >>> 0) / 4294967296 * 2 - 1;   // -1..1
    };
    const crookLegs = () => {
      const amt = P.crook || 0;
      if (amt <= 0) return;
      for (let i = 0; i < d.limbs.length; i++) {
        const lb = d.limbs[i];
        // fore/aft reach and lateral reach: the leg genuinely gets longer or
        // shorter along its own path
        const legLen = Math.hypot(lb.f[0], lb.f[1], lb.f[2]) || b;
        lb.f[0] += crookRnd(i, 1) * 0.30 * amt * legLen;
        lb.f[2] *= 1 + crookRnd(i, 2) * 0.34 * amt;
        // the bend. Pushing the knee past the straight line is the
        // hyper-extension, and it is what makes a long leg look wrong rather
        // than just long.
        lb.k[0] += crookRnd(i, 3) * 0.40 * amt;
        lb.k[1] += crookRnd(i, 4) * 0.34 * amt;
        lb.k[2] *= 1 + crookRnd(i, 5) * 0.30 * amt;
        lb.th *= 1 + crookRnd(i, 6) * 0.22 * amt;
        // f[1] is deliberately untouched: every foot still reaches the floor.
      }
    };
    switch (pi) {""")
s = sub1(s, "        tailPut('f_fluke', 0.8);\n        break;\n    }\n    return d;\n  }",
            "        tailPut('f_fluke', 0.8);\n        break;\n    }\n    crookLegs();\n    return d;\n  }")
open(p, 'w', encoding='utf-8').write(s)
print('horror3: crooked legs ok')

# ---------------------------------------------------------------- 8. what the picker offers
# The previous ten stay in the table -- renumbering turns every saved design
# into a different animal -- they are just no longer offered.
s = open(p, encoding='utf-8').read()
s = sub1(s, """  { label: 'land', note: 'ten shapes. every one of them walks.',
    plans: [30, 31, 32, 33, 22, 23, 26, 27, 25, 24] },
  { label: 'air', note: 'wings. the moth has no legs at all and cannot enter a match.',
    plans: [34, 35, 37, 36] },""",
"""  { label: 'land', note: 'seven shapes. every one of them walks.',
    plans: [38, 40, 41, 42, 43, 44, 47] },
  { label: 'air', note: 'three wings, and no two of them are the same wing.',
    plans: [39, 45, 46] },""")
open(p, 'w', encoding='utf-8').write(s)
print('horror3: the picker offers the new ten ok')

# ---------------------------------------------------------------- 9. the tile camera, per plan
# "Winged -> look from above" was right for four birds and wrong for a dragon:
# from overhead a long neck and a long tail are two dots, which is exactly how
# the drake kept failing. A plan can now name its own view.
s = open(p, encoding='utf-8').read()
s = sub1(s, """      const winged = (d.parts || []).some((q) => { const sim = C.ITEM_SIM[q.id]; return sim && sim.t === 'WING'; });
      view = winged ? [0.30, 0.74, 0.60] : [0.60, 0.26, 0.80];""",
"""      const winged = (d.parts || []).some((q) => { const sim = C.ITEM_SIM[q.id]; return sim && sim.t === 'WING'; });
      const pv = C.PLANS[j.plan] && C.PLANS[j.plan].view;
      view = pv ? pv.slice() : winged ? [0.30, 0.74, 0.60] : [0.60, 0.26, 0.80];""")
open(p, 'w', encoding='utf-8').write(s)
print('horror3: a plan can name its own tile camera ok')

# ---------------------------------------------------------------- 10. make the signature parts read
# S = vis.size * clamp(pt.s, 0.3, 3) * R, so the size field is the real lever:
# the per-plan scale saturates at 3. A creature whose one oversized feature is
# drawn at 0.8 R does not have an oversized feature.
s = open(p, encoding='utf-8').read()
s = sub1(s, "  m_bloom: { name: 'split mandible', cat: 'mouth', size: 0.60, col: 'base',",
            "  m_bloom: { name: 'split mandible', cat: 'mouth', size: 1.05, col: 'base',")
s = sub1(s, "  s_sting: { name: 'stinger tail', cat: 'armor', size: 0.5, col: [0.72, 0.66, 0.54],",
            "  s_sting: { name: 'stinger tail', cat: 'armor', size: 0.95, col: [0.72, 0.66, 0.54],")
s = sub1(s, "  s_blade: { name: 'bone blades', cat: 'armor', size: 0.36, col: [0.86, 0.82, 0.72],",
            "  s_blade: { name: 'bone blades', cat: 'armor', size: 0.52, col: [0.86, 0.82, 0.72],")
s = sub1(s, "  e_pit: { name: 'pit field', cat: 'eyes', size: 0.22, col: [0.14, 0.12, 0.13],",
            "  e_pit: { name: 'pit field', cat: 'eyes', size: 0.34, col: [0.14, 0.12, 0.13],")
# w_ragged was torn to nothing: at tear 0.62 on two spars there is no membrane
# left to read as a wing. Three spars, and the tear capped well short of the
# spar so a continuous strip always survives.
s = sub1(s, "{ fingers: 2, span: 1.85, chord: 0.46, tear: 0.62, thick: 0.62, fan: 0.85 }",
            "{ fingers: 3, span: 2.05, chord: 0.62, tear: 0.34, thick: 0.62, fan: 1.05 }")
open(p, 'w', encoding='utf-8').write(s)
print('horror3: the oversized features are oversized ok')

# ---------------------------------------------------------------- 11. second shape pass
# Everything below was decided by looking at the contact sheet, not at numbers.
s = open(p, encoding='utf-8').read()

# A wing seen edge-on is a line -- true of the palette icon as much as of the
# creature tile, and the icons were rendering as needles.
s = sub1(s, "      if (v.cat === 'mouth') view = [0.58, 0.26, 0.95];",
"""      if (v.cat === 'mouth') view = [0.58, 0.26, 0.95];
      else if (v.cat === 'wings') view = [0.26, 0.78, 0.56];""")

# The mandible rests HALF OPEN. A mouth that only splays when it bites shows a
# closed fist in every tile and on every animal that is not mid-attack, and the
# splay is the entire idea.
s = sub1(s, "      const o = e.chomp;                       // 0 shut (crossed) .. 1 splayed",
            "      const o = 0.42 + e.chomp * 0.58;         // rests half open; 1 is fully splayed")
# and the throat behind it was a wide blue disc that read as a dinner plate
s = sub1(s, "      g.sp(-0.10, 0.30, 0, 0, 1, 0, 0.30, 0.34, 0.30, lip);\n      g.ball(0.16, 0.32, 0, 0.26, gum);",
            "      g.sp(-0.02, 0.30, 0, 0, 1, 0, 0.19, 0.26, 0.19, lip);\n      g.ball(0.18, 0.32, 0, 0.17, gum);")
# longer petals, so the flower is the head rather than a crown on it
s = sub1(s, "        const b1 = v3.add(b0, v3.mul(d, 0.52));\n        const b2 = v3.add(b0, v3.mul(d, 0.95));",
            "        const b1 = v3.add(b0, v3.mul(d, 0.86));\n        const b2 = v3.add(b0, v3.mul(d, 1.44));")
s = sub1(s, "             d[0], d[1], d[2], 0.20, 0.30, 0.10, hard, across[0], across[1], across[2]);",
            "             d[0], d[1], d[2], 0.22, 0.44, 0.11, hard, across[0], across[1], across[2]);")
s = sub1(s, "             (b0[2] + b1[2]) / 2 + d[2] * 0.22, d[0], d[1], d[2], 0.13, 0.34, 0.055, c,",
            "             (b0[2] + b1[2]) / 2 + d[2] * 0.22, d[0], d[1], d[2], 0.135, 0.56, 0.055, c,")
s = sub1(s, "        g.cn(b1[0], b1[1], b1[2], hk[0], hk[1], hk[2], 0.075, 0.46, IVORY);",
            "        g.cn(b1[0], b1[1], b1[2], hk[0], hk[1], hk[2], 0.085, 0.62, IVORY);")

# s_blade was reading as three rounded flames on a saucer. Thinner, taller,
# and the wound plate under it cut right back.
s = sub1(s, "        const lean = (i - 1) * 0.34, h = 1.5 - Math.abs(i - 1) * 0.42;",
            "        const lean = (i - 1) * 0.40, h = 2.1 - Math.abs(i - 1) * 0.62;")
s = sub1(s, "        g.sp(m[0], m[1], m[2], d[0], d[1], d[2], 0.30, h * 0.5, 0.075,",
            "        g.sp(m[0], m[1], m[2], d[0], d[1], d[2], 0.26, h * 0.5, 0.045,")
s = sub1(s, "        g.sp(m2[0], m2[1], m2[2], d[0], d[1], d[2], 0.15, h * 0.24, 0.055, colMul(c, 1.05),",
            "        g.sp(m2[0], m2[1], m2[2], d[0], d[1], d[2], 0.10, h * 0.26, 0.032, colMul(c, 1.05),")
s = sub1(s, "        g.sp(r0[0], r0[1], r0[2], 0, 1, 0, 0.30, 0.07, 0.24, base);",
            "        g.sp(r0[0], r0[1], r0[2], 0, 1, 0, 0.17, 0.05, 0.13, base);")

# the telson needs to read as a bulb, not as one more segment
s = sub1(s, "      g.sp(tb[0], tb[1], tb[2], d[0], d[1], d[2], 0.245, 0.30, 0.215, colMul(c, 1.06));",
            "      g.sp(tb[0], tb[1], tb[2], d[0], d[1], d[2], 0.30, 0.34, 0.27, colMul(c, 1.10));")

open(p, 'w', encoding='utf-8').write(s)
print('horror3: second shape pass ok')

# plan tweaks off the same sheet
s = open(p, encoding='utf-8').read()
s = sub1(s, "crook: 0.25, view: [0.86, 0.22, 0.46] }, // 46 sire",
            "crook: 0.25, view: [0.60, 0.50, 0.62] }, // 46 sire")
s = sub1(s, "ns: 8, head: 0.46, snx: 1.20, snr: 0.40, tail: 2.6, tailR: 0.30, ts: 12",
            "ns: 8, head: 0.46, snx: 1.20, snr: 0.40, tail: 2.2, tailR: 0.30, ts: 11")
# 47 was a fat horizontal tube: starve it and rear the front hard
s = sub1(s, "{ a: 0.70, b: 0.40, seg: 11, prof: 'tube',   arch: 0.54, droop: 0.20, wide: 0.10,",
            "{ a: 0.74, b: 0.30, seg: 11, prof: 'insect', arch: 0.86, droop: 0.22, wide: 0.10,")
s = sub1(s, "mouthAt('m_bloom', 1.35);", "mouthAt('m_bloom', 2.60);")
open(p, 'w', encoding='utf-8').write(s)
print('horror3: plan tweaks ok')

# =====================================================================
# 12. THE REAL PROBLEM WAS THE MESH, NOT THE TABLE
#
# Ten plans, ten sets of numbers, and the sheet came back with ten potatoes.
# That is the 2026-09-25 mistake again one level up: I found a level I could
# measure (the plan table) and worked there instead of at the level that was
# actually broken.
#
# The skin is a smooth union of round cones along one spine with a FIXED blend
# radius, kb = 0.32 * b. A smooth minimum at that radius melts every joint in
# the chain, so whatever a, b, hump and waist say, the output is one lozenge.
# None of the layering rules can be said in that mesh at all: hard shell over
# soft core, plates over exposed muscle, starved concavity, sectioned body
# segments -- there is no parameter for any of them, so the best a plan could
# do was bolt small parts onto a smooth blob.
#
# Three additions, all at the mesh level, all defaulting to exactly what the
# old code did so no existing plan moves by a byte:
#
#   blend   multiplier on kb. At 1.0 nothing changes. At 0.1 the chain stops
#           melting and the body is visibly sectioned, with a hard crease at
#           every joint -- which is what an arthropod or a starved thing is.
#   ribs    modulates the girth PER SEGMENT instead of along one smooth curve,
#           so the flank is ridged. Concave where the eye predicts convex is
#           the per-region error signal that reads as starvation (rule P4);
#           one global "it is thin" does not.
#   keel    a real row of balls above the spine. A back can be a blade or a
#           plated ridge instead of the top of a curve, and because it is
#           geometry rather than a decal it survives the silhouette test.
# =====================================================================
s = open(p, encoding='utf-8').read()

# ---- ribs: a per-segment notch on top of the profile curve
s = sub1(s, """    for (let i = 0; i < P.seg; i++) {
      const u = i / (P.seg - 1);
      balls.push({ x: -a + 2 * a * u, y: spineY(u), z: 0, r: b * girth(u), g: 'body' });
    }""",
"""    // ribs: a notch on the SEGMENT index rather than on u, so the ridges land
    // on the joints instead of drifting between them. ribs 0 is the old curve.
    const rib = P.ribs || 0;
    for (let i = 0; i < P.seg; i++) {
      const u = i / (P.seg - 1);
      const ridge = rib > 0 ? 1 - rib * 0.5 * (1 - Math.cos(i * Math.PI)) : 1;
      balls.push({ x: -a + 2 * a * u, y: spineY(u), z: 0, r: b * girth(u) * ridge, g: 'body' });
    }""")

# ---- keel: a dorsal row. Fixed count so part anchors keep their ball index.
s = sub1(s, "    const NK = P.neck * Nm;",
"""    // ---- dorsal keel ------------------------------------------------------
    // Five balls riding above the spine. A plan with keel 0 emits them hidden
    // and at zero radius, so every existing plan keeps its exact ball list and
    // every saved design keeps its anchors.
    const keel = P.keel || 0;
    for (let ki = 0; ki < 5; ki++) {
      const u = 0.18 + ki * 0.16;
      const pr = girth(u);
      const r = keel > 0 ? b * pr * 0.34 * (0.7 + 0.6 * Math.sin(Math.PI * ((u - 0.18) / 0.64))) : 0.0001;
      balls.push({ x: -a + 2 * a * u, y: spineY(u) + b * pr * keel, z: 0, r, g: 'body', hide: keel <= 0 });
    }
    const NK = P.neck * Nm;""")

# the keel balls have to be welded to the spine, and at the plan's own blend
s = sub1(s, "    for (let i = P.seg; i < P.seg + 6; i++) if (live(i)) { sph(i, body, kb * 3.0); cone(i, nearestSpine(B[i].x, B[i].y, B[i].z), body, kb * 3.0); }",
"""    for (let i = P.seg; i < P.seg + 6; i++) if (live(i)) { sph(i, body, kb * 3.0); cone(i, nearestSpine(B[i].x, B[i].y, B[i].z), body, kb * 3.0); }
    // keel: welded hard to the spine whatever the body blend, so it reads as a
    // ridge of bone standing out of the back rather than as a swelling in it
    for (let i = P.seg + 6; i < P.seg + 11; i++) if (live(i)) { sph(i, body, kb * 0.30); cone(i, nearestSpine(B[i].x, B[i].y, B[i].z), body, kb * 0.30); }""")

# every index after the spine+lateral block shifts by the five keel balls
s = sub1(s, "    const chain = [];\n    for (let i = P.seg + 6; i < sk.headIdx; i++) if (live(i)) chain.push(i);",
            "    const chain = [];\n    for (let i = P.seg + 11; i < sk.headIdx; i++) if (live(i)) chain.push(i);")

# ---- blend: the one number that decides melted or sectioned
s = sub1(s, "    const kb = 0.26 * sk.b;",
"""    // A smooth minimum at 0.26 b melts every joint in the chain, which is why
    // every plan came out as one lozenge. Low blend leaves the creases in.
    const kb = 0.26 * sk.b * (P.blend == null ? 1 : P.blend);""")

open(p, 'w', encoding='utf-8').write(s)
print('horror3: blend, ribs and a dorsal keel ok')

# =====================================================================
# 13. A LIMB IS NOT A PIPE
#
# "Rotate the cross-section along the shaft rather than only tapering it --
# wide-flat at the joint, narrow-flat at mid-shaft -- so turning the creature
# reveals a different profile. A constant circular sweep is what makes a limb
# read as pipe." (rule J7)
#
# Every shaft in the game was a round cone, so every leg was a pipe with two
# knuckles on it. Each bone is three stacked slabs now, and the flat face turns
# roughly sixty degrees from one to the next. The WIDEST half-axis of every
# slab is exactly the round radius it replaces, so the drawn envelope does not
# grow and test_nomerge_steps measures the same clearance it did before.
# =====================================================================
s = open(p, encoding='utf-8').read()
s = sub1(s, """  pushT(a[0], a[1], a[2], b[0], b[1], b[2], r0, col, r1);
  // knee: a cap, squashed along the bone so it reads as a knee and not a ball""",
"""  chiselShaft(a, b, r0, r1, col);
  // knee: a cap, squashed along the bone so it reads as a knee and not a ball""")
s = sub1(s, """  pushT(b[0], b[1], b[2], c[0], c[1], c[2], r1, col, r2);
  pushSX(c[0], c[1], c[2], bcd[0], bcd[1], bcd[2], 0, 0, 0,""",
"""  chiselShaft(b, c, r1, r2, col);
  pushSX(c[0], c[1], c[2], bcd[0], bcd[1], bcd[2], 0, 0, 0,""")
s = sub1(s, "function drawLimbTube(a, b, c, th, R, col, fine) {",
r"""// One bone, built as three slabs with the flat face rotating along its length.
// The half-axis across the flat is the full shaft radius and the one through it
// is 0.58 of that, so the limb is chiselled without ever drawing wider than the
// round cone it replaces.
function chiselShaft(p0, p1, ra, rb, col) {
  const d = v3.sub(p1, p0), L = v3.len(d);
  if (L < 1e-6) { return; }
  const ax = v3.mul(d, 1 / L);
  // a stable perpendicular: whichever world axis the bone is least aligned to
  const up = Math.abs(ax[1]) > 0.9 ? [1, 0, 0] : [0, 1, 0];
  const e0 = v3.norm(v3.cross(ax, up)), e1 = v3.cross(ax, e0);
  const N = 3;
  for (let k = 0; k < N; k++) {
    const u0 = k / N, u1 = (k + 1) / N, um = (u0 + u1) / 2;
    const r = ra + (rb - ra) * um;
    const m = v3.lerp(p0, p1, um);
    const ang = um * 1.9;                       // ~109 deg of twist end to end
    const ca = Math.cos(ang), sa = Math.sin(ang);
    const across = [e0[0] * ca + e1[0] * sa, e0[1] * ca + e1[1] * sa, e0[2] * ca + e1[2] * sa];
    pushSX(m[0], m[1], m[2], ax[0], ax[1], ax[2], across[0], across[1], across[2],
           r, L / N * 0.62, r * 0.58, k % 2 ? colMul(col, 0.95) : col);
  }
}
function drawLimbTube(a, b, c, th, R, col, fine) {""")
open(p, 'w', encoding='utf-8').write(s)
print('horror3: chiselled limb planes ok')

# ---------------------------------------------------------------- 14. per-plan mesh character
s = open(p, encoding='utf-8').read()
MESH = {
  38: "blend: 0.45, ribs: 0.20, keel: 0.38",   # armoured bulldozer, brow ridge over the shoulders
  39: "blend: 0.22, ribs: 0.48, keel: 0.00",   # starved and sectioned; nothing on the back to add drag
  40: "blend: 0.28, ribs: 0.32, keel: 0.62",   # the yoke, with bone standing out of it
  41: "blend: 0.80, ribs: 0.08, keel: 0.00",   # the sac stays SMOOTH: that is the contrast with the legs
  42: "blend: 0.12, ribs: 0.58, keel: 0.22",   # hard, sectioned, arthropod
  43: "blend: 0.20, ribs: 0.26, keel: 0.90",   # the lid: one ridge running the length of the shell
  44: "blend: 0.08, ribs: 0.66, keel: 0.18",   # every segment separate. This is the whole animal.
  45: "blend: 0.18, ribs: 0.52, keel: 0.34",
  46: "blend: 0.52, ribs: 0.24, keel: 0.78",   # a ridge down the back, muscle everywhere else
  47: "blend: 0.22, ribs: 0.60, keel: 0.66",   # a blade for a spine and nothing to spare
}
for pi, extra in MESH.items():
    tag = "}, // %d " % pi
    idx = s.index(tag)
    s = s[:idx] + ", " + extra + s[idx:]
open(p, 'w', encoding='utf-8').write(s)
print('horror3: per-plan mesh character ok')

# =====================================================================
# 15. WET
#
# Finn's explicit priority for this pass: "wet, slimy skin, not matte hide --
# specular that moves, a clear-coat layer over the base, a sense of fluid on
# the surface", and "a wet scale look, with scales that catch light as scales
# and follow the body's flow rather than being stretched across it".
#
# The skin shader had ONE Blinn lobe at a fixed power with a gloss multiplier.
# A single lobe is why everything read as painted plastic or as matte hide with
# nothing in between. What is here now, and where each piece comes from:
#
#   X1  wet = darker diffuse + smoother specular, and the darkening is
#       POROSITY driven, so chitin and bone stay bright while exposed dermis
#       goes dark. Without the porosity split, wet armour just goes muddy.
#   X2  porosity comes off gloss, so no new texture and no new vertex data:
#         porosity = saturate(-2.5 * gloss + 1.25)
#   X3  fluid POOLS in cavities, and pooling is a normal-flattening operation
#       rather than a texture: as fluid accumulates the surface normal is
#       blended back toward the geometric normal, so mucus in the creases
#       between plates goes mirror-flat while the ridges keep their relief.
#   X4  the slime is a CLEAR COAT at a fixed f0 of 0.04, composited as
#       (diffuse + spec) * (1 - Fc) + coat, with the base f0 re-derived for the
#       coat/base interface -- skip that and the flesh under the mucus is too
#       bright.
#   X5  DUAL NORMALS. The coat normal is the fluid sheet: large, smooth,
#       flowing. The base normal is pores and scales: small, static, high
#       frequency. This is the single biggest "it looks wet" win, because
#       without the split both are lit together and the surface reads flat.
#   X6  "the specular moves" is a flow-mapped normal on the COAT ONLY, sampled
#       twice at half-period offset and cross-faded so it never stretches
#       without bound. The flesh normal stays still, so the body stays solid
#       while the highlight crawls over it. That is the whole trick.
#   X7  TWO specular lobes, broad and tight. One lobe always reads as plastic.
#   X8  red travels about ten times further through flesh than blue, which is
#       why thin flesh glows red at the rim. The transmission term is weighted
#       to the published six-Gaussian profile's red tail.
#   X10 scales catch light INDIVIDUALLY with anisotropic roughness aligned to
#       the body flow, so each row's highlight stretches along the row.
#   X11 cavity drives specular occlusion, reduced at grazing angles, or the wet
#       highlight glows inside creases that should be dark.
# =====================================================================
s = open(p, encoding='utf-8').read()

# ---- 15a. the covering block also reports flow, anisotropy and wetness
s = sub1(s, "  var h = 0.0; var tone = 1.0; var amp = 0.0; var gloss = 1.0; var fuzz = 0.0;",
"""  var h = 0.0; var tone = 1.0; var amp = 0.0; var gloss = 1.0; var fuzz = 0.0;
  // flow: the direction the covering runs, in rest space. Scales, plates and
  // feathers all run head-to-tail around the body axis, so the flow is the
  // body's own axis -- which is exactly what stops them being stretched across
  // it. aniso stretches each row's highlight ALONG the row.
  var aniso = 0.0;
  var wet = 1.0;            // how much fluid this covering carries, 0..1
  var cavity = 1.0;         // 1 on a ridge, 0 deep in a crease""")

# scales: wet, strongly anisotropic, cavity from the shingle rim
s = sub1(s, """    tone = mix(0.78, 1.0, smoothstep(0.0, 0.25, sh.y)) * (0.95 + 0.1 * sh.z);
    amp = 0.12 / sf; gloss = 1.1;""",
"""    tone = mix(0.78, 1.0, smoothstep(0.0, 0.25, sh.y)) * (0.95 + 0.1 * sh.z);
    amp = 0.12 / sf; gloss = 1.1;
    // each scale is a hard little lens: anisotropic along the row, and the
    // seam between two scales is a cavity that holds fluid
    aniso = 0.62; wet = 1.0; cavity = smoothstep(0.0, 0.22, sh.y);""")
s = sub1(s, "    tone = mix(0.72, 1.08, sh.x) * (0.9 + 0.2 * sh.z) * (0.95 + 0.06 * barbs);\n    amp = 0.035; gloss = 0.55; fuzz = 0.25;",
            "    tone = mix(0.72, 1.08, sh.x) * (0.9 + 0.2 * sh.z) * (0.95 + 0.06 * barbs);\n"
            "    amp = 0.035; gloss = 0.55; fuzz = 0.25; aniso = 0.35; wet = 0.30; cavity = smoothstep(0.0, 0.3, sh.y);")
s = sub1(s, "    tone = 0.9 + 0.16 * h;\n    amp = 0.012; gloss = 0.25; fuzz = 0.55;",
            "    tone = 0.9 + 0.16 * h;\n    amp = 0.012; gloss = 0.25; fuzz = 0.55; aniso = 0.0; wet = 0.12; cavity = 1.0;")
# armour: hard, non-porous, and the seams between plates are where fluid sits
s = sub1(s, "    tone = mix(0.6, 1.0, smoothstep(0.0, 0.07, e)) * (0.9 + 0.2 * w.id);\n    amp = 0.1; gloss = 2.2;",
            "    tone = mix(0.6, 1.0, smoothstep(0.0, 0.07, e)) * (0.9 + 0.2 * w.id);\n"
            "    amp = 0.1; gloss = 2.2; aniso = 0.18; wet = 0.85; cavity = smoothstep(0.0, 0.055, e);")
s = sub1(s, "    h = fbm(p * 26.0) * 0.5;\n    amp = 0.012; gloss = 1.0;",
            "    h = fbm(p * 26.0) * 0.5;\n    amp = 0.012; gloss = 1.0; aniso = 0.0; wet = 1.0; cavity = 0.5 + h;")

open(p, 'w', encoding='utf-8').write(s)
print('horror3: covering reports flow, cavity and wetness ok')

# ---- 15b. the wet lighting model
s = open(p, encoding='utf-8').read()
OLD = """  let ao = pow(clamp(i.misc.y, 0.0, 1.0), 1.15) * mix(0.8, 1.0, h);
  col = col * i.misc.w;
  var lit = shade(col * (0.35 + 0.65 * ao), N, i.wpos);
  let L = normalize(g.lightDir.xyz);
  let V = normalize(g.camPos.xyz - i.wpos);
  let H = normalize(L + V);
  lit += vec3<f32>(1.0, 0.97, 0.9) * pow(max(dot(N, H), 0.0), 20.0 + 30.0 * gloss) * 0.1 * gloss * g.params.z * ao;
  let wrap = clamp(1.0 - abs(dot(N, L)), 0.0, 1.0);
  lit += col * vec3<f32>(0.22, 0.08, 0.05) * wrap * wrap * 0.3 * g.params.z;
  // fur and down catch light on the silhouette
  let rim = pow(1.0 - clamp(dot(normalize(i.nrm), V), 0.0, 1.0), 2.5);
  lit += col * rim * fuzz * (0.4 + 0.6 * g.params.z);
  return vec4<f32>(lit, 1.0);"""
NEW = r"""  let ao = pow(clamp(i.misc.y, 0.0, 1.0), 1.15) * mix(0.8, 1.0, h);
  let L = normalize(g.lightDir.xyz);
  let V = normalize(g.camPos.xyz - i.wpos);
  let Ngeo = normalize(i.nrm);

  // ---- how wet is this patch --------------------------------------------
  // Fluid runs down and collects in the creases, so accumulation is driven by
  // cavity and by how far the surface faces down. Fur sheds it; chitin holds a
  // film; exposed dermis soaks.
  let downface = clamp(0.5 - 0.5 * Ngeo.y, 0.0, 1.0);
  let pool = clamp((1.0 - cavity) * 0.75 + downface * 0.45, 0.0, 1.0);
  let wetLevel = clamp(wet * (0.55 + 0.45 * pool), 0.0, 1.0);
  // porosity straight off gloss: no extra map, no extra vertex data. Plate and
  // bone come out near zero and so do not darken; dermis comes out near one.
  let porosity = clamp(-2.5 * (gloss * 0.45) + 1.25, 0.0, 1.0);
  let darken = mix(1.0, mix(1.0, 0.24, porosity), wetLevel);
  col = col * darken * i.misc.w;

  // ---- the two normals ---------------------------------------------------
  // BASE: the covering. Pores, scales, plate seams. Static, high frequency,
  // and flattened back toward the geometric normal wherever fluid has pooled,
  // because a pool fills the relief in rather than covering it.
  let Nbase = normalize(mix(N, Ngeo, pool * wetLevel * 0.80));
  // COAT: the fluid sheet itself. Large, smooth, and MOVING. Two samples half
  // a period apart, cross-faded on a triangle wave, so the sheet advects
  // forever without ever stretching without bound.
  let t = g.params.x * 0.07;
  let ph0 = fract(t); let ph1 = fract(t + 0.5);
  let fl = vec3<f32>(0.0, -1.0, 0.0) * 0.9;       // fluid runs down the body
  let q0 = p * 3.1 + fl * ph0; let q1 = p * 3.1 + fl * ph1;
  let tw = abs(1.0 - 2.0 * fract(t));
  let sheetH = mix(fbm(q0), fbm(q1), tw);
  let sx = mix(fbm(q0 + vec3<f32>(0.14, 0.0, 0.0)), fbm(q1 + vec3<f32>(0.14, 0.0, 0.0)), tw) - sheetH;
  let sz = mix(fbm(q0 + vec3<f32>(0.0, 0.0, 0.14)), fbm(q1 + vec3<f32>(0.0, 0.0, 0.14)), tw) - sheetH;
  // the sheet perturbs the coat only, in the surface tangent frame
  var tang = normalize(cross(Ngeo, select(vec3<f32>(0.0, 1.0, 0.0), vec3<f32>(1.0, 0.0, 0.0), abs(Ngeo.y) > 0.9)));
  let bitan = cross(Ngeo, tang);
  let Ncoat = normalize(Ngeo + (tang * sx + bitan * sz) * 7.0 * wetLevel);

  var lit = shade(col * (0.35 + 0.65 * ao), Nbase, i.wpos);

  // ---- base specular: TWO lobes, stretched along the covering's flow ------
  // One lobe is what makes skin read as plastic. A broad soft lobe carries the
  // sheen and a tight one carries the glint, and the tight one is stretched
  // along the body axis so a row of scales catches the light AS a row.
  let Hb = normalize(L + V);
  let nh = max(dot(Nbase, Hb), 0.0);
  // the covering runs head to tail: flow is the body x axis, pushed into world
  let flowW = normalize(cross(Ngeo, cross(vec3<f32>(1.0, 0.0, 0.0), Ngeo)) + Ngeo * 1e-4);
  let th2 = dot(flowW, Hb);
  let stretch = 1.0 - aniso * 0.72 * th2 * th2;     // wider along the row
  let baseRough = mix(0.55, 0.14, wetLevel * clamp(gloss, 0.0, 2.0) * 0.5);
  let pw = 2.0 / max(baseRough * baseRough * baseRough, 1e-3);
  let specOcc = mix(cavity, 1.0, 0.35 + 0.45 * pow(1.0 - clamp(dot(Ngeo, V), 0.0, 1.0), 2.0));
  let broad = pow(nh, max(pw * 0.10, 4.0)) * 0.055;
  let tight = pow(nh, max(pw * stretch, 8.0)) * 0.22 * (0.4 + 0.6 * wetLevel);
  lit += vec3<f32>(1.0, 0.97, 0.90) * (broad + tight) * gloss * g.params.z * ao * specOcc;

  // ---- the clear coat ----------------------------------------------------
  // Air/coat IOR 1.5 gives a fixed normal-incidence reflectance of 0.04. The
  // coat takes its cut of the light first and the layer underneath keeps the
  // rest, which is why wet flesh goes dark AND shiny at the same time instead
  // of just brighter.
  let Hc = normalize(L + V);
  let vh = clamp(dot(V, Hc), 0.0, 1.0);
  let Fc = (0.04 + 0.96 * pow(1.0 - vh, 5.0)) * wetLevel;
  let cr = mix(0.32, 0.055, wetLevel);
  let cpw = 2.0 / max(cr * cr * cr, 1e-3);
  let coatSpec = pow(max(dot(Ncoat, Hc), 0.0), cpw) * Fc * 1.35;
  // and the sky the film reflects, which is what sells a film over a sunlit
  // one: a wet back is bright even with the sun behind it
  let sky = pow(1.0 - clamp(dot(Ncoat, V), 0.0, 1.0), 4.0) * Fc * 0.55;
  lit = lit * (1.0 - Fc * 0.55) + (vec3<f32>(1.0, 0.99, 0.96) * coatSpec + vec3<f32>(0.55, 0.66, 0.80) * sky) * g.params.z * specOcc;

  // ---- transmission ------------------------------------------------------
  // Red travels roughly ten times further through flesh than blue, so thin
  // parts glow red at the edge. Weighted to the published six-Gaussian tail.
  let wrap = clamp(1.0 - abs(dot(Nbase, L)), 0.0, 1.0);
  let back = pow(clamp(dot(V, -L), 0.0, 1.0), 3.0);
  lit += col * vec3<f32>(0.62, 0.17, 0.11) * (wrap * wrap * 0.34 + back * 0.30) * g.params.z;

  // fur and down catch light on the silhouette
  let rim = pow(1.0 - clamp(dot(Ngeo, V), 0.0, 1.0), 2.5);
  lit += col * rim * fuzz * (0.4 + 0.6 * g.params.z);
  return vec4<f32>(lit, 1.0);"""
s = sub1(s, OLD, NEW)
open(p, 'w', encoding='utf-8').write(s)
print('horror3: wet skin ok')

# ---- 15c. scales you can actually see
# On the armour plates the wet pass reads immediately, because a plate is big
# and its seams are deep. On scales it did almost nothing: the shingles were
# ten to fifteen rows over the whole body with a relief of 0.12/sf, which is
# under a pixel at any sane distance, so a scaled animal stayed matte hide.
# Coarser rows, real relief, and a hard rim on every scale so each one catches
# the light as a separate piece of the animal.
s = open(p, encoding='utf-8').read()
s = sub1(s, "    let sf = mix(10.0, 15.0, belly);\n    let sh = shingle(p.x * sf, arc * sf, 0.74);",
"""    let sf = mix(6.5, 10.0, belly);
    let sh = shingle(p.x * sf, arc * sf, 0.80);""")
s = sub1(s, """    tone = mix(0.78, 1.0, smoothstep(0.0, 0.25, sh.y)) * (0.95 + 0.1 * sh.z);
    amp = 0.12 / sf; gloss = 1.1;""",
"""    // dark in the seam, bright on the free rim, and each scale a slightly
    // different shade so the rows do not read as a printed pattern
    tone = mix(0.62, 1.06, smoothstep(0.0, 0.30, sh.y)) * (0.90 + 0.20 * sh.z);
    amp = 0.46 / sf; gloss = 1.45;""")
open(p, 'w', encoding='utf-8').write(s)
print('horror3: scales you can see ok')

# ---- 15d. the hides were poster paint
# Saturated yellow and orange detail colours on a black base is a wasp, not a
# thing in a wet forest. Everything pulled toward dirty, desaturated flesh and
# chitin, with the one saturated accent kept small.
s = open(p, encoding='utf-8').read()
HIDES = {
 38: "{ base: [0.30, 0.22, 0.21], coat: [0.50, 0.41, 0.38], detail: [0.47, 0.20, 0.21], pat: 3 },  // 38 bloom",
 39: "{ base: [0.19, 0.18, 0.19], coat: [0.36, 0.35, 0.36], detail: [0.44, 0.38, 0.35], pat: 0 },  // 39 kite",
 40: "{ base: [0.24, 0.23, 0.21], coat: [0.44, 0.43, 0.40], detail: [0.58, 0.56, 0.50], pat: 0 },  // 40 gibbet",
 41: "{ base: [0.32, 0.27, 0.23], coat: [0.52, 0.47, 0.40], detail: [0.42, 0.26, 0.26], pat: 2 },  // 41 cradle",
 42: "{ base: [0.17, 0.17, 0.16], coat: [0.33, 0.34, 0.31], detail: [0.40, 0.34, 0.20], pat: 1 },  // 42 thresher",
 43: "{ base: [0.21, 0.21, 0.22], coat: [0.38, 0.38, 0.39], detail: [0.34, 0.37, 0.33], pat: 1 },  // 43 pall",
 44: "{ base: [0.26, 0.21, 0.18], coat: [0.45, 0.39, 0.33], detail: [0.44, 0.28, 0.20], pat: 1 },  // 44 husk",
 45: "{ base: [0.20, 0.19, 0.16], coat: [0.36, 0.35, 0.30], detail: [0.34, 0.39, 0.27], pat: 2 },  // 45 wrack",
 46: "{ base: [0.18, 0.20, 0.18], coat: [0.34, 0.37, 0.34], detail: [0.48, 0.25, 0.18], pat: 1 },  // 46 sire",
 47: "{ base: [0.23, 0.22, 0.22], coat: [0.41, 0.40, 0.39], detail: [0.56, 0.54, 0.50], pat: 0 },  // 47 null",
}
import re as _re
for pi, row in HIDES.items():
    pat = _re.compile(r"\{ base: \[[^\]]*\], coat: \[[^\]]*\], detail: \[[^\]]*\], pat: \d \},  // %d \w+" % pi)
    m = pat.search(s)
    assert m, pi
    s = s[:m.start()] + row + s[m.end():]
open(p, 'w', encoding='utf-8').write(s)
print('horror3: hides pulled out of poster paint ok')


# ---- crook must never close a gap
# The first version jittered lateral reach both ways, which let a leg wander in
# toward its mirror partner: the merge guard still passed, but the tightest
# pair in the whole offered set fell from 0.43 shaft radii to 0.04. The
# separation pass should not be spending its budget undoing my own jitter.
# Lateral reach now only ever widens; the shortening goes into fore-and-aft,
# where it cannot bring a pair together.
s = open(p, encoding='utf-8').read()
s = sub1(s, "        lb.f[2] *= 1 + crookRnd(i, 2) * 0.34 * amt;",
            "        lb.f[2] *= 1 + Math.abs(crookRnd(i, 2)) * 0.34 * amt;")
open(p, 'w', encoding='utf-8').write(s)
print('horror3: crook only ever widens ok')

# Adjacent rows in a leg row were the pair that kept closing: a fore-and-aft
# jitter bigger than the gap between two rows walks them into each other, and
# the separation pass then spends its whole budget undoing my jitter (plan 41
# fell to 0.04 shaft radii, and forcing the sign made plan 43 interpenetrate).
# The jitter is capped at a third of the distance to the nearest leg on the
# same side, measured BEFORE anything moves. Two legs a long way apart still
# get the full crookedness; two legs already close barely move.
s = open(p, encoding='utf-8').read()
s = sub1(s, """      for (let i = 0; i < d.limbs.length; i++) {
        const lb = d.limbs[i];""",
"""      const orig = d.limbs.map((l) => l.f.slice());
      for (let i = 0; i < d.limbs.length; i++) {
        const lb = d.limbs[i];
        // nearest neighbour ON THE SAME SIDE, in the rest pose
        let gap = Infinity;
        for (let j = 0; j < d.limbs.length; j++) {
          if (j === i || Math.sign(orig[j][2]) !== Math.sign(orig[i][2])) continue;
          gap = Math.min(gap, Math.abs(orig[j][0] - orig[i][0]));
        }
        const room = isFinite(gap) ? gap * 0.33 : Infinity;""")
s = sub1(s, "        lb.f[0] += crookRnd(i, 1) * 0.30 * amt * legLen;",
            "        lb.f[0] += Math.max(-room, Math.min(room, crookRnd(i, 1) * 0.30 * amt * legLen));")
open(p, 'w', encoding='utf-8').write(s)
print('horror3: the crook cannot walk two legs together ok')

# The two many-legged plans were still the tightest pair in the set at 0.08
# shaft radii. Eight crooked legs on a body only two units long is not enough
# room for full crookedness, so they get less of it and a wider row pitch.
s = open(p, encoding='utf-8').read()
s = sub1(s, "        const room = isFinite(gap) ? gap * 0.33 : Infinity;",
            "        const room = isFinite(gap) ? gap * 0.25 : Infinity;")
s = sub1(s, "ts: 5, stand: 2.00, hump: 0.18, crook: 0.6 ,", "ts: 5, stand: 2.00, hump: 0.18, crook: 0.38 ,")
s = sub1(s, "ts: 4, stand: 1.30, hump: 0.30, crook: 1.0 ,", "ts: 4, stand: 1.30, hump: 0.30, crook: 0.55 ,")
s = sub1(s, "legRow('l_thin', [0.44, 0.06, -0.38], { out: 0.78, up: 0.25, rake: 1.25, reach: 2.25, knee: 1.15, th: 0.52, tip: 't_talon' });",
            "legRow('l_thin', [0.58, 0.04, -0.52], { out: 0.78, up: 0.25, rake: 1.25, reach: 2.25, knee: 1.15, th: 0.52, tip: 't_talon' });")
s = sub1(s, "legRow('l_thin', [0.62, 0.22, -0.20, -0.58], { out: 0.94, up: 0.05, rake: 1.05, reach: 2.05, knee: 0.95, th: 0.66, tip: 't_talon' });",
            "legRow('l_thin', [0.74, 0.26, -0.24, -0.72], { out: 0.98, up: 0.05, rake: 1.05, reach: 2.15, knee: 0.95, th: 0.66, tip: 't_talon' });")
open(p, 'w', encoding='utf-8').write(s)
print('horror3: room for eight crooked legs ok')

# The sire is the one plan whose whole point is the length of its neck and
# tail, and both vanish in a three-quarter view. It is looked at nearly side on:
# the wing loses some area, but a dragon that does not read as a dragon has
# already failed, and the wing has a whole tile of its own in the palette.
s = open(p, encoding='utf-8').read()
s = sub1(s, "view: [0.60, 0.50, 0.62] , blend", "view: [0.26, 0.30, 0.92] , blend")
open(p, 'w', encoding='utf-8').write(s)
print('horror3: the sire is looked at from the side ok')
