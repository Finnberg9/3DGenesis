# =====================================================================
# THE UNIVERSAL FIXES: JOINTS, FLESH AND EYES
#
# Three changes that apply to every creature at once, which is why they are
# worth more than any amount of per-plan tuning.
#
# 1. KNOBBY JOINTS, STARVED LIMBS. Every limb in the game is drawn by one
#    function: a sphere at the hip, a tapered tube, a sphere at the knee,
#    another tube, a sphere at the foot. The joints were barely larger than
#    the shaft, so a leg read as a smooth plastic pipe. The joints are now
#    much bigger than the bone between them and the shafts are roughly half
#    the thickness -- skeletal, with the flesh gone from between the knuckles.
#    The knee is an ellipsoid squashed along the limb rather than a ball, so
#    it reads as a knee CAP, and a small spur rides on it.
#
# 2. EYES. Almost everything had large round side-facing eyes, which is what
#    prey animals have -- rabbits, birds -- and is most of why these read as
#    friendly. The set is now blind, hooded or beaded: a cluster of small
#    irregular beads, a slit, or nothing at all.
#
# 3. BONE THROUGH THE BACK. The heavy classes had a smooth curved spine.
#    Their vertebrae now break the skin as a row of spurs that grows over the
#    hump and dies away toward the hips, so the hunch has an edge on it.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, ('ANCHOR %d/%d' % (n, cnt), a[:110]); return s.replace(a, b)

p = 'g3.html'; s = open(p, encoding='utf-8').read()

# ---------------------------------------------------------------- 1. the limbs
s = sub1(s, """function drawLimbTube(a, b, c, th, R, col, fine) {
  const r0 = 0.17 * th * R, r1 = 0.122 * th * R, r2 = 0.092 * th * R;
  const sh = r0 * 1.2;
  pushSX(a[0], a[1], a[2], 0, 1, 0, 0, 0, 0, sh, sh, sh, col);
  pushT(a[0], a[1], a[2], b[0], b[1], b[2], r0, col, r1);
  pushSX(b[0], b[1], b[2], 0, 1, 0, 0, 0, 0, r1 * 1.08, r1 * 1.08, r1 * 1.08, colMul(col, 0.98));
  pushT(b[0], b[1], b[2], c[0], c[1], c[2], r1, col, r2);
  pushSX(c[0], c[1], c[2], 0, 1, 0, 0, 0, 0, r2 * 1.05, r2 * 1.05, r2 * 1.05, col);""",
"""// A limb is knuckles with bone between them, not a pipe. The joints are much
// larger than the shaft and the shaft is thin, which is what makes a leg look
// starved rather than moulded.
const LIMB_SHAFT = 0.55;     // how much of the old thickness the bone keeps
const LIMB_HIP = 1.55, LIMB_KNEE = 1.70, LIMB_ANKLE = 1.35;   // joint swell
function drawLimbTube(a, b, c, th, R, col, fine) {
  const t0 = 0.17 * th * R, t1 = 0.122 * th * R, t2 = 0.092 * th * R;
  const r0 = t0 * LIMB_SHAFT, r1 = t1 * LIMB_SHAFT, r2 = t2 * LIMB_SHAFT;
  const jc = colMul(col, 0.93);
  // hip: a knuckle, swollen across the limb
  const ab = v3.sub(b, a), abL = v3.len(ab) || 1, abd = v3.mul(ab, 1 / abL);
  const bc = v3.sub(c, b), bcL = v3.len(bc) || 1, bcd = v3.mul(bc, 1 / bcL);
  pushSX(a[0], a[1], a[2], abd[0], abd[1], abd[2], 0, 0, 0,
         t0 * LIMB_HIP, t0 * LIMB_HIP * 0.78, t0 * LIMB_HIP, jc);
  pushT(a[0], a[1], a[2], b[0], b[1], b[2], r0, col, r1);
  // knee: a cap, squashed along the bone so it reads as a knee and not a ball
  pushSX(b[0], b[1], b[2], abd[0], abd[1], abd[2], 0, 0, 0,
         t1 * LIMB_KNEE, t1 * LIMB_KNEE * 0.66, t1 * LIMB_KNEE, jc);
  // and a spur riding on the outside of it
  if (fine !== 0) {
    const sp = v3.norm(v3.sub(abd, bcd));
    pushC(b[0] + sp[0] * t1 * 0.6, b[1] + sp[1] * t1 * 0.6, b[2] + sp[2] * t1 * 0.6,
          sp[0], sp[1], sp[2], t1 * 0.5, t1 * 1.5, colMul(col, 1.12));
  }
  pushT(b[0], b[1], b[2], c[0], c[1], c[2], r1, col, r2);
  pushSX(c[0], c[1], c[2], bcd[0], bcd[1], bcd[2], 0, 0, 0,
         t2 * LIMB_ANKLE, t2 * LIMB_ANKLE * 0.8, t2 * LIMB_ANKLE, jc);""")
s = sub1(s, """    mus(a, b, 0.36, r0, 1.1);
    mus(b, c, 0.3, r1, 1.08);""",
"""    // the little flesh there is sits high on the bone, near the joint
    mus(a, b, 0.26, r0, 1.25);
    mus(b, c, 0.22, r1, 1.20);""")

open(p, 'w', encoding='utf-8').write(s)
print('creepy: knobby joints and starved limbs ok')

# ---------------------------------------------------------------- 2. the eyes
# Large round side-facing eyes are what PREY has. Blind, hooded or beaded.
s = open(p, encoding='utf-8').read()
EYES = [
    # (plan, old call, new call)
    (30, "eyeAt('e_round', 0.70, 0.55, 0.42, 0.52);", "eyeAt('e_cluster', 0.34, 0.62, 0.44, 0.40); eyeAt('e_cluster', 0.24, 0.42, 0.62, 0.52);"),
    (31, "eyeAt('e_cluster', 0.55, 0.85, 0.20, 0.34); eyeAt('e_slit', 0.40, 0.62, 0.50, 0.46);", "eyeAt('e_slit', 0.26, 0.50, 0.66, 0.44);"),
    (32, "eyeAt('e_round', 0.55, 0.45, 0.30, 0.50);", "eyeAt('e_cluster', 0.30, 0.34, 0.52, 0.48);"),
    (33, "eyeAt('e_bug', 0.85, 0.35, 0.45, 0.60);", "eyeAt('e_cluster', 0.36, 0.34, 0.48, 0.58);"),
    (22, "eyeAt('e_cluster', 0.7, 0.70, 0.30, 0.30); eyeAt('e_round', 0.45, 0.50, 0.55, 0.50);", "eyeAt('e_cluster', 0.34, 0.70, 0.30, 0.30); eyeAt('e_cluster', 0.24, 0.46, 0.58, 0.50);"),
    (23, "eyeAt('e_stalk', 0.8, 0.60, 0.35, 0.45);", "eyeAt('e_cluster', 0.30, 0.52, 0.40, 0.48);"),
    (26, "eyeAt('e_stalk', 0.7, 0.85, 0.20, 0.35);", "eyeAt('e_cluster', 0.28, 0.80, 0.24, 0.36);"),
    (25, "eyeAt('e_bug', 1.0, 0.45, 0.45, 0.60);", "eyeAt('e_cluster', 0.40, 0.44, 0.50, 0.60);"),
    (24, "eyeAt('e_slit', 0.8, 0.50, 0.30, 0.55);", "eyeAt('e_cluster', 0.30, 0.56, 0.40, 0.42); eyeAt('e_cluster', 0.20, 0.34, 0.60, 0.54);"),
    (27, "eyeAt('e_round', 0.75, 0.40, 0.35, 0.58);", "eyeAt('e_cluster', 0.30, 0.40, 0.44, 0.56);"),
    (34, "eyeAt('e_big', 1.05, 0.45, 0.35, 0.58);", "eyeAt('e_slit', 0.40, 0.46, 0.38, 0.58);"),
    (35, "eyeAt('e_cluster', 1.0, 0.40, 0.42, 0.58);", "eyeAt('e_cluster', 0.46, 0.40, 0.44, 0.58);"),
    (36, "eyeAt('e_slit', 0.95, 0.50, 0.32, 0.58);", "eyeAt('e_slit', 0.42, 0.52, 0.34, 0.58);"),
    (37, "eyeAt('e_big', 0.85, 0.42, 0.34, 0.55);", "eyeAt('e_slit', 0.34, 0.44, 0.36, 0.56);"),
]
for pi, old, new in EYES:
    assert s.count(old) >= 1, 'eye anchor %d: %s' % (pi, old[:50])
    s = s.replace(old, new, 1)

# ---------------------------------------------------------------- 3. bone through the back
# A row of spurs that grows over the hump and dies away toward the hips, so
# the hunch has an edge on it instead of being a smooth curve.
s = sub1(s, "    const hr = head.r;\n    const eyeAt =",
"""    // Vertebrae breaking the skin. Tallest over the shoulder, dying away
    // toward the hips, so the spurs follow the hump rather than sitting in a
    // straight line along a level back.
    const spurs = (n, peak, big, id) => {
      for (let i = 0; i < n; i++) {
        const u = -0.55 + (i / Math.max(1, n - 1)) * 1.25;
        const k = Math.exp(-Math.pow((u - peak) / 0.55, 2));
        if (k < 0.12) continue;
        put(id || 's_spike', a * u, b * 1.02, b * 0.05, -0.12, 1, 0.08, big * (0.35 + 0.85 * k), false);
      }
    };
    const hr = head.r;
    const eyeAt =""")
for pi, call in [(30, "spurs(7, 0.30, 1.25);"), (32, "spurs(7, 0.26, 1.35);"), (27, "spurs(6, 0.24, 1.15);"), (26, "spurs(5, 0.10, 0.85);")]:
    import re
    m = re.search(r"(      case %d: [^\n]*\n(?:        [^\n]*\n)*?)(        break;)" % pi, s)
    assert m, 'no case body for plan %d' % pi
    s = s[:m.end(1)] + '        ' + call + '\n' + s[m.end(1):]

open(p, 'w', encoding='utf-8').write(s)
print('creepy: blind, beaded and spurred ok')

# ---------------------------------------------------------------- 4. the limb the GAME draws
# There are two limb renderers. drawLimbTube is the instanced one; the fused
# creature mesh builds its own, and that one had NO KNEE JOINT AT ALL -- a
# root ball and two smooth cones. That is why in-game limbs read as plastic
# pipes however much the other path was sharpened.
s = open(p, encoding='utf-8').read()
s = sub1(s, """    out.push({ t: 's', ax: root[0], ay: root[1], az: root[2], ra: r0 * 1.12, k: 0.24 * th, bone: up, col });
    out.push({ t: 'c', ax: root[0], ay: root[1], az: root[2], bx: knee[0], by: knee[1], bz: knee[2], ra: r0, rb: r1, k: 0.06, bone: up, col });
    out.push({ t: 'c', ax: knee[0], ay: knee[1], az: knee[2], bx: foot[0], by: foot[1], bz: foot[2], ra: r1 * 1.02, rb: r2, k: 0.06, bone: lo, col });""",
"""    // Knuckles with bone between them. The shafts are thin, the joints swell
    // well past them, and the blend at each joint is tight so it creases
    // rather than melting into the bone.
    // Swell enough to read as a knuckle, not so much that a thick leg becomes a
    // string of beads -- which is exactly what 1.85/2.05 did to the heavy classes.
    const SH = 0.66;
    out.push({ t: 's', ax: root[0], ay: root[1], az: root[2], ra: r0 * 1.38, k: 0.09 * th, bone: up, col });
    out.push({ t: 'c', ax: root[0], ay: root[1], az: root[2], bx: knee[0], by: knee[1], bz: knee[2], ra: r0 * SH, rb: r1 * SH, k: 0.03, bone: up, col });
    // the knee itself, which did not exist before
    out.push({ t: 's', ax: knee[0], ay: knee[1], az: knee[2], ra: r1 * 1.52, k: 0.05 * th, bone: up, col });
    out.push({ t: 'c', ax: knee[0], ay: knee[1], az: knee[2], bx: foot[0], by: foot[1], bz: foot[2], ra: r1 * SH, rb: r2 * SH, k: 0.03, bone: lo, col });
    out.push({ t: 's', ax: foot[0], ay: foot[1], az: foot[2], ra: r2 * 1.35, k: 0.05 * th, bone: lo, col });""")
# and the starved flesh between them sits high on the bone
s = sub1(s, "      const m = v3.lerp(root, knee, 0.36), ey = v3.norm(ud);",
            "      const m = v3.lerp(root, knee, 0.26), ey = v3.norm(ud);")
s = sub1(s, "      out.push({ t: 'e', ax: m[0], ay: m[1], az: m[2], ex, ey, ez: v3.cross(ex, ey), rx: r0 * 1.12 * bulk, ry: L1 * 0.32 * (bulk > 1 ? 1.2 : 1), rz: r0 * 1.08 * bulk, k: 0.08, bone: up, col });",
            "      out.push({ t: 'e', ax: m[0], ay: m[1], az: m[2], ex, ey, ez: v3.cross(ex, ey), rx: r0 * 0.92 * bulk, ry: L1 * 0.22 * (bulk > 1 ? 1.2 : 1), rz: r0 * 0.88 * bulk, k: 0.04, bone: up, col });")

# ---------------------------------------------------------------- 5. the body stops melting
# The spine capsules were blended with k = 0.32 of the body radius, which is a
# very molten union: every join rounded away into the next and the result was
# a single smooth mass. Halved, so segments meet with a visible crease and an
# armoured body reads as sections rather than as a bean.
s = sub1(s, "    const kb = 0.32 * sk.b;", "    const kb = 0.20 * sk.b;")

open(p, 'w', encoding='utf-8').write(s)
print('creepy: the game-path limbs and a body that creases ok')
