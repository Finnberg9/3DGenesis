# =====================================================================
# V WAS TWO KEYS
#
# `if (k === 'v')` appears twice in the same keydown handler. Both ran. One
# detached the camera; the other searched the body at your feet. Pressing V
# over a corpse threw you into the spectator camera AND opened the loot
# picker, and pressing it anywhere else flipped the camera when you were
# trying to search.
#
# Searching is a pick-up, and E is already the pick-up key: the cage pile,
# then a mushroom. The body joins that list rather than getting a key of its
# own, so there is ONE key for "take whatever is in front of me" instead of
# three. V goes back to being the camera and nothing else.
#
# Priority when several are in reach: the cage pile (it is a thirty-second
# window and you cannot come back to it), then a body (it is finite), then a
# mushroom (it regrows).
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, ('ANCHOR %d/%d' % (n, cnt), a[:110]); return s.replace(a, b)

p = 'g3.html'; s = open(p, encoding='utf-8').read()

# ---------------------------------------------------------------- one interact key
s = sub1(s, """    if (k === 'e') {
      let r = brTakePile();
      if (!r.ok) r = shroomTake();
      if (!r.ok && r.why === 'none') toast('Nothing to pick up here.', 900);
    }""",
"""    if (k === 'e') tryTake();""")
s = sub1(s, "    if (k === 'v') tryInspect();\n", "")
s = sub1(s, "function tryInspect() {",
"""// E takes whatever is in front of you. One key, one meaning, and an order of
// preference that puts the thing you cannot come back for first.
function tryTake() {
  let r = brTakePile();                     // your cage pile: thirty seconds, once
  if (r.ok) return r;
  if (carcEatTarget && carcNearest(player.c ? player.c.x : 0, player.c ? player.c.y : 0,
      player.c ? interactRange(player.c.ph) * 1.45 : 0)) { tryInspect(); return { ok: true, why: 'body' }; }
  r = shroomTake();                         // a mushroom, which regrows
  if (r.ok) return r;
  toast('Nothing to pick up here.', 900);
  return { ok: false, why: 'none' };
}
function tryInspect() {""")

# ---------------------------------------------------------------- the prompt says E
s = sub1(s, """      const carcLine = body0 ? '<div class="keys"><span class="ok">V</span> search the body at your feet &middot; ' + ((body0.parts || []).length) + ' parts</div>' : '';""",
             """      const carcLine = body0 ? '<div class="keys"><span class="ok">E</span> search the body at your feet &middot; ' + ((body0.parts || []).length) + ' parts</div>' : '';""")
s = sub1(s, """          '<div class="keys"><span class="ok">V</span> search it</div>' + (fp2 ? fp2.html : '');""",
             """          '<div class="keys"><span class="ok">E</span> search it</div>' + (fp2 ? fp2.html : '');""")

# and so does the controls page
s = s.replace('<b>V</b> search a body', '<b>E</b> take / search')
s = s.replace('<b>V</b>', '<b>V</b>')

# ---------------------------------------------------------------- no key may ever be bound twice again
# A silent double binding is exactly the kind of thing that is found with your
# hands rather than your eyes, so the handler checks ITSELF at load: its own
# source is scanned for repeated `k === 'x'` tests and any duplicate is
# reported. It cannot go stale, because it reads the code rather than a list
# somebody has to remember to update.
s = sub1(s, "  addEventListener('keydown', (e) => {\n    if (ED.open) return;",
         "  function onPlayKey(e) {\n    if (ED.open) return;")
s = sub1(s, """    if ([' ', 'w', 'a', 's', 'd'].includes(k)) e.preventDefault();
  });
  addEventListener('keyup', (e) => {""",
"""    if ([' ', 'w', 'a', 's', 'd'].includes(k)) e.preventDefault();
  }
  addEventListener('keydown', onPlayKey);
  (function () {
    const seen = {}, dup = [];
    for (const m of String(onPlayKey).match(/k === '(?:[^']|\\\\')+'/g) || []) {
      if (seen[m]) { if (dup.indexOf(m) < 0) dup.push(m); } else seen[m] = 1;
    }
    if (dup.length) console.warn('input: these keys are handled more than once in onPlayKey:', dup.join(', '));
  })();
  addEventListener('keyup', (e) => {""")

open(p, 'w', encoding='utf-8').write(s)
print('keys: one interact key ok')
