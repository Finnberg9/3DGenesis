# =====================================================================
# A KILL IS WORTH A QUARTER OF WHAT YOU KILLED
#
# Growth was a per-cell increment with no relationship to any number a player
# could reason about: `gain = 0.02 + 0.10 * ratio`, added to every cell, every
# kill. Three or four kills and you were enormous, and nothing in the rule
# said what you should expect.
#
# The rule is now one sentence: KILLING SOMETHING ADDS A QUARTER OF ITS MASS
# TO YOURS. Mass scales with the cells' growth, so the whole body is
# multiplied by exactly (1 + 0.25 * preyMass/yourMass), which lands your new
# mass on yourMass + 0.25 * preyMass and nowhere else.
#
# That also makes the curve self-limiting in the way the old one was not:
# killing things your own size adds 25% each time, and the bigger you get the
# less any one kill is worth, because the ratio falls as you grow.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, ('ANCHOR %d/%d' % (n, cnt), a[:110]); return s.replace(a, b)

p = 'g3.html'; s = open(p, encoding='utf-8').read()

s = sub1(s, """function feedGrowth(c, preyMass, label) {
  if (!c || !c.alive || !c.cellState || !c.cellState.length) return;
  const ratio = clamp((preyMass || 0.5) / Math.max(0.2, c.ph.mass), 0.05, 1.5);
  const gain = 0.02 + 0.10 * ratio;
  const r0 = c.ph.radius, ef = C.hpFrac(c);
  let sum = 0, n = 0;
  for (const q of c.cellState) {
    if (!q.alive) continue;
    if (q.grow < 1) q.grow = q.grow + gain * 2.5;                    // juvenile spurt
    else q.grow = q.grow + gain * Math.max(0, 1 - (q.grow - 1) / (BULK_MAX - 1));
    q.grow = Math.min(BULK_MAX, q.grow);
    sum += q.grow; n++;
  }""",
"""// You gain a quarter of the mass of whatever you killed. Not a tuned
// increment: the actual stated fraction, applied as a multiplier on the whole
// body so the arithmetic comes out exactly on yourMass + 0.25 * preyMass.
const KILL_GROWTH = 0.25;
const KILL_RATIO_CAP = 4;      // a newborn killing something huge still cannot triple
function feedGrowth(c, preyMass, label) {
  if (!c || !c.alive || !c.cellState || !c.cellState.length) return;
  const ratio = clamp((preyMass || 0.5) / Math.max(0.2, c.ph.mass), 0, KILL_RATIO_CAP);
  // mass rises with cell growth, so scaling every cell by this scales the
  // body by it: M -> M * (1 + 0.25 * prey/M) = M + 0.25 * prey
  const mul = 1 + KILL_GROWTH * ratio;
  const r0 = c.ph.radius, ef = C.hpFrac(c);
  let sum = 0, n = 0;
  for (const q of c.cellState) {
    if (!q.alive) continue;
    q.grow = Math.min(BULK_MAX, q.grow * mul);
    sum += q.grow; n++;
  }""")
s = sub1(s, "  get GFX() { return GFX; }, gfxSet: (n) => gfxSet(n),",
"""  get GFX() { return GFX; }, gfxSet: (n) => gfxSet(n),
  growth: {
    KILL_GROWTH, KILL_RATIO_CAP,
    // feed the player a kill of a given mass and report the mass before and after
    tryKill: (preyMass) => {
      const c = player.c;
      if (!c) return null;
      const before = c.ph.mass;
      feedGrowth(c, preyMass, null);
      return { before: +before.toFixed(4), after: +c.ph.mass.toFixed(4), prey: preyMass,
               want: +(before + 0.25 * Math.min(preyMass, before * 4)).toFixed(4) };
    },
  },""")
open(p, 'w', encoding='utf-8').write(s)
print('growth ok')
