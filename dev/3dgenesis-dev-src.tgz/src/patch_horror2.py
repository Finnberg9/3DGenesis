# =====================================================================
# THE HORROR PASS, SECOND CUT
#
# Three things wrong with the first one, all visible the moment a mouth was
# actually open in front of the camera:
#
#   THE INNER JAW WAS OUTSIDE THE HEAD. It was pushed FORWARD from the throat
#   by up to (0.22 + 0.9) x (0.9 + wide) -- nearly two units in jaw space on a
#   crushing jaw whose whole muzzle is 1.55 long. It flew out in front of the
#   snout and hung in mid-air beside the face. It belongs deep in the throat,
#   behind the tooth line, barely moving.
#
#   THE TONGUE WAS A STRING OF BEADS hanging straight down out of the jaw.
#   The segments were as wide as they were long and stepped too far apart, so
#   instead of one continuous tongue you got five separate blobs, and they
#   drooped out of the mouth rather than lying along the floor of it.
#
#   THE DROOL WAS FLOATING BUBBLES. The strands were too thin to see and the
#   beads too big, so what read was a handful of pale spheres unattached to
#   anything -- and the "broken" bead fell up to two units clear of the mouth,
#   which is why it looked like it belonged to something else.
#
# And one that was there before any of this:
#
#   THE FLESH SWALLOWED THE TEETH. Teeth sat at 0.92 of the profile half-width
#   while the muzzle flesh is built at 1.00 of it, so the upper row was inside
#   the lip and only the longest fangs ever showed. They sit proud of the flesh
#   now, and hang from the lip line rather than from the middle of the muzzle,
#   so a closed mouth still has teeth in it.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, ('ANCHOR %d/%d' % (n, cnt), a[:110]); return s.replace(a, b)

p = 'g3.html'; s = open(p, encoding='utf-8').read()

# ---------------------------------------------------------------- 1. teeth outside the lip
s = sub1(s, """    const yU = 0.42 - S.curve * u * u * 1.4 - p.d * 0.1;
    const yL = 0.30 - S.curve * u * u * 1.2 - p.d * 0.05;
    for (const s of [1, -1]) {
      const z = s * p.w * (S.beak ? 0.82 : 0.92);""",
"""    // The flesh of the muzzle is built at p.w and its underside sits at
    // -0.32 of the depth; teeth placed inside either of those are teeth you
    // never see. They hang from the LIP, and stand a little proud of it.
    const yU = 0.42 - S.curve * u * u * 1.4 - p.d * 0.34;
    const yL = 0.30 - S.curve * u * u * 1.2 + p.d * 0.06;
    for (const s of [1, -1]) {
      const z = s * p.w * (S.beak ? 0.86 : 1.02);""")
s = sub1(s, """      // upper teeth point down and rake backward; lower teeth point up
      g.cn(x, yU, z, -0.18, -1, 0, size * 0.34, size, IVORY);
      j.cn(x - 0.05, yL, z * 0.95, -0.12, 1, 0, size * 0.3, size * 0.85, IVORY);""",
"""      // upper teeth point down and rake backward; lower teeth point up
      g.cn(x, yU, z, -0.18, -1, 0, size * 0.34, size, IVORY);
      j.cn(x - 0.05, yL, z * 0.92, -0.12, 1, 0, size * 0.3, size * 0.85, IVORY);""")
# and the gum line follows them out
s = sub1(s, """        g.sp(x, yU + 0.02, z, 0, 1, 0, S.len / n * 0.6, 0.035, size * 0.22, gum);
        j.sp(x - 0.05, yL - 0.02, z * 0.95, 0, 1, 0, S.len / n * 0.6, 0.035, size * 0.2, gum);""",
"""        g.sp(x, yU + size * 0.42, z * 0.97, 0, 1, 0, S.len / n * 0.6, 0.045, size * 0.22, gum);
        j.sp(x - 0.05, yL - size * 0.36, z * 0.89, 0, 1, 0, S.len / n * 0.6, 0.045, size * 0.2, gum);""")

# ---------------------------------------------------------------- 2. saliva
s = sub1(s, """const SPIT = [0.74, 0.80, 0.72];        // saliva: pale, cold, slightly green
const SPIT_D = [0.58, 0.64, 0.56];""",
"""// Saliva is nearly white and barely there. The first cut was a cold blue-grey
// at three times this thickness, which is why it read as bubbles.
const SPIT = [0.88, 0.89, 0.84];
const SPIT_D = [0.74, 0.76, 0.70];""")
s = sub1(s, """function droolStrand(g, x, y, z, len, ph, t, r0) {
  let p = [x, y, z];
  const N = 4, R = r0 || 0.036;
  for (let i = 0; i < N; i++) {
    const u = (i + 1) / N;
    // the swing grows toward the free end, which is what makes it hang
    const sx = Math.sin(t * 1.6 + ph + u * 2.4) * 0.09 * u;
    const sz = Math.cos(t * 1.27 + ph * 1.7 + u * 2.0) * 0.07 * u;
    const q = [p[0] + sx * 0.4, p[1] - len / N, p[2] + sz * 0.4];
    const d = v3.sub(q, p), L = v3.len(d) || 1e-4, dn = v3.mul(d, 1 / L);
    g.cn(p[0], p[1], p[2], dn[0], dn[1], dn[2], R * (1 - 0.5 * (u - 1 / N)), L * 1.06,
         u > 0.6 ? SPIT_D : SPIT);
    p = q;
  }
  g.ball(p[0], p[1], p[2], R * 1.7, SPIT);
}""",
"""// A thread, not a string of beads. More segments, each much shorter than it
// is thin, so it reads as one continuous line; the bead at the end is smaller
// than the thread is thick at the top, which is what makes it read as a drip
// about to fall rather than as a ball on a stick.
function droolStrand(g, x, y, z, len, ph, t, r0) {
  let p = [x, y, z];
  const N = 6, R = r0 || 0.020;
  for (let i = 0; i < N; i++) {
    const u = (i + 1) / N;
    // the swing grows toward the free end, which is what makes it hang
    const sx = Math.sin(t * 1.6 + ph + u * 2.4) * 0.05 * u;
    const sz = Math.cos(t * 1.27 + ph * 1.7 + u * 2.0) * 0.04 * u;
    const q = [p[0] + sx * 0.35, p[1] - len / N, p[2] + sz * 0.35];
    const d = v3.sub(q, p), L = v3.len(d) || 1e-4, dn = v3.mul(d, 1 / L);
    g.cn(p[0], p[1], p[2], dn[0], dn[1], dn[2], R * (1 - 0.42 * (u - 1 / N)), L * 1.12,
         u > 0.65 ? SPIT_D : SPIT);
    p = q;
  }
  g.ball(p[0], p[1], p[2], R * 1.15, SPIT);
}""")
s = sub1(s, """function drool(g, e, x, y, halfW, n, len, seed) {
  if (!gore(e)) return;
  const t = e.t;
  for (let i = 0; i < n; i++) {
    const f = n === 1 ? 0 : (i / (n - 1)) * 2 - 1;
    const ph = seed + i * 2.399;
    // each strand runs its own slow stretch-and-snap cycle
    const cyc = (t * 0.33 + i * 0.41 + seed * 0.11) % 1;
    const grow = cyc < 0.82 ? 0.35 + cyc * 1.0 : 0.15;         // snaps back short
    droolStrand(g, x, y, f * halfW, len * grow, ph, t, 0.034);
  }
  // the bead that let go, falling and repeating
  const d = (t * 0.55 + seed * 0.37) % 1;
  g.ball(x + 0.05, y - len * (0.4 + d * 1.5), (seed % 1 - 0.5) * halfW * 1.2, 0.05 * (1 - d * 0.35), SPIT);
}""",
"""function drool(g, e, x, y, halfW, n, len, seed) {
  if (!gore(e)) return;
  const t = e.t;
  for (let i = 0; i < n; i++) {
    const f = n === 1 ? 0 : (i / (n - 1)) * 2 - 1;
    const ph = seed + i * 2.399;
    // each strand runs its own slow stretch-and-snap cycle
    const cyc = (t * 0.33 + i * 0.41 + seed * 0.11) % 1;
    const grow = cyc < 0.82 ? 0.30 + cyc * 0.85 : 0.12;        // snaps back short
    // hung off the lip line itself, not out of the middle of the muzzle
    droolStrand(g, x, y, f * halfW, len * grow, ph, t, 0.020);
  }
  // The bead that let go. It falls a SHORT way and is small: the first cut
  // sent it a length and a half clear of the jaw, where it read as an
  // unrelated object floating beside the head.
  const d = (t * 0.55 + seed * 0.37) % 1;
  g.ball(x + 0.03, y - len * (0.10 + d * 0.55), (seed % 1 - 0.5) * halfW * 0.8, 0.026 * (1 - d * 0.4), SPIT);
}""")

# ---------------------------------------------------------------- 3. the tongue
s = sub1(s, """function lollTongue(g, e, x0, y0, len, wide, open) {
  const t = e.t, out = 0.25 + open * 1.25;
  let p = [x0, y0, 0];
  const N = 5;
  for (let i = 0; i < N; i++) {
    const u = (i + 1) / N;
    const drag = Math.sin(t * 1.1 + e.seed + u * 1.6) * 0.16 * u * out;
    const q = [p[0] + (len * out) / N, p[1] - u * u * 0.30 * out, p[2] + drag * 0.5];
    const d = v3.sub(q, p), L = v3.len(d) || 1e-4, dn = v3.mul(d, 1 / L);
    const m = v3.mul(v3.add(p, q), 0.5), w = wide * (1 - 0.32 * u);
    g.sp(m[0], m[1], m[2], dn[0], dn[1], dn[2], w, L * 0.58, w * 1.25,
         i > 2 ? colMul(TONGUE, 0.82) : TONGUE);
    p = q;
  }
  g.sp(p[0], p[1], p[2], 1, 0, 0, wide * 0.5, wide * 0.55, wide * 0.7, colMul(TONGUE, 0.7));
  // and it is wet
  if (gore(e) && open > 0.25) droolStrand(g, p[0], p[1] - wide * 0.4, p[2], 0.34 * open, e.seed * 3.1, t, 0.028);
}""",
"""// A tongue lies along the FLOOR of the mouth and only reaches past the teeth
// when the mouth is properly open. Nine short segments rather than five long
// ones, each much wider than the step between them, so it is one continuous
// body instead of a row of separate blobs -- which is exactly what the first
// cut looked like.
function lollTongue(g, e, x0, y0, len, wide, open) {
  const t = e.t;
  // barely past the teeth at rest; a real lolling tongue only when gaping
  const out = 0.55 + open * 0.75;
  let p = [x0, y0, 0];
  const N = 9;
  for (let i = 0; i < N; i++) {
    const u = (i + 1) / N;
    // it only starts to droop once it is past the tooth line
    const past = Math.max(0, u - 0.62) / 0.38;
    const drag = Math.sin(t * 1.1 + e.seed + u * 1.6) * 0.10 * past * open;
    const q = [p[0] + (len * out) / N, p[1] - past * past * 0.22 * open, p[2] + drag];
    const d = v3.sub(q, p), L = v3.len(d) || 1e-4, dn = v3.mul(d, 1 / L);
    const m = v3.mul(v3.add(p, q), 0.5);
    // tapering, and flatter than it is wide: a tongue is a strap, not a rope
    const w = wide * (1 - 0.45 * u * u);
    g.sp(m[0], m[1], m[2], dn[0], dn[1], dn[2], w * 1.15, L * 0.80, w * 0.55,
         i > 5 ? colMul(TONGUE, 0.86) : TONGUE);
    p = q;
  }
  g.sp(p[0], p[1], p[2], 1, 0, 0, wide * 0.45, wide * 0.36, wide * 0.30, colMul(TONGUE, 0.72));
  // and it is wet, but only when it is actually hanging out
  if (gore(e) && open > 0.45) droolStrand(g, p[0], p[1] - wide * 0.3, p[2], 0.22 * open, e.seed * 3.1, t, 0.017);
}""")

# ---------------------------------------------------------------- 4. the inner jaw, back where it belongs
s = sub1(s, """function innerJaw(g, e, x0, y0, scale, open) {
  if (!gore(e)) return;
  const push = (0.22 + e.chomp * 0.9) * scale;
  const x = x0 + push, gap = (0.06 + open * 0.10) * scale;
  const s = scale;
  g.sp(x, y0 + gap, 0, 1, 0.1, 0, 0.16 * s, 0.11 * s, 0.20 * s, colMul(GORE, 1.35));
  g.sp(x, y0 - gap, 0, 1, -0.1, 0, 0.15 * s, 0.10 * s, 0.19 * s, colMul(GORE, 1.15));
  for (let i = 0; i < 3; i++) {
    const z = (i - 1) * 0.10 * s;
    g.cn(x + 0.10 * s, y0 + gap * 0.4, z, 1, -0.5, 0, 0.022 * s, 0.11 * s, IVORY);
    g.cn(x + 0.10 * s, y0 - gap * 0.4, z, 1, 0.5, 0, 0.020 * s, 0.10 * s, IVORY);
  }
}""",
"""// The second set of jaws, DEEP IN THE THROAT. It moves a little, not a lot:
// the first cut pushed it forward by up to two units in jaw space on a muzzle
// 1.55 long, which put it out in front of the snout hanging in mid-air beside
// the face. The whole effect is that you glimpse it when the mouth gapes, so
// it is drawn only when the mouth is actually open and it never leaves the
// throat.
function innerJaw(g, e, x0, y0, scale, open) {
  if (!gore(e) || !(open > 0.12)) return;
  const s = scale * 0.55;
  // a short lunge forward, bounded so it can never clear the tooth line
  const push = Math.min(0.30, (0.04 + e.chomp * 0.26)) * scale;
  const x = x0 + push, gap = (0.05 + open * 0.07) * scale;
  g.sp(x, y0 + gap, 0, 1, 0.1, 0, 0.13 * s, 0.09 * s, 0.17 * s, colMul(GORE, 1.35));
  g.sp(x, y0 - gap, 0, 1, -0.1, 0, 0.12 * s, 0.08 * s, 0.16 * s, colMul(GORE, 1.15));
  for (let i = 0; i < 3; i++) {
    const z = (i - 1) * 0.085 * s;
    g.cn(x + 0.08 * s, y0 + gap * 0.4, z, 1, -0.5, 0, 0.016 * s, 0.085 * s, IVORY);
    g.cn(x + 0.08 * s, y0 - gap * 0.4, z, 1, 0.5, 0, 0.015 * s, 0.080 * s, IVORY);
  }
}""")

# ---------------------------------------------------------------- 5. where they are hung
s = sub1(s, """  if (horror) {
    lollTongue(j, e, -0.05, 0.26, S.len * 0.62, S.wide * 0.30, open);
    innerJaw(g, e, -0.20, 0.34, 0.9 + S.wide, open);
    drool(g, e, S.len * 0.34, 0.30 - S.curve * 0.4, S.wide * 0.72, 3, 0.55 + open * 0.5, (e.seed || 0) + S.len);
    lipTendrils(g, e, S.len * 0.20, 0.30, S.wide * 0.88, 3, 0.42, S.len * 0.45);
  } else {""",
"""  if (horror) {
    // the tongue starts at the back of the mouth floor and runs forward
    lollTongue(j, e, -0.22, 0.24, S.len * 0.55, S.wide * 0.34, open);
    // the inner jaw sits behind the throat opening, which is drawn at -0.12
    innerJaw(g, e, -0.30, 0.33, 0.9 + S.wide, open);
    // saliva hangs off the LIP, at the depth the upper teeth now hang from
    const lipY = 0.42 - S.curve * 0.35 - jawProfile(S, 0.55).d * 0.40;
    drool(g, e, S.len * 0.42, lipY, jawProfile(S, 0.55).w * 0.80, 2, 0.34 + open * 0.34, (e.seed || 0) + S.len);
    // Tendril length is scaled off the WIDTH of the muzzle, not a flat
    // number: a narrow fishing jaw was growing the same beard as a
    // crushing one, which hung it out past the lip.
    lipTendrils(g, e, S.len * 0.22, 0.28, S.wide * 0.86, 3, S.wide * 0.52, S.len * 0.40);
  } else {""")
s = sub1(s, """    lollTongue(g, e, -0.1, 0.30, 0.66, 0.16, o);
    innerJaw(g, e, -0.24, 0.34, 1.0, o);
    drool(g, e, 0.24, 0.40, 0.55, 3, 0.52 + o * 0.6, (e.seed || 0) + 1.7);
    lipTendrils(g, e, 0.18, 0.36, 0.62, 2, 0.34, 0.5);""",
"""    lollTongue(g, e, -0.28, 0.28, 0.56, 0.17, o);
    innerJaw(g, e, -0.34, 0.32, 1.0, o);
    drool(g, e, 0.30, 0.24, 0.46, 2, 0.30 + o * 0.34, (e.seed || 0) + 1.7);
    lipTendrils(g, e, 0.20, 0.30, 0.60, 2, 0.28, 0.45);""")
s = sub1(s, """    drool(g, e, 0.18, 0.40, 0.42, 2, 0.40 + o * 0.5, (e.seed || 0) + 0.9);
    lipTendrils(g, e, 0.14, 0.34, 0.48, 2, 0.26, 0.4);""",
"""    drool(g, e, 0.22, 0.26, 0.34, 2, 0.26 + o * 0.28, (e.seed || 0) + 0.9);
    lipTendrils(g, e, 0.14, 0.28, 0.30, 2, 0.14, 0.30);""")

open(p, 'w', encoding='utf-8').write(s)
print('horror2 ok')
