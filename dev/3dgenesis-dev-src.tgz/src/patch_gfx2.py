# Render 2: sun shadows (cascaded shadow map), post-processing (AO, sun
# shafts, bloom, grade, sharpened upscale), render scale + auto resolution,
# and view-frustum culling. See src/render2.js and src/wgsl_post.js.
def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
p='g3.html'; s=open(p,encoding='utf-8').read()
# ---- shared WGSL: extended globals, shadow lookup, shadowed sun term
s=sub1(s,"""  params   : vec4<f32>,   // x=time  y=fogDensity  z=lightAmount  w=seaLevelY
};
@group(0) @binding(0) var<uniform> g : G;
""","""  params   : vec4<f32>,   // x=time  y=fogDensity  z=lightAmount  w=seaLevelY
  shadowVP0 : mat4x4<f32>,
  shadowVP1 : mat4x4<f32>,
  shadowP  : vec4<f32>,   // x=near cascade radius  y=cascades  z=1/map size  w=strength
};
@group(0) @binding(0) var<uniform> g : G;
@group(0) @binding(8) var shadowMap : texture_depth_2d_array;
@group(0) @binding(9) var shadowSmp : sampler_comparison;
fn shadowCascade(wpos: vec3<f32>, N: vec3<f32>, c: i32) -> f32 {
  var m = g.shadowVP0;
  var bias = 0.9;
  if (c == 1) { m = g.shadowVP1; bias = 5.0; }
  let p4 = m * vec4<f32>(wpos + N * bias, 1.0);
  let p = p4.xyz / p4.w;
  let uv = vec2<f32>(p.x * 0.5 + 0.5, 0.5 - p.y * 0.5);
  if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0 || p.z > 1.0 || p.z < 0.0) { return 1.0; }
  let ts = g.shadowP.z * select(1.0, 1.5, c == 1);
  var sum = 0.0;
  for (var y = -1; y <= 1; y = y + 1) {
    for (var x = -1; x <= 1; x = x + 1) {
      sum += textureSampleCompareLevel(shadowMap, shadowSmp, uv + vec2<f32>(f32(x), f32(y)) * ts * 1.25, c, p.z - 0.0005);
    }
  }
  return sum / 9.0;
}
fn shadowAt(wpos: vec3<f32>, N: vec3<f32>) -> f32 {
  let n = i32(g.shadowP.y + 0.5);
  if (n == 0) { return 1.0; }
  let d = distance(wpos, g.camPos.xyz);
  let r0 = g.shadowP.x;
  var s = 1.0;
  if (d < r0 * 0.8) { s = shadowCascade(wpos, N, 0); }
  else if (n > 1) {
    let r1 = r0 * 6.3;
    s = mix(shadowCascade(wpos, N, 1), 1.0, smoothstep(r1 * 0.55, r1 * 0.9, d));
  }
  return mix(1.0, s, g.shadowP.w);
}
""")
s=sub1(s,"""  var lit = col * (ambCol * (0.55 + 0.45 * sky) + sunCol * sun * 0.85 + col * bounce);""",
"""  let shd = shadowAt(wpos, N);
  var lit = col * (ambCol * (0.55 + 0.45 * sky) * (0.82 + 0.18 * shd) + sunCol * sun * 0.85 * shd + col * bounce);""")
s=sub1(s,"""  lit += sunCol * pow(max(dot(N, H), 0.0), 22.0) * 0.10 * day;""","""  lit += sunCol * pow(max(dot(N, H), 0.0), 22.0) * 0.10 * day * shd;""")
s=sub1(s,"let gBuf, gArr = new Float32Array(32);","let gBuf, gArr = new Float32Array(68);")
s=sub1(s,"  gBuf = dev.createBuffer({ size: 128, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });",
"""  gBuf = dev.createBuffer({ size: 272, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });
  // remember every pipeline descriptor so render2 can build depth-only shadow copies
  const __crp = dev.createRenderPipeline;
  dev.createRenderPipeline = (d) => { const pp = __crp.call(dev, d); R2.descOf.set(pp, d); return pp; };""")
s=sub1(s,"""  plantVB  = dev.createBuffer({ size: plantData.byteLength, usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST });
}""","""  plantVB  = dev.createBuffer({ size: plantData.byteLength, usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST });
  dev.createRenderPipeline = __crp;
  r2BuildPipelines();
}""")
# bind groups: every lit pipeline gets the shadow map
s=sub1(s,"""  folBind = dev.createBindGroup({ layout: folPipe.getBindGroupLayout(0), entries: [{ binding: 0, resource: { buffer: gBuf } }] });
  skinBind = dev.createBindGroup({ layout: skinPipe.getBindGroupLayout(0), entries: [
    { binding: 0, resource: { buffer: gBuf } }, { binding: 1, resource: { buffer: boneBuf } }] });""","""  const SE = r2ShadowEntries();
  folBind = dev.createBindGroup({ layout: folPipe.getBindGroupLayout(0), entries: [{ binding: 0, resource: { buffer: gBuf } }].concat(SE) });
  skinBind = dev.createBindGroup({ layout: skinPipe.getBindGroupLayout(0), entries: [
    { binding: 0, resource: { buffer: gBuf } }, { binding: 1, resource: { buffer: boneBuf } }].concat(SE) });
  R2.bL = [{}, {}];""")
for k in ['terrain','inst','body','tube','over']:
    pipe={'terrain':'terrainPipe','inst':'instPipe','body':'bodyPipe','tube':'tubePipe','over':'overPipe'}[k]
    pad=' '*(8-len(k))
    old=f"    {k}:{pad}dev.createBindGroup({{ layout: {pipe}.getBindGroupLayout(0),"
    i=s.index(old); j=s.index("}] }),", i)
    s=s[:j]+"}].concat(SE) }),"+s[j+len("}] }),"):]
# ---- code
code=open('src/wgsl_post.js',encoding='utf-8').read()+'\n'+open('src/render2.js',encoding='utf-8').read()
s=sub1(s,"function stepSim(dt) {\n", code+"\nfunction stepSim(dt) {\n")
# ---- frame: frustum, globals, shadow pass, scene at render scale, post
s=sub1(s,"""  m4look(player.camX, player.camY, player.camZ, tx, ty, tz, viewM);
  m4mul(projM, viewM, vpM);
""","""  m4look(player.camX, player.camY, player.camZ, tx, ty, tz, viewM);
  m4mul(projM, viewM, vpM);
  r2Frustum(vpM);
  r2AutoRes();
""",1)
s=sub1(s,"""  gArr[28] = t; gArr[29] = FOG_DENSITY * GFX.fog *""","""  r2FrameGlobals();
  gArr[28] = t; gArr[29] = FOG_DENSITY * GFX.fog *""")
s=sub1(s,"""  const enc = dev.createCommandEncoder();
  const pass = enc.beginRenderPass({
    colorAttachments: [{ view: msaaTex.createView(), resolveTarget: ctx.getCurrentTexture().createView(),
      clearValue: { r: fog[0], g: fog[1], b: fog[2], a: 1 }, loadOp: 'clear', storeOp: 'discard' }],
    depthStencilAttachment: { view: depthTex.createView(), depthClearValue: 1.0,
      depthLoadOp: 'clear', depthStoreOp: 'store' },
  });""","""  const enc = dev.createCommandEncoder();
  const R2on = R2.ok;
  if (R2on) { r2EnsureScene(); r2ShadowPass(enc, nInst, nPlant); }
  const pass = enc.beginRenderPass({
    colorAttachments: [{ view: (R2on ? R2.sceneMs : msaaTex).createView(), resolveTarget: (R2on ? R2.sceneRes : ctx.getCurrentTexture()).createView(),
      clearValue: { r: fog[0], g: fog[1], b: fog[2], a: 1 }, loadOp: 'clear', storeOp: 'discard' }],
    depthStencilAttachment: { view: (R2on ? R2.sceneDepth : depthTex).createView(), depthClearValue: 1.0,
      depthLoadOp: 'clear', depthStoreOp: 'store' },
  });""")
s=sub1(s,"""  pass.setVertexBuffer(0, waterVB); pass.draw(6);
  pass.end();
  dev.queue.submit([enc.finish()]);
  return { inst: nInst, plants: nPlant };""","""  pass.setVertexBuffer(0, waterVB); pass.draw(6);
  pass.end();
  if (R2on) r2PostPass(enc, fog);
  dev.queue.submit([enc.finish()]);
  return { inst: nInst, plants: nPlant };""")
# canvas at native resolution; the scene itself is rendered at the render scale
s=sub1(s,"  let dpr = Math.min(window.devicePixelRatio || 1, 2) * GFX.res;","  let dpr = Math.min(window.devicePixelRatio || 1, 2) * (R2.ok ? 1 : GFX.res);")
# editor: never shadows
s=sub1(s,"  gArr[28] = t; gArr[29] = fogDen; gArr[30] = 1; gArr[31] = -1000;","  gArr[28] = t; gArr[29] = fogDen; gArr[30] = 1; gArr[31] = -1000; gArr[65] = 0;")
# ---- culling
s=sub1(s,"""    if (d2 > FAR * FAR) continue;
    if (instCount > MAX_INST - 64) break;""","""    if (d2 > FAR * FAR) continue;
    // not in view: skip entirely (your own body always draws)
    if (c !== player.c && d2 > 900 && !r2InView(c.x, groundAt(c.x, c.y) + (c.ph.standH || c.ph.radius || 4) * BODY_SCALE, c.y, bodyExtent(c) * 1.4 + 12)) continue;
    if (instCount > MAX_INST - 64) break;""")
s=sub1(s,"""    if (d2 > FARR) continue;
    const y = groundAt(pl.x, pl.y);""","""    if (d2 > FARR) continue;
    const y = groundAt(pl.x, pl.y);
    if (d2 > 160000 && !r2InView(pl.x, y + 40, pl.y, 110)) continue;""")
s=sub1(s,"""    if (d > 260 && (dx * fx + dz * fz) / d < -0.45) continue;""","""    if (!r2InCone(dx, dz, d, 60 + tr.s * 60, fx, fz)) continue;""")
s=sub1(s,"""    if (d > 60 && (dx * fx + dz * fz) / d < -0.5) continue;""","""    if (d > 60 && !r2InCone(dx, dz, d, 20, fx, fz)) continue;""")
s=sub1(s,"    if (dcam > REMAINS_DRAW_R) continue;","    if (dcam > REMAINS_DRAW_R || (dcam > 60 && !r2InView(r.x, groundAt(r.x, r.z), r.z, r.R * 4 + 10))) continue;")
# ---- presets and HUD
s=sub1(s,"""  low:    { res: 0.60, cover: 380,  plant: 2600,  lod0: 420,  lod1: 1600, crit: 0.6, fog: 1.00, folMax: 50000 },
  medium: { res: 0.85, cover: 620,  plant: 4200,  lod0: 700,  lod1: 2600, crit: 0.9, fog: 0.80, folMax: 90000 },
  high:   { res: 1.00, cover: 900,  plant: 6500,  lod0: 1000, lod1: 3800, crit: 1.3, fog: 0.60, folMax: 140000 },
  ultra:  { res: 1.25, cover: 1250, plant: 11000, lod0: 1500, lod1: 6000, crit: 1.9, fog: 0.42, folMax: 200000 },""","""  low:    { res: 0.65, cover: 380,  plant: 2600,  lod0: 420,  lod1: 1600, crit: 0.6, fog: 1.00, folMax: 50000,  shadow: 0, ao: 0, bloom: 0, rays: 0 },
  medium: { res: 0.80, cover: 620,  plant: 4200,  lod0: 700,  lod1: 2600, crit: 0.9, fog: 0.80, folMax: 90000,  shadow: 1, ao: 0, bloom: 1, rays: 1 },
  high:   { res: 0.90, cover: 900,  plant: 6500,  lod0: 1000, lod1: 3800, crit: 1.3, fog: 0.60, folMax: 140000, shadow: 2, ao: 1, bloom: 1, rays: 1 },
  ultra:  { res: 1.15, cover: 1250, plant: 11000, lod0: 1500, lod1: 6000, crit: 1.9, fog: 0.42, folMax: 200000, shadow: 3, ao: 1, bloom: 1, rays: 1 },""")
s=sub1(s,"""<div id="gfxsel"><span>graphics</span>""","""<div id="gfxsel"><span id="gfxfps" title="frame rate and render scale">-</span><button data-q="auto" id="gfxauto" class="on" title="lower the render scale automatically to keep the frame rate up">auto res</button><span>graphics</span>""")
s=sub1(s,"""    if (b) { gfxSet(b.dataset.q); e.stopPropagation(); }""","""    if (b && b.dataset.q === 'auto') { R2.auto = !R2.auto; if (!R2.auto) R2.dyn = 1; b.classList.toggle('on', R2.auto); try { localStorage.setItem('g3d_autores', R2.auto ? '1' : '0'); } catch (err) { /* not remembered */ } e.stopPropagation(); return; }
    if (b) { gfxSet(b.dataset.q); e.stopPropagation(); }""")
s=sub1(s,"""  if (el) for (const b of el.querySelectorAll('button')) b.classList.toggle('on', b.dataset.q === name);""","""  if (el) for (const b of el.querySelectorAll('button')) if (b.dataset.q !== 'auto') b.classList.toggle('on', b.dataset.q === name);
  if (typeof R2 !== 'undefined') R2.dyn = 1;""")
s=sub1(s,"""  el.addEventListener('mousedown', (e) => e.stopPropagation());
  gfxLoad();""","""  el.addEventListener('mousedown', (e) => e.stopPropagation());
  try { if (localStorage.getItem('g3d_autores') === '0') { R2.auto = false; const ab = document.getElementById('gfxauto'); if (ab) ab.classList.remove('on'); } } catch (err) { /* default on */ }
  gfxLoad();""")
s=sub1(s,"function updateHUD() {\n  edHudLine();\n  gfxPlace();","function updateHUD() {\n  edHudLine();\n  gfxPlace();\n  r2Hud();")
s=sub1(s,"  get GFX() { return GFX; },","  get R2() { return R2; },\n  get GFX() { return GFX; },")
open(p,'w',encoding='utf-8').write(s)
print('gfx2 ok')
