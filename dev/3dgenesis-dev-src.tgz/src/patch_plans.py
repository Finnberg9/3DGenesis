# =====================================================================
# EIGHT NEW BODY PLANS: MYTHICAL, NOT PREHISTORIC
#
# "The original creature shapes are too generic, and too dinosaur looking.
#  They need to just be natural creatures / not necessarily existing
#  creatures." Reference sheets: arthropod sculpts and silhouette studies --
#  stilt-walkers with tiny bodies on enormous legs, hydras, crabs, scorpions,
#  hunched brutes, scythe-armed mantids, drifting bell bodies.
#
# The eight are APPENDED, never renumbered. A saved design stores its plan by
# index, so renumbering would silently turn somebody's creature into a
# different animal. The new shapes are what the picker offers first instead.
#
# One new skeleton parameter comes with them: `tailUp`, which sweeps the tail
# up and over the back instead of trailing it. Zero for every existing plan,
# so nothing that already exists moves by a hair -- it is what makes a
# scorpion a scorpion.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, ('ANCHOR %d/%d' % (n, cnt), a[:110]); return s.replace(a, b)

p = 'g3.html'; s = open(p, encoding='utf-8').read()

# ---------------------------------------------------------------- 1. a tail that can arch
s = sub1(s, """    for (let i = 1; i <= P.ts; i++) {
      const u = i / P.ts;
      tx -= seg * Math.cos(0.12 + 0.18 * u);
      ty -= seg * Math.sin(0.12 + 0.18 * u) * 0.6;""",
"""    // tailUp sweeps the tail up and over the back rather than trailing it
    // behind. 0 for every plan that existed before, so nothing already built
    // moves; 1 is a scorpion.
    const tup = P.tailUp || 0;
    for (let i = 1; i <= P.ts; i++) {
      const u = i / P.ts;
      const ang = 0.12 + 0.18 * u - tup * (0.30 + 1.55 * u);
      tx -= seg * Math.cos(ang);
      ty -= seg * Math.sin(ang) * 0.6;""")

# ---------------------------------------------------------------- 2. the plans
s = sub1(s, """    { a: 1.35, b: 0.85, seg: 11, prof: 'fish',   arch: 0.08, droop: 0.00, wide: 0.15, neck: 2.20, nx: 0.50, ny: 0.80, ns: 7, head: 0.34, snx: 0.70, snr: 0.45, tail: 0.9, tailR: 0.24, ts: 6, stand: 0.80 },  // 21 plesiosaur
  ];""",
"""    { a: 1.35, b: 0.85, seg: 11, prof: 'fish',   arch: 0.08, droop: 0.00, wide: 0.15, neck: 2.20, nx: 0.50, ny: 0.80, ns: 7, head: 0.34, snx: 0.70, snr: 0.45, tail: 0.9, tailR: 0.24, ts: 6, stand: 0.80 },  // 21 plesiosaur
    // ---- mythical plans ---------------------------------------------------
    // Invented animals rather than reconstructions. Silhouette first: each one
    // has to be recognisable as a black shape at fifty paces.
    { a: 1.15, b: 0.70, seg: 11, prof: 'insect', arch: 0.05, droop: 0.00, wide: 0.55, neck: 0.05, nx: 0.95, ny: 0.25, ns: 2, head: 0.34, snx: 0.45, snr: 0.42, tail: 2.1, tailR: 0.27, ts: 9, stand: 0.85, tailUp: 1.0 }, // 22 scorpion
    { a: 0.80, b: 0.50, seg: 9,  prof: 'round',  arch: 0.10, droop: 0.00, wide: 0,    neck: 1.15, nx: 0.45, ny: 0.95, ns: 5, head: 0.30, snx: 0.72, snr: 0.32, tail: 1.5, tailR: 0.13, ts: 7, stand: 3.10 }, // 23 stilt-walker
    { a: 1.30, b: 0.88, seg: 12, prof: 'animal', arch: 0.16, droop: 0.06, wide: 0.22, neck: 2.95, nx: 0.40, ny: 0.92, ns: 9, head: 0.32, snx: 0.62, snr: 0.42, tail: 1.9, tailR: 0.22, ts: 9, stand: 1.35 }, // 24 hydra
    { a: 1.05, b: 0.48, seg: 11, prof: 'insect', arch: 0.22, droop: 0.00, wide: 0,    neck: 0.85, nx: 0.55, ny: 0.88, ns: 4, head: 0.30, snx: 0.50, snr: 0.34, tail: 1.6, tailR: 0.24, ts: 7, stand: 1.85 }, // 25 mantis
    { a: 0.95, b: 0.78, seg: 9,  prof: 'round',  arch: 0.06, droop: 0.00, wide: 0.88, neck: 0.05, nx: 0.95, ny: 0.20, ns: 2, head: 0.36, snx: 0.40, snr: 0.46, tail: 0.3, tailR: 0.20, ts: 4, stand: 0.95 }, // 26 crab
    { a: 1.10, b: 1.05, seg: 11, prof: 'animal', arch: 0.34, droop: 0.10, wide: 0.30, neck: 0.30, nx: 0.70, ny: 0.55, ns: 2, head: 0.52, snx: 0.55, snr: 0.62, tail: 0.4, tailR: 0.26, ts: 4, stand: 1.70 }, // 27 brute
    { a: 0.85, b: 1.10, seg: 9,  prof: 'blob',   arch: 0.18, droop: 0.00, wide: 0.40, neck: 0.10, nx: 0.90, ny: 0.50, ns: 2, head: 0.44, snx: 0.36, snr: 0.58, tail: 2.0, tailR: 0.15, ts: 9, stand: 0.70 }, // 28 drifter
    { a: 2.05, b: 0.54, seg: 18, prof: 'tube',   arch: 0.00, droop: 0.00, wide: 0,    neck: 0.55, nx: 0.80, ny: 0.55, ns: 3, head: 0.46, snx: 0.68, snr: 0.50, tail: 2.3, tailR: 0.34, ts: 10, stand: 0.62, flex: 1 }, // 29 wyrm
  ];""")

# ---------------------------------------------------------------- 3. hides
s = sub1(s, """    { base: [0.28, 0.36, 0.36], coat: [0.76, 0.80, 0.76], detail: [0.18, 0.22, 0.24], pat: 1 },  // plesiosaur
  ];""",
"""    { base: [0.28, 0.36, 0.36], coat: [0.76, 0.80, 0.76], detail: [0.18, 0.22, 0.24], pat: 1 },  // plesiosaur
    // mythical: dark chitin and wet hide, pale undersides, one hot display colour
    { base: [0.22, 0.20, 0.24], coat: [0.52, 0.47, 0.44], detail: [0.86, 0.62, 0.10], pat: 0 },  // 22 scorpion
    { base: [0.30, 0.28, 0.30], coat: [0.62, 0.60, 0.58], detail: [0.72, 0.70, 0.66], pat: 0 },  // 23 stilt-walker
    { base: [0.20, 0.30, 0.30], coat: [0.54, 0.62, 0.58], detail: [0.16, 0.52, 0.46], pat: 1 },  // 24 hydra
    { base: [0.24, 0.32, 0.20], coat: [0.58, 0.66, 0.44], detail: [0.84, 0.86, 0.30], pat: 2 },  // 25 mantis
    { base: [0.28, 0.24, 0.26], coat: [0.60, 0.54, 0.50], detail: [0.72, 0.26, 0.20], pat: 3 },  // 26 crab
    { base: [0.26, 0.24, 0.22], coat: [0.54, 0.50, 0.44], detail: [0.70, 0.30, 0.16], pat: 3 },  // 27 brute
    { base: [0.30, 0.26, 0.38], coat: [0.68, 0.62, 0.78], detail: [0.60, 0.34, 0.92], pat: 1 },  // 28 drifter
    { base: [0.22, 0.26, 0.32], coat: [0.56, 0.60, 0.64], detail: [0.36, 0.72, 0.74], pat: 1 },  // 29 wyrm
  ];""")
s = sub1(s, "  const PLAN_SKIN = [1, 3, 1, 1, 3, 4, 1, 2, 4, 0,  1, 2, 1, 1, 4, 1, 1, 1, 2, 0, 0, 0];",
"""  const PLAN_SKIN = [1, 3, 1, 1, 3, 4, 1, 2, 4, 0,  1, 2, 1, 1, 4, 1, 1, 1, 2, 0, 0, 0,
  //                 scorpion stilt hydra mantis crab brute drifter wyrm
                     4, 1, 1, 4, 4, 3, 0, 1];""")

open(p, 'w', encoding='utf-8').write(s)
print('plans: table ok')

# ---------------------------------------------------------------- 4. what each one is born as
s = open(p, encoding='utf-8').read()

# a many-legged plan needs the same splayed-leg loop three of the old plans
# already wrote out by hand, so it is a helper now rather than a fourth copy
ANCHOR_HR = "    const hr = head.r;\n    const eyeAt = (id, s, up, fwd, side) =>"
s = sub1(s, ANCHOR_HR,
"""    // A row of paired legs down the body, splayed out sideways and planted on
    // the ground: how every arthropod in the game stands. Was written out
    // three times before this; the mythical plans would have made it six.
    const legRow = (id, us, opt2) => {
      const o = opt2 || {};
      for (const u of us) {
        const h = surfaceAt(sk, a * u, (o.up || 0) * b, b * (o.out || 0.8), 0, o.dn == null ? 0.1 : o.dn, 1);
        if (!h) continue;
        const key = mkey++;
        const spread = u * (o.rake == null ? 1.1 : o.rake);
        for (const sg of [1, -1]) {
          const lb = { id, b: 0, o: [0, 0, 0], n: [0, 0, sg],
                       k: [spread * 0.35, o.knee == null ? 0.75 : o.knee, (o.kz == null ? 0.95 : o.kz) * sg],
                       f: [spread * 0.8, -st - h.p[1], (o.reach == null ? 1.85 : o.reach) * sg],
                       th: o.th == null ? 0.85 : o.th, c: null,
                       tip: o.tip ? { id: (opt.map ? opt.map(o.tip) : o.tip), c: null, s: o.tipS || 1 } : null, m: key };
          const rp = [h.p[0], h.p[1], h.p[2] * sg], rn = [h.n[0], h.n[1], h.n[2] * sg];
          setAnchor(sk, lb, rp, rn, nearestBall(sk, rp[0], rp[1], rp[2], false));
          d.limbs.push(lb);
        }
      }
    };
    const hr = head.r;
    const eyeAt = (id, s, up, fwd, side) =>""")

s = sub1(s, """      case 21: // plesiosaur: long neck and four paddles""",
"""      // ---- mythical ------------------------------------------------------
      case 22: // scorpion: low armoured carapace, eight legs, pincers, a tail over the back
        eyeAt('e_cluster', 0.7, 0.70, 0.30, 0.30); eyeAt('e_round', 0.45, 0.50, 0.55, 0.50);
        mouthAt('m_hook', 0.85);
        put('s_plate', -a * 0.15, b * 1.05, b * 0.30, 0, 1, 0.3, 1.25, true);
        put('s_plate', a * 0.35, b * 1.00, b * 0.26, 0.2, 1, 0.3, 1.0, true);
        legRow('l_thin', [0.42, 0.14, -0.14, -0.42], { out: 0.86, rake: 1.15, reach: 1.9, knee: 0.8, th: 0.8, tip: 't_talon' });
        // the pincers: short heavy arms carried out in front
        limb('l_thick', a * 0.62, b * 0.10, b * 0.52, a * 1.30, -st * 0.55, b * 0.95, 0.10, -0.20, 0.18, 't_pincer', 1.05);
        tailPut('s_spike', 1.7);
        break;
      case 23: // stilt-walker: a small body carried absurdly high on thin legs
        eyeAt('e_stalk', 0.8, 0.60, 0.35, 0.45); mouthAt('m_beak', 0.75);
        put('d_crest', head.x - hr * 0.2, head.y + hr, 0, -0.2, 1, 0, 0.9, false);
        limb('l_thin',  a * 0.40, -b * 0.15,  b * 0.45,  a * 0.50, -st,  b * 0.40, 0.30, 0.10, 0.02, 't_hoof', 0.55);
        limb('l_thin', -a * 0.42, -b * 0.15,  b * 0.45, -a * 0.52, -st,  b * 0.40, -0.30, 0.10, 0.02, 't_hoof', 0.55);
        break;
      case 24: // hydra: a low heavy body under one enormous neck
        eyeAt('e_slit', 0.8, 0.50, 0.30, 0.55); mouthAt('m_maw', 1.05);
        put('d_frill', head.x - hr * 0.55, head.y + hr * 0.5, hr * 0.5, -0.4, 0.7, 0.6, 1.15, true);
        put('d_antenna', head.x - hr * 0.1, head.y + hr, hr * 0.25, -0.1, 1, 0.3, 0.9, true);
        limb('l_leg',  a * 0.48, -b * 0.30,  b * 0.52,  a * 0.55, -st,  b * 0.70, 0.15, 0, 0.04, 't_paw', 1.05);
        limb('l_leg', -a * 0.50, -b * 0.30,  b * 0.52, -a * 0.55, -st,  b * 0.70, -0.15, 0, 0.04, 't_paw', 1.05);
        break;
      case 25: // mantis: upright, narrow, two scythe arms held up
        eyeAt('e_bug', 1.0, 0.45, 0.45, 0.60); mouthAt('m_hook', 0.8);
        put('d_antenna', head.x + hr * 0.25, head.y + hr, hr * 0.28, 0.35, 1, 0.3, 1.15, true);
        legRow('l_thin', [0.05, -0.32], { out: 0.75, rake: 0.9, reach: 1.35, knee: 0.9, th: 0.8, tip: 't_talon' });
        limb('l_thin', a * 0.66, b * 0.30, b * 0.42, a * 1.15, -b * 0.30, b * 0.75, 0.35, 0.45, 0.10, 't_claw', 0.72);
        break;
      case 26: // crab: wide flat plate, legs all round it, pincers forward
        eyeAt('e_stalk', 0.7, 0.85, 0.20, 0.35); mouthAt('m_hook', 0.8);
        put('s_shell', -a * 0.05, b * 1.05, 0, 0, 1, 0, 1.4, false);
        put('s_plate', a * 0.35, b * 0.85, b * 0.45, 0.2, 0.8, 0.5, 1.0, true);
        legRow('l_thin', [0.30, 0.00, -0.30], { out: 0.92, rake: 1.25, reach: 2.0, knee: 0.85, th: 0.9, tip: 't_talon' });
        limb('l_thick', a * 0.55, 0, b * 0.70, a * 1.25, -st * 0.5, b * 1.25, 0.15, -0.15, 0.25, 't_pincer', 1.1);
        break;
      case 27: // brute: hunched shoulders, long arms, short hips
        eyeAt('e_round', 0.75, 0.40, 0.35, 0.58); mouthAt('m_maw', 1.15);
        put('s_spike', -a * 0.25, b * 1.10, b * 0.45, -0.1, 0.9, 0.45, 1.3, true);
        put('s_spike', a * 0.05, b * 1.05, b * 0.55, 0.1, 0.85, 0.5, 1.05, true);
        put('h_ram', snout.x + snout.r * 0.1, snout.y + snout.r * 0.9, 0, 0.3, 1, 0, 0.9, false);
        limb('l_thick', -a * 0.30, -b * 0.35, b * 0.50, -a * 0.20, -st, b * 0.58, 0.28, 0.05, 0.04, 't_pad', 1.35);
        limb('l_thick',  a * 0.50,  b * 0.35, b * 0.70,  a * 0.90, -st * 0.92, b * 0.95, 0.10, -0.28, 0.16, 't_claw', 1.15);
        break;
      case 28: // drifter: a bell body with a curtain of tendrils, no legs at all
        eyeAt('e_cluster', 0.9, 0.55, 0.15, 0.40); mouthAt('m_grazer', 0.9);
        put('d_frill', -a * 0.10, b * 1.25, 0, 0, 1, 0, 1.35, false);
        put('d_antenna', a * 0.20, b * 0.20, b * 0.85, 0.1, -0.2, 1, 1.25, true);
        put('d_antenna', -a * 0.25, b * 0.10, b * 0.80, -0.2, -0.3, 1, 1.1, true);
        tailPut('d_antenna', 1.3);
        break;
      case 29: // wyrm: a long flexible body with a hood and a fluke
        eyeAt('e_slit', 0.95, 0.50, 0.30, 0.60); mouthAt('m_spino', 1.0);
        put('d_frill', head.x - hr * 0.7, head.y + hr * 0.35, hr * 0.62, -0.5, 0.5, 0.7, 1.3, true);
        put('f_dorsal', -a * 0.10, b * 1.15, 0, 0, 1, 0, 1.2, false);
        put('f_fin', a * 0.30, -b * 0.20, b * 0.92, 0, -0.3, 1, 0.9, true);
        tailPut('f_fluke', 1.0);
        break;
      case 21: // plesiosaur: long neck and four paddles""")

# ---------------------------------------------------------------- 5. in the picker
s = sub1(s, """const PLAN_NAMES = ['blob', 'quadruped', 'biped', 'serpent', 'crawler', 'glider', 'fish', 'tank', 'runner', 'grazer',
                    'theropod', 'raptor', 'sauropod', 'horned', 'armoured', 'plated', 'duckbill', 'sail-back',
                    'pterosaur', 'shark', 'whale', 'plesiosaur'];""",
"""// Kept for the tooltip and for anything that has to name a shape in prose.
// The picker itself shows silhouettes and no words.
const PLAN_NAMES = ['blob', 'quadruped', 'biped', 'serpent', 'crawler', 'glider', 'fish', 'tank', 'runner', 'grazer',
                    'theropod', 'raptor', 'sauropod', 'horned', 'armoured', 'plated', 'duckbill', 'sail-back',
                    'pterosaur', 'shark', 'whale', 'plesiosaur',
                    'scorpion', 'stilt-walker', 'hydra', 'mantis', 'crab', 'brute', 'drifter', 'wyrm'];""")
# the mythical shapes come first, because they are what the game is about now
s = sub1(s, """  { label: 'land', note: 'walks and runs. breathes air.', plans: [1, 2, 8, 9, 0, 3, 4, 10, 11, 12, 13, 14, 15, 16, 17] },
  { label: 'air', note: 'wings: flight once they beat your weight.', plans: [5, 7, 18] },
  { label: 'sea', note: 'no legs: breathes water, starts in the sea and cannot come ashore without lungs.', plans: [6, 19, 20, 21] },""",
"""  { label: 'land', note: 'walks and runs. breathes air.',
    plans: [22, 25, 27, 23, 24, 26, 28, 1, 2, 8, 9, 0, 3, 4, 10, 11, 12, 13, 14, 15, 16, 17] },
  { label: 'air', note: 'wings: flight once they beat your weight.', plans: [5, 7, 18] },
  { label: 'sea', note: 'no legs: breathes water, starts in the sea and cannot come ashore without lungs.', plans: [29, 6, 19, 20, 21] },""")

open(p, 'w', encoding='utf-8').write(s)
print('plans: bodies ok')

# ---------------------------------------------------------------- 6. the picker shows shapes, not words
# "Don't add names to the initial creature shapes, just have black outlines to
# show them." The thumbnail is already a render of the real body on a
# transparent ground, so a brightness(0) filter turns it into exactly that: a
# black silhouette of the animal you would actually get. Nothing is described;
# you pick the shape you like the look of.
s = open(p, encoding='utf-8').read()
s = sub1(s, """      for (const p of list) html += `<div class="edtile plan${ED.des.plan === p ? ' cur' : ''}${planLocked && ED.des.plan !== p ? ' locked' : ''}" data-plan="${p}" title="${PLAN_NAMES[p] || ''}">${tileHTML('plan' + p, !planLocked || ED.des.plan === p)}<span class="edcname2">${PLAN_NAMES[p] || ''}</span></div>`;""",
"""      for (const p of list) html += `<div class="edtile plan silho${ED.des.plan === p ? ' cur' : ''}${planLocked && ED.des.plan !== p ? ' locked' : ''}" data-plan="${p}" title="${PLAN_NAMES[p] || ''}">${tileHTML('plan' + p, !planLocked || ED.des.plan === p)}</div>`;""")
s = sub1(s, "  .edtile.locked img { filter: grayscale(.7) brightness(.82) contrast(1.05); opacity: .9; }",
"""  .edtile.locked img { filter: grayscale(.7) brightness(.82) contrast(1.05); opacity: .9; }
  /* body shapes read as black silhouettes: the shape is the whole description */
  .edtile.silho { background: #dfe8ec; }
  .edtile.silho img { filter: brightness(0) saturate(0); opacity: .92; }
  .edtile.silho:hover img { opacity: 1; }
  .edtile.silho.cur { background: #eefbe4; }
  .edtile.silho.locked img { filter: brightness(0) saturate(0); opacity: .34; }""")
s = sub1(s, "    else html += '<div class=\"edhint\">pick the skeleton: it sets your size, stance, neck and tail, and where parts can go</div>';",
            "    else html += '<div class=\"edhint\">pick a shape. it sets your size, stance, neck and tail, and where parts can go</div>';")

open(p, 'w', encoding='utf-8').write(s)
print('plans: silhouette picker ok')
