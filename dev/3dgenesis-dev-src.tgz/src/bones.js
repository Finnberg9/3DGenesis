// =====================================================================
// BONES: the parts economy.
//
// Bones are the currency. You earn them by killing, and you spend them in the
// shop to unlock a part outright instead of waiting for an animal that happens
// to carry one to walk past. Every part sits in one of five tiers, and that
// same tier decides three things at once: what it costs, what it sells back
// for, and how often a wild animal is born carrying it. So the ladder you pay
// is the ladder you hunt.
//
// Balances live in localStorage with the rest of the progress. They are NOT
// authoritative -- anyone can edit their own browser storage -- which is fine
// for single player and is exactly why the online mode has to settle bones on
// a server. BONES.remote is the seam for that.
// =====================================================================
const BONE_TIERS = ['weak', 'solid', 'super', 'ultra', 'alpha'];
const BONE_PRICE = { weak: 50, solid: 100, super: 200, ultra: 500, alpha: 2000 };
const BONE_SELL_PCT = 0.25;          // what you get back for a part you do not want
const BONES_PER_KILL = 5;
const BONE_TIER_LABEL = {
  weak: 'weak', solid: 'solid', super: 'super', ultra: 'ultra', alpha: 'alpha',
};
const BONE_TIER_COL = {
  weak: '#8fa39c', solid: '#6fb8a6', super: '#6aa6e8', ultra: '#c07be0', alpha: '#e8a13a',
};
// How likely a wild animal is to be born carrying a part of each tier,
// relative to a weak one. An alpha part on a wild body is a once-a-run event.
const BONE_TIER_WILD = { weak: 1, solid: 0.55, super: 0.18, ultra: 0.035, alpha: 0.004 };

// Every part, by tier. Deliberately hand-set rather than derived from genome
// cost: genome cost is how much room a part takes on a body, which is a
// different question from how badly you want one.
const ITEM_TIER = {
  // ---- weak: the starting kit. Cheap, common, on half the animals you meet.
  m_beak: 'weak', m_grazer: 'weak', e_round: 'weak', e_slit: 'weak',
  s_spike: 'weak', s_knob: 'weak', l_thin: 'weak', t_paw: 'weak', t_hoof: 'weak',
  t_pad: 'weak', t_flipper: 'weak', d_crest: 'weak', d_frill: 'weak', d_antenna: 'weak',
  // ---- solid: a working body. Real jaws, real legs, real fins.
  m_jaws: 'solid', m_hook: 'solid', m_duck: 'solid', e_big: 'solid', e_bug: 'solid',
  h_straight: 'solid', h_curved: 'solid', h_tusk: 'solid', s_quills: 'solid', s_plate: 'solid',
  l_leg: 'solid', t_talon: 'solid', t_claw: 'solid', f_fin: 'solid', f_dorsal: 'solid',
  d_gills: 'solid', d_lungs: 'solid',
  // ---- super: specialist kit that changes how you hunt or move.
  m_maw: 'super', m_trunk: 'super', m_short: 'super', e_stalk: 'super', e_cluster: 'super',
  h_ram: 'super', h_rhino: 'super', s_club: 'super', l_thick: 'super', l_spring: 'super',
  t_hand: 'super', t_pincer: 'super', f_fluke: 'super', w_insect: 'super', d_gland: 'super',
  // ---- ultra: flight, armour and the long killing jaws.
  m_spino: 'ultra', h_antler: 'ultra', s_shell: 'ultra', w_bat: 'ultra', w_feather: 'ultra',
  // ---- alpha: the apex bite. Almost never born wild.
  m_rex: 'alpha',
};
function boneTier(id) { return ITEM_TIER[id] || 'solid'; }
function bonePrice(id) { return BONE_PRICE[boneTier(id)]; }
function boneRefund(id) { return Math.floor(bonePrice(id) * BONE_SELL_PCT); }
function boneTierIdx(t) { return BONE_TIERS.indexOf(t); }

// A missing entry would silently price a part at the 'solid' default, so the
// table is checked against the simulation's own item list once at start-up.
function boneAuditTiers() {
  const sim = (typeof C !== 'undefined' && C.ITEM_SIM) ? C.ITEM_SIM : null;
  if (!sim) return null;
  const missing = Object.keys(sim).filter(id => !ITEM_TIER[id]);
  const extra = Object.keys(ITEM_TIER).filter(id => !sim[id]);
  if (missing.length) console.warn('bones: no tier for', missing.join(', '), '-- priced as solid');
  if (extra.length) console.warn('bones: tier for unknown part', extra.join(', '));
  return { missing, extra };
}

// ---- balance ---------------------------------------------------------------
// BONES.remote is null in single player. An online match sets it to an object
// with credit/debit that talk to the server, and then nothing here touches the
// local balance: the server's number is the only one that counts.
const BONES = { remote: null, spentAt: 0 };
function boneBalance() {
  if (BONES.remote) return BONES.remote.balance | 0;
  return PROG.bones | 0;
}
function boneEarn(n, why) {
  n = Math.max(0, n | 0);
  if (!n) return 0;
  if (BONES.remote) { BONES.remote.credit(n, why); return n; }
  PROG.bones = (PROG.bones | 0) + n;
  saveProgress();
  boneHudFlash('+' + n);
  return n;
}
// Returns true only if the whole amount was taken. Never goes negative.
function boneSpend(n, why) {
  n = Math.max(0, n | 0);
  if (BONES.remote) return !!BONES.remote.debit(n, why);
  if ((PROG.bones | 0) < n) return false;
  PROG.bones = (PROG.bones | 0) - n;
  saveProgress();
  boneHudFlash('-' + n);
  return true;
}
// Buying a part unlocks it for good, exactly as a kill would.
function boneBuy(id) {
  if (!VIS[id]) return { ok: false, msg: 'No such part.' };
  if (isUnlocked(id)) return { ok: false, msg: 'You already own the ' + VIS[id].name + '.' };
  const price = bonePrice(id);
  if (boneBalance() < price) return { ok: false, msg: 'Not enough bones: the ' + VIS[id].name + ' costs ' + price + '.' };
  if (!boneSpend(price, 'buy:' + id)) return { ok: false, msg: 'Purchase failed.' };
  PROG.unlocked.add(id);
  PROG.bought = PROG.bought || [];
  if (!PROG.bought.includes(id)) PROG.bought.push(id);
  saveProgress();
  return { ok: true, msg: 'Bought the ' + VIS[id].name + ' for ' + price + ' bones.', price };
}
// Selling gives back a quarter, rounded down, and takes the part off you. A
// part the body you are editing is actually wearing cannot be sold out from
// under it.
function boneSell(id) {
  if (!VIS[id]) return { ok: false, msg: 'No such part.' };
  if (!PROG.unlocked.has(id)) return { ok: false, msg: 'You do not own the ' + VIS[id].name + '.' };
  if (ED.des && countItem(ED.des, id) > 0) {
    return { ok: false, msg: 'Your creature is wearing the ' + VIS[id].name + '. Take it off first.' };
  }
  const back = boneRefund(id);
  PROG.unlocked.delete(id);
  if (PROG.bought) PROG.bought = PROG.bought.filter(q => q !== id);
  boneEarn(back, 'sell:' + id);
  saveProgress();
  return { ok: true, msg: 'Sold the ' + VIS[id].name + ' for ' + back + ' bones.', back };
}

// ---- per-world rarity ------------------------------------------------------
// Every island (and every match) rolls a ceiling on what the wild can carry.
// Most worlds top out below alpha, and a fair few below ultra too, so finding
// an alpha part in the wild is a thing that happens to a run, not a thing you
// farm. The roll is a pure function of the seed, so the same seed is the same
// world.
function worldRarityCap(seed) {
  let h = (seed | 0) >>> 0;
  h = Math.imul(h ^ (h >>> 16), 2246822519) >>> 0;
  h = Math.imul(h ^ (h >>> 13), 3266489917) >>> 0;
  const r = ((h ^ (h >>> 16)) >>> 0) / 4294967296;
  if (r < 0.18) return 'super';        // 18%: no ultra parts anywhere in this world
  if (r < 0.82) return 'ultra';        // 64%: no alpha parts
  return 'alpha';                      // 18%: everything can appear
}
function rarityCapLabel(cap) {
  if (cap === 'alpha') return 'rich: every part can be born here, alpha included';
  if (cap === 'ultra') return 'normal: no alpha parts are born on this island';
  return 'poor: no ultra or alpha parts are born on this island';
}
// Weight for a part appearing on a wild body: its tier's rarity, or zero if
// the world rolled a ceiling below it.
function boneWildWeight(id, cap) {
  const t = boneTier(id);
  if (boneTierIdx(t) > boneTierIdx(cap || 'ultra')) return 0;
  return BONE_TIER_WILD[t] || 0;
}
// Pick from [[id, weight], ...] with the tier rarity folded in. Falls back to
// the plain weights if the cap removed everything, so a caller can never be
// handed nothing.
function boneWeighted(rng, opts, cap) {
  let tot = 0;
  const w = [];
  for (const [id, base] of opts) { const k = base * boneWildWeight(id, cap); w.push(k); tot += k; }
  if (tot <= 0) {
    let t2 = 0; for (const [, base] of opts) t2 += base;
    let r2 = rng() * t2;
    for (const [id, base] of opts) { r2 -= base; if (r2 <= 0) return id; }
    return opts[0][0];
  }
  let r = rng() * tot;
  for (let i = 0; i < opts.length; i++) { r -= w[i]; if (r <= 0) return opts[i][0]; }
  return opts[opts.length - 1][0];
}

// ---- real-money bundles ----------------------------------------------------
// Listed because the prices are decided, disabled because taking money needs a
// payment processor and a server-side account to credit. Nothing here mints
// bones: a button that handed them out for free would wreck the economy the
// rest of this file exists to keep honest.
const BONE_BUNDLES = [
  { bones: 100, usd: 2, label: 'handful' },
  { bones: 500, usd: 5, label: 'sack' },
  { bones: 10000, usd: 30, label: 'ossuary' },
];
const BONE_BUNDLES_LIVE = false;

// ---- HUD -------------------------------------------------------------------
const BONE_HUD = { flash: '', t: 0 };
function boneHudFlash(s) { BONE_HUD.flash = s; BONE_HUD.t = performance.now(); }
function boneHudHtml() {
  const f = BONE_HUD.flash && performance.now() - BONE_HUD.t < 1600 ? BONE_HUD.flash : '';
  return '<span class="boneN">' + boneBalance() + '</span> bones' +
         (f ? ' <span class="boneF">' + f + '</span>' : '');
}
