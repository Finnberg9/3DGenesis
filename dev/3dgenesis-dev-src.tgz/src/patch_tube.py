# tapered tube primitive: smooth limbs, tails and trunks
def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
s=open('g3.html',encoding='utf-8').read()
s=sub1(s,"""// Cone: unit radius at the base (y=0), apex at y=1.""","""// Frustum: radius 1 at y=0 tapering to TUBE_TAPER at y=1, smooth sides, no caps
// (joint spheres cover the ends). One mesh for every limb, tail and trunk segment.
const TUBE_TAPER = 0.74;
function makeFrustum(seg) {
  const v = [], idx = [];
  // unit cylinder; the per-instance taper is applied in WGSL_TUBE
  for (let j = 0; j <= 1; j++) {
    for (let i = 0; i <= seg; i++) {
      const th = (i / seg) * Math.PI * 2, cx = Math.cos(th), cz = Math.sin(th);
      v.push(cx, j, cz, cx, 0, cz);
    }
  }
  for (let i = 0; i < seg; i++) { const a = i, b = i + seg + 1; idx.push(a, b, a + 1, a + 1, b, b + 1); }
  return { v: new Float32Array(v), idx: new Uint16Array(idx) };
}
// Cone: unit radius at the base (y=0), apex at y=1.""")
s=sub1(s,"""  const cn = makeCone(14);""","""  const fr = makeFrustum(18);
  tubeMeshCount = fr.idx.length;
  tubeVB = dev.createBuffer({ size: fr.v.byteLength, usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST });
  dev.queue.writeBuffer(tubeVB, 0, fr.v);
  tubeIB = dev.createBuffer({ size: fr.idx.byteLength, usage: GPUBufferUsage.INDEX | GPUBufferUsage.COPY_DST });
  dev.queue.writeBuffer(tubeIB, 0, fr.idx);
  tubeInstVB = dev.createBuffer({ size: tubeData.byteLength, usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST });
  const cn = makeCone(14);""")
s=sub1(s,"""const MAX_SPIKE_INST = 30000;""","""const MAX_SPIKE_INST = 30000;
const MAX_TUBE_INST = 40000;
const tubeData = new Float32Array(MAX_TUBE_INST * INST_FLOATS);
let tubeN = 0, tubeVB, tubeIB, tubeMeshCount = 0, tubeInstVB;
// tube from a (radius r) to b (radius r1, default r * TUBE_TAPER)
function pushT(ax, ay, az, bx, by, bz, r, col, r1) {
  if (tubeN >= MAX_TUBE_INST) return;
  const dx = bx - ax, dy = by - ay, dz = bz - az, L = Math.hypot(dx, dy, dz);
  if (L < 1e-6) return;
  const o = tubeN * INST_FLOATS;
  tubeData[o] = ax; tubeData[o+1] = ay; tubeData[o+2] = az;
  tubeData[o+3] = dx / L; tubeData[o+4] = dy / L; tubeData[o+5] = dz / L;
  tubeData[o+6] = r; tubeData[o+7] = L; tubeData[o+8] = r;
  tubeData[o+9] = col[0]; tubeData[o+10] = col[1]; tubeData[o+11] = col[2];
  tubeData[o+12] = r > 1e-9 ? (r1 != null ? r1 : r * TUBE_TAPER) / r : 1; tubeData[o+13] = 0; tubeData[o+14] = 0;
  tubeN++;
}
function drawTubes(pass) {
  if (!tubeN) return;
  dev.queue.writeBuffer(tubeInstVB, 0, tubeData, 0, tubeN * INST_FLOATS);
  pass.setPipeline(tubePipe); pass.setBindGroup(0, bindG.tube);
  pass.setVertexBuffer(0, tubeVB); pass.setIndexBuffer(tubeIB, 'uint16');
  pass.setVertexBuffer(1, tubeInstVB); pass.drawIndexed(tubeMeshCount, tubeN);
}""")
# the instanced pipeline culls back faces; tube sides are single-sided and wound outward
s=sub1(s,"""  instCount = 0; spikeCount = 0;
  bodyBatches.length = 0;""","""  instCount = 0; spikeCount = 0; tubeN = 0;
  bodyBatches.length = 0;""")
s=sub1(s,"""  if (nInst)  { pass.setVertexBuffer(1, instVB);  pass.drawIndexed(sphCount, nInst); }""","""  if (nInst)  { pass.setVertexBuffer(1, instVB);  pass.drawIndexed(sphCount, nInst); }
  drawTubes(pass);
  pass.setPipeline(instPipe); pass.setBindGroup(0, bindG.inst);""")
s=sub1(s,"""const WGSL_BODY = WGSL_COMMON + `""","""const WGSL_TUBE = WGSL_COMMON + `
struct VO { @builtin(position) pos: vec4<f32>, @location(0) nrm: vec3<f32>,
            @location(1) col: vec3<f32>, @location(2) wpos: vec3<f32> };
fn basisOf(d: vec3<f32>) -> mat3x3<f32> {
  let up = select(vec3<f32>(0.0, 0.0, 1.0), vec3<f32>(0.0, 1.0, 0.0), abs(d.y) < 0.9);
  let x = normalize(cross(up, d));
  let z = cross(d, x);
  return mat3x3<f32>(x, d, z);
}
@vertex fn vs(@location(0) p: vec3<f32>, @location(1) n: vec3<f32>,
              @location(2) iPos: vec3<f32>, @location(3) iDir: vec3<f32>,
              @location(4) iScl: vec3<f32>, @location(5) iCol: vec3<f32>,
              @location(6) iXh: vec3<f32>) -> VO {
  let B = basisOf(normalize(iDir));
  let t = iXh.x;
  let s = mix(1.0, t, p.y);
  let q = vec3<f32>(p.x * s * iScl.x, p.y * iScl.y, p.z * s * iScl.z);
  let w = B * q + iPos;
  let slope = (1.0 - t) * iScl.x / max(iScl.y, 1e-4);
  let nn = B * normalize(vec3<f32>(n.x, slope, n.z));
  var o: VO; o.pos = g.viewProj * vec4<f32>(w, 1.0);
  o.nrm = normalize(nn); o.col = iCol; o.wpos = w; return o;
}
@fragment fn fs(i: VO) -> @location(0) vec4<f32> {
  return vec4<f32>(shade(i.col, i.nrm, i.wpos), 1.0);
}`;
const WGSL_BODY = WGSL_COMMON + `""")
s=sub1(s,"""  const bm = dev.createShaderModule({ code: WGSL_BODY });""","""  const tbm = dev.createShaderModule({ code: WGSL_TUBE });
  tubePipe = dev.createRenderPipeline({
    layout: 'auto',
    vertex: { module: tbm, entryPoint: 'vs', buffers: [
      { arrayStride: 24, attributes: [
        { shaderLocation: 0, offset: 0,  format: 'float32x3' },
        { shaderLocation: 1, offset: 12, format: 'float32x3' }] },
      { arrayStride: INST_FLOATS * 4, stepMode: 'instance', attributes: [
        { shaderLocation: 2, offset: 0,  format: 'float32x3' },
        { shaderLocation: 3, offset: 12, format: 'float32x3' },
        { shaderLocation: 4, offset: 24, format: 'float32x3' },
        { shaderLocation: 5, offset: 36, format: 'float32x3' },
        { shaderLocation: 6, offset: 48, format: 'float32x3' }] } ] },
    fragment: { module: tbm, entryPoint: 'fs', targets: [{ format: fmt }] },
    primitive: { topology: 'triangle-list', cullMode: 'none' },
    depthStencil: depthState, multisample: MS,
  });
  const bm = dev.createShaderModule({ code: WGSL_BODY });""")
s=sub1(s,"let terrainPipe, instPipe, waterPipe, bodyPipe, unlitPipe, bindG;","let terrainPipe, instPipe, waterPipe, bodyPipe, unlitPipe, tubePipe, overPipe, bindG;")
# instanced spheres drawn over everything (editor joint handles)
s=sub1(s,"""  const bm = dev.createShaderModule({ code: WGSL_BODY });""","""  overPipe = dev.createRenderPipeline({
    layout: 'auto',
    vertex: { module: im, entryPoint: 'vs', buffers: [
      { arrayStride: 24, attributes: [
        { shaderLocation: 0, offset: 0,  format: 'float32x3' },
        { shaderLocation: 1, offset: 12, format: 'float32x3' }] },
      { arrayStride: INST_FLOATS * 4, stepMode: 'instance', attributes: [
        { shaderLocation: 2, offset: 0,  format: 'float32x3' },
        { shaderLocation: 3, offset: 12, format: 'float32x3' },
        { shaderLocation: 4, offset: 24, format: 'float32x3' },
        { shaderLocation: 5, offset: 36, format: 'float32x3' },
        { shaderLocation: 6, offset: 48, format: 'float32x3' }] } ] },
    fragment: { module: im, entryPoint: 'fs', targets: [{ format: fmt }] },
    primitive: { topology: 'triangle-list', cullMode: 'back' },
    depthStencil: { format: 'depth24plus', depthWriteEnabled: false, depthCompare: 'always' }, multisample: MS,
  });
  const bm = dev.createShaderModule({ code: WGSL_BODY });""",1)
s=sub1(s,"""    unlit:   dev.createBindGroup({ layout: unlitPipe.getBindGroupLayout(0),   entries: [{ binding: 0, resource: { buffer: gBuf } }] }),""","""    unlit:   dev.createBindGroup({ layout: unlitPipe.getBindGroupLayout(0),   entries: [{ binding: 0, resource: { buffer: gBuf } }] }),
    tube:    dev.createBindGroup({ layout: tubePipe.getBindGroupLayout(0),    entries: [{ binding: 0, resource: { buffer: gBuf } }] }),
    over:    dev.createBindGroup({ layout: overPipe.getBindGroupLayout(0),    entries: [{ binding: 0, resource: { buffer: gBuf } }] }),""")
open('g3.html','w',encoding='utf-8').write(s)
print('tube ok')
