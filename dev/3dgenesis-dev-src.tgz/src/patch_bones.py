# BONES: the parts economy. Currency earned by killing, spent in a shop in the
# builder to unlock parts outright, sold back at a quarter. Five tiers price
# every part, and the same tier decides how often the wild carries one, with a
# per-world ceiling rolled from the seed. See src/bones.js.
def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
p='g3.html'; s=open(p,encoding='utf-8').read()

# ---------------------------------------------------------------- module
s=sub1(s,"loadProgress();\n", "loadProgress();\n"+open('src/bones.js',encoding='utf-8').read()+"\n")

# ---------------------------------------------------------------- persistence
s=sub1(s,"const PROG = { kills: 0, unlocked: new Set(STARTER_ITEMS), saved: [], last: null };",
         "const PROG = { kills: 0, bones: 0, bought: [], unlocked: new Set(STARTER_ITEMS), saved: [], last: null };")
s=sub1(s,"      PROG.kills = Math.max(0, (o.kills | 0));",
"""      PROG.kills = Math.max(0, (o.kills | 0));
      PROG.bones = Math.max(0, (o.bones | 0));
      if (Array.isArray(o.bought)) PROG.bought = o.bought.filter(id => typeof id === 'string');""")
s=sub1(s,"      kills: PROG.kills, unlocked: [...PROG.unlocked], saved: PROG.saved, last: PROG.last,",
         "      kills: PROG.kills, bones: PROG.bones | 0, bought: PROG.bought || [], unlocked: [...PROG.unlocked], saved: PROG.saved, last: PROG.last,")

# ---------------------------------------------------------------- earning
s=sub1(s,"""function edOnKill(prey) {
  PROG.kills++;""","""function edOnKill(prey) {
  PROG.kills++;
  boneEarn(BONES_PER_KILL, 'kill');""")
s=sub1(s,"""  if (!opts.length) { toast('Killed it. +' + KILL_SPACE + ' genome space.', 2600); return; }
  player.picker = { opts, label: 'You killed it: +' + KILL_SPACE + ' genome space. Take one of its parts', t0: performance.now(), items: true };""",
"""  if (!opts.length) { toast('Killed it. +' + KILL_SPACE + ' genome space, +' + BONES_PER_KILL + ' bones.', 2600); return; }
  player.picker = { opts, label: 'You killed it: +' + KILL_SPACE + ' genome space, +' + BONES_PER_KILL + ' bones. Take one of its parts', t0: performance.now(), items: true };""")

# ---------------------------------------------------------------- per-world rarity
# The cap is rolled from the world seed and read by every wild-body roll.
s=sub1(s,"""  function randomDesign(rng, opt) {
    opt = opt || {};""","""  function randomDesign(rng, opt) {
    opt = opt || {};
    // The world's rarity ceiling, handed down by the caller. Falls back to
    // 'ultra' (no alpha) so a design rolled outside a world is never richer
    // than an ordinary island.
    const rcap = opt.rarityCap || (DESIGN_API.rarityCap || 'ultra');
    const wpick = (o) => (DESIGN_API.boneWeighted ? DESIGN_API.boneWeighted(rng, o, rcap) : pickW(rng, o));""")
# richer wild pools, thinned by tier
s=sub1(s,"""    const eye = pi === 4 || pi === 5 ? pickW(rng, [['e_bug', 2], ['e_round', 1], ['e_cluster', 1]])
              : pi === 9 ? pickW(rng, [['e_stalk', 2], ['e_round', 1], ['e_big', 0.5]])
              : pickW(rng, [['e_round', 3], ['e_slit', 2.2], ['e_big', 0.8], ['e_stalk', 0.25]]);
    const mouth = carn ? pickW(rng, [['m_jaws', 3], ['m_maw', 1]]) : pickW(rng, [['m_beak', 2], ['m_grazer', 3], ['m_trunk', 0.35]]);""",
"""    const eye = pi === 4 || pi === 5 ? wpick([['e_bug', 2], ['e_round', 1], ['e_cluster', 1]])
              : pi === 9 ? wpick([['e_stalk', 2], ['e_round', 1], ['e_big', 0.5]])
              : wpick([['e_round', 3], ['e_slit', 2.2], ['e_big', 0.8], ['e_stalk', 0.25], ['e_cluster', 0.3]]);
    // Hunters can now be born with the whole jaw ladder, down to the apex
    // crushing jaw. The tier weights make that vanishingly rare, and the
    // world's ceiling may forbid it outright.
    const mouth = carn ? wpick([['m_jaws', 3], ['m_maw', 1.2], ['m_hook', 0.8], ['m_short', 0.7], ['m_spino', 0.5], ['m_rex', 0.4]])
                       : wpick([['m_beak', 2], ['m_grazer', 3], ['m_duck', 1.1], ['m_trunk', 0.35]]);""")
s=sub1(s,"""      if (id === 't_paw' || id === 't_hoof') return carn ? pickW(rng, [['t_paw', 2], ['t_claw', 1.5], ['t_talon', 1]]) : pickW(rng, [['t_paw', 2], ['t_hoof', 2], ['t_pad', 1]]);
      if (id === 't_claw') return carn ? pickW(rng, [['t_claw', 2], ['t_pincer', 1], ['t_hand', 1]]) : pickW(rng, [['t_hand', 2], ['t_paw', 1], ['t_claw', 0.5]]);
      if (id === 't_talon') return pickW(rng, [['t_talon', 2], ['t_paw', 1]]);""",
"""      if (id === 't_paw' || id === 't_hoof') return carn ? wpick([['t_paw', 2], ['t_claw', 1.5], ['t_talon', 1]]) : wpick([['t_paw', 2], ['t_hoof', 2], ['t_pad', 1]]);
      if (id === 't_claw') return carn ? wpick([['t_claw', 2], ['t_pincer', 1], ['t_hand', 1]]) : wpick([['t_hand', 2], ['t_paw', 1], ['t_claw', 0.5]]);
      if (id === 't_talon') return wpick([['t_talon', 2], ['t_paw', 1]]);""")
s=sub1(s,"""    const spring = (pi === 0 || pi === 2 || pi === 7) && rng() < 0.14;""",
"""    const spring = (pi === 0 || pi === 2 || pi === 7) && rng() < 0.14
                   && (!DESIGN_API.boneWildWeight || DESIGN_API.boneWildWeight('l_spring', rcap) > 0);""")
s=sub1(s,"    const nOrn = Math.floor(rng() * (1 + div * 3.2));\n    if (nOrn) addOrnaments(d, rng, nOrn);",
         "    const nOrn = Math.floor(rng() * (1 + div * 3.2));\n    if (nOrn) addOrnaments(d, rng, nOrn, rcap);")
# ornaments: same ladder
s=sub1(s,"  function addOrnaments(d, rng, n) {","""  function addOrnaments(d, rng, n, rarityCap) {
    const ocap = rarityCap || DESIGN_API.rarityCap || 'ultra';
    const opick = (o) => (DESIGN_API.boneWeighted ? DESIGN_API.boneWeighted(rng, o, ocap) : pickW(rng, o));""")
s=sub1(s,"        const id = pickW(rng, [['s_spike', 3], ['s_plate', 2], ['s_quills', 1.2]]);",
         "        const id = opick([['s_spike', 3], ['s_plate', 2], ['s_quills', 1.2], ['s_shell', 0.9]]);")
s=sub1(s,"        const id = pickW(rng, [['h_straight', 2], ['h_curved', 2], ['h_ram', 1], ['h_antler', 1], ['h_tusk', 0.6]]);",
         "        const id = opick([['h_straight', 2], ['h_curved', 2], ['h_ram', 1.4], ['h_antler', 1.6], ['h_tusk', 0.6], ['h_rhino', 1.2]]);")
s=sub1(s,"    ITEM_SIM, ITEM_SINGLE, PLANS, BODY_RANGE, planProfile, buildDesignSkeleton, skinField, raySkin, snapToSkin,",
         "    ITEM_SIM, ITEM_SINGLE, PLANS, BODY_RANGE, planProfile, buildDesignSkeleton, skinField, raySkin, snapToSkin, rarityCap: 'ultra',")
# DESIGN_API's properties are SPREAD onto the export, so C.DESIGN_API would not
# exist and every write to it would be swallowed. Export the object itself.
s=sub1(s,"    ...DESIGN_API,", "    ...DESIGN_API,\n    DESIGN_API,")
# hand the page's rarity helpers to the (DOM-free) core, and set the cap per world
s=sub1(s,"loadProgress();\n"+open('src/bones.js',encoding='utf-8').read()+"\n",
        "loadProgress();\n"+open('src/bones.js',encoding='utf-8').read()+"""
// The simulation core is DOM-free and has no idea what a bone is, so the
// rarity ladder is handed to it rather than imported by it.
if (!C.DESIGN_API) {
  console.error('bones: the core did not export DESIGN_API -- wild rarity is OFF');
} else {
  C.DESIGN_API.boneWeighted = boneWeighted;
  C.DESIGN_API.boneWildWeight = boneWildWeight;
}
boneAuditTiers();
// Returns the cap; the caller sets it on the world it is building. (Setting
// `world` from in here would hit the page-level binding, which during
// makeWorld() is still the PREVIOUS world.)
function boneApplyWorldRarity(seed) {
  const cap = worldRarityCap(seed | 0);
  if (C.DESIGN_API) C.DESIGN_API.rarityCap = cap;
  return cap;
}
""")
open(p,'w',encoding='utf-8').write(s)
print('bones core ok')
s=open(p,encoding='utf-8').read()

# ---- the cap has to be set BEFORE the founders are designed -------------------
# The core is a separate scope, so it cannot call back into the page: the page
# rolls the cap from the seed and passes it in with the rest of the world opts.
s=s.replace(
  "world = C.makeWorld(Object.assign({ w: WORLD_W, h: WORLD_H, tileSize: TILE, seed, featureScale: 2, heightScale: HEIGHT_SCALE, maxSlope: 1, baseRelief: 0.35, plantArea: 0.5 }, panelOpts()));",
  "world = C.makeWorld(Object.assign({ w: WORLD_W, h: WORLD_H, tileSize: TILE, seed, rarityCap: boneApplyWorldRarity(seed), featureScale: 2, heightScale: HEIGHT_SCALE, maxSlope: 1, baseRelief: 0.35, plantArea: 0.5 }, panelOpts()));")
assert s.count("rarityCap: boneApplyWorldRarity(seed)") == 2, s.count("rarityCap: boneApplyWorldRarity(seed)")
# and the world remembers what it rolled
s=sub1(s,"""    world.forest = buildForest(terrain, w, h, world.params.treeDensity || 1);""",
"""    world.rarityCap = (opts && opts.rarityCap) || 'ultra';
    world.forest = buildForest(terrain, w, h, world.params.treeDensity || 1);""")
open(p,'w',encoding='utf-8').write(s)
print('bones rarity hook ok')

# ---------------------------------------------------------------- buying in the palette
# Buying is not a separate screen. A locked card in the right-hand palette
# carries its own price and its own button: you buy the part where you were
# already looking at it, and it unlocks in place. Selling is on the card you
# own, behind a confirm so a mis-click cannot cost you a part.
s=open(p,encoding='utf-8').read()
s=sub1(s,"""    <button id="edSaved">my creatures</button>""",
"""    <button id="edSaved">my creatures</button>
    <span id="edBones" title="5 bones for every kill. Bundles (100 for $2, 500 for $5, 10000 for $30) need an account server, which this build does not have."><b id="edBoneN">0</b> bones</span>""")
s=sub1(s,"""            flash: $('edFlash'), tip: $('edTip'), dragImg, saved: $('edSavedBox'), title: $('edTabTitle') };""",
"""            flash: $('edFlash'), tip: $('edTip'), dragImg, saved: $('edSavedBox'), title: $('edTabTitle') };""")
s=sub1(s,"""  edRenderSaved();
}
function edSkinAllowed(i) {""","""  edRenderSaved();
  { const b = $('edBoneN'); if (b) b.textContent = boneBalance(); }
}
function edSkinAllowed(i) {""")
# the card itself: price line, buy button, sell on what you own
s=sub1(s,"""      const av = itemAvailable(id);
      const v = VIS[id];
      html += `<div class="edcard${av ? '' : ' locked'}" data-item="${id}">` +
        `<div class="edtile item${av ? '' : ' locked'}" data-item="${id}">${tileHTML(id, av, `<span class="edcost">${itemCost(id)}</span>`)}</div>` +
        `<div class="edcname">${v.name}</div><div class="edcuse">${v.use || effectText(id) || ''}</div>` +
        `<div class="edccost">${itemCost(id)} genome space${av ? '' : ' · locked'}</div></div>`;""",
"""      const av = itemAvailable(id);
      const v = VIS[id];
      const owned = isUnlocked(id);
      const tier = boneTier(id), price = bonePrice(id), col = BONE_TIER_COL[tier];
      const bal = boneBalance();
      const buyable = !owned && !SANDBOX;
      const selling = ED.sellArm === id;
      html += `<div class="edcard${av ? '' : ' locked'}" data-item="${id}">` +
        `<div class="edtile item${av ? '' : ' locked'}" data-item="${id}">${tileHTML(id, av, `<span class="edcost">${itemCost(id)}</span>`)}</div>` +
        `<div class="edcname">${v.name}</div><div class="edcuse">${v.use || effectText(id) || ''}</div>` +
        `<div class="edccost">${itemCost(id)} genome space · <span class="edtierb" style="color:${col}">${BONE_TIER_LABEL[tier]}</span></div>` +
        (buyable
          ? `<button class="edbuy${bal >= price ? '' : ' poor'}" data-buy="${id}" style="border-color:${col}"><span>buy</span><b style="color:${col}">${price}</b></button>`
          : owned && !SANDBOX
            ? `<button class="edsell${selling ? ' arm' : ''}" data-sell="${id}">${selling ? 'sell for ' + boneRefund(id) + '?' : 'owned &middot; sell ' + boneRefund(id)}</button>`
            : '<div class="edowned">yours</div>') +
        `</div>`;""")
# clicks on the card buttons, and the two-click sell confirm
s=sub1(s,"""  $('edPrev').onclick = () => step(-1);""","""  $('edGrid').addEventListener('click', (e) => {
    const buy = e.target.closest ? e.target.closest('[data-buy]') : null;
    if (buy) {
      e.stopPropagation(); e.preventDefault();
      ED.sellArm = null;
      const r = boneBuy(buy.getAttribute('data-buy'));
      edFlash(r.msg);
      edRefreshUI();
      return;
    }
    const sell = e.target.closest ? e.target.closest('[data-sell]') : null;
    if (sell) {
      e.stopPropagation(); e.preventDefault();
      const id = sell.getAttribute('data-sell');
      // first click arms, second click sells: a part is too dear to lose to a slip
      if (ED.sellArm !== id) { ED.sellArm = id; edRefreshUI(); return; }
      ED.sellArm = null;
      const r = boneSell(id);
      edFlash(r.msg);
      edRefreshUI();
    }
  }, true);
  $('edPrev').onclick = () => step(-1);""")
# tooltip line
s=sub1(s,"""                                : '<div class="lk">locked: kill an animal that has one, then pick it</div>');""",
"""                                : '<div class="lk">locked: kill an animal that has one, or buy it on this card for ' + bonePrice(id) + ' bones (' + BONE_TIER_LABEL[boneTier(id)] + ')</div>');""")
# css
s=sub1(s,"  .edcard.locked .edcname{color:#8aa3ab}","""  .edcard.locked .edcname{color:#8aa3ab}
  .edtierb{font-weight:700;letter-spacing:.06em;text-transform:uppercase;font-size:9.5px}
  .edbuy{display:flex;justify-content:space-between;align-items:center;gap:6px;width:100%;margin-top:4px;
    font:inherit;font-size:11px;padding:5px 9px;border-radius:8px;cursor:pointer;
    background:rgba(10,32,29,.75);border:1px solid #2c4b45;color:#dff3ec}
  .edbuy b{font-size:12px}
  .edbuy:hover{background:rgba(20,52,46,.9)}
  .edbuy.poor{opacity:.42;cursor:not-allowed}
  .edsell{width:100%;margin-top:4px;font:inherit;font-size:10.5px;padding:5px 9px;border-radius:8px;cursor:pointer;
    background:transparent;border:1px solid rgba(140,190,210,.2);color:#7fa3b4;text-align:center}
  .edsell:hover{border-color:#8a6a4a;color:#e8c9a8}
  .edsell.arm{background:rgba(90,50,20,.5);border-color:#b07a3a;color:#ffe0c0}
  .edowned{margin-top:4px;font-size:10.5px;color:#6d97a4;text-align:center}
  #edBones{margin-left:6px;font-size:12px;color:#8fb4c4;align-self:center}
  #edBoneN{color:#e8d9a8;font-size:13px}""")
# ---- test surface (the page runs in its own scope) ---------------------------
s=sub1(s,"  rebuild: () => rebuildWorld(),","""  rebuild: () => rebuildWorld(),
  bones: {
    get balance() { return boneBalance(); },
    get rarityCap() { return world && world.rarityCap; },
    earn: (n) => boneEarn(n, 'test'), spend: (n) => boneSpend(n, 'test'),
    buy: (id) => boneBuy(id), sell: (id) => boneSell(id),
    price: (id) => bonePrice(id), tier: (id) => boneTier(id), refund: (id) => boneRefund(id),
    audit: () => boneAuditTiers(), perKill: BONES_PER_KILL,
    reset: () => { PROG.bones = 0; PROG.unlocked = new Set(); PROG.bought = []; ED.sellArm = null; saveProgress(); },
    grant: (id) => { PROG.unlocked.add(id); saveProgress(); },
    // the palette IS the shop now
    tab: (t) => { ED.tab = t; edRefreshUI(); },
    buyButtons: () => [...document.querySelectorAll('#edGrid [data-buy]')].map(b => b.getAttribute('data-buy')),
    sellButtons: () => [...document.querySelectorAll('#edGrid [data-sell]')].map(b => b.getAttribute('data-sell')),
    clickBuy: (id) => { const b = document.querySelector('#edGrid [data-buy=\"' + id + '\"]'); if (b) b.click(); return !!b; },
    clickSell: (id) => { const b = document.querySelector('#edGrid [data-sell=\"' + id + '\"]'); if (b) b.click(); return !!b; },
    hudBones: () => { const e = document.getElementById('edBoneN'); return e && e.textContent; },
    worn: () => { const out = []; if (!ED.des) return out;
      for (const q of ED.des.parts || []) out.push(q.id);
      for (const l of ED.des.limbs || []) { out.push(l.id); if (l.tip) out.push(l.tip.id); }
      return [...new Set(out)]; },
    refresh: () => edRefreshUI(),
  },
  openEditor: (m) => openEditor(m || 'game'),""")
open(p,'w',encoding='utf-8').write(s)
print('bones palette ok')

