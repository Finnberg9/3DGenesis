// ---- designed creature inside the live world --------------------------------
function legRanks(G) {
  if (G._ranks) return G._ranks;
  const legs = G.cls.limbs.filter(o => o.leg);
  const keys = [];
  for (const o of legs.slice().sort((a, b) => b.root[0] - a.root[0])) {
    const key = o.lb.m || ('x' + o.root[0].toFixed(2));
    if (!keys.includes(key)) keys.push(key);
  }
  const m = new Map();
  for (const o of legs) m.set(o.lb, keys.indexOf(o.lb.m || ('x' + o.root[0].toFixed(2))));
  G._ranks = m;
  return m;
}
function solveKnee(rootW, footW, L1, L2, poleW) {
  let d = v3.sub(footW, rootW);
  let D = v3.len(d);
  const maxD = (L1 + L2) * 0.999;
  if (D > maxD) { footW = v3.add(rootW, v3.mul(d, maxD / D)); d = v3.sub(footW, rootW); D = maxD; }
  if (D < 1e-6) return { knee: v3.add(rootW, v3.mul(poleW, L1)), foot: footW };
  const dir = v3.mul(d, 1 / D);
  const a = (L1 * L1 - L2 * L2 + D * D) / (2 * D);
  const h = Math.sqrt(Math.max(0, L1 * L1 - a * a));
  let pole = v3.sub(poleW, v3.mul(dir, v3.dot(poleW, dir)));
  if (v3.len(pole) < 1e-6) pole = [0, 1, 0];
  pole = v3.norm(pole);
  return { knee: v3.add(v3.add(rootW, v3.mul(dir, a)), v3.mul(pole, h)), foot: footW };
}
function deadTypes(c) {
  const cs = c.cellState, cn = c.cellNodes;
  if (!cs || !cn) return null;
  let s = null;
  for (let i = 1; i < cs.length; i++) if (!cs[i].alive && cn[i]) (s || (s = new Set())).add(cn[i].type);
  return s;
}
// ---- attack choreography ---------------------------------------------------------
// an: { kind, k (0..1 through the move), s (strikeCurve: -0.4 wind-up .. 1 impact .. 0) }.
// Returns the head pose, jaw opening and a per-limb override that lands the hit:
// claw = raise and rake across, punch = cock back and drive out, headbutt/gore =
// rear the head and ram it down and forward, bite = gape and lunge, sweep = the
// tail whips (tailPose reads tailSwing). Shared by the world and the editor.
function attackRig(G, an, leadSide, t, id, toW) {
  const kind = an ? an.kind : null, s = an ? an.s : 0;
  const wind = Math.max(0, -s) / 0.4, hit = Math.max(0, s);
  let head = { pitch: Math.sin(t * 0.6 + id) * 0.035, fwd: 0, lift: 0 };
  if (kind === 'headbutt' || kind === 'gore') head = { pitch: 0.26 * wind - 0.62 * hit, fwd: -0.14 * wind + 0.5 * hit, lift: 0.05 * wind - 0.12 * hit };
  else if (kind === 'bite') head = { pitch: 0.2 * wind - 0.16 * hit, fwd: -0.2 * wind + 0.6 * hit, lift: 0.04 * wind - 0.05 * hit };
  else if (kind === 'flinch') { const f = Math.sin(an.k * Math.PI); head = { pitch: 0.28 * f, fwd: -0.25 * f, lift: 0.05 * f }; }
  else if (kind === 'mate') { const f = Math.sin(an.k * Math.PI); head = { pitch: -0.3 * f, fwd: 0.15 * f, lift: 0 }; }
  const chomp = kind === 'bite' ? 0.2 + wind * 1.5 + hit * 0.3 * (1 - an.k) : null;
  const hasArms = G.cls.limbs.some(o => !o.leg);
  const nArms = G.cls.limbs.filter(o => !o.leg).length;
  const ranks = legRanks(G);
  const ease = (u) => u * u * (3 - 2 * u);
  // rest -> wound-up pose -> impact pose -> rest, on the same timing as strikeCurve
  const phasePose = (rest, P1, P2, amt) => {
    const k = an.k;
    let q;
    if (k < 0.32) q = v3.lerp(rest, P1, ease(k / 0.32));
    else if (k < 0.56) q = v3.lerp(P1, P2, ease((k - 0.32) / 0.24));
    else q = v3.lerp(P2, rest, ease((k - 0.56) / 0.44));
    return v3.lerp(rest, q, amt);
  };
  const strikeLimb = (o, root, target, poleL) => {
    const k = solveKnee(root, target, o.L1, o.L2, poleL);
    return { knee: toW(k.knee), foot: toW(k.foot) };
  };
  const limb = (o, root, foot) => {
    if (!an) return null;
    const zs = root[2] < 0 ? -1 : 1;
    const Lr = o.L1 + o.L2;
    if (!o.leg && (kind === 'claw' || kind === 'punch')) {
      const amt = (zs === leadSide || nArms < 2) ? 1 : 0.3;
      let tgt;
      if (kind === 'claw') {
        const up = [root[0] - 0.1 * Lr, root[1] + 0.7 * Lr, root[2] + 0.45 * Lr * zs];
        const dn = [root[0] + 0.9 * Lr, root[1] - 0.2 * Lr, root[2] - 0.2 * Lr * zs];
        tgt = phasePose(foot, up, dn, amt);
      } else {
        const back = [root[0] - 0.35 * Lr, root[1] + 0.05 * Lr, root[2] + 0.2 * Lr * zs];
        const out = v3.add(root, v3.mul(v3.norm([1, -0.05, -0.12 * zs]), Lr * 0.98));
        tgt = phasePose(foot, back, out, amt);
      }
      return strikeLimb(o, root, tgt, [-0.4, -1, 0.5 * zs]);
    }
    if (o.leg && (kind === 'claw' || kind === 'punch') && !hasArms && (ranks.get(o.lb) || 0) === 0 && zs === leadSide) {
      // no arms: the leading front leg rears up and swipes (or stamps) forward
      const up = [root[0] + 0.55 * Lr, root[1] - 0.2 * Lr, root[2] + 0.35 * Lr * zs];
      const dn = [root[0] + 0.95 * Lr, root[1] - 0.8 * Lr, root[2] - 0.05 * Lr * zs];
      return strikeLimb(o, root, phasePose(foot, up, dn, 1), [1, 0.2, 0.3 * zs]);
    }
    return null;
  };
  return { kind, head, chomp, limb, tailMul: kind === 'sweep' ? 1.6 : 1 };
}
function drawDesignedCreature(c, t, camDist, A) {
  const p = c.ph, des = c.genome.design;
  const G = designGeo(des);
  const Rw = A.R;
  const airborne = A.hover > Rw * 0.4;
  const walk = !airborne && !A.swimming;
  // ---- lie along the ground: pitch and roll from the terrain under the body ----
  // Sampled at the nose and rump (pitch) and both flanks (roll), eased over a
  // fraction of a second, and switched off in the air or water.
  const cyw = Math.cos(A.yaw), syw = Math.sin(A.yaw);
  let tP = 0, tQ = 0;
  if (walk) {
    const L = Math.max(0.5, G.sk.a * 0.9) * Rw, W = Math.max(0.4, G.sk.b * 0.9) * Rw;
    const cx0 = c.x, cz0 = c.y;
    const hF = A.groundAt(cx0 + cyw * L, cz0 + syw * L), hB = A.groundAt(cx0 - cyw * L, cz0 - syw * L);
    const hR = A.groundAt(cx0 - syw * W, cz0 + cyw * W), hL = A.groundAt(cx0 + syw * W, cz0 - cyw * W);
    tP = clamp(Math.atan2(hF - hB, 2 * L), -0.6, 0.6);
    tQ = clamp(Math.atan2(hR - hL, 2 * W), -0.35, 0.35);
  }
  const ke = Math.min(1, (typeof frameDt === 'number' ? frameDt : 1 / 60) * 6);
  c._tiltP = c._tiltP == null ? tP : c._tiltP + (tP - c._tiltP) * ke;
  c._tiltQ = c._tiltQ == null ? tQ : c._tiltQ + (tQ - c._tiltQ) * ke;
  const cP = Math.cos(c._tiltP), sP = Math.sin(c._tiltP), cQ = Math.cos(c._tiltQ), sQ = Math.sin(c._tiltQ);
  // tilt in body space: pitch about z (nose up), then roll about x (right side up)
  const tilt = (v) => { const x1 = v[0] * cP - v[1] * sP, y1 = v[0] * sP + v[1] * cP; return [x1, y1 * cQ + v[2] * sQ, -y1 * sQ + v[2] * cQ]; };
  const untilt = (v) => { const y1 = v[1] * cQ - v[2] * sQ, z = v[1] * sQ + v[2] * cQ; return [v[0] * cP + y1 * sP, -v[0] * sP + y1 * cP, z]; };
  const toW = (l0) => { const l = tilt(l0); return [A.wx(l[0] * Rw, l[2] * Rw), A.bodyY + l[1] * Rw, A.wz(l[0] * Rw, l[2] * Rw)]; };
  const dW = (v0) => { const v = tilt(v0); return A.dirW(v[0], v[1], v[2]); };
  // world -> body space (inverse of toW; used to bring IK results back for skinning)
  const o0 = toW([0, 0, 0]);
  const toL = (w) => {
    const dx = w[0] - o0[0], dz = w[2] - o0[2];
    return untilt([(dx * cyw + dz * syw) / Rw, (w[1] - o0[1]) / Rw, (-dx * syw + dz * cyw) / Rw]);
  };
  // the same tilt as an affine for the skin's bones: R = roll * pitch (row-major)
  const tiltAff = (Math.abs(c._tiltP) + Math.abs(c._tiltQ) > 1e-4)
    ? { R: [cP, -sP, 0, sP * cQ, cP * cQ, sQ, -sP * sQ, -cP * sQ, cQ], t: [0, 0, 0] } : null;
  const isPlayer = typeof player !== 'undefined' && player && player.c === c;
  const ranks = legRanks(G);
  const rig = attackRig(G, A.anim, ((c._strikeSeq || 0) & 1) ? 1 : -1, t, c.id, toW);
  const head = rig.head, kind = rig.kind;
  const X = {
    head, tilt: tiltAff,
    R: Rw, t, seed: c.id * 0.37, toW, toL, yaw: A.yaw, dirW: dW,
    quality: isPlayer ? 2 : camDist < 420 ? 1 : 0, sync: false, meshFar: true, far: A.far, lod: camDist > 650 ? 2 : camDist > 420 ? 1 : 0,
    hide: deadTypes(c), gaitPhase: A.phase0, tailSwing: A.tailSwing * rig.tailMul,
    tailAmp: 0.35 + 0.65 * A.gaitAmt, flexAmp: 0.10 + 0.22 * A.gaitAmt,
    flap: Math.sin(t * (airborne ? 6.5 : 3.4) + c.id) * (airborne ? 0.62 : (p.canFly ? 0.18 : 0.08)),
    chomp: rig.chomp != null ? rig.chomp : A.bite > 0 ? A.bite : 0.12 + 0.12 * Math.sin(t * 1.7 + c.id),
    grip: clamp(c._grab || 0, 0, 1),
    tint: A.flinch > 0.01 ? [1, 0.25, 0.22] : null, tintK: A.flinch * 0.55,
    blink: (pi) => (((t * 0.29 + pi * 0.137 + c.id * 0.071) % 1) < 0.035 ? 1 : 0),
    limbPose(o, li, root, knee, foot) {
      const ov = rig.limb(o, root, foot);
      if (ov) return ov;
      if (!o.leg) {
        const sw = A.armSwing, gr = clamp(c._grab || 0, 0, 1);
        const idle = Math.sin(t * 1.3 + li) * 0.035;
        const f2 = v3.add(foot, [sw * 0.95 + gr * 0.35, Math.abs(sw) * 0.35 + idle, 0]);
        const k2 = v3.add(knee, [sw * 0.45 + gr * 0.15, Math.abs(sw) * 0.2, 0]);
        return { knee: toW(k2), foot: toW(f2) };
      }
      if (!walk) return null;
      const rank = ranks.get(o.lb) || 0;
      const side = root[2] < 0 ? -1 : 1;
      const legL = o.L1 + o.L2;
      const ph = A.phase0 + c.id * 0.7 + rank * 1.9 + (side > 0 ? Math.PI : 0);
      const stride = legL * (0.05 + 0.34 * A.gaitAmt);
      const swing = Math.sin(ph) * stride;
      const lift = Math.max(0, Math.sin(ph)) * legL * 0.16 * A.gaitAmt;
      const fl = v3.add(foot, [swing, 0, 0]);
      const fw = toW(fl);
      fw[1] = A.groundAt(fw[0], fw[2]) + (lift + 0.07) * Rw;
      const rootW = toW(root);
      const poleW = v3.sub(toW(knee), toW(v3.lerp(root, foot, 0.5)));
      return solveKnee(rootW, fw, o.L1 * Rw, o.L2 * Rw, poleW);
    },
  };
  drawDesign(des, X);
}
