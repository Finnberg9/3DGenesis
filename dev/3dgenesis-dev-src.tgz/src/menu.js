// =====================================================================
// MAIN MENU: a list you move through, with a torn brush mark behind the
// highlighted line, the chosen entry's name set large above it and a short
// description of what it does at the bottom. Continue, new game, load a saved
// creature, controls, options and credits. Mouse or arrow keys.
// =====================================================================
const MENU = { i: 0, page: null, items: [] };
function menuItems() {
  const out = [];
  if (PROG.last) out.push({ id: 'continue', label: 'CONTINUE', desc: 'Play your last creature on a fresh island.' });
  out.push({ id: 'new', label: 'NEW GAME', desc: 'Build a creature from scratch and hatch it into a new island.' });
  out.push({ id: 'load', label: 'LOAD CREATURE', desc: 'Pick one of the creatures you have saved and play it.' });
  out.push({ id: 'controls', label: 'CONTROLS', desc: 'Every key and what it does: moving, fighting, flying and surviving.' });
  out.push({ id: 'options', label: 'OPTIONS', desc: 'Graphics quality, render scale, sound and the world settings.' });
  out.push({ id: 'credits', label: 'ABOUT', desc: 'What this game is and how its animals are made.' });
  return out;
}
function menuRender() {
  const nav = document.getElementById('mmNav');
  if (!nav) return;
  MENU.items = menuItems();
  MENU.i = clamp(MENU.i, 0, MENU.items.length - 1);
  nav.innerHTML = MENU.items.map((it, k) =>
    `<button class="mmItem${k === MENU.i ? ' on' : ''}" data-mi="${k}"><span class="mmBrush"></span><span class="mmLabel">${it.label}</span></button>`).join('');
  const cur = MENU.items[MENU.i];
  const big = document.getElementById('mmBig'), desc = document.getElementById('mmDesc');
  if (big) big.textContent = cur.label;
  if (desc) desc.textContent = cur.desc;
}
function menuMove(d) {
  MENU.i = (MENU.i + d + MENU.items.length) % MENU.items.length;
  menuRender();
}
function menuPage(id) {
  MENU.page = id;
  const el = document.getElementById('mmPage');
  if (!el) return;
  if (!id) { el.classList.remove('show'); el.innerHTML = ''; return; }
  let h = '';
  if (id === 'controls') {
    h = '<h2>CONTROLS</h2>' + (document.getElementById('mmKeysSrc') ? document.getElementById('mmKeysSrc').innerHTML : '');
  } else if (id === 'options') {
    h = '<h2>OPTIONS</h2><div class="mmopt">' +
      '<div class="mmrow"><span>graphics</span><span>' +
      ['low', 'medium', 'high', 'ultra'].map(q => `<button class="mmb" data-gfx="${q}">${q}</button>`).join('') + '</span></div>' +
      '<div class="mmrow"><span>auto resolution</span><span><button class="mmb" data-auto="1">on / off</button></span></div>' +
      '<div class="mmrow"><span>sound</span><span><button class="mmb" data-snd="1">on / off</button></span></div>' +
      '<div class="mmrow"><span>world settings</span><span class="mmnote">press Tab in game for population, plants, day length and the rest</span></div>' +
      '<div class="mmrow"><span>reset saved progress</span><span><button class="mmb" data-wipe="1">wipe unlocks and creatures</button></span></div>' +
      '</div>';
  } else if (id === 'credits') {
    h = '<h2>ABOUT</h2><p>Every animal here is grown from a genome: a body plan, parts placed on it, a brain, and a metabolism. ' +
        'Nothing is hand-placed. The island, the weather, the animals and their behaviour all come out of the simulation, so no two worlds are alike.</p>' +
        '<p>You are one of those animals. Eat, grow, fight, take parts from what you kill, breed, and keep your line going.</p>' +
        '<p class="mmnote">Built with WebGPU. Made by Finn Berg.</p>';
  } else if (id === 'load') {
    const list = (PROG.saved || []);   // { name, design }
    h = '<h2>LOAD CREATURE</h2>' + (list.length
      ? '<div class="mmsaved">' + list.map((s, k) => `<button class="mmb wide" data-load="${k}">${(s.name || 'unnamed creature')}</button>`).join('') + '</div>'
      : '<p class="mmnote">You have no saved creatures yet. Save one from the creature builder with "my creatures".</p>');
  }
  el.innerHTML = h + '<button class="mmb back" data-back="1">back</button>';
  el.classList.add('show');
}
function menuChoose() {
  const it = MENU.items[MENU.i];
  if (!it) return;
  if (it.id === 'continue') { becomeDesigned(C.cloneDesign(PROG.last)); menuStart(); return; }
  if (it.id === 'new') { const st = document.getElementById('start'); if (st) st.style.display = 'none'; openEditor('start'); return; }
  menuPage(it.id);
}
let menuFadeTimer = null;

// Stop the menu track. fade=true rides the volume down over 2 s so leaving the
// menu does not cut the music dead; fade=false kills it immediately.
function stopMenuMusic(fade = true) {
  const mus = document.getElementById('mmMusic');
  if (!mus) return;

  if (menuFadeTimer) {
    clearInterval(menuFadeTimer);
    menuFadeTimer = null;
  }

  if (!fade) {
    mus.pause();
    mus.currentTime = 0;
    mus.volume = 0;
    return;
  }

  const startVolume = mus.volume;
  if (startVolume <= 0.001 || mus.paused) {
    mus.pause();
    mus.currentTime = 0;
    return;
  }

  const fadeDuration = 2000;
  const stepMs = 50;
  const volumeStep = startVolume * (stepMs / fadeDuration);

  menuFadeTimer = setInterval(() => {
    mus.volume = Math.max(0, mus.volume - volumeStep);
    if (mus.volume <= 0.001) {
      mus.volume = 0;
      mus.pause();
      mus.currentTime = 0;
      clearInterval(menuFadeTimer);
      menuFadeTimer = null;
    }
  }, stepMs);
}

function menuStart() {
  started = true;
  stopMenuMusic(true);
  const st = document.getElementById('start');
  if (st) st.style.display = 'none';
  menuPage(null);
}
function menuBind() {
  const st = document.getElementById('start');
  if (!st) return;
  menuRender();
  const nav = document.getElementById('mmNav');
  nav.addEventListener('mousemove', (e) => {
    const b = e.target.closest ? e.target.closest('[data-mi]') : null;
    if (b) { const k = +b.dataset.mi; if (k !== MENU.i) { MENU.i = k; menuRender(); } }
  });
  nav.addEventListener('click', (e) => {
    const b = e.target.closest ? e.target.closest('[data-mi]') : null;
    if (!b) return;
    e.stopPropagation();
    MENU.i = +b.dataset.mi; menuRender(); menuChoose();
  });
  const page = document.getElementById('mmPage');
  page.addEventListener('click', (e) => {
    e.stopPropagation();
    const t = e.target.closest ? e.target.closest('button') : null;
    if (!t) return;
    if (t.dataset.back != null) { menuPage(null); return; }
    if (t.dataset.gfx) { gfxSet(t.dataset.gfx); return; }
    if (t.dataset.auto) { R2.auto = !R2.auto; toast('auto resolution ' + (R2.auto ? 'on' : 'off'), 1200); return; }
    if (t.dataset.snd) { sndToggle(); return; }
    if (t.dataset.wipe) { try { localStorage.removeItem(PROG_KEY); } catch (err) { /* nothing saved */ } location.reload(); return; }
    if (t.dataset.load != null) { const s = (PROG.saved || [])[+t.dataset.load]; if (s && s.design) { becomeDesigned(C.cloneDesign(s.design)); menuStart(); } return; }
  });
  addEventListener('keydown', (e) => {
    if (started || ED.open || st.style.display === 'none') return;
    if (MENU.page) { if (e.key === 'Escape') { menuPage(null); e.preventDefault(); } return; }
    if (e.key === 'ArrowDown' || e.key === 's') { menuMove(1); e.preventDefault(); }
    else if (e.key === 'ArrowUp' || e.key === 'w') { menuMove(-1); e.preventDefault(); }
    else if (e.key === 'Enter' || e.key === ' ') { menuChoose(); e.preventDefault(); }
  });
}
