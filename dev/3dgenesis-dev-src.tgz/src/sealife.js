// =====================================================================
// SEA LIFE: shoals of small fish, and the bubbles a diver trails.
//
// Both are decoration. They carry no simulation state, take no part in the
// ecology, and cannot be eaten or hurt, so they cost the world nothing. They
// are drawn through the same instanced-ellipsoid path as the plants, which
// means a full reef of them is a few hundred instances a frame.
//
// A shoal is one object: a centre, a heading and a count. The individual fish
// are positions derived from a hash plus the swim phase, so nothing per fish
// is stored or stepped.
// =====================================================================
const SHOAL_MAX = 18;          // shoals kept alive around the camera
const SHOAL_R = 1100;          // they live inside this radius; outside it they are recycled
const SHOAL_FISH = 44;         // fish in the biggest shoal
const SEA_TINTS = [
  [0.62, 0.68, 0.74], [0.55, 0.64, 0.72], [0.78, 0.72, 0.48],
  [0.40, 0.58, 0.66], [0.82, 0.58, 0.30], [0.50, 0.66, 0.58],
];
const SEA = { shoals: [], t: -1, bub: [], bubAcc: 0, seed: 1 };
const SEA_BUB_MAX = 220;

function seaRnd() {
  SEA.seed = (Math.imul(SEA.seed ^ (SEA.seed >>> 15), 2246822519) + 0x9E3779B9) >>> 0;
  return ((SEA.seed ^ (SEA.seed >>> 16)) >>> 0) / 4294967296;
}
function seaSurfaceY() { return (terrain && terrain.LV ? terrain.LV.water : 0.3) * HEIGHT_SCALE; }

// Find somewhere in an annulus around the camera with enough water in it.
// Returns null rather than looping forever when the camera is inland.
function seaFindSpot(camX, camZ) {
  const sy = seaSurfaceY();
  for (let k = 0; k < 24; k++) {
    const a = seaRnd() * 6.2832, r = SHOAL_R * (0.25 + 0.7 * Math.sqrt(seaRnd()));
    const x = camX + Math.cos(a) * r, z = camZ + Math.sin(a) * r;
    if (x < 40 || z < 40 || x > WORLD_W - 40 || z > WORLD_H - 40) continue;
    const gy = groundAt(x, z);
    const room = sy - gy;
    if (room < 22) continue;
    return { x, z, gy, room, sy };
  }
  return null;
}
function seaSpawnShoal(camX, camZ) {
  const p = seaFindSpot(camX, camZ);
  if (!p) return null;
  const big = seaRnd();
  return {
    x: p.x, z: p.z,
    y: p.gy + 6 + seaRnd() * Math.max(2, p.room - 12),
    hd: seaRnd() * 6.2832,
    spd: 8 + seaRnd() * 16,
    turn: 0,
    n: 8 + ((big * big * (SHOAL_FISH - 8)) | 0),
    len: 0.8 + seaRnd() * (big > 0.75 ? 3.2 : 1.1),   // body length in world units
    rad: 7 + seaRnd() * 16 + big * 22,                // how loosely the shoal packs
    col: SEA_TINTS[(seaRnd() * SEA_TINTS.length) | 0],
    ph: seaRnd() * 100,
    id: (seaRnd() * 1e6) | 0,
  };
}
function seaShoalStep(s, dt, sy) {
  // a slow random walk on the heading, plus a nudge away from the map edge
  s.turn += (seaRnd() - 0.5) * dt * 2.2;
  s.turn *= Math.pow(0.35, dt);
  s.hd += s.turn * dt;
  const edge = 260;
  if (s.x < edge) s.hd += (0 - Math.cos(s.hd)) * dt * 1.6;
  if (s.x > WORLD_W - edge) s.hd -= (0 + Math.cos(s.hd)) * dt * 1.6;
  if (s.z < edge) s.hd += (0 - Math.sin(s.hd)) * dt * 1.6;
  if (s.z > WORLD_H - edge) s.hd -= (0 + Math.sin(s.hd)) * dt * 1.6;
  s.x += Math.cos(s.hd) * s.spd * dt;
  s.z += Math.sin(s.hd) * s.spd * dt;
  // stay in the water column: above the floor, below the surface
  const gy = groundAt(s.x, s.z);
  const lo = gy + 4 + s.rad * 0.5, hi = sy - 4 - s.rad * 0.5;
  if (hi <= lo) { s.dead = true; return; }
  s.y += (Math.sin(s.ph + performance.now() * 0.00021) * 6) * dt;
  s.y = clamp(s.y, lo, hi);
}
function seaTick(camX, camZ, dt) {
  const sy = seaSurfaceY();
  for (const s of SEA.shoals) {
    seaShoalStep(s, dt, sy);
    const dx = s.x - camX, dz = s.z - camZ;
    if (s.dead || dx * dx + dz * dz > SHOAL_R * SHOAL_R * 1.44) s.dead = true;
  }
  for (let i = SEA.shoals.length - 1; i >= 0; i--) if (SEA.shoals[i].dead) SEA.shoals.splice(i, 1);
  // refill a couple per frame at most, so a fresh world fills in over a second
  for (let k = 0; k < 2 && SEA.shoals.length < SHOAL_MAX; k++) {
    const s = seaSpawnShoal(camX, camZ);
    if (!s) break;
    SEA.shoals.push(s);
  }
}

// ---- bubbles ---------------------------------------------------------------
// Rising from the player's head whenever it is under water, faster when the
// animal is working. Air breathers make far more of them than gill breathers.
function seaBubbleSpawn(x, y, z, n, spread, rise) {
  for (let k = 0; k < n; k++) {
    if (SEA.bub.length >= SEA_BUB_MAX) break;
    SEA.bub.push({
      x: x + (seaRnd() - 0.5) * spread, y: y + (seaRnd() - 0.5) * spread * 0.4, z: z + (seaRnd() - 0.5) * spread,
      r: 0.18 + seaRnd() * 0.5, vy: rise * (0.7 + seaRnd() * 0.7),
      ph: seaRnd() * 6.2832, wob: 0.5 + seaRnd() * 1.6,
    });
  }
}
function seaBubbleTick(dt, sy) {
  for (let i = SEA.bub.length - 1; i >= 0; i--) {
    const b = SEA.bub[i];
    b.y += b.vy * dt;
    b.vy = Math.min(b.vy + 14 * dt, 46);        // a bubble accelerates as it expands
    b.r += dt * 0.09;
    b.ph += dt * 3.2;
    if (b.y > sy - 0.4) { SEA.bub.splice(i, 1); }
  }
}
function seaPlayerBubbles(dt, sy) {
  const c = player && player.c;
  if (!c || !c.alive || !c._sub) return;
  const p = c.ph;
  const hx = c.x, hz = c.y;                     // creatures live on the x/y ground plane; height is the camera's
  const hy = clamp(player.camY, groundAt(hx, hz) + 1, sy - 1);
  const moving = Math.min(1, Math.hypot(c.vx || 0, c.vy || 0) / Math.max(1, p.speedWater || 40));
  const rate = (p.waterBreath ? 1.2 : 5.5) * (0.5 + moving);
  SEA.bubAcc += rate * dt;
  while (SEA.bubAcc >= 1) {
    SEA.bubAcc -= 1;
    seaBubbleSpawn(hx, hy, hz, 1, Math.max(1.2, p.radius * BODY_SCALE * 0.8), 16 + p.radius * 0.4);
  }
}

// ---- drawing ---------------------------------------------------------------
// One ellipsoid for the body and one flattened one for the tail. Both go into
// the plant instance buffer, which is drawn with the shared sphere mesh.
function seaDrawShoal(s, camX, camY, camZ, t, sy, fx, fz) {
  const dx = s.x - camX, dz = s.z - camZ;
  const d2 = dx * dx + dz * dz;
  if (d2 > 620 * 620) return 0;
  const d = Math.sqrt(d2);
  if (d > 90 && (dx * fx + dz * fz) / d < -0.35) return 0;      // behind the camera
  // a shoal only shows if there is water between it and the eye
  if (camY > sy && s.y > sy - 2) return 0;
  const detail = d < 260 ? 1 : 0;                                // far shoals lose their tails
  const hd = s.hd, ch = Math.cos(hd), sh = Math.sin(hd);
  const px = -sh, pz = ch;                                       // sideways
  const L = s.len, W = L * 0.34, Hh = L * 0.62;
  const back = [s.col[0] * 0.45, s.col[1] * 0.5, s.col[2] * 0.55];
  let n = 0;
  for (let k = 0; k < s.n; k++) {
    // a fixed, well-spread offset per fish inside a stretched ellipsoid
    const h1 = ((k * 2654435761) ^ (s.id * 40503)) >>> 0;
    const u = ((h1 & 1023) / 1024) * 2 - 1;
    const v = (((h1 >>> 10) & 1023) / 1024) * 2 - 1;
    const wgt = (((h1 >>> 20) & 1023) / 1024) * 2 - 1;
    const ph = s.ph + k * 0.7;
    const sw = Math.sin(t * 2.4 + ph) * s.rad * 0.12;            // the whole shoal breathes
    const along = u * s.rad * 1.7 + sw;
    const side = v * s.rad + Math.sin(t * 1.7 + ph * 1.3) * s.rad * 0.1;
    const up = wgt * s.rad * 0.55 + Math.sin(t * 1.1 + ph * 2.1) * s.rad * 0.08;
    const fxp = s.x + ch * along + px * side;
    const fzp = s.z + sh * along + pz * side;
    const fyp = clamp(s.y + up, groundAt(fxp, fzp) + L * 0.8, sy - L * 0.8);
    // body wiggle: the nose leads, the tail whips
    const wig = Math.sin(t * 9 + ph * 3) * 0.20;
    const bdx = ch - px * wig, bdz = sh - pz * wig;
    pushP(fxp, fyp, fzp, bdx, 0, bdz, W, Hh, L, s.col);
    n++;
    if (detail) {
      const twig = Math.sin(t * 9 + ph * 3 - 0.9) * 0.55;
      pushP(fxp - ch * L * 1.05, fyp, fzp - sh * L * 1.05,
            ch - px * twig, 0, sh - pz * twig, W * 0.22, Hh * 1.15, L * 0.55, back);
      n++;
    }
  }
  return n;
}
// Called once a frame from the plant instance pass, after the plants are in.
function seaLifeInstances(camX, camY, camZ, t) {
  if (!world || !terrain || !terrain.LV) return;
  const dt = SEA.t < 0 ? 0 : clamp(t - SEA.t, 0, 0.25);
  SEA.t = t;
  const sy = seaSurfaceY();
  if (dt > 0) { seaTick(camX, camZ, dt); seaBubbleTick(dt, sy); seaPlayerBubbles(dt, sy); }
  // leave room for the bubbles and a safety margin on the plant buffer
  const budget = MAX_PLANT_INST - plantCount - SEA_BUB_MAX - 64;
  if (budget > 40) {
    const yaw = player.yaw, fx = Math.cos(yaw), fz = Math.sin(yaw);
    let used = 0;
    for (const s of SEA.shoals) {
      if (used > budget) break;
      used += seaDrawShoal(s, camX, camY, camZ, t, sy, fx, fz);
    }
  }
  const bcol = [0.80, 0.90, 0.95];
  for (const b of SEA.bub) {
    if (plantCount >= MAX_PLANT_INST - 8) break;
    const wob = Math.sin(b.ph) * b.r * 1.6;
    pushP(b.x + wob, b.y, b.z + Math.cos(b.ph * 0.8) * b.r * 1.6, 0, 1, 0, b.r, b.r * 1.15, b.r, bcol);
  }
}
function seaLifeReset() { SEA.shoals.length = 0; SEA.bub.length = 0; SEA.t = -1; SEA.bubAcc = 0; }
