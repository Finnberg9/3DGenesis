# 3D HRTF audio, footsteps, proximity warning arcs (replacing the ground
# rings), graphics quality presets, and growing by eating. See src/spatial.js
# and src/gfx.js.
def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
p='g3.html'; s=open(p,encoding='utf-8').read()
code=open('src/gfx.js',encoding='utf-8').read()+'\n'+open('src/spatial.js',encoding='utf-8').read()
s=sub1(s,"function stepSim(dt) {\n", code+"\nfunction stepSim(dt) {\n")
s=sub1(s,"  try { objTick(dt); sndTick(dt); } catch (e) { console.warn(e); }","  try { objTick(dt); sndTick(dt); spatTick(dt); } catch (e) { console.warn(e); }")
s=sub1(s,"function bindInput() {\n","function bindInput() {\n  gfxBind();\n")
# threat ring: keep the threat reading for the HUD, draw nothing on the ground
s=sub1(s,"""      pushS(rx, groundAt(rx, rz) + 1.6, rz, 0, 1, 0, sz, 0.6, sz, col);""","""      void sz; void col; void rx; void rz;""")
s=sub1(s,"""      pushS(rx, groundAt(rx, rz) + 1.0, rz, 0, 1, 0, 0.9, 0.28, 0.9,
            [0.42 + dim, 0.22, 0.20]);""","""      void rx; void rz; void dim;""")
# graphics presets
s=sub1(s,"const COVER_R = 720, COVER_CELL = 15;","let COVER_R = 720; const COVER_CELL = 15;")
s=sub1(s,"const TREE_LOD0 = 750, TREE_LOD1 = 2400;","let TREE_LOD0 = 750, TREE_LOD1 = 2400;")
s=sub1(s,"const FOL_MAX_INST = 60000;","const FOL_MAX_INST = 200000;   // buffer size; the live budget is GFX.folMax")
# pack partially instead of dropping whole meshes (trees first, so they never vanish)
s=sub1(s,"""    const n = arr.length / FOL_IF;
    if (off + n > FOL_MAX_INST) break;
    FOL.inst.set(arr, off * FOL_IF);""","""    let n = arr.length / FOL_IF;
    const room = Math.min(FOL_MAX_INST, GFX.folMax) - off;
    if (room <= 0) break;
    if (n > room) { n = room; arr.length = n * FOL_IF; }
    FOL.inst.set(arr, off * FOL_IF);""")
s=sub1(s,"FARR = 3600 * 3600","FARR = GFX.plant * GFX.plant")
s=sub1(s,"""  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const w = Math.max(1, Math.floor(canvas.clientWidth * dpr));""","""  const lim = dev && dev.limits ? dev.limits.maxTextureDimension2D : 8192;
  let dpr = Math.min(window.devicePixelRatio || 1, 2) * GFX.res;
  dpr = Math.min(dpr, lim / Math.max(1, canvas.clientWidth), lim / Math.max(1, canvas.clientHeight), 3);
  const w = Math.max(1, Math.floor(canvas.clientWidth * dpr));""")
s=sub1(s,"gArr[29] = FOG_DENSITY *","gArr[29] = FOG_DENSITY * GFX.fog *")
s=sub1(s,"  const far = camDist > 900;","  const far = camDist > 900 * GFX.crit;")
s=sub1(s,"quality: isPlayer ? 2 : camDist < 420 ? 1 : 0, sync: false, meshFar: true, far: A.far, lod: camDist > 650 ? 2 : camDist > 420 ? 1 : 0,",
       "quality: isPlayer ? 2 : camDist < 420 * GFX.crit ? 1 : 0, sync: false, meshFar: true, far: A.far, lod: camDist > 650 * GFX.crit ? 2 : camDist > 420 * GFX.crit ? 1 : 0,")
s=sub1(s,"sndCall(Math.random() * 1.6 - 0.8, night); }\n  voxTick(dt);","sndCall(sndRandDir(900 + Math.random() * 1600), night); }\n  voxTick(dt);")
# DOM: proximity canvas + quality selector
s=sub1(s,"""<div id="hurtfx" ""","""<div id="gfxsel"><span>graphics</span><button data-q="low">low</button><button data-q="medium">medium</button><button data-q="high">high</button><button data-q="ultra">ultra</button></div>
<div id="hurtfx" """)
s=sub1(s,"""  #vitals{left:14px;bottom:14px;min-width:260px}""","""  #vitals{left:14px;bottom:14px;min-width:260px}
  #gfxsel{position:fixed;right:14px;bottom:14px;z-index:14;display:flex;gap:4px;align-items:center;
    background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:6px 8px;font-size:12px;backdrop-filter:blur(7px)}
  #gfxsel span{color:var(--dim);margin-right:4px}
  #gfxsel button{font:inherit;color:var(--ink);background:#06201c;border:1px solid var(--line);border-radius:6px;padding:3px 8px;cursor:pointer}
  #gfxsel button:hover{border-color:var(--cyan)}
  #gfxsel button.on{background:var(--cyan);color:#04100e;font-weight:700;border-color:var(--cyan)}
  body.editing #gfxsel{display:none}""")
# keep it clear of the control panel
s=sub1(s,"function updateHUD() {\n  edHudLine();","function updateHUD() {\n  edHudLine();\n  gfxPlace();")
# help text: the rings are gone
s=sub1(s,"""    ground arc = where your selected attack lands, refilling as it recovers (<span style="color:#f04c38">red</span> target,
    <span style="color:#35e0d8">cyan</span> mate)<br>
    outer ring = predators nearby, at their real bearing<br>""","""    wear headphones: footsteps and roars are placed all around you<br>""")
# size readout and growing by eating
s=sub1(s,"""      `<span class="k">mass</span> <span class="v">${p.mass.toFixed(1)}</span> · ` +""","""      `<span class="k">mass</span> <span class="v">${p.mass.toFixed(1)}</span> · ` +
      ((c._bulk || 0) > 1.005 ? `<span class="k">size</span> <span class="v">x${c._bulk.toFixed(2)}</span> · ` : '') +""")
s=sub1(s,"""  else c.energy = Math.min(p.storage, c.energy + Math.max(6, gain));
  if (world.flags.toxins && best.ph.toxin > 0) {
    c.energy -= best.ph.toxin * 22;
    if (c.energy < 0) c.energy = 0;
  }
  // a spattered pool""","""  else { c.energy = Math.min(p.storage, c.energy + Math.max(6, gain)); feedGrowth(c, best.ph.mass, 'Ate your kill'); }
  if (world.flags.toxins && best.ph.toxin > 0) {
    c.energy -= best.ph.toxin * 22;
    if (c.energy < 0) c.energy = 0;
  }
  // a spattered pool""")
s=sub1(s,"""    c.energy = Math.min(p.storage, c.energy + gain);
    toast('Ate carrion. +' + gain.toFixed(0) + ' energy.', 1800); objOnEat();""","""    c.energy = Math.min(p.storage, c.energy + gain);
    toast('Ate carrion. +' + gain.toFixed(0) + ' energy.', 1800); objOnEat();
    feedGrowth(c, Math.max(0.3, (bestC.e - 20) / 14) * 0.6, 'Ate carrion');""")
s=sub1(s,"""  HEIGHT_SCALE, WORLD_W, WORLD_H,
""","""  HEIGHT_SCALE, WORLD_W, WORLD_H,
  get GFX() { return GFX; }, gfxSet: (n) => gfxSet(n), feedGrowth: (c, m) => feedGrowth(c, m),
  spat: { stepInterval, stepSurface, proxDraw, sndPlacer: (p) => SND.ctx && sndPlacer(SND.ctx, p, SND.master), get ok() { return SPAT.ok; } },
""")
open(p,'w',encoding='utf-8').write(s)
print('spatial ok')
