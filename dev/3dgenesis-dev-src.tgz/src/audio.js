// =====================================================================
// AMBIENT SOUND: everything is synthesised (no files). Wind in the canopy,
// insects by day and crickets by night, distant calls you cannot place,
// rustling in the undergrowth from animals you cannot see (panned to where
// they are), and a heartbeat when something that eats meat is closing in.
// N toggles sound. Audio starts on the first key press or click (browser rule).
// =====================================================================
const SND = { ctx: null, on: true, master: null, wind: null, windF: null, insect: null, noiseBuf: null, nextCall: 6, nextChirp: 0, nextRustle: 0, beatT: 0, threat: 0 };
function sndInit() {
  if (SND.ctx || !SND.on) return;
  const AC = window.AudioContext || window.webkitAudioContext;
  if (!AC) { SND.on = false; return; }
  try { SND.ctx = new AC(); } catch (e) { SND.on = false; return; }
  const ctx = SND.ctx;
  SND.master = ctx.createGain(); SND.master.gain.value = 0.55;
  // a limiter so a close roar on top of a fight never clips
  const comp = ctx.createDynamicsCompressor();
  comp.threshold.value = -14; comp.knee.value = 10; comp.ratio.value = 8; comp.attack.value = 0.004; comp.release.value = 0.25;
  SND.master.connect(comp).connect(ctx.destination);
  // two seconds of noise, reused by every noisy voice
  const buf = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
  const d = buf.getChannelData(0);
  let b0 = 0, b1 = 0;
  for (let i = 0; i < d.length; i++) { const w = Math.random() * 2 - 1; b0 = 0.99 * b0 + w * 0.05; b1 = 0.6 * b1 + w * 0.4; d[i] = (b0 * 2 + b1) * 0.5; }
  SND.noiseBuf = buf;
  // wind: looping filtered noise, its loudness and pitch wandering
  const src = ctx.createBufferSource(); src.buffer = buf; src.loop = true;
  SND.windF = ctx.createBiquadFilter(); SND.windF.type = 'lowpass'; SND.windF.frequency.value = 380; SND.windF.Q.value = 0.7;
  SND.wind = ctx.createGain(); SND.wind.gain.value = 0.0;
  src.connect(SND.windF).connect(SND.wind).connect(SND.master); src.start();
  // insects: a high band of noise that pulses
  const s2 = ctx.createBufferSource(); s2.buffer = buf; s2.loop = true; s2.playbackRate.value = 1.3;
  const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 5200; bp.Q.value = 9;
  SND.insect = ctx.createGain(); SND.insect.gain.value = 0;
  s2.connect(bp).connect(SND.insect).connect(SND.master); s2.start();
}
function sndToggle() {
  SND.on = !SND.on;
  if (SND.ctx) { if (SND.on) SND.ctx.resume(); else SND.ctx.suspend(); }
  else if (SND.on) sndInit();
  toast('sound ' + (SND.on ? 'on' : 'off') + '  (N)', 1400);
}
function sndPan(dx, dz) {
  // pan by where the source is relative to the way you are looking
  const yaw = player.yaw || 0;
  const side = -Math.sin(yaw) * dx + Math.cos(yaw) * dz;
  const d = Math.hypot(dx, dz) || 1;
  return clamp(side / d, -1, 1);
}
function sndVoice(build, pan, when) {
  const ctx = SND.ctx; if (!ctx) return;
  const p = ctx.createStereoPanner ? ctx.createStereoPanner() : null;
  if (p) { p.pan.value = pan || 0; p.connect(SND.master); }
  build(ctx, p || SND.master, when || ctx.currentTime);
}
function sndNoiseBurst(freq, q, dur, vol, pan, rate) {
  sndVoice((ctx, out, t) => {
    const s = ctx.createBufferSource(); s.buffer = SND.noiseBuf; s.playbackRate.value = rate || 1;
    const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = freq; f.Q.value = q;
    const g = ctx.createGain(); g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(vol, t + dur * 0.25); g.gain.exponentialRampToValueAtTime(0.0005, t + dur);
    s.connect(f).connect(g).connect(out); s.start(t, Math.random() * 1.5); s.stop(t + dur + 0.05);
  }, pan);
}
// a far-off call: a falling, wavering tone through the trees
function sndCall(pan, night) {
  sndVoice((ctx, out, t) => {
    const o = ctx.createOscillator(); o.type = 'sine';
    const f0 = night ? 240 + Math.random() * 180 : 520 + Math.random() * 500;
    o.frequency.setValueAtTime(f0, t);
    o.frequency.exponentialRampToValueAtTime(f0 * (night ? 0.55 : 0.8), t + (night ? 2.2 : 0.6));
    const vib = ctx.createOscillator(); vib.frequency.value = night ? 5.5 : 11; const vg = ctx.createGain(); vg.gain.value = f0 * 0.03;
    vib.connect(vg).connect(o.frequency);
    const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 1400;
    const g = ctx.createGain(); const dur = night ? 2.6 : 0.8;
    g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(night ? 0.05 : 0.03, t + 0.2); g.gain.exponentialRampToValueAtTime(0.0003, t + dur);
    o.connect(lp).connect(g).connect(out); o.start(t); vib.start(t); o.stop(t + dur + 0.1); vib.stop(t + dur + 0.1);
  }, pan);
}
function sndThump(vol) {
  sndVoice((ctx, out, t) => {
    const o = ctx.createOscillator(); o.type = 'sine'; o.frequency.setValueAtTime(62, t); o.frequency.exponentialRampToValueAtTime(38, t + 0.12);
    const g = ctx.createGain(); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0005, t + 0.16);
    o.connect(g).connect(out); o.start(t); o.stop(t + 0.2);
  }, 0);
}
function sndHit() { if (SND.ctx && SND.on) { sndThump(0.35); sndNoiseBurst(900, 1.2, 0.18, 0.25, 0, 0.7); } }
function sndTick(dt) {
  if (!SND.ctx || !SND.on || !world) return;
  const ctx = SND.ctx, t = ctx.currentTime;
  const light = world.light != null ? world.light : 1;
  const night = light < 0.3;
  const c = player.c;
  const cx = c ? c.x : player.camX, cz = c ? c.y : player.camZ;
  const canopy = forestCanopyAt(cx, cz);
  // wind rises with altitude and in the open, gusting slowly
  const alt = clamp((player.camY - groundAt(cx, cz)) / 400, 0, 1);
  const gust = 0.5 + 0.5 * Math.sin(performance.now() * 0.00021) * Math.sin(performance.now() * 0.00053);
  SND.wind.gain.setTargetAtTime(0.05 + 0.12 * gust * (1 - canopy * 0.5) + 0.2 * alt, t, 0.8);
  SND.windF.frequency.setTargetAtTime(260 + 500 * gust + 600 * alt, t, 0.8);
  // insects by day (louder under the canopy), silence then crickets at night
  const pulse = 0.5 + 0.5 * Math.sin(performance.now() * 0.012);
  SND.insect.gain.setTargetAtTime(night ? 0 : (0.004 + 0.014 * canopy) * (0.4 + 0.6 * pulse) * light, t, 0.15);
  if (night && t > SND.nextChirp) {
    SND.nextChirp = t + 0.35 + Math.random() * 0.9;
    const pan = Math.random() * 2 - 1;
    for (let k = 0; k < 3; k++) sndVoice((cx2, out, tt) => {
      const o = cx2.createOscillator(); o.frequency.value = 4300 + Math.random() * 300;
      const g = cx2.createGain(); g.gain.setValueAtTime(0, tt); g.gain.linearRampToValueAtTime(0.008, tt + 0.008); g.gain.linearRampToValueAtTime(0, tt + 0.035);
      o.connect(g).connect(out); o.start(tt); o.stop(tt + 0.05);
    }, pan, t + k * 0.06);
  }
  if (t > SND.nextCall) { SND.nextCall = t + (night ? 7 : 14) + Math.random() * (night ? 12 : 22); sndCall(Math.random() * 1.6 - 0.8, night); }
  // unseen movement nearby, and anything hungry closing in
  let threat = 0;
  if (c && c.alive && t > SND.nextRustle) {
    let best = null, bestScore = 0;
    for (const o of world.creatures) {
      if (o === c || !o.alive) continue;
      const dx = o.x - c.x, dz = o.y - c.y, d = Math.hypot(dx, dz);
      if (d > 220) continue;
      const sp = Math.hypot(o.vx || 0, o.vy || 0);
      if (o.ph.carnivory > 0.5 && (o.target === c || o.foe === c || (d < 140 && ((o.vx || 0) * -dx + (o.vy || 0) * -dz) > 0))) threat = Math.max(threat, 1 - d / 220);
      const fx = Math.cos(player.yaw), fz = Math.sin(player.yaw);
      const behind = (dx * fx + dz * fz) / (d || 1) < 0.3;
      const cover = forestCanopyAt(o.x, o.y) + (['forest', 'marsh', 'savanna', 'plains'].includes(terrain.biomeAt(o.x, o.y)) ? 0.5 : 0);
      const score = (sp > 3 ? 1 : 0.15) * (1 - d / 220) * (behind ? 1.4 : 0.7) * (0.4 + cover);
      if (score > bestScore) { bestScore = score; best = o; }
    }
    if (best && bestScore > 0.12) {
      const dx = best.x - c.x, dz = best.y - c.y;
      sndNoiseBurst(1100 + Math.random() * 900, 1.4, 0.18 + Math.random() * 0.25, 0.05 + 0.12 * bestScore, sndPan(dx, dz), 0.8 + Math.random() * 0.5);
    }
    SND.nextRustle = t + 0.35 + Math.random() * 0.8;
    SND.threat = threat;
  }
  // heartbeat when hunted
  if (SND.threat > 0.15) {
    SND.beatT -= dt;
    if (SND.beatT <= 0) { const bpm = 70 + 60 * SND.threat; SND.beatT = 60 / bpm; sndThump(0.12 + 0.2 * SND.threat); setTimeout(() => sndThump(0.08 + 0.14 * SND.threat), 140); }
  }
}
