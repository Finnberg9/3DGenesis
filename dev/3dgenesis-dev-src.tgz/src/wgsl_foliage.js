// Foliage: instanced tree and ground-cover meshes. Wind sways each vertex by
// its baked sway weight; leaves are two-sided, let light through from behind,
// and dissolve (dithered) when they come right up against the camera so the
// canopy never blinds you.
const WGSL_FOLIAGE = WGSL_COMMON + `
struct VO { @builtin(position) pos: vec4<f32>, @location(0) nrm: vec3<f32>, @location(1) wpos: vec3<f32>,
            @location(2) col: vec3<f32>, @location(3) leaf: f32 };
@vertex fn vs(@location(0) p: vec3<f32>, @location(1) n: vec3<f32>, @location(2) c: vec3<f32>,
              @location(3) sway: f32, @location(4) leaf: f32,
              @location(5) iPos: vec3<f32>, @location(6) iYaw: f32, @location(7) iScl: f32, @location(8) iTint: vec3<f32>) -> VO {
  let s = sin(iYaw); let co = cos(iYaw);
  let q = p * iScl;
  var w = vec3<f32>(q.x * co - q.z * s, q.y, q.x * s + q.z * co) + iPos;
  let t = g.params.x;
  let ph = iPos.x * 0.011 + iPos.z * 0.017;
  let gust = 0.65 + 0.35 * sin(t * 0.23 + ph * 0.3);
  let a = (sin(t * 0.95 + ph + q.y * 0.004) * 0.7 + sin(t * 2.6 + ph * 2.1 + p.x * 0.35 + p.z * 0.3) * 0.3 * leaf) * gust;
  w.x += a * sway * iScl * 0.8;
  w.z += cos(t * 0.73 + ph * 1.3) * sway * iScl * 0.45 * gust;
  var o: VO;
  o.pos = g.viewProj * vec4<f32>(w, 1.0);
  o.nrm = vec3<f32>(n.x * co - n.z * s, n.y, n.x * s + n.z * co);
  o.wpos = w; o.col = c * iTint; o.leaf = leaf;
  return o;
}
@fragment fn fs(i: VO, @builtin(front_facing) ff: bool) -> @location(0) vec4<f32> {
  let d = distance(i.wpos, g.camPos.xyz);
  let hs = fract(sin(dot(i.pos.xy, vec2<f32>(12.9898, 78.233))) * 43758.5453);
  if (g.camPos.w < 0.5) {
    if (i.leaf > 0.5 && d < 30.0 && hs > (d - 8.0) / 22.0) { discard; }
    if (d < 22.0 && hs > (d - 6.0) / 16.0) { discard; }
  } else if (d < 4.0 && hs > (d - 1.5) / 2.5) { discard; }   // editor: plants right at the lens
  var N = normalize(i.nrm);
  if (!ff && i.leaf > 0.5) { N = -N; }
  var lit = shade(i.col, N, i.wpos);
  if (i.leaf > 0.5) {
    // light through the leaf from behind
    let L = normalize(g.lightDir.xyz);
    let V = normalize(g.camPos.xyz - i.wpos);
    let tr = pow(clamp(dot(-V, L), 0.0, 1.0), 3.0) * 0.35 + clamp(-dot(N, L), 0.0, 1.0) * 0.22;
    let f = clamp(1.0 - exp(-(d * g.params.y) * (d * g.params.y)), 0.0, 1.0);
    lit += i.col * vec3<f32>(0.9, 1.1, 0.5) * tr * g.params.z * (1.0 - f);
  }
  return vec4<f32>(lit, 1.0);
}`;
