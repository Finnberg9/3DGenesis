// Foliage: instanced tree and ground-cover meshes. Wind sways each vertex by
// its baked sway weight; leaves are two-sided, let light through from behind,
// and dissolve (dithered) when they come right up against the camera so the
// canopy never blinds you.
const WGSL_FOLIAGE = WGSL_COMMON + `
struct VO { @builtin(position) pos: vec4<f32>, @location(0) nrm: vec3<f32>, @location(1) wpos: vec3<f32>,
            @location(2) col: vec3<f32>, @location(3) leaf: f32 };
@vertex fn vs(@location(0) p: vec3<f32>, @location(1) n: vec3<f32>, @location(2) c: vec3<f32>,
              @location(3) sway: f32, @location(4) leaf: f32,
              @location(5) iPos: vec3<f32>, @location(6) iYaw: f32, @location(7) iScl: f32, @location(8) iTint: vec3<f32>) -> VO {
  let s = sin(iYaw); let co = cos(iYaw);
  let q = p * iScl;
  var w = vec3<f32>(q.x * co - q.z * s, q.y, q.x * s + q.z * co) + iPos;
  let t = g.params.x;
  let ph = iPos.x * 0.011 + iPos.z * 0.017;
  let gust = 0.65 + 0.35 * sin(t * 0.23 + ph * 0.3);
  let a = (sin(t * 0.95 + ph + q.y * 0.004) * 0.7 + sin(t * 2.6 + ph * 2.1 + p.x * 0.35 + p.z * 0.3) * 0.3 * leaf) * gust;
  w.x += a * sway * iScl * 0.8;
  w.z += cos(t * 0.73 + ph * 1.3) * sway * iScl * 0.45 * gust;
  var o: VO;
  o.pos = g.viewProj * vec4<f32>(w, 1.0);
  o.nrm = vec3<f32>(n.x * co - n.z * s, n.y, n.x * s + n.z * co);
  o.wpos = w; o.col = c * iTint; o.leaf = leaf;
  return o;
}
// sin-free hash: stays stable at large world coordinates, where sin() loses
// precision on the GPU and turns into per-pixel sparkle
fn fhash(p: vec2<f32>) -> f32 {
  var p3 = fract(vec3<f32>(p.x, p.y, p.x) * 0.1031);
  p3 += dot(p3, p3.yzx + vec3<f32>(33.33));
  return fract((p3.x + p3.y) * p3.z);
}
fn fnoise(p: vec2<f32>) -> f32 {
  let i = floor(p); let f = fract(p); let u = f * f * (3.0 - 2.0 * f);
  return mix(mix(fhash(i), fhash(i + vec2<f32>(1.0, 0.0)), u.x), mix(fhash(i + vec2<f32>(0.0, 1.0)), fhash(i + vec2<f32>(1.0, 1.0)), u.x), u.y);
}
// Bark: deep vertical furrows broken into plates, fine grain, a bumped normal
// so the ridges catch the light, and moss/lichen on upward and shaded faces.
// Coordinates run round the trunk (horizontal tangent) and up it, so the
// pattern follows each trunk without needing UVs. Detail fades with distance
// so it never shimmers.
fn barkPattern(a: f32, y: f32, fine: f32) -> f32 {
  let q = vec2<f32>(a * 0.30, y * 0.032);
  let warp = fnoise(q * vec2<f32>(1.0, 2.5) + vec2<f32>(3.1, 7.7)) * 1.6;
  let n = fnoise(q + vec2<f32>(warp, 0.0));
  let plates = smoothstep(0.30, 0.62, n);
  let grain = fnoise(vec2<f32>(a * 0.9, y * 0.11));
  return plates * 0.85 + mix(0.075, grain * 0.15, fine);   // fine grain only up close
}
// triplanar: project on the two vertical world planes, weighted by how much the
// surface faces each. (Projecting onto the normal's own tangent made the
// coordinate swing by hundreds of units per pixel at large world positions.)
fn barkTri(p: vec3<f32>, N: vec3<f32>, fine: f32, da: f32, dy: f32) -> f32 {
  var w = vec2<f32>(abs(N.x), abs(N.z));
  w = w * w; w = w / max(w.x + w.y, 1e-4);
  let bx = barkPattern(p.z + da, p.y + dy, fine);
  let bz = barkPattern(p.x + da, p.y + dy, fine);
  return bx * w.x + bz * w.y;
}
@fragment fn fs(i: VO, @builtin(front_facing) ff: bool) -> @location(0) vec4<f32> {
  let d = distance(i.wpos, g.camPos.xyz);
  let hs = fract(sin(dot(i.pos.xy, vec2<f32>(12.9898, 78.233))) * 43758.5453);
  if (g.camPos.w < 0.5) {
    if (i.leaf > 0.5 && d < 30.0 && hs > (d - 8.0) / 22.0) { discard; }
    if (d < 22.0 && hs > (d - 6.0) / 16.0) { discard; }
  } else if (d < 4.0 && hs > (d - 1.5) / 2.5) { discard; }   // editor: plants right at the lens
  var N = normalize(i.nrm);
  if (!ff && i.leaf > 0.5) { N = -N; }
  var col = i.col;
  if (i.leaf < 0.5) {
    let det = 1.0 - smoothstep(260.0, 900.0, d);
    if (det > 0.001) {
      let hz = vec2<f32>(N.x, N.z);
      let hl = length(hz);
      let T = select(vec3<f32>(1.0, 0.0, 0.0), normalize(vec3<f32>(-N.z, 0.0, N.x)), hl > 0.2);
      let a = (i.wpos.x + i.wpos.z) * 0.7071;   // a fixed diagonal plane: smooth, never depends on the normal
      let fine = 1.0 - smoothstep(25.0, 120.0, d);
      let b0 = barkTri(i.wpos, N, fine, 0.0, 0.0);
      let b1 = barkTri(i.wpos, N, fine, 0.8, 0.0);
      let b2 = barkTri(i.wpos, N, fine, 0.0, 4.0);
      // furrows dark, plate faces light, with a touch of grey weathering on the ridges
      let bark = col * (0.50 + 0.78 * b0) + vec3<f32>(0.05, 0.05, 0.045) * smoothstep(0.75, 0.95, b0);
      // moss: patchy, heavier on faces that look up or away from the sun
      let mp = fnoise(vec2<f32>(a * 0.08, i.wpos.y * 0.02) + i.wpos.xz * 0.004);
      let shadeSide = clamp(0.5 - 0.5 * dot(N, normalize(g.lightDir.xyz)), 0.0, 1.0);
      let moss = smoothstep(0.52, 0.80, mp) * (0.35 + 0.65 * max(shadeSide, clamp(N.y + 0.2, 0.0, 1.0))) * (1.0 - smoothstep(0.55, 0.9, b0));
      let mossCol = mix(vec3<f32>(0.16, 0.26, 0.08), vec3<f32>(0.30, 0.38, 0.14), fnoise(vec2<f32>(a * 0.12, i.wpos.y * 0.05)));
      let lichen = smoothstep(0.80, 0.92, fnoise(vec2<f32>(a * 0.22, i.wpos.y * 0.035) + vec2<f32>(9.0, 2.0))) * (0.3 + 0.7 * fine);
      var detailed = mix(bark, mossCol, moss * 0.85);
      detailed = mix(detailed, vec3<f32>(0.55, 0.58, 0.46), lichen * 0.5 * (1.0 - moss));
      col = mix(col, detailed, det);
      // bump from the pattern's slope, round the trunk and up it
      let gA = (b1 - b0) / 0.8 * (0.4 + 0.6 * fine);
      let gY = (b2 - b0) / 4.0 * (0.4 + 0.6 * fine);
      N = normalize(N - (T * gA * 0.55 + vec3<f32>(0.0, 1.0, 0.0) * gY * 0.9) * det);
    }
  }
  var lit = shade(col, N, i.wpos);
  if (i.leaf > 0.5) {
    // light through the leaf from behind
    let L = normalize(g.lightDir.xyz);
    let V = normalize(g.camPos.xyz - i.wpos);
    let tr = pow(clamp(dot(-V, L), 0.0, 1.0), 3.0) * 0.35 + clamp(-dot(N, L), 0.0, 1.0) * 0.22;
    let f = clamp(1.0 - exp(-(d * g.params.y) * (d * g.params.y)), 0.0, 1.0);
    lit += i.col * vec3<f32>(0.9, 1.1, 0.5) * tr * g.params.z * (1.0 - f);
  }
  return vec4<f32>(lit, 1.0);
}`;
