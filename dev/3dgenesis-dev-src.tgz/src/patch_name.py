# Name your species: you type the stem, the game adds -saurus. It shows in the
# HUD, on saved creatures, and passes down your line.
def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
p='g3.html'; s=open(p,encoding='utf-8').read()
s=sub1(s,"""    $('v-name').textContent = `${diet.toUpperCase()} · sp${c.speciesId} · gen ${player.generation}`;""",
"""    const nm = (c.genome && c.genome.design && c.genome.design.name) || '';
    $('v-name').textContent = (nm ? nm + ' · ' : '') + `${diet.toUpperCase()} · sp${c.speciesId} · gen ${player.generation}`;""")
# the name rides along with the design, and the menu shows it
s=sub1(s,"  if (PROG.last) out.push({ id: 'continue', label: 'CONTINUE', desc: 'Play your last creature on a fresh island.' });",
         "  if (PROG.last) out.push({ id: 'continue', label: 'CONTINUE', desc: 'Play ' + (PROG.last.name || 'your last creature') + ' again on a fresh island.' });")
# styling for the name field
s=sub1(s,"  body.editing #gfxsel{display:none}","""  body.editing #gfxsel{display:none}
  .edname{display:inline-flex;align-items:center;gap:4px;margin-left:8px}
  .edname input{font:inherit;font-size:13px;width:180px;color:#dff3ec;background:#06201c;border:1px solid #2c4b45;border-radius:6px;padding:4px 8px}
  .edname button{margin-left:4px}""")
# hide the in-game buttons while the menu is up
s=sub1(s,"function gfxPlace() {\n  const el = document.getElementById('gfxsel'), tab = document.getElementById('ptab');\n  if (!el) return;","""function gfxPlace() {
  const el = document.getElementById('gfxsel'), tab = document.getElementById('ptab');
  if (!el) return;
  const st = document.getElementById('start');
  const menuUp = st && st.style.display !== 'none';
  el.style.display = menuUp ? 'none' : '';
  const rb0 = document.getElementById('resetbtn'); if (rb0) rb0.style.display = menuUp ? 'none' : '';
  if (menuUp) return;""")
open(p,'w',encoding='utf-8').write(s)
print('name ok')
s=open(p,encoding='utf-8').read()
# every design that goes into the world carries a name
s=sub1(s,"    PROG.last = stripDesign(ED.des);","    if (!ED.des.name) ED.des.name = speciesName(ED.des);\n    PROG.last = stripDesign(ED.des);")
# styles for the new palette: category bar, item cards
s=sub1(s,"  .edname button{margin-left:4px}","""  .edname button{margin-left:4px}
  #edTabBar{display:flex;align-items:center;gap:8px;margin:2px 2px}
  #edTabBar button{width:30px;height:30px;font-size:17px;line-height:1;border-radius:9px;padding:0}
  #edTabBar #edTabTitle{flex:1;text-align:center;margin:0}
  #edTabHint{margin:0 4px 10px;font-size:11.5px;color:#7fb9c9;text-align:center}
  .edgrid.cards{grid-template-columns:repeat(2,1fr);gap:12px}
  .edcard{display:flex;flex-direction:column;gap:2px;cursor:grab}
  .edcard .edtile{aspect-ratio:1.25}
  .edcname{font-size:12.5px;font-weight:700;color:#dff3ec;letter-spacing:.02em}
  .edcuse{font-size:10.5px;line-height:1.35;color:#8fb8c6;min-height:28px}
  .edccost{font-size:10px;color:#6d97a4}
  .edcard.locked .edcname{color:#8aa3ab}""")
open(p,'w',encoding='utf-8').write(s)
