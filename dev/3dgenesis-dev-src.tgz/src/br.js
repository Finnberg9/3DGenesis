// =====================================================================
// BATTLE ROYALE
//
// A match is fifteen minutes. Everyone starts locked in a numbered cage on a
// ring around the island. The gates open together, nobody can touch another
// player for the first five minutes (the island's own animals are fair game,
// and looting them is how you build your beast), and then it is open. A fog
// closes in from the edge, killing anything that stays in it, until one player
// or one pack is left.
//
// WHAT IS REAL HERE AND WHAT IS NOT
// Every rule below -- the grace period, the zone, damage, looting, packs, the
// win -- is real and runs to completion. The opponents are bots, because this
// build has no game server: it is a single static HTML file. Everything that
// would have to be decided by a server goes through BR_NET instead of being
// done inline, so swapping BR_NET_LOCAL for a socket implementation is the
// whole job rather than a rewrite. BR_NET_LOCAL is also what a practice match
// against bots would use even after a server exists.
//
// The transport contract, in one place:
//   join(profile)      -> { matchId, slot, bays, seed, players: [...] }
//   ready()            -> the server starts the match when everyone is in
//   send(ev)           -> an intent from this client (move/attack/loot/choose)
//   poll()             -> [events] the server has decided since the last poll
//   leave()
// Events are plain JSON. Nothing in this file touches the DOM except the HUD,
// and nothing outside it decides a match rule.
// =====================================================================
const BR_MATCH_SECS = 15 * 60;
const BR_GRACE_SECS = 5 * 60;
const BR_CAGE_SECS = 30;             // you walk around your cage before the gates go up
const BR_BOTS = 23;                  // plus you: 24 bays on the ring
const BR_CAGE_R = 34;                // half-width of a cage, world units
const BR_CAGE_H = 46;
const BR_ZONE_GRACE = 90;            // the fog does not start moving for this long
const BR_ZONE_DPS = 7;               // health a second, deep in the fog
const BR_ZONE_EDGE = 90;             // how far into the fog before it starts hurting
const BR_PACK_NONE = -1;


// ---- the match ruleset -----------------------------------------------------
// A match is a fair fight or it is nothing, so none of it is the player's to
// set. The island, its weather, its clock, its animals and its seed are all
// fixed, identical for everyone in the match, and handed down by join() --
// which today is brNetLocal() and tomorrow is a server. While a match is live
// the world panel is inert: its sliders do not reach world.params, the reset
// button will not fire, and panelOpts() ignores the DOM entirely and answers
// with these numbers however the controls have been dragged.
//
// Climate drift is off on purpose. It re-classifies biomes as the match runs,
// so a player who happened to start in a band that shifted would gain or lose
// cover through no choice of their own.
const BR_RULES = Object.freeze({
  startPop: 200,            // a living island worth hunting
  startPlants: 0,
  prerun: 30,               // biological seconds run before the gates, so the island is not empty
  mutationRate: 0.8,
  plantRate: 20,
  plantEnergy: 10,
  timeScale: 0.01,          // one match is about one in-game day
  dayLen: 10,
  yearLen: 5,
  carrionLife: 50,
  carrionYield: 0.5,
  founderDiversity: 0.8,
  foodPatchiness: 0.5,
  terrainRelief: 1,
  waterDepthMul: 1,
  regionDensity: 1,
  treeDensity: 1,
  flags: Object.freeze({ brains: true, sexual: true, dayNight: true, seasons: true, toxins: true, climate: false }),
});
// Everything the panel can touch, and what a match pins it to. Used both to
// answer panelOpts() and to snap a dragged control back to where it belongs.
const BR_LOCKED_CONTROLS = [
  ['startPop', 'startPop'], ['startPopR', 'startPop'], ['startPlants', 'startPlants'], ['prerun', 'prerun'],
  ['mut', 'mutationRate'], ['plant', 'plantRate'], ['pe', 'plantEnergy'], ['tscale', 'timeScale'],
  ['dayl', 'dayLen'], ['yearl', 'yearLen'], ['clife', 'carrionLife'], ['cy', 'carrionYield'],
  ['fd', 'founderDiversity'], ['fp', 'foodPatchiness'], ['trelief', 'terrainRelief'],
  ['twater', 'waterDepthMul'], ['tregion', 'regionDensity'], ['ttree', 'treeDensity'],
];
const BR_LOCKED_FLAGS = [['f_brains', 'brains'], ['f_sex', 'sexual'], ['f_day', 'dayNight'],
                         ['f_season', 'seasons'], ['f_tox', 'toxins'], ['f_climate', 'climate']];
// True from the moment a match is being armed until the match is over. Every
// guard in the page asks this one question.
function brLocked() { return !!BR.arming || (BR.on && BR.phase !== 'over'); }
// The parameters a locked world is built and run with. Returned in place of
// whatever the panel says.
function brRuleOpts() {
  const o = Object.assign({}, BR_RULES);
  o.flags = Object.assign({}, BR_RULES.flags);
  delete o.prerun;
  return o;
}
// Put every control back where the match says it is and grey the panel out, so
// the player can see what the match has taken over rather than wondering why
// dragging a slider does nothing.
function brSyncPanel() {
  const pan = document.getElementById('panel');
  if (pan) pan.classList.toggle('brlocked', brLocked());
  // the free-roam goal box and the reset button are not part of a match
  document.body.classList.toggle('brmatch', brLocked());
  if (!brLocked()) {
    for (const [id] of BR_LOCKED_CONTROLS) { const el = document.getElementById(id); if (el) el.disabled = false; }
    for (const [id] of BR_LOCKED_FLAGS) { const el = document.getElementById(id); if (el) el.disabled = false; }
    const sd = document.getElementById('seed'); if (sd) sd.disabled = false;
    const lk = document.getElementById('seedLock'); if (lk) lk.disabled = false;
    const rb = document.getElementById('resetbtn'); if (rb) rb.disabled = false;
    return;
  }
  for (const [id, key] of BR_LOCKED_CONTROLS) {
    const el = document.getElementById(id);
    if (!el) continue;
    const v = key === 'prerun' ? BR_RULES.prerun : BR_RULES[key];
    if (v != null) el.value = String(v);
    el.disabled = true;
    const out = document.getElementById(id + 'v');
    if (out && v != null) out.textContent = String(v);
  }
  for (const [id, key] of BR_LOCKED_FLAGS) {
    const el = document.getElementById(id);
    if (!el) continue;
    el.checked = !!BR_RULES.flags[key];
    el.disabled = true;
  }
  const sd = document.getElementById('seed');
  if (sd) { sd.value = String(BR.seed >>> 0); sd.disabled = true; }
  const lk = document.getElementById('seedLock'); if (lk) lk.disabled = true;
  const rb = document.getElementById('resetbtn'); if (rb) rb.disabled = true;
}

const BR = {
  on: false, phase: 'off',           // off | cage | grace | open | over
  t: 0, matchId: null, slot: 0, seed: 0,
  bays: [],                          // { n, x, z, y, yaw } one per player
  players: [],                       // { slot, name, bot, alive, pack, kills, x, z, c }
  zone: { cx: 0, cz: 0, r: 0, r0: 0, r1: 0 },
  net: null, log: [], msg: '', msgT: 0, arming: false, pending: false,
  gateY: 0, deadChoice: null, result: null, bones: 0,
};

// ---- transport -------------------------------------------------------------
// The local implementation. It is authoritative in exactly the way a server
// would be: the rest of the file asks it for decisions rather than making them.
function brNetLocal() {
  const S = {
    matchId: 'local-' + Date.now().toString(36),
    slot: 0, seed: 0, players: [], queue: [], started: false, t: 0,
  };
  return {
    kind: 'local',
    join(profile) {
      S.seed = (Math.random() * 1e9) | 0;
      S.players = [{ slot: 0, name: profile.name || 'you', bot: false, alive: true, pack: BR_PACK_NONE, kills: 0 }];
      const taken = new Set(['you']);
      for (let i = 1; i <= BR_BOTS; i++) {
        let nm = brBotName(S.seed + i);
        for (let k = 1; taken.has(nm); k++) nm = brBotName(S.seed + i + k * 7919);
        taken.add(nm);
        S.players.push({ slot: i, name: nm, bot: true, alive: true, pack: BR_PACK_NONE, kills: 0 });
      }
      return { matchId: S.matchId, slot: 0, bays: S.players.length, seed: S.seed, players: S.players.map(p => Object.assign({}, p)) };
    },
    ready() { S.started = true; S.queue.push({ type: 'start', t: 0 }); },
    // An intent from this client. A server would validate it; locally the only
    // thing that can be refused is a hit inside the grace period, which is
    // enforced in brHitAllowed() so the client and a server agree on the rule.
    send(ev) { S.queue.push(Object.assign({ from: 0 }, ev)); },
    poll() { const q = S.queue; S.queue = []; return q; },
    leave() { S.started = false; S.queue.length = 0; },
    // local-only: the match loop drives the bots through here
    _state: S,
  };
}
const BR_BOT_A = ['grim', 'ash', 'bone', 'rift', 'mire', 'gore', 'hush', 'vex', 'dun', 'coil', 'slag', 'wren'];
const BR_BOT_B = ['maw', 'fang', 'spine', 'talon', 'husk', 'crest', 'gale', 'shard', 'clutch', 'thorn'];
function brBotName(seed) {
  let h = seed >>> 0;
  h = Math.imul(h ^ (h >>> 15), 2246822519) >>> 0;
  const a = BR_BOT_A[h % BR_BOT_A.length], b = BR_BOT_B[(h >>> 8) % BR_BOT_B.length];
  return a + b;
}

// ---- the cage ring ---------------------------------------------------------
// One bay per player, evenly spaced on a circle that encloses the whole island,
// each turned to face the middle. Bays are numbered from 1 at due north,
// clockwise, so "bay 7" means something you can find.
function brBuildBays(n) {
  const cx = WORLD_W / 2, cz = WORLD_H / 2;
  const R0 = Math.min(WORLD_W, WORLD_H) * 0.47;
  const sea = terrain && terrain.LV ? terrain.LV.water : 0.3;
  const out = [];
  for (let i = 0; i < n; i++) {
    const a = -Math.PI / 2 + (i / n) * Math.PI * 2;
    const ca = Math.cos(a), sa = Math.sin(a);
    // The ring starts out at the edge of the map, which is open ocean. Walk it
    // inward until it finds dry land, so the cages land on the coast facing the
    // island instead of standing in the sea, where a land animal would drown
    // before the gate ever opened.
    let x = cx + ca * R0, z = cz + sa * R0, found = false;
    for (let r = R0; r > 200; r -= 40) {
      const px = clamp(cx + ca * r, 140, WORLD_W - 140), pz = clamp(cz + sa * r, 140, WORLD_H - 140);
      if (terrain.height(px, pz) > sea + 0.012) { x = px; z = pz; found = true; break; }
    }
    if (!found) { x = clamp(cx + ca * 260, 140, WORLD_W - 140); z = clamp(cz + sa * 260, 140, WORLD_H - 140); }
    out.push({ n: i + 1, x, z, y: groundAt(x, z), yaw: Math.atan2(cz - z, cx - x) });
  }
  return out;
}

// ---- match -----------------------------------------------------------------
// Entering a match is two halves with a world build between them. join()
// hands down the seed and the ruleset, the island is rebuilt from exactly
// those, and only then does the match itself begin. That order is what makes
// every player's island the same island.
function brArm(net) {
  BR.net = net || brNetLocal();
  const j = BR.net.join({ name: (ED.des && ED.des.stem) || 'you' });
  BR.join = j;
  BR.arming = true;
  BR.matchId = j.matchId;
  BR.slot = j.slot;
  BR.seed = j.seed >>> 0;
  BR.players = j.players;
  brSyncPanel();
  return j;
}
// Called once the world has been rebuilt from BR.seed under BR_RULES.
function brBegin() {
  if (!BR.net) return false;
  BR.on = true;
  BR.arming = false;
  BR.phase = 'cage';
  BR.t = 0;
  BR.bays = brBuildBays(BR.players.length);
  BR.gateY = 0;
  BR.result = null;
  BR.deadChoice = null;
  BR.bones = 0;
  BR.log.length = 0;
  const bay = BR.bays[BR.slot];
  BR.zone = { cx: WORLD_W / 2, cz: WORLD_H / 2, r0: Math.min(WORLD_W, WORLD_H) * 0.52, r1: 90, r: Math.min(WORLD_W, WORLD_H) * 0.52 };
  if (player.c) { player.c.x = bay.x; player.c.y = bay.z; player.c._spawnT = simT; }
  player.camX = bay.x; player.camZ = bay.z;
  player.spectator = false;
  brSpawnBots();
  BR.net.ready();
  brSyncPanel();
  brSay('BAY ' + bay.n + '. The gate opens in ' + BR_CAGE_SECS + ' seconds.', 5000);
  return true;
}
// The whole entry: arm, rebuild the island from the match seed, take the
// design in, then begin. Returns a promise so the caller can wait for it.
function brEnterMatch(design, net) {
  brArm(net);
  return Promise.resolve(rebuildWorld()).then(() => {
    if (design) { try { becomeDesigned(design); } catch (e) { console.warn('br: could not take that creature in', e); } }
    brBegin();
  }).catch((e) => {
    console.warn('br: match could not start', e);
    BR.arming = false; BR.on = false; BR.phase = 'off';
    if (BR.net) { BR.net.leave(); BR.net = null; }
    brSyncPanel();
    toast('The match could not start. You are in free roam.', 4000);
  });
}
// Kept for the test harness and for starting a match in a world that is
// already the match world.
function brStart(net) {
  brArm(net);
  return brBegin();
}
function brStop() {
  if (BR.net) BR.net.leave();
  BR.on = false; BR.arming = false; BR.phase = 'off'; BR.net = null;
  BR.players.length = 0; BR.bays.length = 0;
  brSyncPanel();
}
// Bots are ordinary world creatures, born in their bay from a random design,
// and flagged so the match can tell them from the island's wildlife.
function brSpawnBots() {
  if (!world) return;
  const rng = world.rng || Math.random;
  for (const pl of BR.players) {
    if (!pl.bot) { pl.c = player.c; pl.alive = true; continue; }
    const bay = BR.bays[pl.slot];
    let c = null;
    try {
      const g = C.seedHerbivore(world, rng);
      g.design = C.randomDesign(rng, { diversity: 0.85, diet: rng() < 0.55 ? 'carn' : 'herb', rarityCap: world.rarityCap });
      C.compileDesign(g);
      c = C.makeCreature(g, bay.x, bay.z, 400);
      // start full: a player would not spawn one bite from starving
      c.energy = c.ph && c.ph.storage ? c.ph.storage : 400;
      c._br = pl.slot;
      c._brName = pl.name;
      c._spawnT = simT;
      world.creatures.push(c);
    } catch (e) { console.warn('br: could not spawn bot', pl.slot, e); }
    pl.c = c;
    pl.alive = !!c;
    pl.x = bay.x; pl.z = bay.z;
  }
}
function brSay(msg, ms) { BR.msg = msg; BR.msgT = performance.now() + (ms || 3000); }

// ---- rules -----------------------------------------------------------------
// The one rule every hit in the match goes through. Both the client and a
// server would call this, so they cannot disagree about who may hit whom.
function brHitAllowed(victim, att) {
  if (!BR.on) return true;
  const vs = brSlotOf(victim), as = brSlotOf(att);
  if (vs === as && vs != null) return false;
  // A caged animal cannot be got at, by anything. Once the gates are up the
  // island's own wildlife is fair game in both directions.
  if (BR.phase === 'cage') return vs == null;
  if (vs == null || as == null) return true;                 // wildlife: always fair game
  if (BR.phase === 'grace') return false;                    // no player may touch another yet
  const vp = BR.players[vs], ap = BR.players[as];
  if (!vp || !ap) return true;
  if (vp.pack !== BR_PACK_NONE && vp.pack === ap.pack) return false;  // packmates cannot hurt each other
  if (vp.pack !== BR_PACK_NONE && vp.pack === as) return false;       // nor can a pack member hurt its leader
  if (ap.pack !== BR_PACK_NONE && ap.pack === vs) return false;
  return true;
}
function brSlotOf(c) {
  if (!c) return null;
  if (c === player.c) return BR.on ? BR.slot : null;
  return c._br != null ? c._br : null;
}
function brAliveCount() {
  let n = 0;
  const packs = new Set();
  for (const p of BR.players) {
    if (!p.alive) continue;
    n++;
    packs.add(p.pack === BR_PACK_NONE ? 'solo' + p.slot : 'pack' + p.pack);
  }
  return { n, sides: packs.size };
}

// ---- the fog ---------------------------------------------------------------
// Radius shrinks from enclosing the island to a small circle over the match.
// Standing outside it costs health, and the further out the worse it is.
function brZoneRadiusAt(t) {
  const z = BR.zone;
  if (t <= BR_ZONE_GRACE) return z.r0;
  const u = clamp((t - BR_ZONE_GRACE) / Math.max(1, BR_MATCH_SECS - BR_ZONE_GRACE - 40), 0, 1);
  // ease so the last minutes close fast
  return z.r0 + (z.r1 - z.r0) * (u * u * (3 - 2 * u));
}
// How deep into the fog a point is, 0 at the edge and 1 well inside it.
function brFogAt(x, z) {
  if (!BR.on) return 0;
  const d = Math.hypot(x - BR.zone.cx, z - BR.zone.cz);
  return clamp((d - BR.zone.r) / BR_ZONE_EDGE, 0, 1);
}

// ---- death, loot and packs -------------------------------------------------
// Killing a player takes their parts, grows you, and offers them a choice.
function brOnPlayerKilled(victimSlot, killerSlot, cause) {
  const v = BR.players[victimSlot], k = BR.players[killerSlot];
  if (!v || !v.alive) return;
  v.alive = false;
  v.deadAt = BR.t;
  if (k) {
    k.kills++;
    // the parts they were carrying become yours to equip
    const design = v.c && v.c.genome && v.c.genome.design;
    if (killerSlot === BR.slot && design) brLootDesign(design, v.name);
    if (killerSlot === BR.slot) {
      BR.bones += BONES_PER_KILL;
      boneEarn(BONES_PER_KILL, 'br:kill');
      // eating a player grows you, through the same path a normal feed uses
      try { if (player.c && v.c && v.c.ph) feedGrowth(player.c, v.c.ph.mass, 'Ate a rival'); } catch (e) { console.warn(e); }
    }
  }
  const by = k ? k.name : (cause || 'the island');
  BR.log.push({ t: BR.t, msg: v.name + ' killed by ' + by });
  if (victimSlot === BR.slot) {
    BR.deadChoice = { killer: killerSlot, t: BR.t };
  } else {
    brSay(v.name + ' killed by ' + by + ' · ' + brAliveCount().n + ' left', 2600);
  }
  // a dead leader frees its pack
  for (const p of BR.players) if (p.pack === victimSlot) p.pack = BR_PACK_NONE;
  brCheckOver();
}
// Every part on the design you killed, offered as an unlock.
function brLootDesign(design, from) {
  const ids = new Set();
  for (const pt of design.parts || []) if (VIS[pt.id]) ids.add(pt.id);
  for (const lb of design.limbs || []) {
    if (VIS[lb.id]) ids.add(lb.id);
    if (lb.tip && VIS[lb.tip.id]) ids.add(lb.tip.id);
  }
  const opts = [...ids].filter(id => !PROG.unlocked.has(id));
  if (!opts.length) { brSay('You ate ' + from + '. Nothing on it you did not already have.', 2600); return; }
  player.picker = { opts: opts.slice(0, 6), label: 'You killed ' + from + '. Take one of their parts', t0: performance.now(), items: true };
  renderPicker();
}
// The loser's choice: watch, or come back as a baby in the winner's pack.
function brChoose(join) {
  const dc = BR.deadChoice;
  if (!dc) return;
  BR.deadChoice = null;
  if (!join || dc.killer == null) {
    player.spectator = true;
    brSay('Spectating. The match runs to the end.', 4000);
    return;
  }
  const me = BR.players[BR.slot], k = BR.players[dc.killer];
  if (!k || !k.alive) { player.spectator = true; brSay('Your killer is already dead. Spectating.', 4000); return; }
  me.pack = dc.killer;
  me.alive = true;
  // reborn small, beside the leader, on the leader's design
  const bx = (k.c ? k.c.x : BR.zone.cx) + (Math.random() - 0.5) * 60;
  const bz = (k.c ? k.c.y : BR.zone.cz) + (Math.random() - 0.5) * 60;
  try {
    const d = k.c && k.c.genome && k.c.genome.design ? C.cloneDesign(k.c.genome.design) : (PROG.last && C.cloneDesign(PROG.last));
    if (d) becomeDesigned(d);
  } catch (e) { console.warn('br: rebirth failed', e); }
  if (player.c) {
    player.c.x = bx; player.c.y = bz;
    player.c._spawnT = simT;
    me.c = player.c;
  }
  player.spectator = false;
  brSay('You are ' + k.name + "'s. Fight together or you both lose.", 5000);
}
// Time ran out with more than one side standing. The match is decided on
// kills, then on how much fight is left, so it always ends with a winner
// rather than a draw.
function brTimeUp() {
  if (BR.phase === 'over') return;
  let best = null;
  for (const q of BR.players) {
    if (!q.alive) continue;
    const hp = q.c && q.c.alive ? q.c.energy : 0;
    if (!best || q.kills > best.kills || (q.kills === best.kills && hp > best.hp)) best = { q, hp, kills: q.kills };
  }
  const winSide = best ? (best.q.pack !== BR_PACK_NONE ? best.q.pack : best.q.slot) : null;
  for (const q of BR.players) {
    if (!q.alive) continue;
    const side = q.pack !== BR_PACK_NONE ? q.pack : q.slot;
    if (side !== winSide) q.alive = false;
  }
  brSay('TIME. Decided on kills.', 6000);
  brFinish();
}
function brCheckOver() {
  if (BR.phase === 'over') return;
  const a = brAliveCount();
  if (a.sides > 1) return;
  brFinish();
}
function brFinish() {
  if (BR.phase === 'over') return;
  BR.phase = 'over';
  brSyncPanel();
  const me = BR.players[BR.slot];
  const won = !!(me && me.alive);
  BR.result = {
    won, kills: me ? me.kills : 0, bones: BR.bones, t: BR.t,
    survivors: BR.players.filter(p => p.alive).map(p => p.name),
  };
  if (won) {
    // a win pays out, and is recorded. A server would be the one recording it
    // for a public account; locally it goes in with the rest of progress.
    const purse = 25 + BR.bones;
    boneEarn(25, 'br:win');
    PROG.brWins = (PROG.brWins | 0) + 1;
    PROG.brBest = Math.max(PROG.brBest | 0, me ? me.kills : 0);
    saveProgress();
    brSay('YOU WON. ' + (me ? me.kills : 0) + ' kills, ' + purse + ' bones.', 9000);
  } else {
    brSay('Match over. ' + (BR.result.survivors[0] || 'nobody') + ' won it.', 9000);
  }
}

// ---- tick ------------------------------------------------------------------
function brTick(dt) {
  if (!BR.on) return;
  for (const ev of BR.net.poll()) BR.log.push(ev);
  // The HUD is drawn from here rather than from the frame loop, so it can
  // never fall behind the match state it is reporting -- including the death
  // offer, which has to appear the instant you are killed.
  try { brRenderHud(); } catch (e) { console.warn('br hud', e); }
  if (BR.phase === 'over') { BR.t += dt; return; }
  BR.t += dt;
  // phase
  if (BR.phase === 'cage' && BR.t >= BR_CAGE_SECS) {
    BR.phase = 'grace';
    brSay('GATES OPEN. No player can hurt another for ' + Math.round(BR_GRACE_SECS / 60) + ' minutes. Hunt the island and take its parts.', 7000);
  } else if (BR.phase === 'grace' && BR.t >= BR_CAGE_SECS + BR_GRACE_SECS) {
    BR.phase = 'open';
    brSay('OPEN SEASON. Everyone can kill everyone.', 7000);
  }
  // the gate slides up over two seconds once the cage phase ends
  const want = BR.phase === 'cage' ? 0 : 1;
  BR.gateY += clamp(want - BR.gateY, -dt * 0.5, dt * 0.5);
  // keep a caged player in their cage
  if (BR.phase === 'cage' && player.c) { brConfineToCage(player.c, BR.bays[BR.slot]); brHoldCaged(player.c); }
  // the fog
  BR.zone.r = brZoneRadiusAt(BR.t);
  brZoneDamage(dt);
  brBotTick(dt);
  // The end condition is checked every tick, not only when a kill reports one,
  // so a side that quietly stops existing still ends the match.
  brCheckOver();
  // And the panel is re-asserted once a second, so nothing that reaches in and
  // edits a control can leave the display disagreeing with the match.
  BR._panelAcc = (BR._panelAcc || 0) + dt;
  if (BR._panelAcc > 1) { BR._panelAcc = 0; brSyncPanel(); }
  if (BR.t >= BR_MATCH_SECS && BR.phase !== 'over') brTimeUp();
}
// Bots run for the middle of the ring, hard when the fog is on them and at a
// stroll otherwise, and the core's own wander handles the rest.
function brBotMove(c, dt) {
  const dx = BR.zone.cx - c.x, dz = BR.zone.cz - c.y;
  const d = Math.hypot(dx, dz);
  if (d < 40) return;
  const fog = brFogAt(c.x, c.y);
  // Keep well inside the ring rather than hugging its edge, and sprint when
  // the fog is already on them. A player who waits at the line dies to it.
  if (fog <= 0 && d < BR.zone.r * 0.72) return;
  const land = Math.max(24, c.ph && c.ph.speedLand ? c.ph.speedLand : 30);
  const sp = land * (fog > 0 ? 1.15 : 0.7);
  const step = Math.min(d, sp * dt);
  let nx = c.x + dx / d * step, nz = c.y + dz / d * step;
  // A bot that cannot swim will not walk into the sea: it slides along the
  // water's edge instead, which is what the shoreline does to a real animal.
  const canSwim = !!(c.ph && c.ph.canSwim);
  if (!canSwim && terrain.isWater(nx, nz)) {
    const px = -dz / d, pz = dx / d;
    const side = ((c.id | 0) & 1) ? 1 : -1;
    nx = c.x + px * side * step; nz = c.y + pz * side * step;
    if (terrain.isWater(nx, nz)) { nx = c.x - px * side * step; nz = c.y - pz * side * step; }
    if (terrain.isWater(nx, nz)) return;
  }
  c.x = clamp(nx, 2, WORLD_W - 2);
  c.y = clamp(nz, 2, WORLD_H - 2);
}
// In the cage nothing can touch you and nothing can wear you down: the match
// has not started. Holding energy at full is what makes that true for hunger,
// and clearing the drowning flags is what makes it true for a bay that ended
// up with its feet in the surf.
function brHoldCaged(c) {
  if (!c || !c.alive) return;
  if (c.ph && c.ph.storage) c.energy = c.ph.storage;
  c._drown = 0; c._sub = false; c._suffoc = 0;
}
// Close on a rival, and stop just inside reach so the two of them trade blows
// instead of orbiting each other.
function brBotChase(c, foe, dt) {
  const dx = foe.x - c.x, dz = foe.y - c.y;
  const d = Math.hypot(dx, dz);
  const reach = ((c.ph ? c.ph.radius : 4) + (foe.ph ? foe.ph.radius : 4)) * 1.2 + 10;
  if (d < reach || d < 1e-3) return;
  const land = Math.max(24, c.ph && c.ph.speedLand ? c.ph.speedLand : 30);
  const step = Math.min(d - reach * 0.8, land * dt);
  if (step <= 0) return;
  const nx = c.x + dx / d * step, nz = c.y + dz / d * step;
  if (!(c.ph && c.ph.canSwim) && terrain.isWater(nx, nz)) return;
  c.x = clamp(nx, 2, WORLD_W - 2);
  c.y = clamp(nz, 2, WORLD_H - 2);
}
function brConfineToCage(c, bay) {
  if (!bay) return;
  const r = BR_CAGE_R - (c.ph ? c.ph.radius * BODY_SCALE : 4) - 1;
  c.x = clamp(c.x, bay.x - r, bay.x + r);
  c.y = clamp(c.y, bay.z - r, bay.z + r);
}
function brZoneDamage(dt) {
  for (const p of BR.players) {
    if (!p.alive || !p.c || !p.c.alive) continue;
    const f = brFogAt(p.c.x, p.c.y);
    if (f <= 0) continue;
    p.c.energy -= BR_ZONE_DPS * f * dt;
    if (p.c.energy <= 0) {
      p.c.alive = false;
      brOnPlayerKilled(p.slot, null, 'the fog');
    } else if (p.slot === BR.slot && f > 0.05) {
      if (!BR._fogWarn || performance.now() - BR._fogWarn > 3000) {
        BR._fogWarn = performance.now();
        brSay('THE FOG IS KILLING YOU. Get back inside.', 2500);
      }
    }
  }
}
// Bots: run for the middle of the zone, fight what is in reach once the grace
// period is over, and take the fog's damage like everyone else. Deliberately
// simple -- they stand in for players, they are not the point.
function brBotTick(dt) {
  for (const p of BR.players) {
    if (p.bot === false || !p.alive) continue;
    const c = p.c;
    if (!c || !c.alive) { if (p.alive) { p.alive = false; brOnPlayerKilled(p.slot, null, 'the island'); } continue; }
    p.x = c.x; p.z = c.y;
    if (BR.phase === 'cage') { brConfineToCage(c, BR.bays[p.slot]); brHoldCaged(c); continue; }
    // A bot stands in for a player, and a player spends the match hunting, so
    // a bot feeds itself rather than quietly starving to death off-screen.
    // This is the one thing about them that is not a real animal's life.
    if (c.ph && c.ph.storage) c.energy = Math.min(c.ph.storage, c.energy + c.ph.upkeep * 1.15 * dt + c.ph.storage * 0.004 * dt);
    // pick a fight with the nearest other player
    let best = null, bd = 1e9;
    if (BR.phase === 'open') {
      for (const q of BR.players) {
        if (q === p || !q.alive || !q.c || !q.c.alive) continue;
        if (!brHitAllowed(q.c, c)) continue;
        const d = Math.hypot(q.c.x - c.x, q.c.y - c.y);
        if (d < bd) { bd = d; best = q; }
      }
    }
    // A player who has run out of room stops running and starts hunting, so
    // the last minutes are a fight rather than everyone quietly gassing.
    const hunting = best && (BR.zone.r < 1400 || bd < 260) && brFogAt(c.x, c.y) <= 0;
    if (hunting) brBotChase(c, best.c, dt);
    else brBotMove(c, dt);
    if (!best) continue;
    const reach = ((c.ph ? c.ph.radius : 4) + (best.c.ph ? best.c.ph.radius : 4)) * 1.4 + 16;
    if (bd > reach) continue;
    c._brAcc = (c._brAcc || 0) + dt;
    const rate = 1.1 + 0.6 * Math.random();
    if (c._brAcc < rate) continue;
    c._brAcc = 0;
    const dmg = (c.ph && c.ph.attack ? c.ph.attack : 4) * (0.8 + Math.random() * 0.5);
    best.c.energy -= dmg;
    if (best.c.energy <= 0) {
      best.c.alive = false;
      brOnPlayerKilled(best.slot, p.slot);
    }
  }
}

// ---- HUD -------------------------------------------------------------------
function brHudHtml() {
  if (!BR.on) return '';
  const a = brAliveCount();
  const left = Math.max(0, BR_MATCH_SECS - BR.t);
  const mm = Math.floor(left / 60), ss = Math.floor(left % 60);
  const me = BR.players[BR.slot];
  let phase = '';
  if (BR.phase === 'cage') phase = 'IN THE CAGE · gate in ' + Math.ceil(BR_CAGE_SECS - BR.t) + 's';
  else if (BR.phase === 'grace') phase = 'GRACE · players safe for ' + Math.ceil(BR_CAGE_SECS + BR_GRACE_SECS - BR.t) + 's';
  else if (BR.phase === 'open') phase = 'OPEN SEASON';
  else phase = 'MATCH OVER';
  const d = player.c ? Math.hypot(player.c.x - BR.zone.cx, player.c.y - BR.zone.cz) : 0;
  const out = Math.max(0, d - BR.zone.r);
  return '<div class="brhud">' +
    '<div class="brtop"><b>' + mm + ':' + String(ss).padStart(2, '0') + '</b> · ' + a.n + ' alive · bay ' + (BR.bays[BR.slot] ? BR.bays[BR.slot].n : '?') + '</div>' +
    '<div class="brphase">' + phase + '</div>' +
    '<div class="brzone">' + (out > 0 ? '<span class="bad">IN THE FOG · ' + Math.round(out) + ' from safety</span>' : 'inside the ring · ' + Math.round(BR.zone.r - d) + ' to the edge') + '</div>' +
    '<div class="brk">' + (me ? me.kills : 0) + ' kills · ' + BR.bones + ' bones' + (me && me.pack !== BR_PACK_NONE ? ' · in ' + BR.players[me.pack].name + "'s pack" : '') + '</div>' +
    '</div>';
}
