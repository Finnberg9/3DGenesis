def sub1(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(a[:90],n); return s.replace(a,b)
s=open('g3.html',encoding='utf-8').read()
# ---- instance format: + x-axis hint so flat parts can be rolled about their own axis
s=sub1(s,"const INST_FLOATS = 12;      // pos3 dir3 scale3 col3 -- one format for every primitive",
         "const INST_FLOATS = 15;      // pos3 dir3 scale3 col3 xhint3 -- one format for every primitive (xhint 0 = automatic roll)")
for arr,cnt in (('instData','instCount'),('spikeData','spikeCount'),('plantData','plantCount')):
    a=f"  {arr}[o+9] = col[0]; {arr}[o+10] = col[1]; {arr}[o+11] = col[2];\n"
    s=sub1(s,a,a+f"  {arr}[o+12] = 0; {arr}[o+13] = 0; {arr}[o+14] = 0;\n")
s=sub1(s,"""        { shaderLocation: 5, offset: 36, format: 'float32x3' }] } ] },
    fragment: { module: im, entryPoint: 'fs', targets: [{ format: fmt }] },""","""        { shaderLocation: 5, offset: 36, format: 'float32x3' },
        { shaderLocation: 6, offset: 48, format: 'float32x3' }] } ] },
    fragment: { module: im, entryPoint: 'fs', targets: [{ format: fmt }] },""")
s=sub1(s,"""@vertex fn vs(@location(0) p: vec3<f32>, @location(1) n: vec3<f32>,
              @location(2) iPos: vec3<f32>, @location(3) iDir: vec3<f32>,
              @location(4) iScl: vec3<f32>, @location(5) iCol: vec3<f32>) -> VO {
  let B = basisOf(normalize(iDir));""","""fn basisX(d: vec3<f32>, xh: vec3<f32>) -> mat3x3<f32> {
  let xp = xh - d * dot(xh, d);
  if (dot(xp, xp) < 1e-8) { return basisOf(d); }
  let x = normalize(xp);
  let z = cross(d, x);
  return mat3x3<f32>(x, d, z);
}
@vertex fn vs(@location(0) p: vec3<f32>, @location(1) n: vec3<f32>,
              @location(2) iPos: vec3<f32>, @location(3) iDir: vec3<f32>,
              @location(4) iScl: vec3<f32>, @location(5) iCol: vec3<f32>,
              @location(6) iXh: vec3<f32>) -> VO {
  let B = basisX(normalize(iDir), iXh);""")

# ---- body instances: three colours and a pattern, resolved per fragment in object space
s=sub1(s,"const BINST_FLOATS = 8;                     // pos3 yaw scale tint3",
         "const BINST_FLOATS = 20;                    // pos3 yaw scale base3 coat3 detail3 pattern pad wave3 pad")
s=sub1(s,"""const WGSL_BODY = WGSL_COMMON + `
struct VO { @builtin(position) pos: vec4<f32>, @location(0) nrm: vec3<f32>,
            @location(1) col: vec3<f32>, @location(2) wpos: vec3<f32> };
@vertex fn vs(@location(0) p: vec3<f32>, @location(1) n: vec3<f32>, @location(2) tis: f32,
              @location(3) iPos: vec3<f32>, @location(4) iYaw: f32,
              @location(5) iScl: f32,      @location(6) iTint: vec3<f32>) -> VO {
  let s = sin(iYaw); let c = cos(iYaw);
  let q = p * iScl;
  let w = vec3<f32>(q.x * c - q.z * s, q.y, q.x * s + q.z * c) + iPos;
  let rn = vec3<f32>(n.x * c - n.z * s, n.y, n.x * s + n.z * c);
  // tissue class -> material. Skin takes the creature's own hue; bone, eye and
  // gland are fixed so they read as the same organ on every animal.
  var col = iTint;
  if (tis > 3.5)      { col = iTint * 0.22 + vec3<f32>(0.20, 0.05, 0.06); }   // maw
  else if (tis > 2.5) { col = iTint * 0.4 + vec3<f32>(0.55, 0.20, 0.60); }   // gland
  else if (tis > 1.5) { col = vec3<f32>(0.96, 0.96, 0.93); }                 // eye
  else if (tis > 0.5) { col = vec3<f32>(0.90, 0.86, 0.74); }                 // bone
  var o: VO; o.pos = g.viewProj * vec4<f32>(w, 1.0);
  o.nrm = normalize(rn); o.col = col; o.wpos = w; return o;
}
@fragment fn fs(i: VO) -> @location(0) vec4<f32> {
  return vec4<f32>(shade(i.col, i.nrm, i.wpos), 1.0);
}`;""","""const WGSL_BODY = WGSL_COMMON + `
struct VO { @builtin(position) pos: vec4<f32>, @location(0) nrm: vec3<f32>,
            @location(1) wpos: vec3<f32>, @location(2) opos: vec3<f32>, @location(3) onrm: vec3<f32>,
            @location(4) base: vec3<f32>, @location(5) coat: vec3<f32>, @location(6) detail: vec3<f32>,
            @location(7) pt: vec2<f32> };
@vertex fn vs(@location(0) p: vec3<f32>, @location(1) n: vec3<f32>, @location(2) tis: f32,
              @location(3) iPos: vec3<f32>, @location(4) iYaw: f32,
              @location(5) iScl: f32,      @location(6) iBase: vec3<f32>,
              @location(7) iCoat: vec3<f32>, @location(8) iDetail: vec3<f32>, @location(9) iPat: f32,
              @location(10) iWave: vec3<f32>) -> VO {
  let s = sin(iYaw); let c = cos(iYaw);
  // lateral travelling wave for flexible (serpentine) bodies: x = amplitude,
  // y = phase, z = half body length. Zero amplitude leaves the mesh untouched.
  var pw = p;
  if (iWave.x > 0.0) {
    let wz = iWave.x * sin(iWave.y - p.x * 2.4) * (0.35 + 0.65 * clamp((iWave.z - p.x) / (2.0 * iWave.z), 0.0, 1.0));
    pw = vec3<f32>(p.x, p.y, p.z + wz);
  }
  let q = pw * iScl;
  let w = vec3<f32>(q.x * c - q.z * s, q.y, q.x * s + q.z * c) + iPos;
  let rn = vec3<f32>(n.x * c - n.z * s, n.y, n.x * s + n.z * c);
  var o: VO; o.pos = g.viewProj * vec4<f32>(w, 1.0);
  o.nrm = normalize(rn); o.wpos = w; o.opos = p; o.onrm = n;
  o.base = iBase; o.coat = iCoat; o.detail = iDetail; o.pt = vec2<f32>(iPat, tis);
  return o;
}
@fragment fn fs(i: VO) -> @location(0) vec4<f32> {
  let p = i.opos; let n = normalize(i.onrm);
  // coat: countershaded underside
  let coatW = smoothstep(-0.10, 0.55, -n.y) * 0.95;
  var m = 0.0;
  let pat = i.pt.x;
  if (pat > 0.5 && pat < 1.5) {            // stripes wrapping the body
    m = smoothstep(0.55, 0.72, sin(p.x * 7.0 + sin(p.y * 2.6) * 0.9 + p.z * 0.4));
  } else if (pat > 1.5 && pat < 2.5) {     // spots
    let v = sin(p.x * 8.3 + 0.7) * sin(p.y * 7.9 + 1.3) * sin(p.z * 8.7 + 2.1);
    m = smoothstep(0.22, 0.34, v);
  } else if (pat > 2.5 && pat < 3.5) {     // patches
    let v = sin(p.x * 3.9 + sin(p.z * 3.1) * 1.7) * sin(p.y * 3.6 + sin(p.x * 2.7) * 1.4) + 0.35 * sin(p.z * 5.1 + p.x * 2.0);
    m = smoothstep(0.18, 0.30, v);
  } else if (pat > 3.5 && pat < 4.5) {     // dark saddle along the back
    m = smoothstep(0.35, 0.62, n.y);
  } else if (pat > 4.5) {                  // speckle
    let v = sin(p.x * 23.0) * sin(p.y * 21.0 + 1.0) * sin(p.z * 25.0 + 2.0);
    m = smoothstep(0.30, 0.45, v);
  }
  var col = mix(i.base, i.detail, m * (1.0 - coatW));
  col = mix(col, i.coat, coatW);
  let tis = i.pt.y;
  if (tis > 3.5)      { col = i.base * 0.22 + vec3<f32>(0.20, 0.05, 0.06); }
  else if (tis > 2.5) { col = i.base * 0.4 + vec3<f32>(0.55, 0.20, 0.60); }
  else if (tis > 1.5) { col = vec3<f32>(0.96, 0.96, 0.93); }
  else if (tis > 0.5) { col = vec3<f32>(0.90, 0.86, 0.74); }
  return vec4<f32>(shade(col, i.nrm, i.wpos), 1.0);
}`;
// Unlit geometry with vertex colour (the editor's sky dome)
const WGSL_UNLIT = WGSL_COMMON + `
struct VO { @builtin(position) pos: vec4<f32>, @location(0) col: vec3<f32> };
@vertex fn vs(@location(0) p: vec3<f32>, @location(1) n: vec3<f32>, @location(2) c: vec3<f32>) -> VO {
  var o: VO; o.pos = g.viewProj * vec4<f32>(p, 1.0); o.col = c; return o;
}
@fragment fn fs(i: VO) -> @location(0) vec4<f32> { return vec4<f32>(i.col, 1.0); }`;""")
s=sub1(s,"""        { shaderLocation: 5, offset: 16, format: 'float32'   },
        { shaderLocation: 6, offset: 20, format: 'float32x3' }] } ] },""","""        { shaderLocation: 5, offset: 16, format: 'float32'   },
        { shaderLocation: 6, offset: 20, format: 'float32x3' },
        { shaderLocation: 7, offset: 32, format: 'float32x3' },
        { shaderLocation: 8, offset: 44, format: 'float32x3' },
        { shaderLocation: 9, offset: 56, format: 'float32'   },
        { shaderLocation: 10, offset: 64, format: 'float32x3' }] } ] },""")
# unlit pipeline (no depth write) created alongside the water pipe
s=sub1(s,"""  const sph = makeSphere(16, 11);""","""  const um = dev.createShaderModule({ code: WGSL_UNLIT });
  unlitPipe = dev.createRenderPipeline({
    layout: 'auto',
    vertex: { module: um, entryPoint: 'vs', buffers: [{ arrayStride: 36, attributes: [
      { shaderLocation: 0, offset: 0,  format: 'float32x3' },
      { shaderLocation: 1, offset: 12, format: 'float32x3' },
      { shaderLocation: 2, offset: 24, format: 'float32x3' }] }] },
    fragment: { module: um, entryPoint: 'fs', targets: [{ format: fmt }] },
    primitive: { topology: 'triangle-list', cullMode: 'none' },
    depthStencil: { format: 'depth24plus', depthWriteEnabled: false, depthCompare: 'less-equal' },
    multisample: MS,
  });
  const sph = makeSphere(16, 11);""")
s=sub1(s,"let terrainPipe, instPipe, waterPipe, bodyPipe, bindG;","let terrainPipe, instPipe, waterPipe, bodyPipe, unlitPipe, bindG;")
s=sub1(s,"""    body:    dev.createBindGroup({ layout: bodyPipe.getBindGroupLayout(0),    entries: [{ binding: 0, resource: { buffer: gBuf } }] }),
  };""","""    body:    dev.createBindGroup({ layout: bodyPipe.getBindGroupLayout(0),    entries: [{ binding: 0, resource: { buffer: gBuf } }] }),
    unlit:   dev.createBindGroup({ layout: unlitPipe.getBindGroupLayout(0),   entries: [{ binding: 0, resource: { buffer: gBuf } }] }),
  };""")
# the existing skinned-body push (AI creatures): base, derived belly coat, darker detail, no pattern
s=sub1(s,"""      arr.push(wx(0, 0), bodyY, wz(0, 0), yaw, R, base[0], base[1], base[2]);""",
"""      arr.push(wx(0, 0), bodyY, wz(0, 0), yaw, R, base[0], base[1], base[2],
               belly[0], belly[1], belly[2], base[0] * 0.7, base[1] * 0.7, base[2] * 0.7, 0, 0, 0, 0, 1, 0);""")
open('g3.html','w',encoding='utf-8').write(s)
print('render1 ok')
