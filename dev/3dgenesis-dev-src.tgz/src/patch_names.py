# =====================================================================
# NO GRACE, AND NAMEPLATES.
#
# 1. The five-minute grace period is gone. The gates go up and the match is
#    live: any player can hit any other from the first second. What the grace
#    period was really buying was a window in which the island was still full
#    of animals to loot, and that is now its own timer, decoupled from who may
#    hit whom.
#
# 2. Every other player in the match carries their name and a health bar over
#    their head. Drawn as a DOM layer over the canvas rather than as geometry,
#    because text is the one thing the instanced renderer cannot do, and
#    projected through the same view-projection matrix the frame was drawn
#    with, so a plate cannot drift from the body under it. Terrain occludes
#    them: a plate is not a wallhack.
# =====================================================================
def sub1(s, a, b, cnt=1):
    n = s.count(a); assert n == cnt, (a[:100], n); return s.replace(a, b)
p = 'g3.html'; s = open(p, encoding='utf-8').read()

# ---------------------------------------------------------------- 1. no grace
s = sub1(s, "const BR_GRACE_SECS = 5 * 60;",
"""// There is no grace period. The gates go up and the match is live.
// What the grace period was actually for was a stocked island: this is how
// long the wildlife stays before it thins out and only players are left.
const BR_WILD_SECS = 5 * 60;""")
s = sub1(s, "  on: false, phase: 'off',           // off | cage | grace | open | over",
            "  on: false, phase: 'off',           // off | cage | open | over")
s = sub1(s, """  if (BR.phase === 'cage') return vs == null;
  if (vs == null || as == null) return true;                 // wildlife: always fair game
  if (BR.phase === 'grace') return false;                    // no player may touch another yet""",
"""  if (BR.phase === 'cage') return vs == null;
  if (vs == null || as == null) return true;                 // wildlife: always fair game""")
s = sub1(s, """  if (BR.phase === 'cage' && BR.t >= BR_CAGE_SECS) {
    BR.phase = 'grace';
    brSay('GATES OPEN. No player can hurt another for ' + Math.round(BR_GRACE_SECS / 60) + ' minutes. Hunt the island and take its parts.', 7000);
  } else if (BR.phase === 'grace' && BR.t >= BR_CAGE_SECS + BR_GRACE_SECS) {
    BR.phase = 'open';
    BR._cullAcc = 0;
    brSay('OPEN SEASON. The island empties. Only players are left.', 7000);
  }
  if (BR.phase === 'open') brCullWildlife(dt);""",
"""  if (BR.phase === 'cage' && BR.t >= BR_CAGE_SECS) {
    BR.phase = 'open';
    BR._cullAcc = 0;
    BR._wildSaid = false;
    brSay('GATES OPEN. Everyone can kill everyone. Hunt the island for parts while it lasts.', 7000);
  }
  // The island empties partway through, whoever is left alive. It is a clock
  // on the loot, not a truce.
  if (BR.phase === 'open' && BR.t >= BR_CAGE_SECS + BR_WILD_SECS) {
    if (!BR._wildSaid) { BR._wildSaid = true; brSay('THE ISLAND EMPTIES. Only players are left.', 7000); }
    brCullWildlife(dt);
  }""")
s = sub1(s, "  else if (BR.phase === 'grace') phase = 'GRACE \u00b7 players safe for ' + Math.ceil(BR_CAGE_SECS + BR_GRACE_SECS - BR.t) + 's';\n", "")
s = sub1(s, "  else if (BR.phase === 'open') phase = 'OPEN SEASON';",
"""  else if (BR.phase === 'open') {
    const wl = Math.ceil(BR_CAGE_SECS + BR_WILD_SECS - BR.t);
    phase = wl > 0 ? 'LIVE \u00b7 island empties in ' + wl + 's' : 'LIVE \u00b7 players only';
  }""")
# bots hunt from the moment the gates open, which is now the only live phase
s = sub1(s, """// Bots: run for the middle of the zone, fight what is in reach once the grace
// period is over, and take the fog's damage like everyone else. Deliberately
// simple -- they stand in for players, they are not the point.""",
"""// Bots: run for the middle of the zone, fight whatever is in reach from the
// moment the gates open, and take the fog's damage like everyone else.
// Deliberately simple -- they stand in for players, they are not the point.""")
s = sub1(s, """    // An intent from this client. A server would validate it; locally the only
    // thing that can be refused is a hit inside the grace period, which is
    // enforced in brHitAllowed() so the client and a server agree on the rule.""",
"""    // An intent from this client. A server would validate it; locally the only
    // thing that can be refused is a hit on a caged or packmate target, which
    // is enforced in brHitAllowed() so the client and a server agree.""")
s = sub1(s, "// Every rule below -- the grace period, the zone, damage, looting, packs, the",
            "// Every rule below -- the cage, the zone, damage, looting, packs, the")
open(p, 'w', encoding='utf-8').write(s)
print('grace removed')

# ---------------------------------------------------------------- 2. nameplates
s = open(p, encoding='utf-8').read()
s = sub1(s, '<div id="brChoice"></div>', '<div id="brChoice"></div>\n<div id="brNames"></div>')
s = sub1(s, "function brHudHtml() {",
'''// ---- nameplates ------------------------------------------------------------
// Every other player in the match, named, with the health they have left, over
// their head. Text is the one thing the instanced renderer cannot draw, so
// this is a DOM layer, projected through the SAME view-projection matrix the
// frame was rendered with: a plate cannot drift from the body it belongs to.
//
// It is not a wallhack. A plate is dropped when terrain stands between the
// camera and the body, when the target is beyond BR_NAME_FAR, and when the
// closing fog is thick enough that you could not see them anyway.
const BR_NAME_FAR = 1400;          // world units; a walk is about 40 a second
const BR_NAME_FADE = 420;          // the last stretch fades out rather than popping
const BR_NAME_SAMPLES = 14;        // terrain samples along the line of sight
const BRN = { pool: [], box: null };
// True when the ground rises through the line from the eye to the target.
// Sampled rather than marched: the heightmap is smooth at this scale, and 14
// lookups per player is nothing next to one draw call.
function brNameOccluded(ex, ey, ez, tx, ty, tz) {
  for (let i = 1; i < BR_NAME_SAMPLES; i++) {
    const u = i / BR_NAME_SAMPLES;
    const x = ex + (tx - ex) * u, y = ey + (ty - ey) * u, z = ez + (tz - ez) * u;
    if (groundAt(x, z) > y + 2) return true;
  }
  return false;
}
function brNameNode(i) {
  if (BRN.pool[i]) return BRN.pool[i];
  const el = document.createElement('div');
  el.className = 'brname';
  el.innerHTML = '<span class="bn"></span><i class="bb"><b></b></i>';
  el.style.display = 'none';
  BRN.box.appendChild(el);
  const node = { el, name: el.querySelector('.bn'), bar: el.querySelector('.bb'), fill: el.querySelector('.bb b'),
                 lastName: '', lastF: -1, lastCls: '' };
  BRN.pool[i] = node;
  return node;
}
function brDrawNames() {
  if (!BRN.box) BRN.box = document.getElementById('brNames');
  const box = BRN.box;
  if (!box) return;
  // Nothing over a frozen screen: not while paused, and not while the builder
  // is open over the top of the world.
  if (!BR.on || BR.phase === 'off' || paused || (typeof ED !== 'undefined' && ED.open)) { brNamesHide(0); return; }
  const rect = canvas.getBoundingClientRect();
  const ex = player.camX, ey = player.camY, ez = player.camZ;
  let n = 0;
  for (const q of BR.players) {
    if (q.slot === BR.slot) continue;                       // not your own head
    if (!q.alive || !q.c || !q.c.alive) continue;
    const c = q.c;
    const dx = c.x - ex, dz = c.y - ez;
    const dist = Math.hypot(dx, dz);
    if (dist > BR_NAME_FAR) continue;
    // the fog takes your sight before it takes your health
    if (typeof brFogAt === 'function' && brFogAt(c.x, c.y) > 0.35) continue;
    const ty = fightTopY(c) + 14;
    if (brNameOccluded(ex, ey, ez, c.x, ty, c.y)) continue;
    // project through the frame's own view-projection
    const wx = vpM[0] * c.x + vpM[4] * ty + vpM[8] * c.y + vpM[12];
    const wy = vpM[1] * c.x + vpM[5] * ty + vpM[9] * c.y + vpM[13];
    const ww = vpM[3] * c.x + vpM[7] * ty + vpM[11] * c.y + vpM[15];
    if (!(ww > 0.001)) continue;                            // behind the camera
    const ndcX = wx / ww, ndcY = wy / ww;
    if (ndcX < -1.3 || ndcX > 1.3 || ndcY < -1.3 || ndcY > 1.3) continue;
    const sx = (ndcX * 0.5 + 0.5) * rect.width;
    const sy = (1 - (ndcY * 0.5 + 0.5)) * rect.height;
    const node = brNameNode(n++);
    const f = clamp(c.energy / Math.max(1, c.ph.storage), 0, 1);
    const me = BR.players[BR.slot];
    const friend = !!(me && q.pack !== BR_PACK_NONE && (q.pack === me.pack || q.pack === BR.slot || (me.pack !== BR_PACK_NONE && me.pack === q.slot)));
    const cls = 'brname' + (friend ? ' pack' : '') + (f <= 0.25 ? ' hurt' : '');
    if (node.lastCls !== cls) { node.el.className = cls; node.lastCls = cls; }
    if (node.lastName !== q.name) { node.name.textContent = q.name; node.lastName = q.name; }
    const pct = Math.round(f * 100);
    if (node.lastF !== pct) { node.fill.style.width = pct + '%'; node.lastF = pct; }
    // smaller and fainter with distance, so a crowd at range does not shout
    const k = clamp(1 - (dist - (BR_NAME_FAR - BR_NAME_FADE)) / BR_NAME_FADE, 0, 1);
    const scale = clamp(1.05 - dist / (BR_NAME_FAR * 1.5), 0.6, 1.05);
    node.el.style.transform = 'translate(-50%,-100%) translate(' + sx.toFixed(1) + 'px,' + sy.toFixed(1) + 'px) scale(' + scale.toFixed(2) + ')';
    node.el.style.opacity = (0.35 + 0.65 * k).toFixed(2);
    node.el.style.display = 'block';
  }
  brNamesHide(n);
}
function brNamesHide(from) {
  for (let i = from; i < BRN.pool.length; i++) {
    const nd = BRN.pool[i];
    if (nd && nd.el.style.display !== 'none') nd.el.style.display = 'none';
  }
}

// ---- HUD -------------------------------------------------------------------
function brHudHtml() {''')
# drawn every frame, from the frame that owns vpM, so it can never lag the body
s = sub1(s, """  if (R2on) r2PostPass(enc, fog);
  dev.queue.submit([enc.finish()]);
  return { inst: nInst, plants: nPlant };""",
"""  if (R2on) r2PostPass(enc, fog);
  dev.queue.submit([enc.finish()]);
  try { brDrawNames(); } catch (e) { if (!renderFrame._nameWarn) { renderFrame._nameWarn = 1; console.warn('br names', e); } }
  return { inst: nInst, plants: nPlant };""")
# and taken down the moment a match ends or is quit
s = sub1(s, "function brStop() {", "function brStop() {\n  try { brNamesHide(0); } catch (e) { /* the layer may not exist yet */ }")
s = sub1(s, "#brChoice{", """#brNames{position:fixed;left:0;top:0;width:100%;height:100%;pointer-events:none;z-index:32}
  .brname{position:absolute;left:0;top:0;transform-origin:50% 100%;will-change:transform;
    display:none;min-width:86px;max-width:190px;padding:3px 7px 4px;border-radius:7px;
    background:rgba(6,12,14,.58);border:1px solid rgba(255,120,100,.30);
    font:600 12px/1.15 system-ui,sans-serif;color:#ffd9d2;text-align:center;
    text-shadow:0 1px 3px rgba(0,0,0,.9);backdrop-filter:blur(2px)}
  .brname.pack{border-color:rgba(110,220,180,.42);color:#ccf6e6;background:rgba(6,16,14,.58)}
  .brname.hurt{border-color:rgba(255,70,50,.75)}
  .brname .bn{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;letter-spacing:.01em}
  .brname .bb{display:block;height:4px;margin-top:3px;border-radius:3px;overflow:hidden;
    background:rgba(0,0,0,.55);box-shadow:inset 0 0 0 1px rgba(255,255,255,.10)}
  .brname .bb b{display:block;height:100%;width:100%;border-radius:3px;background:#e2503c;
    transition:width .12s linear}
  .brname.pack .bb b{background:#49c98d}
  .brname.hurt .bb b{background:#ff3a22}
  #brChoice{""")
# test surface
s = sub1(s, "    renderHud: () => brRenderHud(),",
"""    renderHud: () => brRenderHud(),
    wildSecs: BR_WILD_SECS,
    names: () => [...document.querySelectorAll('#brNames .brname')]
      .filter(e => e.style.display !== 'none')
      .map(e => ({ name: e.querySelector('.bn').textContent, hp: e.querySelector('.bb b').style.width, pack: e.classList.contains('pack') })),
    drawNames: () => brDrawNames(),
    // why a given player has no plate, so a missing one can be diagnosed
    // rather than guessed at
    nameWhy: (slot) => {
      const q = BR.players[slot | 0];
      if (!q) return 'no such player';
      if (q.slot === BR.slot) return 'self';
      if (!q.alive || !q.c || !q.c.alive) return 'dead';
      const c = q.c, ex = player.camX, ey = player.camY, ez = player.camZ;
      const dist = Math.hypot(c.x - ex, c.y - ez);
      if (dist > BR_NAME_FAR) return 'far ' + Math.round(dist);
      if (brFogAt(c.x, c.y) > 0.35) return 'fog';
      const ty = fightTopY(c) + 14;
      if (brNameOccluded(ex, ey, ez, c.x, ty, c.y)) return 'occluded';
      const ww = vpM[3] * c.x + vpM[7] * ty + vpM[11] * c.y + vpM[15];
      if (!(ww > 0.001)) return 'behind w=' + ww.toFixed(3);
      const ndcX = (vpM[0] * c.x + vpM[4] * ty + vpM[8] * c.y + vpM[12]) / ww;
      const ndcY = (vpM[1] * c.x + vpM[5] * ty + vpM[9] * c.y + vpM[13]) / ww;
      if (ndcX < -1.3 || ndcX > 1.3 || ndcY < -1.3 || ndcY > 1.3) return 'offscreen ' + ndcX.toFixed(2) + ',' + ndcY.toFixed(2);
      return 'shown';
    },""")
open(p, 'w', encoding='utf-8').write(s)
print('nameplates ok')

s = open(p, encoding='utf-8').read()
assert "BR_GRACE_SECS" not in s, 'grace constant still referenced'
assert s.count("'grace'") == 0, "a 'grace' phase is still referenced"
print('no grace phase left')
