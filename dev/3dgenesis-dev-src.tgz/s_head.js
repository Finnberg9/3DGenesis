module.exports = async (p, T) => {
  await p.click('[data-act="create"]'); await T.wait(3000);
  const list = (process.env.PL || '0,2,7').split(',').map(Number);
  for (let k = 0; k < list.length; k++) {
    await p.evaluate(([pl]) => { const G = window.__G3D, C = G.core, E = G.ED; E.des = C.defaultDesign(pl); E.des._rev = 1; E.sel = null; E.cam.yaw = 0.5; E.cam.pitch = 0.25; E.cam.zoom = 0.5; }, [list[k]]);
    await T.wait(2500);
    await p.screenshot({ path: `head_${k}.png`, clip: { x: 350, y: 60, width: 830, height: 780 } });
  }
};
