// The wet mouth detail has to actually be drawn, and has to actually go away
// when the quality setting says it should.
module.exports = async (p, h) => {
  const fail = [];
  const t = (n, c, x) => { h.log((c ? 'ok  ' : 'FAIL') + '  ' + n + (x != null ? '  ' + x : '')); if (!c) fail.push(n); };
  const errs = []; p.on('pageerror', (e) => errs.push(e.message));

  // a body with a heavy carnivore jaw, held still, drawn at each quality
  await p.evaluate(() => {
    const G = window.__G3D, C2 = window.GenesisCore;
    const d = C2.defaultDesign(10);                 // theropod: crushing jaw
    G.becomeDesigned ? G.becomeDesigned(d) : G.becomeArchetype('theropod');
    G.beginPlay();
  });
  await h.wait(2500);
  t('no page error from the new mouth geometry', errs.length === 0, errs.slice(0, 3).join(' | '));

  const at = async (q) => {
    await p.evaluate((n) => { window.__G3D.gfxSet(n); }, q);
    await h.wait(900);
    return p.evaluate(() => ({ inst: window.__G3D.instCount, gore: window.__G3D.gfx.gore() }));
  };
  const lo = await at('medium');
  const hi = await at('ultra');
  t('the creature is drawn at all', lo.inst > 0 && hi.inst > 0, JSON.stringify({ medium: lo.inst, ultra: hi.inst }));
  t('the wet detail is off at medium and on at ultra', lo.gore === false && hi.gore === true);

  // the geometry itself, counted directly off the part builder rather than
  // inferred from a whole frame (which also contains terrain, foliage and fog)
  const g = await p.evaluate(() => {
    const G = window.__G3D;
    const count = (thumb, lod, gore) => {
      let n = 0;
      const g2 = {
        sp: () => n++, cn: () => n++, ball: () => n++,
        fw: [1, 0, 0], up: [0, 1, 0],
        rotated: () => g2,
      };
      const e = { t: 1.2, seed: 0.7, chomp: 0.3, jaw: 0.6, lod: lod ? 1 : 0, thumb: !!thumb,
                  base: [0.4, 0.4, 0.4], coat: [0.6, 0.6, 0.6], detail: [0.2, 0.2, 0.2], blink: 0 };
      const was = G.GFX.gore; G.GFX.gore = gore ? 1 : 0;
      try { G.VIS.m_rex.draw(g2, [0.4, 0.35, 0.3], e); } catch (err) { n = -1; }
      G.GFX.gore = was;
      return n;
    };
    return { near: count(false, false, true), far: count(false, true, true), low: count(false, false, false), icon: count(true, false, false) };
  });
  t('a crushing jaw close up draws a lot of pieces', g.near > 40, String(g.near));
  t('and fewer when the wet detail is switched off', g.low > 0 && g.low < g.near, g.low + ' vs ' + g.near);
  t('and fewer again far away', g.far > 0 && g.far <= g.low, g.far + ' vs ' + g.low);
  t('but the palette icon keeps it at every setting', g.icon > g.low, g.icon + ' vs ' + g.low);

  // ---- nothing the wet detail adds may leave the mouth ----------------------
  // This is the check that was missing. The inner jaw was pushed forward by
  // nearly two units in jaw space on a muzzle 1.55 long and hung in the air
  // beside the head; it looked obviously wrong on screen and nothing in the
  // code said so. The rule: turning the wet detail ON must not make the mouth
  // any bigger than the mouth, except downward, where saliva is supposed to
  // hang.
  const box = await p.evaluate(() => {
    const G = window.__G3D;
    const grab = (id, gore, open) => {
      const pts = [];
      const rec = (x, y, z) => { if (isFinite(x) && isFinite(y) && isFinite(z)) pts.push([x, y, z]); };
      const g2 = { sp: (x, y, z) => rec(x, y, z), cn: (x, y, z) => rec(x, y, z),
                   ball: (x, y, z) => rec(x, y, z), fw: [1, 0, 0], up: [0, 1, 0], rotated: () => g2 };
      const e = { t: 3.7, seed: 0.41, chomp: 1, jaw: open, lod: 0, thumb: false,
                  base: [0.4, 0.4, 0.4], coat: [0.6, 0.6, 0.6], detail: [0.2, 0.2, 0.2], blink: 0 };
      const was = G.GFX.gore; G.GFX.gore = gore ? 1 : 0;
      try { G.VIS[id].draw(g2, [0.4, 0.35, 0.3], e); } catch (err) { return null; }
      G.GFX.gore = was;
      const lo = [Infinity, Infinity, Infinity], hi = [-Infinity, -Infinity, -Infinity];
      for (const q of pts) for (let k = 0; k < 3; k++) { if (q[k] < lo[k]) lo[k] = q[k]; if (q[k] > hi[k]) hi[k] = q[k]; }
      return { n: pts.length, lo, hi, pts };
    };
    const out = {};
    for (const id of ['m_rex', 'm_spino', 'm_short', 'm_maw', 'm_jaws']) {
      const dry = grab(id, false, 1), wet = grab(id, true, 1);
      if (!dry || !wet) { out[id] = { err: true }; continue; }
      // the muzzle points along +y in engine space; +x is up, so DOWN is -x
      // Lip tendrils are SUPPOSED to hang a little past the lip, so the
      // tolerance is not zero. What this guard is for is the order of
      // magnitude: the inner jaw was nearly two units clear of a muzzle 1.55
      // long. Measured overhang from the tendrils is under 0.2.
      const pad = [0.32, 0.32, 0.32];       // sideways, up, forward slack
      const down = 1.10;                    // saliva may hang this far below
      let worst = 0, where = null;
      for (const q of wet.pts) {
        const over = [
          Math.max(0, q[0] - (dry.hi[0] + pad[1]), (dry.lo[0] - down) - q[0]),
          Math.max(0, q[1] - (dry.hi[1] + pad[2]), (dry.lo[1] - pad[2]) - q[1]),
          Math.max(0, q[2] - (dry.hi[2] + pad[0]), (dry.lo[2] - pad[0]) - q[2]),
        ];
        const m = Math.max(over[0], over[1], over[2]);
        if (m > worst) { worst = m; where = q.map(v => +v.toFixed(2)); }
      }
      out[id] = { worst: +worst.toFixed(3), where, dry: dry.n, wet: wet.n };
    }
    return out;
  });
  for (const id of Object.keys(box)) {
    const b = box[id];
    t('the wet detail stays inside the mouth on ' + id, !b.err && b.worst === 0,
      JSON.stringify(b));
  }

  // and the tongue is one continuous body, not a row of separate blobs
  const cont = await p.evaluate(() => {
    const G = window.__G3D;
    const pts = [];
    const g2 = { sp: (x, y, z) => pts.push([x, y, z]), cn: () => {}, ball: () => {},
                 fw: [1, 0, 0], up: [0, 1, 0], rotated: () => g2 };
    const e = { t: 3.7, seed: 0.41, chomp: 0, jaw: 1, lod: 0, thumb: false,
                base: [0.4, 0.4, 0.4], coat: [0.6, 0.6, 0.6], detail: [0.2, 0.2, 0.2], blink: 0 };
    const was = G.GFX.gore; G.GFX.gore = 1;
    G.VIS.m_rex.draw(g2, [0.4, 0.35, 0.3], e);
    G.GFX.gore = was;
    return pts.length;
  });
  t('a gaping mouth is built from a lot of small pieces, not a few big ones', cont > 20, String(cont));

  h.log(fail.length ? '\nFAILED: ' + fail.join(' | ') : '\nALL HORROR CHECKS PASS');
};
