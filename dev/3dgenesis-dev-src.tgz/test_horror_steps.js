// The wet mouth detail has to actually be drawn, and has to actually go away
// when the quality setting says it should.
module.exports = async (p, h) => {
  const fail = [];
  const t = (n, c, x) => { h.log((c ? 'ok  ' : 'FAIL') + '  ' + n + (x != null ? '  ' + x : '')); if (!c) fail.push(n); };
  const errs = []; p.on('pageerror', (e) => errs.push(e.message));

  // a body with a heavy carnivore jaw, held still, drawn at each quality
  await p.evaluate(() => {
    const G = window.__G3D, C2 = window.GenesisCore;
    const d = C2.defaultDesign(10);                 // theropod: crushing jaw
    G.becomeDesigned ? G.becomeDesigned(d) : G.becomeArchetype('theropod');
    G.beginPlay();
  });
  await h.wait(2500);
  t('no page error from the new mouth geometry', errs.length === 0, errs.slice(0, 3).join(' | '));

  const at = async (q) => {
    await p.evaluate((n) => { window.__G3D.gfxSet(n); }, q);
    await h.wait(900);
    return p.evaluate(() => ({ inst: window.__G3D.instCount, gore: window.__G3D.gfx.gore() }));
  };
  const lo = await at('medium');
  const hi = await at('ultra');
  t('the creature is drawn at all', lo.inst > 0 && hi.inst > 0, JSON.stringify({ medium: lo.inst, ultra: hi.inst }));
  t('the wet detail is off at medium and on at ultra', lo.gore === false && hi.gore === true);

  // the geometry itself, counted directly off the part builder rather than
  // inferred from a whole frame (which also contains terrain, foliage and fog)
  const g = await p.evaluate(() => {
    const G = window.__G3D;
    const count = (thumb, lod, gore) => {
      let n = 0;
      const g2 = {
        sp: () => n++, cn: () => n++, ball: () => n++,
        fw: [1, 0, 0], up: [0, 1, 0],
        rotated: () => g2,
      };
      const e = { t: 1.2, seed: 0.7, chomp: 0.3, jaw: 0.6, lod: lod ? 1 : 0, thumb: !!thumb,
                  base: [0.4, 0.4, 0.4], coat: [0.6, 0.6, 0.6], detail: [0.2, 0.2, 0.2], blink: 0 };
      const was = G.GFX.gore; G.GFX.gore = gore ? 1 : 0;
      try { G.VIS.m_rex.draw(g2, [0.4, 0.35, 0.3], e); } catch (err) { n = -1; }
      G.GFX.gore = was;
      return n;
    };
    return { near: count(false, false, true), far: count(false, true, true), low: count(false, false, false), icon: count(true, false, false) };
  });
  t('a crushing jaw close up draws a lot of pieces', g.near > 40, String(g.near));
  t('and fewer when the wet detail is switched off', g.low > 0 && g.low < g.near, g.low + ' vs ' + g.near);
  t('and fewer again far away', g.far > 0 && g.far <= g.low, g.far + ' vs ' + g.low);
  t('but the palette icon keeps it at every setting', g.icon > g.low, g.icon + ' vs ' + g.low);

  h.log(fail.length ? '\nFAILED: ' + fail.join(' | ') : '\nALL HORROR CHECKS PASS');
};
