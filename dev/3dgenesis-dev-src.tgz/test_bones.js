// Bones economy, core-side: the tier table must cover every part the
// simulation knows about, prices must be the published ladder, and the
// per-world rarity roll must actually gate what the wild can be born with.
const fs = require('fs');
const C = require('./core.js');
const src = fs.readFileSync(__dirname + '/src/bones.js', 'utf8');
// Pull the tables straight out of the source the page uses, so the test can
// never drift from what ships.
function pick(name) {
  const i = src.indexOf('const ' + name + ' = {');
  if (i < 0) throw new Error('test_bones: could not find ' + name + ' in src/bones.js');
  const a = src.indexOf('{', i);
  let depth = 0, b = a;
  for (; b < src.length; b++) {
    if (src[b] === '{') depth++;
    else if (src[b] === '}') { depth--; if (!depth) break; }
  }
  return eval('(' + src.slice(a, b + 1) + ')');
}
const ITEM_TIER = pick('ITEM_TIER');
const BONE_PRICE = pick('BONE_PRICE');
const BONE_TIER_WILD = pick('BONE_TIER_WILD');
const BONE_TIERS = ['weak', 'solid', 'super', 'ultra', 'alpha'];
let ok = true;
const t = (name, cond, extra) => { console.log((cond ? 'ok  ' : 'FAIL') + '  ' + name + (extra != null ? '  ' + extra : '')); if (!cond) ok = false; };

// ---- the table covers exactly the simulation's parts
const sim = Object.keys(C.ITEM_SIM);
const missing = sim.filter(id => !ITEM_TIER[id]);
const extra = Object.keys(ITEM_TIER).filter(id => !C.ITEM_SIM[id]);
t('every part has a tier', missing.length === 0, missing.join(','));
t('no tier for a part that does not exist', extra.length === 0, extra.join(','));
t('prices are the published ladder',
  BONE_PRICE.weak === 50 && BONE_PRICE.solid === 100 && BONE_PRICE.super === 200 &&
  BONE_PRICE.ultra === 500 && BONE_PRICE.alpha === 2000);
t('sell-back is a quarter, floored', Math.floor(BONE_PRICE.alpha * 0.25) === 500);
t('rarer tiers are rarer in the wild',
  BONE_TIER_WILD.weak > BONE_TIER_WILD.solid && BONE_TIER_WILD.solid > BONE_TIER_WILD.super &&
  BONE_TIER_WILD.super > BONE_TIER_WILD.ultra && BONE_TIER_WILD.ultra > BONE_TIER_WILD.alpha);

// ---- the per-world roll, as the page computes it
function worldRarityCap(seed) {
  let h = (seed | 0) >>> 0;
  h = Math.imul(h ^ (h >>> 16), 2246822519) >>> 0;
  h = Math.imul(h ^ (h >>> 13), 3266489917) >>> 0;
  const r = ((h ^ (h >>> 16)) >>> 0) / 4294967296;
  return r < 0.18 ? 'super' : r < 0.82 ? 'ultra' : 'alpha';
}
const caps = {};
for (let i = 0; i < 20000; i++) caps[worldRarityCap(i)] = (caps[worldRarityCap(i)] || 0) + 1;
t('the same seed always rolls the same world', worldRarityCap(12345) === worldRarityCap(12345));
t('most worlds have no alpha parts', caps.alpha / 20000 < 0.25 && caps.alpha / 20000 > 0.10, JSON.stringify(caps));
t('some worlds have no ultra parts either', caps.super / 20000 > 0.10);

// ---- the ladder actually gates wild bodies
const wildW = (id, cap) => {
  const tier = ITEM_TIER[id] || 'solid';
  return BONE_TIERS.indexOf(tier) > BONE_TIERS.indexOf(cap) ? 0 : (BONE_TIER_WILD[tier] || 0);
};
C.DESIGN_API.boneWildWeight = wildW;
C.DESIGN_API.boneWeighted = (rng, opts, cap) => {
  let tot = 0; const w = [];
  for (const [id, b] of opts) { const k = b * wildW(id, cap); w.push(k); tot += k; }
  if (tot <= 0) return opts[0][0];
  let r = rng() * tot;
  for (let i = 0; i < opts.length; i++) { r -= w[i]; if (r <= 0) return opts[i][0]; }
  return opts[opts.length - 1][0];
};
function sample(cap, n) {
  C.DESIGN_API.rarityCap = cap;
  let seed = 12345;
  const rng = () => { seed = (Math.imul(seed ^ (seed >>> 15), 2246822519) + 0x9E3779B9) >>> 0; return ((seed ^ (seed >>> 16)) >>> 0) / 4294967296; };
  const cnt = {};
  for (let i = 0; i < n; i++) {
    const d = C.randomDesign(rng, { diversity: 0.85, diet: 'carn', rarityCap: cap });
    for (const p of d.parts || []) cnt[p.id] = (cnt[p.id] || 0) + 1;
    for (const l of d.limbs || []) { cnt[l.id] = (cnt[l.id] || 0) + 1; if (l.tip) cnt[l.tip.id] = (cnt[l.tip.id] || 0) + 1; }
  }
  return cnt;
}
const N = 5000;
const poor = sample('super', N), mid = sample('ultra', N), rich = sample('alpha', N);
const alphaIds = Object.keys(ITEM_TIER).filter(id => ITEM_TIER[id] === 'alpha');
const ultraIds = Object.keys(ITEM_TIER).filter(id => ITEM_TIER[id] === 'ultra');
const anyOf = (cnt, ids) => ids.reduce((a, id) => a + (cnt[id] || 0), 0);
// The cap governs what the roll may ADD to a body. It does not strip a body
// plan of the parts it is defined by: a pterosaur has wings in every world, or
// it is not a pterosaur. So the guarantee is about the rolled slots.
const ROLLED_ULTRA = ['m_spino', 'h_antler', 's_shell'];
const ROLLED_ALPHA = ['m_rex'];
t('a poor world rolls no ultra parts', anyOf(poor, ROLLED_ULTRA) === 0, anyOf(poor, ROLLED_ULTRA));
t('a poor world rolls no alpha parts', anyOf(poor, ROLLED_ALPHA) === 0, anyOf(poor, ROLLED_ALPHA));
t('a normal world rolls no alpha parts', anyOf(mid, ROLLED_ALPHA) === 0, anyOf(mid, ROLLED_ALPHA));
t('a normal world does roll ultra parts', anyOf(mid, ROLLED_ULTRA) > 0, anyOf(mid, ROLLED_ULTRA));
t('a rich world rolls ultra parts too', anyOf(rich, ROLLED_ULTRA) > 0, anyOf(rich, ROLLED_ULTRA));
t('every world still grows common parts', (poor.m_jaws || 0) > 0 && (rich.m_jaws || 0) > 0);
t('a body plan keeps its own parts whatever the world rolls',
  anyOf(poor, ultraIds) > 0, 'plan-given ultra parts in a poor world: ' + anyOf(poor, ultraIds));

// The alpha rate is far too low to measure through randomDesign in a test-sized
// sample, which is the point of it, so measure the pick itself.
const MOUTHS = [['m_jaws', 3], ['m_maw', 1.2], ['m_hook', 0.8], ['m_short', 0.7], ['m_spino', 0.5], ['m_rex', 0.4]];
function rate(cap, n) {
  let seed = 99991;
  const rng = () => { seed = (Math.imul(seed ^ (seed >>> 15), 2246822519) + 0x9E3779B9) >>> 0; return ((seed ^ (seed >>> 16)) >>> 0) / 4294967296; };
  const cnt = {};
  for (let i = 0; i < n; i++) { const id = C.DESIGN_API.boneWeighted(rng, MOUTHS, cap); cnt[id] = (cnt[id] || 0) + 1; }
  return cnt;
}
const M = 400000;
const rr = rate('alpha', M), rm = rate('ultra', M), rp = rate('super', M);
t('the apex jaw is born about once in a couple of thousand hunters',
  (rr.m_rex || 0) / M > 0.0001 && (rr.m_rex || 0) / M < 0.002, '1 in ' + Math.round(M / Math.max(1, rr.m_rex || 0)));
t('and never at all below an alpha world', (rm.m_rex || 0) === 0 && (rp.m_rex || 0) === 0);
t('the ultra jaw is rare but reachable',
  (rm.m_spino || 0) / M > 0.001 && (rm.m_spino || 0) / M < 0.05, '1 in ' + Math.round(M / Math.max(1, rm.m_spino || 0)));
t('a poor world falls back to what it is allowed', (rp.m_jaws || 0) > M * 0.5);

console.log(ok ? '\nALL BONES TESTS PASS' : '\nBONES TESTS FAILED');
process.exit(ok ? 0 : 1);
