module.exports = async (p, T) => {
  await p.evaluate(() => { const G = window.__G3D; document.getElementById('start').style.display = 'none';
    const t = G.world.forest.trees.filter(t => t.kind === 1); const a = t[(t.length * 0.51) | 0]; G.teleport(a.x + 45, a.y + 45); G.look(-2.35, 0.1); G.setDist(0); });
  await T.wait(5000); await T.shot('trees1.png');
  await p.evaluate(() => { const G = window.__G3D;
    const t = G.world.forest.trees.filter(t => t.kind === 0); const a = t[(t.length * 0.4) | 0]; G.teleport(a.x + 70, a.y + 20); G.look(Math.atan2(-20, -70), 0.15); });
  await T.wait(4000); await T.shot('trees2.png');
};
