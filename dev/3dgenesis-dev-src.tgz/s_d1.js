module.exports = async (p, T) => {
  await p.evaluate(() => document.getElementById('start').style.display = 'none');
  await p.keyboard.press('n'); await p.keyboard.press('n');
  await T.wait(2500);
  const b64 = await p.evaluate(async () => {
    const G = window.__G3D, S = G.sndDbg, ctx = S.SND.ctx;
    const dest = ctx.createMediaStreamDestination();
    S.SND.master.connect(dest);
    const rec = new MediaRecorder(dest.stream, { mimeType: 'audio/webm' });
    const chunks = []; rec.ondataavailable = (e) => chunks.push(e.data);
    rec.start();
    // one of each kind of voice, near and far
    const seen = new Set(); const picks = [];
    for (const c of G.world.creatures) { const v = S.voxOf(c); if (false) picks.push(c); }
    const me = G.player.c;
    for (const c of picks) {
      for (const [w, far] of [['call', 0], ['attack', 0], ['pain', 0], ['call', 1]]) {
        if (me) { const d = far ? 1500 : 60; c.x = me.x + d; c.y = me.y; }
        S.voxCall(c, w);
        await new Promise(r => setTimeout(r, 1700));
      }
    }
    S.distant('roar'); await new Promise(r => setTimeout(r, 14000));
    rec.stop(); await new Promise(r => rec.onstop = r);
    const blob = new Blob(chunks, { type: 'audio/webm' });
    const buf = new Uint8Array(await blob.arrayBuffer());
    let s = ''; for (let i = 0; i < buf.length; i++) s += String.fromCharCode(buf[i]);
    return JSON.stringify({ kinds: [...seen], data: btoa(s) });
  });
  const o = JSON.parse(b64);
  T.log('kinds', o.kinds.join(','));
  require('fs').writeFileSync('d1.webm', Buffer.from(o.data, 'base64'));
};
