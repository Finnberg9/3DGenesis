module.exports = async (p, T) => {
  await p.click('[data-act="create"]');
  await T.wait(4000);
  const put = async (plan, list, limbs) => p.evaluate(([plan, list, limbs]) => {
    const G = window.__G3D, C = G.core, E = G.ED;
    E.des = C.defaultDesign(plan); E.des.parts = []; E.des.limbs = E.des.limbs.filter(l => l.f[1] < -0.5); E.des._rev = 99;
    E.mirror = true;
    const sk = C.buildDesignSkeleton(E.des);
    for (const [id, tx, ty, tz, dx, dy, dz] of list) {
      const h = C.surfaceAt(sk, tx * sk.a, ty * sk.b, tz * sk.b, dx, dy, dz);
      if (h) G.edAddPart(id, h);
    }
    for (const [id, tx, ty, tz, dx, dy, dz, tip] of limbs || []) {
      const h = C.surfaceAt(sk, tx * sk.a, ty * sk.b, tz * sk.b, dx, dy, dz);
      if (h) { G.edAddLimb(id, h); const lb = E.des.limbs[E.des.limbs.length - 2] || E.des.limbs[E.des.limbs.length - 1]; if (tip) G.edSetTip(lb, tip); }
    }
    E.sel = null;
    return [E.des.parts.length, E.des.limbs.length];
  }, [plan, list, limbs]);
  const cam = async (yaw, pitch, zoom) => p.evaluate(([y, pi, z]) => { const E = window.__G3D.ED; E.cam.yaw = y; E.cam.pitch = pi; E.cam.zoom = z; }, [yaw, pitch, zoom]);
  // head parts: mouths / eyes / horns
  T.log(await put(0, [
    ['m_maw', 1.9, 1.1, 0, 1, -0.3, 0], ['e_big', 1.4, 1.5, 0.35, 0.2, 0.6, 0.7], ['h_ram', 1.3, 1.8, 0.3, -0.3, 1, 0.5],
    ['s_plate', 0.2, 1.2, 0, 0, 1, 0], ['s_plate', -0.3, 1.2, 0, 0, 1, 0], ['s_plate', 0.6, 1.1, 0, 0, 1, 0],
    ['d_gland', 0, 0.2, 1, 0, 0.2, 1], ['d_frill', 1.0, 1.1, 0, -0.2, 1, 0], ['w_bat', -0.1, 0.6, 0.6, 0, 0.7, 0.7],
  ]));
  await cam(0.95, 0.2, 0.8); await T.wait(1500); await T.shot('v1.png');
  await cam(2.2, 0.35, 0.8); await T.wait(1500); await T.shot('v2.png');
  T.log(await put(2, [
    ['m_jaws', 1.9, 1.1, 0, 1, -0.3, 0], ['e_slit', 1.3, 1.5, 0.3, 0.2, 0.6, 0.7], ['h_antler', 1.2, 1.9, 0.25, -0.3, 1, 0.4],
    ['s_quills', -0.4, 1.1, 0, 0, 1, 0], ['s_spike', 0.2, 1.1, 0, 0, 1, 0], ['d_crest', 1.1, 2.0, 0, 0, 1, 0], ['w_feather', 0.1, 0.6, 0.6, 0, 0.7, 0.7],
  ], [['l_leg', 0.7, 0, 0.7, 0.2, 0, 1, 't_pincer']]));
  await cam(0.95, 0.2, 0.8); await T.wait(1500); await T.shot('v3.png');
  T.log(await put(8, [
    ['m_trunk', 1.9, 1.0, 0, 1, -0.3, 0], ['e_stalk', 1.2, 1.4, 0.3, 0, 1, 0.3], ['h_tusk', 1.7, 0.8, 0.3, 0.6, -0.2, 0.8], ['s_shell', -0.1, 1.2, 0, 0, 1, 0],
    ['d_antenna', 1.0, 1.6, 0.2, 0, 1, 0.3], ['e_bug', 1.3, 1.1, 0.5, 0.3, 0.3, 1], ['d_gills', 0.9, 0.3, 1, 0, 0, 1],
  ], [['l_leg', 0.8, 0.1, 0.8, 0.3, 0, 1, 't_hand']]));
  await cam(0.8, 0.25, 0.8); await T.wait(1500); await T.shot('v4.png');
  T.log(await put(6, [
    ['m_hook', 1.9, 1.1, 0, 1, -0.3, 0], ['e_cluster', 1.4, 1.3, 0.3, 0.3, 0.6, 0.7], ['f_dorsal', -0.1, 1.2, 0, 0, 1, 0], ['f_fin', 0.3, -0.3, 1, 0, -0.35, 1],
    ['w_insect', 0.1, 0.8, 0.5, 0, 0.8, 0.6], ['s_club', -0.9, 0.2, 0, -1, 0.3, 0],
  ]));
  await cam(0.9, 0.3, 0.8); await T.wait(1500); await T.shot('v5.png');
  // every plan default, one after another
  for (const pl of [1, 3, 4, 5, 7, 9]) {
    await p.evaluate((pl) => { const G = window.__G3D, C = G.core, E = G.ED; E.des = C.defaultDesign(pl); E.des._rev = 5; E.sel = null; }, pl);
    await cam(0.95, 0.2, 1); await T.wait(1200); await T.shot('pl' + pl + '.png');
  }
};
