module.exports = async (p, T) => {
  const r = await p.evaluate(() => { const G = window.__G3D; G.begin(); G.becomeDesigned(G.core.defaultDesign(0)); G.gfxSet('high'); G.R2.auto = false; G.stop();
    const t = G.terrain; let beach = null, snow = null;
    for (let i = 0; i < 40000 && (!beach || !snow); i++) { const x = Math.random() * G.WORLD_W, y = Math.random() * G.WORLD_H; const b = t.biomeAt(x, y); if (!beach && b === 'beach') beach = [x, y]; if (!snow && (b === 'tundra' || b === 'snow')) snow = [x, y]; }
    window.__spots = { beach, snow };
    const dl = G.world.params.dayLen; G.world.bt = Math.floor(G.world.bt / dl) * dl + 0.16 * dl;
    const B = G.world.forest.trees.filter(t => t.kind === 9).length;
    return { beach, snow, boulders: B, cover: G.meshDbg.FOL.cover.length }; });
  T.log(JSON.stringify(r));
  const view = async (name, x, z, yaw, pitch, h, fp) => {
    await p.evaluate(([x, z, yaw, pitch, h, fp]) => { const G = window.__G3D; G.player.spectator = !fp; if (fp) { G.teleport(x, z); G.player.dist = 0; } else { G.player.camX = x; G.player.camZ = z; G.player.camY = G.terrain.height(x, z) * G.HEIGHT_SCALE + h; } G.player.yaw = yaw; G.player.pitch = pitch; for (let i = 0; i < 3; i++) G.step(0.02); if (!fp) { G.player.camX = x; G.player.camZ = z; G.player.camY = Math.max(G.player.camY, G.terrain.height(x, z) * G.HEIGHT_SCALE + h); } G.renderFrame(G.simT); }, [x, z, yaw, pitch, h, fp]);
    await T.wait(2500); await p.evaluate(() => { const G = window.__G3D; G.renderFrame(G.simT); }); await T.wait(900); await T.shot(name);
  };
  const s = await p.evaluate(() => window.__spots);
  // look from the beach toward the sea and the sun
  if (s.beach) {
    const yawSea = await p.evaluate((b) => { const G = window.__G3D, t = G.terrain; let best = 0, bd = 1e9; for (let a = 0; a < 6.28; a += 0.2) { for (let d = 50; d < 1500; d += 50) { if (t.isWater(b[0] + Math.cos(a) * d, b[1] + Math.sin(a) * d)) { if (d < bd) { bd = d; best = a; } break; } } } return best; }, s.beach);
    await view('t2_beach.png', s.beach[0], s.beach[1], yawSea, -0.12, 30, false);
    await view('t2_sky.png', s.beach[0], s.beach[1], yawSea + 1.5, 0.35, 30, false);
  }
  if (s.snow) await view('t2_snow.png', s.snow[0], s.snow[1], 0.5, -0.1, 40, false);
  await view('t2_fp.png', s.beach ? s.beach[0] : 6000, s.beach ? s.beach[1] : 4000, 0.3, -1.0, 0, true);
  await p.evaluate(() => { const G = window.__G3D, dl = G.world.params.dayLen; G.world.bt = Math.floor(G.world.bt / dl) * dl + 0.7 * dl; G.world.light = 0.5 + 0.5 * Math.sin(G.world.bt / dl * 6.283); });
  if (s.beach) await view('t2_night.png', s.beach[0], s.beach[1], 3.0, 0.3, 30, false);
};
