// You are PUT DOWN in your cage, not dropped into it.
//
// Entering a match rebuilds the island and then teleports you to a bay on the
// ring. The fall tracker remembers the ground height under your last position
// and reads a drop in it as the ground falling away beneath you. Across a
// world rebuild that remembered height belongs to an island that no longer
// exists, so the difference was read as a fall, the player was lifted into the
// air by it, and the landing killed them. These checks are the ones that
// would have caught it.
module.exports = async (p, h) => {
  const fail = [];
  const t = (n, c, x) => { h.log((c ? 'ok  ' : 'FAIL') + '  ' + n + (x != null ? '  ' + x : '')); if (!c) fail.push(n); };

  // Free roam first, and stand somewhere high, so the world the match replaces
  // is as different from the match island as possible. That difference is
  // exactly what used to become the fall.
  await p.evaluate(() => { const G = window.__G3D; G.becomeArchetype('theropod'); G.beginPlay(); });
  await h.wait(600);
  const before = await p.evaluate(() => {
    const G = window.__G3D;
    // find the highest ground within reach and stand on it
    let bx = G.player.c.x, bz = G.player.c.y, bg = G.groundY(bx, bz);
    for (let i = 0; i < 400; i++) {
      const x = Math.random() * 40000 + 2000, z = Math.random() * 24000 + 2000;
      const g = G.groundY(x, z);
      if (g > bg) { bg = g; bx = x; bz = z; }
    }
    G.teleport(bx, bz);
    return { x: bx, z: bz, ground: Math.round(bg), energy: G.player.c.energy, storage: G.player.c.ph.storage };
  });
  await h.wait(400);
  t('standing on high ground before the match', before.ground > 0, before.ground + ' units up');
  // a teleport is not a fall
  const tp = await p.evaluate(() => ({ jumpY: window.__G3D.fall.jumpY, grounded: window.__G3D.fall.grounded }));
  t('a teleport does not become a fall', tp.jumpY === 0 && tp.grounded === true, JSON.stringify(tp));

  // ---- into a match
  const full = await p.evaluate(() => { const c = window.__G3D.player.c; c.energy = c.ph.storage; return c.energy; });
  await p.evaluate(() => window.__G3D.br.enter());
  await p.waitForFunction(() => window.__G3D.br.on, null, { timeout: 200000 });
  const at = await p.evaluate(() => {
    const G = window.__G3D, c = G.player.c, bay = G.br.bays[G.br.players.findIndex(q => q.bot === false)] || G.br.bays[0];
    return { jumpY: G.fall.jumpY, grounded: G.fall.grounded, alive: !!(c && c.alive),
             energy: c ? Math.round(c.energy) : 0, was: c ? Math.round(G.groundY(c.x, c.y)) : 0,
             offBay: bay ? Math.round(Math.hypot(c.x - bay.x, c.y - bay.z)) : -1, phase: G.br.phase };
  });
  t('you are on the ground the instant the match starts', at.jumpY === 0 && at.grounded === true, JSON.stringify(at));
  t('and alive, at full health', at.alive && at.energy >= Math.round(full) - 1, at.energy + '/' + Math.round(full));
  t('and standing in your own bay', at.offBay >= 0 && at.offBay < 40, at.offBay + ' from the bay centre');
  t('the match is in the cage phase', at.phase === 'cage', at.phase);

  // ---- and stays there. The fall used to land a frame or two later.
  for (let k = 0; k < 6; k++) {
    await p.evaluate(() => { const G = window.__G3D; for (let i = 0; i < 40; i++) G.step(0.05); });
    await h.wait(120);
  }
  const later = await p.evaluate(() => {
    const G = window.__G3D, c = G.player.c;
    return { jumpY: G.fall.jumpY, alive: !!(c && c.alive), energy: c ? Math.round(c.energy) : 0,
             dead: G.br.deadChoice, phase: G.br.phase };
  });
  t('still on the ground twelve seconds in', later.jumpY === 0, JSON.stringify(later));
  t('still alive, unhurt', later.alive && later.energy >= Math.round(full) * 0.9, later.energy + '/' + Math.round(full));
  t('nothing has killed you', !later.dead, JSON.stringify(later.dead));

  // ---- the death screen names the real cause
  const named = await p.evaluate(() => {
    const G = window.__G3D;
    G.br.kill(G.br.slot != null ? G.br.slot : 0, null, 'fall');
    G.br.renderHud();
    const el = document.getElementById('brChoice');
    const head = el && el.querySelector('h3') ? el.querySelector('h3').textContent : '';
    return { head, cause: G.br.deadChoice && G.br.deadChoice.cause };
  });
  t('a fall is reported as a fall, not as the fog', /FALL/.test(named.head), named.head + ' (' + named.cause + ')');

  h.log(fail.length ? '\nFAILED: ' + fail.join(', ') : '\nALL SPAWN CHECKS PASS');
};
