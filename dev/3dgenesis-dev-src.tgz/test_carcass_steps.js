// Bodies on the ground, and searching one for a part.
module.exports = async (p, h) => {
  const fail = [];
  const t = (n, c, x) => { h.log((c ? 'ok  ' : 'FAIL') + '  ' + n + (x != null ? '  ' + x : '')); if (!c) fail.push(n); };

  await p.evaluate(() => { const G = window.__G3D; G.bones.reset(); G.becomeArchetype('theropod'); G.beginPlay(); });
  await h.wait(1200);
  const near = await p.evaluate(() => { const G = window.__G3D; return { near: G.carc.near, built: G.carc.flush() }; });
  t('the island has bodies lying around you', near.near >= 3, JSON.stringify(near));
  t('and their skeletons build', near.built >= 1, near.built);

  const bodies = await p.evaluate(() => window.__G3D.carc.list().filter(q => q.built));
  t('each body carries real parts', bodies.length > 0 && bodies.every(q => q.parts > 0),
    bodies.length + ' bodies, parts ' + bodies.map(q => q.parts).join('/'));
  t('none of them start looted', bodies.every(q => !q.looted));

  // walk up to one
  const at = await p.evaluate(() => window.__G3D.carc.walkTo(0));
  t('you can walk up to one', !!at, JSON.stringify(at));
  await h.wait(500);
  const tgt = await p.evaluate(() => window.__G3D.carc.target());
  t('standing over it, it is the inspect target', !!tgt && tgt.parts.length > 0, JSON.stringify(tgt));
  const prompt = await p.evaluate(() => window.__G3D.carc.prompt());
  t('and the prompt offers the search', /search the body|search it/.test(prompt) && /CARCASS|at your feet/.test(prompt),
    prompt.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim());

  // search it, take a part, and check the inventory grew by exactly one
  const got = await p.evaluate(() => {
    const G = window.__G3D;
    const opts = G.carc.inspect();
    if (!opts || !opts.length) return null;
    const id = opts[0];
    const before = G.bones.count(id);
    G.carc.pick(1);
    return { id, before, opts: opts.length };
  });
  t('searching offers the parts on the body', !!got && got.opts > 0, JSON.stringify(got));

  const after = await p.evaluate((id) => {
    const G = window.__G3D;
    return { n: G.bones.count(id), picker: !!window.player && !!window.player.picker };
  }, got ? got.id : 'l_leg');
  t('taking one adds exactly one copy', !!got && after.n === got.before + 1, JSON.stringify({ got, after }));

  // ...and the body is picked clean
  const second = await p.evaluate(() => {
    const G = window.__G3D;
    const t0 = G.carc.target();
    const again = G.carc.inspect();
    return { target: t0, again };
  });
  t('a searched body is picked clean', second.target === null && second.again === null, JSON.stringify(second));

  // a different body is still worth searching
  const other = await p.evaluate(() => { const G = window.__G3D; const a = G.carc.walkTo(0); return a; });
  await h.wait(400);
  const otherT = await p.evaluate(() => window.__G3D.carc.target());
  t('the next body along is still untouched', !!other && !!otherT && !otherT.looted, JSON.stringify(otherT));

  // the field is the same field on the same seed
  const a1 = await p.evaluate(() => window.__G3D.carc.list().map(q => q.x + ':' + q.z).sort().join(','));
  await p.reload({ timeout: 180000, waitUntil: 'domcontentloaded' });
  await p.waitForFunction(() => window.__G3D && window.__G3D.ready, null, { timeout: 180000 });
  await p.evaluate(() => { const G = window.__G3D; G.becomeArchetype('theropod'); G.beginPlay(); });
  await h.wait(1200);
  const a2 = await p.evaluate(() => window.__G3D.carc.list().map(q => q.x + ':' + q.z).sort().join(','));
  // The loaded window follows the player, who will not be standing in exactly
  // the same spot, so compare the bodies the two runs BOTH had in range: every
  // one of them must be in the same place.
  const s1 = new Set(a1.split(',')), s2 = new Set(a2.split(','));
  const both = [...s1].filter(q => s2.has(q));
  t('the same seed lays out the same bodies', both.length >= 3 && both.every(q => s1.has(q) && s2.has(q)),
    both.length + ' shared of ' + s1.size + '/' + s2.size + ': ' + both.join(' '));

  h.log(fail.length ? '\nFAILED: ' + fail.join(', ') : '\nALL CARCASS CHECKS PASS');
};
