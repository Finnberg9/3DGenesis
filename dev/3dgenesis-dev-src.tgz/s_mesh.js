module.exports = async (p, T) => {
  const r = await p.evaluate(() => {
    const G = window.__G3D, C = G.core, out = [];
    for (let pl = 0; pl < C.PLANS.length; pl++) {
      const d = C.defaultDesign(pl); d._rev = 1;
      const M = G.meshDbg, Gg = M.designGeo(d);
      const prims = M.creaturePrims(d, Gg);
      let t0 = performance.now(); const m1 = M.meshPrims(prims, 1); const t1 = performance.now() - t0;
      t0 = performance.now(); const m0 = M.meshPrims(prims, 0); const t2 = performance.now() - t0;
      out.push(`plan ${pl}: prims ${prims.length} hi ${t1.toFixed(0)}ms tris ${m1.tris} lo ${t2.toFixed(0)}ms tris ${m0.tris}`);
    }
    return out.join('\n');
  });
  T.log(r);
  await p.click('[data-act="create"]'); await T.wait(4000); await T.shot('m1.png');
  await p.evaluate(() => { const E = window.__G3D.ED; E.cam.yaw = 2.2; E.cam.pitch = 0.35; });
  await T.wait(1500); await T.shot('m2.png');
};
