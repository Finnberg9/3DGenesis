module.exports = async (p, T) => {
  await p.evaluate(() => { const G = window.__G3D; G.begin(); G.stop(); G.showDeath({ deathCause: 'drowned' }); });
  await T.wait(2600);
  T.log(await p.evaluate(() => { const el = document.getElementById('deathfx'); const cs = getComputedStyle(el); return JSON.stringify({ cls: el.className, op: cs.opacity, vis: cs.visibility, z: cs.zIndex, disp: cs.display, anim: cs.animationName }); }));
  await T.shot('death2.png');
};
