module.exports = async (p, T) => {
  await p.evaluate(() => { const G = window.__G3D; G.begin(); G.becomeDesigned(G.core.defaultDesign(1)); G.gfxSet('high'); G.R2.auto = false; });
  await T.wait(1500);
  const info = await p.evaluate(() => { const G = window.__G3D; G.stop(); const me = G.player.c; for (const q of me.cellState) q.grow = 1; me.ph = G.core.develop(me.genome, me.cellState);
    G.player.dist = 160; G.player.pitch = -0.3; G.player.yaw = 0.6;
    const bt = G.world.bt, dl = G.world.params.dayLen; G.world.bt = Math.floor(bt / dl) * dl + 0.2 * dl;
    for (let i = 0; i < 5; i++) G.step(0.02); G.renderFrame(G.simT);
    return { ok: G.R2.ok, casc: G.R2.cascades, sw: G.R2.sw, sh: G.R2.sh, shadow: G.R2.shadowSize }; });
  T.log(JSON.stringify(info));
  await T.wait(1500); await p.evaluate(() => { const G = window.__G3D; G.renderFrame(G.simT); }); await T.wait(1000);
  await T.shot('r2_high.png');
  await p.evaluate(() => { const G = window.__G3D; G.gfxSet('low'); G.renderFrame(G.simT); }); await T.wait(1500);
  await p.evaluate(() => { const G = window.__G3D; G.renderFrame(G.simT); }); await T.wait(1000);
  await T.shot('r2_low.png');
  await p.evaluate(() => { const G = window.__G3D; G.gfxSet('ultra'); const t = G.world.forest.trees.filter(t => t.kind === 1); const a = t[(t.length * 0.5) | 0]; G.teleport(a.x + 60, a.y + 60); G.player.yaw = -2.3; G.player.pitch = -0.15; G.player.dist = 120; for (let i = 0; i < 4; i++) G.step(0.02); G.renderFrame(G.simT); });
  await T.wait(2500); await p.evaluate(() => { const G = window.__G3D; G.renderFrame(G.simT); }); await T.wait(1000);
  await T.shot('r2_forest.png');
};
