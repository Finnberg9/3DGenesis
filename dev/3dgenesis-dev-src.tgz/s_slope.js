module.exports = async (p, T) => {
  const r = await p.evaluate(() => {
    const G = window.__G3D, C = G.core; document.getElementById('start').style.display = 'none';
    G.becomeDesigned(C.defaultDesign(8));
    const me = G.player.c; for (const q of me.cellState) q.grow = 1; me.ph = C.develop(me.genome, me.cellState); me._growthAvg = 1;
    const T = G.terrain, HS = 2000; let best = null;
    for (let k = 0; k < 20000 && !best; k++) {
      const x = 2000 + Math.random() * 21000, y = 2000 + Math.random() * 12000;
      if (T.biomeAt(x, y) !== 'plains' && T.biomeAt(x, y) !== 'savanna') continue;
      const gx = (T.height(x + 20, y) - T.height(x - 20, y)) * HS / 40;
      if (Math.abs(gx) > 0.5 && Math.abs(gx) < 0.8) best = [x, y, gx];
    }
    G.teleport(best[0], best[1]); me.vx = 0; me.vy = 0;
    // face downhill
    G.look(best[2] > 0 ? Math.PI : 0, -0.1); G.setDist(60);
    for (const c of G.world.creatures) if (c !== me && Math.hypot(c.x - me.x, c.y - me.y) < 300) c.alive = false;
    return best;
  });
  T.log(JSON.stringify(r));
  await T.wait(4000);
  // look from the side
  await p.evaluate(() => { const G = window.__G3D; G.player.spectator = false; });
  await T.shot('slope1.png');
  T.log(await p.evaluate(() => { const c = window.__G3D.player.c; return JSON.stringify({ p: c._tiltP, q: c._tiltQ }); }));
};
