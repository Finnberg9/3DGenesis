// Two legs that touch are one leg. This measures the geometry the game
// actually draws -- not the plan numbers -- and fails if any two limbs of any
// offered shape come close enough to fuse into a single trunk under the
// smooth union that makes the skin.
module.exports = async (p, h) => {
  const fail = [];
  const t = (n, c, x) => { h.log((c ? 'ok  ' : 'FAIL') + '  ' + n + (x != null ? '  ' + x : '')); if (!c) fail.push(n); };
  const PLANS = [30, 31, 32, 33, 22, 23, 26, 27, 25, 24, 34, 35, 37, 36];
  const res = await p.evaluate((plans) => {
    const C = window.__G3D.core, D = window.__G3D.meshDbg;
    const out = [];
    const segD = (a, b, c, d) => {       // distance between two segments
      const u = [b[0]-a[0], b[1]-a[1], b[2]-a[2]], v = [d[0]-c[0], d[1]-c[1], d[2]-c[2]];
      const w = [a[0]-c[0], a[1]-c[1], a[2]-c[2]];
      const dot = (x, y) => x[0]*y[0] + x[1]*y[1] + x[2]*y[2];
      const A = dot(u,u), B = dot(u,v), Cc = dot(v,v), Dd = dot(u,w), E = dot(v,w);
      const den = A*Cc - B*B; let s0, t0;
      if (den < 1e-9) { s0 = 0; t0 = Cc > 1e-9 ? E/Cc : 0; }
      else { s0 = (B*E - Cc*Dd)/den; t0 = (A*E - B*Dd)/den; }
      s0 = Math.max(0, Math.min(1, s0)); t0 = Math.max(0, Math.min(1, t0));
      const px = a[0]+u[0]*s0 - (c[0]+v[0]*t0), py = a[1]+u[1]*s0 - (c[1]+v[1]*t0), pz = a[2]+u[2]*s0 - (c[2]+v[2]*t0);
      return Math.hypot(px, py, pz);
    };
    for (const pl of plans) {
      const des = C.defaultDesign(pl);
      const G = D.designGeo(des);
      const prims = D.creaturePrims(des, G);
      const LB = G._limbBones || [];
      if (LB.length < 2) { out.push({ pl, n: LB.length, worst: 9, pair: null }); continue; }
      // every drawn shaft, grouped by which limb it belongs to
      const own = new Map();
      LB.forEach((bs, i) => { own.set(bs[0], i); own.set(bs[1], i); });
      const shafts = [];   // { li, a, b, r }
      for (const q of prims) {
        if (q.t !== 'c') continue;
        const li = own.get(q.bone);
        if (li == null) continue;
        shafts.push({ li, a: [q.ax, q.ay, q.az], b: [q.bx, q.by, q.bz], r: Math.max(q.ra, q.rb) });
      }
      let worst = 9, pair = null;
      for (let i = 0; i < shafts.length; i++) for (let j = i + 1; j < shafts.length; j++) {
        if (shafts[i].li === shafts[j].li) continue;
        const d = segD(shafts[i].a, shafts[i].b, shafts[j].a, shafts[j].b);
        // surface-to-surface, as a fraction of the two shafts' combined radius:
        // 0 means the two legs are touching and the union makes them one
        const rr = shafts[i].r + shafts[j].r;
        const clr = rr > 1e-6 ? (d - rr) / rr : 9;
        if (clr < worst) { worst = clr; pair = [shafts[i].li, shafts[j].li]; }
      }
      out.push({ pl, n: LB.length, worst: Math.round(worst * 1000) / 1000, pair });
    }
    return out;
  }, PLANS);

  for (const r of res) {
    // a shaft's own radius of clear air between two legs. Below zero they
    // intersect outright; near zero the smooth union welds them.
    t('plan ' + r.pl + ' keeps its ' + r.n + ' limbs apart',
      r.worst > 0.02, 'clearance ' + r.worst + (r.pair ? ' between limbs ' + r.pair.join(' and ') : ''));
  }
  const worst = res.reduce((m, r) => Math.min(m, r.worst), 9);
  h.log('\ntightest pair anywhere in the offered set: ' + worst + ' shaft radii');
  h.log(fail.length ? 'FAILED: ' + fail.join(' | ') : 'NO LIMB MERGES INTO ANOTHER');
};
