module.exports = async (p, T) => {
  const r = await p.evaluate(() => {
    const G = window.__G3D, C = G.core, w = G.world;
    document.getElementById('start').style.display = 'none';
    // a strong hunter design for the player
    const d = C.defaultDesign(2);
    G.becomeDesigned(d);
    const me = G.player.c;
    for (const q of me.cellState) q.grow = 1; me.ph = C.develop(me.genome, me.cellState); me._growthAvg = 1; me.energy = me.ph.storage;
    // 250 designed animals of every plan around the island
    const isl = G.terrain.island;
    for (let i = 0; i < 250; i++) {
      const g = C.seedHerbivore(w, w.rng); g.design = C.defaultDesign(i % 10); C.compileDesign(g);
      const a = Math.random() * 6.28, rr = Math.random() * 2500;
      const c = C.makeCreature(g, (isl ? isl.cx : 6400) + Math.cos(a) * rr, (isl ? isl.cy : 4000) + Math.sin(a) * rr, 400);
      for (const q of c.cellState) q.grow = Math.random(); c.ph = C.develop(g, c.cellState);
      w.creatures.push(c);
    }
    // a victim right in front of the player
    const g = C.seedHerbivore(w, w.rng); const prey = C.makeCreature(g, me.x + Math.cos(G.player.yaw) * 30, me.y + Math.sin(G.player.yaw) * 30, 5);
    w.creatures.push(prey);
    G.player.dist = 200; G.player.pitch = -0.35;
    return w.creatures.length;
  });
  T.log('creatures', r);
  // run the real loop a while (sim + render)
  const t0 = Date.now(); let frames0 = await p.evaluate(() => performance.now());
  await T.wait(8000);
  // attack until the prey dies -> picker
  for (let i = 0; i < 40; i++) {
    const got = await p.evaluate(() => { const G = window.__G3D; G.player.atkCD = 0; const me = G.player.c; const t = G.world.creatures.find(c => c.alive && c !== me && Math.hypot(c.x - me.x, c.y - me.y) < 120); if (t) { G.player.yaw = Math.atan2(t.y - me.y, t.x - me.x); } G.FIGHT.stam = 100; G.attack(); for (let k = 0; k < 30; k++) G.step(0.02); return !!G.picker; });
    if (got) break;
    await T.wait(120);
  }
  T.log('picker after attacks', await p.evaluate(() => JSON.stringify(window.__G3D.picker && window.__G3D.picker.opts)), 'kills', await p.evaluate(() => window.__G3D.PROG.kills));
  await T.shot('st1.png');
  await p.keyboard.press('1'); await T.wait(300);
  // step the simulation hard (no render) for 60 bio-seconds to exercise births, deaths and starvation of designed bodies
  const res = await p.evaluate(() => { const G = window.__G3D; let err = null; try { for (let i = 0; i < 600; i++) G.step(0.05); } catch (e) { err = e.message + ' ' + e.stack.split('\n')[1]; } const w = G.world; return { err, alive: w.creatures.filter(c => c.alive).length, designed: w.creatures.filter(c => c.alive && c.genome.design).length }; });
  T.log('sim', JSON.stringify(res));
  await T.wait(3000);
  await T.shot('st2.png');
};
