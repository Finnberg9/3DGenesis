module.exports = async (p, T) => {
  await p.click('[data-act="create"]'); await T.wait(3000);
  for (const [i, sp, tl] of [[0, 0, 0], [1, 1.4, 0], [2, 0, 0.9]]) {
    await p.evaluate(([sp, tl]) => { const G = window.__G3D, C = G.core, E = G.ED; E.des = C.defaultDesign(0); for (const l of E.des.limbs) { l.tip = { id: 't_claw', c: null, s: 1.6, spin: sp, tilt: tl }; } E.des._rev = Math.random() * 1e6 | 0; E.sel = null; E.cam.yaw = 0.9; E.cam.pitch = 0.1; E.cam.zoom = 0.5; }, [sp, tl]);
    await T.wait(2500);
    await p.screenshot({ path: `tip_${i}.png`, clip: { x: 450, y: 400, width: 600, height: 440 } });
  }
};
