// A match starts everyone at nothing. These checks drive a real match: the
// body you actually spawn with, the heap actually on your cage floor, the
// creature list actually in the world, and the cage walls themselves.
module.exports = async (p, h) => {
  const fail = [];
  const t = (n, c, x) => { h.log((c ? 'ok  ' : 'FAIL') + '  ' + n + (x != null ? '  ' + x : '')); if (!c) fail.push(n); };

  // own some parts first, so the stash has something to protect
  await p.evaluate(() => {
    const G = window.__G3D;
    G.bones.reset(); G.bones.earn(100000);
    for (const id of ['m_rex', 's_shell', 't_claw']) G.bones.buy(id);
    G.becomeArchetype('theropod'); G.beginPlay();
  });
  await h.wait(600);
  const before = await p.evaluate(() => Object.assign({}, window.__G3D.PROG.owned));
  t('you own parts before the match', Object.keys(before).length > 0, JSON.stringify(before));

  await p.evaluate(() => window.__G3D.br.enter());
  for (let i = 0; i < 40; i++) { await h.wait(1000); if (await p.evaluate(() => window.__G3D.br.on)) break; }
  const st = await p.evaluate(() => ({ on: window.__G3D.br.on, phase: window.__G3D.br.phase, n: window.__G3D.br.players.length }));
  t('the match is running', st.on === true, JSON.stringify(st));

  // ---- nothing on you ------------------------------------------------------
  const me = await p.evaluate(() => window.__G3D.br.bare());
  t('you spawn with no weapon at all', me && me.weapon === 0, JSON.stringify(me && { weapon: me.weapon, cats: me.cats }));
  t('and exactly 100 hp', me && me.hp === 100, String(me && me.hp));
  t('no mouth, no horn, no spike on the body', me && !me.cats.MOUTH && !me.cats.HORN && !me.cats.SPIKE, JSON.stringify(me.cats));
  t('but you can still see', (me.cats.EYE || 0) > 0, String(me.cats.EYE));
  t('and you still have legs to walk on', me.limbs > 0, String(me.limbs));
  t('with plain feet, not bought claws', me.tips.every(x => x === null || x === 't_paw'), JSON.stringify(me.tips));

  // every bot too
  const bots = await p.evaluate(() => {
    const G = window.__G3D, out = [];
    for (let i = 0; i < G.br.players.length; i++) { const b = G.br.bare(i); if (b) out.push(b.weapon); }
    return out;
  });
  t('and so does every other player in the match', bots.length > 1 && bots.every(w => w === 0),
    bots.length + ' players, max weapon ' + Math.max(...bots));

  // ---- your own kit is safe ------------------------------------------------
  const inMatch = await p.evaluate(() => ({ owned: window.__G3D.br.owned(), stashed: window.__G3D.br.stashed() }));
  t('your own parts are out of the match', Object.keys(inMatch.owned).length === 0, JSON.stringify(inMatch.owned));
  t('and held safely aside', JSON.stringify(inMatch.stashed) === JSON.stringify(before), JSON.stringify(inMatch.stashed));

  // ---- the pile in your cage -----------------------------------------------
  const pile = await p.evaluate(() => window.__G3D.br.pile());
  t('there is a starting pile in your bay', pile.ids.length === 2, JSON.stringify(pile.ids));
  t('and it holds a mouth and a weapon', /^m_/.test(pile.ids[0]) && /^(s_|t_|h_)/.test(pile.ids[1]), JSON.stringify(pile.ids));
  t('and it is not taken yet', pile.taken === false);
  const tk = await p.evaluate(() => { const G = window.__G3D; G.br.goToPile(); return { here: G.br.pile().here, took: G.br.takePile(), owned: G.br.owned() }; });
  t('standing on it, you can take it', tk.here === true && tk.took.ok === true, JSON.stringify(tk.took));
  t('and the two parts are yours', Object.keys(tk.owned).length === 2 && Object.values(tk.owned).every(v => v === 1), JSON.stringify(tk.owned));
  const tw = await p.evaluate(() => window.__G3D.br.takePile());
  t('and the pile cannot be taken twice', tw.ok === false, JSON.stringify(tw));

  // ---- the cage holds, while it is still a cage ----------------------------
  const cage = await p.evaluate(() => {
    const G = window.__G3D;
    return { phase: G.br.phase, gateY: G.br.gateY,
             back: G.br.testWall(-900, 0), left: G.br.testWall(0, -900),
             right: G.br.testWall(0, 900), gate: G.br.testWall(900, 0) };
  });
  const R = cage.back.R;
  t('the gate is still down', cage.phase === 'cage' && cage.gateY < 0.5, JSON.stringify({ phase: cage.phase, gateY: cage.gateY }));
  t('you cannot walk out of the back wall', Math.abs(cage.back.lx) <= R, JSON.stringify(cage.back));
  t('nor either side', Math.abs(cage.left.lz) <= R && Math.abs(cage.right.lz) <= R, JSON.stringify([cage.left, cage.right]));
  t('nor through the closed gate', cage.gate.lx <= R, JSON.stringify(cage.gate));
  // and once it lifts, that one face and only that one face opens
  const open = await p.evaluate(() => {
    const G = window.__G3D;
    for (let i = 0; i < 40; i++) G.br.tick(1);          // past the gate
    return { phase: G.br.phase, gateY: G.br.gateY };
  });
  t('the gate opens on its own clock', open.phase === 'open' && open.gateY > 0.5, JSON.stringify(open));

  // ---- no wildlife ---------------------------------------------------------
  const w0 = await p.evaluate(() => window.__G3D.br.wildAlive());
  t('there is not one wild animal in the match', w0 === 0, String(w0));
  const w1 = await p.evaluate(async () => {
    const G = window.__G3D;
    for (let i = 0; i < 120; i++) G.br.tick(1);   // two minutes in
    return G.br.wildAlive();
  });
  t('and still none two minutes later', w1 === 0, String(w1));

  // ---- no fish in a deathmatch ---------------------------------------------
  const sw = await p.evaluate(() => {
    const G = window.__G3D, C2 = window.GenesisCore;
    const walkers = G.br.walkers();
    const out = { walkers, checked: [] };
    for (let pi = 0; pi < C2.PLANS.length; pi++) {
      const d = C2.defaultDesign(pi);
      const legs = G.br.legsOf(d);
      const bare = G.br.bareOf(d);
      out.checked.push({ pi, legs, bareLegs: G.br.legsOf(bare), bornPlan: bare.plan });
    }
    return out;
  });
  const legless = sw.checked.filter(r => r.legs === 0);
  t('some body plans genuinely cannot walk', legless.length > 0, legless.map(r => r.pi).join(','));
  t('and none of them is offered as a walker', legless.every(r => sw.walkers.indexOf(r.pi) < 0), JSON.stringify(sw.walkers));
  t('every plan, taken into a match, comes out with legs',
    sw.checked.every(r => r.bareLegs > 0), JSON.stringify(sw.checked.filter(r => r.bareLegs <= 0)));
  t('a legless shape is swapped for a different plan, not left as it was',
    legless.every(r => r.bornPlan !== r.pi), JSON.stringify(legless.map(r => r.pi + '->' + r.bornPlan)));
  t('while a walking shape is left exactly as you built it',
    sw.checked.filter(r => r.legs > 0).every(r => r.bornPlan === r.pi));
  const keeps = await p.evaluate(() => {
    const G = window.__G3D, C2 = window.GenesisCore;
    const fish = C2.defaultDesign(G.br.walkers().indexOf(6) < 0 ? 6 : 19);
    fish.col.base = [0.11, 0.22, 0.33];
    const bare = G.br.bareOf(fish);
    return { want: fish.col.base, got: bare.col.base, legs: G.br.legsOf(bare) };
  });
  t('and the swap keeps your colours', JSON.stringify(keeps.want) === JSON.stringify(keeps.got), JSON.stringify(keeps));

  // every bot in the lobby can walk too
  const botLegs = await p.evaluate(() => {
    const G = window.__G3D, out = [];
    for (let i = 0; i < G.br.players.length; i++) {
      const q = G.br.players[i];
      if (q && q.c && q.c.genome && q.c.genome.design) out.push(G.br.legsOf(q.c.genome.design));
    }
    return out;
  });
  t('and not one bot in the lobby is a fish', botLegs.length > 1 && botLegs.every(n => n > 0),
    botLegs.length + ' bodies, fewest legs ' + Math.min(...botLegs));

  h.log(fail.length ? '\nFAILED: ' + fail.join(' | ') : '\nALL MATCH-START CHECKS PASS');
};
