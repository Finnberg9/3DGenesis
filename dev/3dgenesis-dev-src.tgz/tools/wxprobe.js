module.exports = async (p, h) => {
  await p.evaluate(() => {
    const G = window.__G3D, C2 = window.GenesisCore;
    G.becomeDesigned ? G.becomeDesigned(C2.defaultDesign(10)) : G.becomeArchetype('theropod');
    G.beginPlay();
  });
  await h.wait(3000);
  await p.evaluate(() => window.__G3D.weather.set(1.0, 0.9, 1.0));
  await h.wait(1500);
  h.log('state', JSON.stringify(await p.evaluate(() => window.__G3D.weather.state)));
};
