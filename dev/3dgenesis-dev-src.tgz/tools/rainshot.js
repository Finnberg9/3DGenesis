// The rain, at ULTRA, from the open, in the same conditions Finn screenshotted.
// The test is whether you can see the world through it.
module.exports = async (p, h) => {
  await p.evaluate(() => {
    const G = window.__G3D, C2 = window.GenesisCore;
    G.gfxSet('high');
    G.becomeDesigned ? G.becomeDesigned(C2.defaultDesign(10)) : G.becomeArchetype('theropod');
    G.beginPlay();
  });
  await h.wait(5000);
  await p.evaluate(() => {
    const G = window.__G3D, T = G.terrain;
    for (let i = 0; i < 4000; i++) {
      const x = Math.random() * T.w, z = Math.random() * T.h;
      if (T.isWater(x, z)) continue;
      const b = T.biomeAt(x, z);
      if (b === 'plains' || b === 'savanna') { G.teleport(x, z); break; }
    }
    G.look(1.2, 0.0);
  });
  await h.wait(3000);
  await p.evaluate(() => window.__G3D.weather.set(0.65, 0, 0.75));
  await h.wait(12000);
  await h.shot('shots/rain_ultra.png');
  h.log('rain', JSON.stringify(await p.evaluate(() => window.__G3D.weather.state)));
  h.log('perf', JSON.stringify(await p.evaluate(() => window.__G3D.br.perf())));
};
