// Dry vs storm vs flash, from the same open ground, with nothing standing on
// the lens. Looking is the only test that matters for weather.
module.exports = async (p, h) => {
  await p.evaluate(() => {
    const G = window.__G3D, C2 = window.GenesisCore;
    G.gfxSet('low');
    G.becomeDesigned ? G.becomeDesigned(C2.defaultDesign(10)) : G.becomeArchetype('theropod');
    G.beginPlay();
  });
  await h.wait(4000);
  // open ground, nothing large within 300 units, and a level horizon
  const where = await p.evaluate(() => {
    const G = window.__G3D, T = G.terrain, W = G.world;
    let best = null, bestScore = -1;
    for (let i = 0; i < 4000; i++) {
      const x = Math.random() * (T.w || 4096), z = Math.random() * (T.h || 4096);
      const b = T.biomeAt(x, z);
      if (b !== 'plains' && b !== 'savanna' && b !== 'beach') continue;
      let near = 0;
      for (const o of W.creatures) { if (!o.alive) continue; const d = Math.hypot(o.x - x, o.y - z); if (d < 260) near += o.ph.mass; }
      const score = 1000 - near * 10;
      if (score > bestScore) { bestScore = score; best = [x, z, b]; }
      if (bestScore > 990) break;
    }
    if (best) G.teleport(best[0], best[1]);
    return best;
  });
  h.log('standing on', JSON.stringify(where));
  await h.wait(2500);
  await p.evaluate(() => { window.__G3D.look(1.2, 0.00); });
  const shot = async (name, r, st, wet) => {
    await p.evaluate(([a, b, c]) => window.__G3D.weather.set(a, b, c), [r, st, wet]);
    await h.wait(9000);
    await h.shot('shots/' + name + '.png');
    h.log(name, JSON.stringify(await p.evaluate(() => window.__G3D.weather.state)));
  };
  await shot('wx_dry', 0, 0, 0);
  await shot('wx_rain', 0.5, 0, 0.7);
  await shot('wx_storm', 1.0, 0.9, 1.0);
  await p.evaluate(() => { window.__G3D.weather.bolt(); });
  await h.wait(40); await h.shot('shots/wx_bolt.png');
};
