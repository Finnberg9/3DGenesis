#!/usr/bin/env python3
"""Contact sheet from shots/*.png. Usage: python3 tools/sheet.py out.png plan30 plan31 ..."""
import sys, os
from PIL import Image, ImageDraw
out = sys.argv[1]
keys = sys.argv[2:]
if not keys:
    keys = sorted([f[:-4] for f in os.listdir('shots') if f.startswith('plan') and f.endswith('.png')],
                  key=lambda k: int(k[4:]))
CELL, PAD, LAB = 192, 8, 18
cols = min(5, max(1, len(keys)))
rows = (len(keys) + cols - 1) // cols
W = cols * (CELL + PAD) + PAD
H = rows * (CELL + PAD + LAB) + PAD
sheet = Image.new('RGB', (W, H), (18, 18, 20))
d = ImageDraw.Draw(sheet)
for i, k in enumerate(keys):
    path = 'shots/%s.png' % k
    if not os.path.exists(path):
        continue
    im = Image.open(path).convert('RGB').resize((CELL, CELL), Image.LANCZOS)
    x = PAD + (i % cols) * (CELL + PAD)
    y = PAD + (i // cols) * (CELL + PAD + LAB)
    sheet.paste(im, (x, y))
    d.text((x + 2, y + CELL + 3), k, fill=(200, 200, 200))
sheet.save(out)
print('wrote %s  %dx%d  %d tiles' % (out, W, H, len(keys)))
