module.exports = async (p, h) => {
  const r = await p.evaluate(() => {
    const C = window.__G3D.core, D = window.__G3D.meshDbg;
    const des = C.defaultDesign(47);
    const out = { desLimbs: (des.limbs || []).length };
    let G;
    try { G = D.designGeo(des); } catch (e) { out.geoErr = e.message; return out; }
    out.clsKeys = Object.keys(G.cls || {});
    out.clsLimbs = (G.cls && G.cls.limbs) ? G.cls.limbs.length : -1;
    out.clsLegs = (G.cls && G.cls.legs) ? G.cls.legs.length : -1;
    try { const pr = D.creaturePrims(des, G); out.prims = pr.length; }
    catch (e) { out.primErr = e.message + ' | ' + (e.stack || '').split('\n')[1]; }
    out.limbBones = (G._limbBones || []).length;
    return out;
  });
  h.log(JSON.stringify(r, null, 1));
};
