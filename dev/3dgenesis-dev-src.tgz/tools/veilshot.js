// You, and then you veiled. The second should be a shimmer you can just steer
// by, not an empty screen and not a solid animal with a purple wash.
module.exports = async (p, h) => {
  await p.evaluate(() => {
    const G = window.__G3D, C2 = window.GenesisCore;
    G.gfxSet('low');
    G.becomeDesigned ? G.becomeDesigned(C2.defaultDesign(10)) : G.becomeArchetype('theropod');
    G.beginPlay();
  });
  await h.wait(4000);
  await p.evaluate(() => {
    const G = window.__G3D, T = G.terrain;
    for (let i = 0; i < 3000; i++) {
      const x = Math.random() * T.w, z = Math.random() * T.h;
      if (T.isWater(x, z)) continue;
      const b = T.biomeAt(x, z);
      if (b === 'plains' || b === 'savanna') { G.teleport(x, z); break; }
    }
    G.look(1.2, -0.25);
  });
  await h.wait(7000); await h.shot('shots/veil_off.png');
  await p.evaluate(() => { const G = window.__G3D; G.spell.give('veil', 1); G.spell.use('veil'); });
  await h.wait(9000); await h.shot('shots/veil_on.png');
  h.log('veil', JSON.stringify(await p.evaluate(() => window.__G3D.br.veil())));
};
