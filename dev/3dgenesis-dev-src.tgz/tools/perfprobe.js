// Where does an ultra frame actually go? Measured, not guessed: the same view,
// the same spot, one thing changed at a time, ftGpu read off the honest clock.
module.exports = async (p, h) => {
  await p.evaluate(() => {
    const G = window.__G3D, C2 = window.GenesisCore;
    G.gfxSet('ultra');
    G.becomeDesigned ? G.becomeDesigned(C2.defaultDesign(10)) : G.becomeArchetype('theropod');
    G.beginPlay();
  });
  await h.wait(5000);
  await p.evaluate(() => {
    const G = window.__G3D, T = G.terrain;
    for (let i = 0; i < 4000; i++) {
      const x = Math.random() * T.w, z = Math.random() * T.h;
      if (T.isWater(x, z)) continue;
      const b = T.biomeAt(x, z);
      if (b === 'forest' || b === 'plains') { G.teleport(x, z); break; }
    }
    G.look(1.2, 0.0);
  });
  await h.wait(4000);
  const measure = async (name, setup) => {
    await p.evaluate(setup);
    await h.wait(3000);                       // let the old frames drain
    await p.evaluate(() => { window.__G3D.br.perfReset(); });
    await h.wait(16000);
    const r = await p.evaluate(() => window.__G3D.br.perf());
    h.log(name.padEnd(26), 'ftGpu', String(r.ftGpu).padStart(7), 'ms   scale', r.scale, ' drops', r.drops, ' subs', r.subs, ' dones', r.dones, ' api', r.api, ' fps', r.fps);
    return r;
  };
  await measure('ultra, dry, as shipped', () => { window.__G3D.weather.set(0, 0, 0); });
  await measure('ultra + heavy rain',     () => { window.__G3D.weather.set(1, 0, 1); });
  await measure('rain off again',         () => { window.__G3D.weather.set(0, 0, 0); });
  await measure('render scale 1.00',      () => { window.__G3D.gfx.setRes(1.0); });
  await measure('render scale 0.85',      () => { window.__G3D.gfx.setRes(0.85); });
  await measure('scale 1.0, half plants', () => { window.__G3D.gfx.setRes(1.0); window.__G3D.gfx.setPlants(0.5); });
  await measure('scale 1.0, no shadows',  () => { window.__G3D.gfx.setPlants(1); window.__G3D.gfx.setShadow(0); });
};
