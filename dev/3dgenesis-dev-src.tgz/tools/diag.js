module.exports = async (p, h) => {
  await p.evaluate(() => window.__G3D.openEditor('start'));
  for (let i=0;i<10;i++){
    await h.wait(4000);
    const s = await p.evaluate(() => ({ ED: typeof ED!=='undefined', ready: typeof ED!=='undefined'&&ED.thumbsReady, busy: typeof ED!=='undefined'&&ED.thumbsBusy, n: typeof ED!=='undefined'&&ED.thumbs?Object.keys(ED.thumbs).length:-1 }));
    h.log(i+' '+JSON.stringify(s));
    if (s.ready) break;
  }
};
