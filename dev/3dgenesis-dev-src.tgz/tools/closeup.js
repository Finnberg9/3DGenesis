// Full-viewport render of one body plan in the builder. The 192 px palette tile
// is the right instrument for a SILHOUETTE and the wrong one for surface: a
// rib 0.2 units deep on a 6 unit animal is under a pixel there. This is how the
// skin and the body sectioning actually get looked at.
//   PLANS=44,47 node play.js tools/closeup.js
module.exports = async (p, h) => {
  await p.evaluate(() => window.__G3D.openEditor('start'));
  for (let k = 0; k < 40; k++) { await h.wait(2000); if (await p.evaluate(() => window.__G3D.bones.thumbsReady())) break; }
  await p.evaluate(() => window.__G3D.bones.tab('body'));
  await h.wait(600);
  for (const pi of (process.env.PLANS || '44').split(',')) {
    const ok = await p.evaluate((n) => {
      const t = document.querySelector('#edGrid .edtile.plan[data-plan="' + n + '"]');
      if (!t) return false; t.click(); return true;
    }, pi);
    if (!ok) { h.log('no tile for plan ' + pi); continue; }
    await h.wait(3500);
    await h.shot('shots/close' + pi + '.png');
    h.log('shot plan ' + pi);
  }
};
