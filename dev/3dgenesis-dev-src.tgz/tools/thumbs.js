// Thumbnail dump. Opens the builder, waits for the palette to finish rendering
// every plan and part, then writes those images out as PNGs in shots/.
//   node play.js tools/thumbs.js
// Env KEYS=plan38,plan39 limits the dump; default is every plan tile.
const fs = require('fs');
module.exports = async (p, h) => {
  await p.evaluate(() => window.__G3D.openEditor('start'));
  let ready = false;
  for (let k = 0; k < 40; k++) {
    await h.wait(2000);
    ready = await p.evaluate(() => window.__G3D.bones.thumbsReady());
    if (ready) break;
  }
  if (!ready) { h.log('THUMBS NEVER READY'); return; }
  const want = process.env.KEYS ? process.env.KEYS.split(',') : null;
  const keys = await p.evaluate((w) => {
    const all = window.__G3D.bones.thumbKeys();
    return w ? all.filter(k => w.includes(k)) : all.filter(k => /^plan\d+$/.test(k));
  }, want);
  fs.mkdirSync('shots', { recursive: true });
  let n = 0;
  for (const k of keys) {
    const url = await p.evaluate((kk) => window.__G3D.bones.thumb(kk), k);
    if (!url || !url.startsWith('data:image/png;base64,')) { h.log('no data for ' + k); continue; }
    fs.writeFileSync('shots/' + k + '.png', Buffer.from(url.slice(22), 'base64'));
    n++;
  }
  h.log('DUMPED ' + n + ' of ' + keys.length);
};
