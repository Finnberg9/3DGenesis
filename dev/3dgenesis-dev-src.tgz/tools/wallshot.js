// The closing wall from outside it, and then from inside it. The first should
// look like a thunderhead standing on the island; the second like being in one.
module.exports = async (p, h) => {
  await p.evaluate(() => {
    const G = window.__G3D;
    G.gfxSet('low');
    G.becomeArchetype('theropod'); G.beginPlay(); return G.br.enter();
  });
  await p.waitForFunction(() => window.__G3D.br.on, null, { timeout: 200000 });
  await h.wait(3000);
  // run the match forward until the ring has closed enough to have a wall
  // close the ring, but keep the player parked in the middle of it so the
  // match does not end before there is anything to photograph
  await p.evaluate(() => {
    const G = window.__G3D;
    // until the ring is smaller than the island, or there is no wall standing
    // anywhere you can see it from
    let guard = 260;
    while (G.br.zone.r > 5000 && G.br.phase !== 'over' && guard-- > 0) {
      for (let k = 0; k < 10; k++) G.br.tick(1.0);
      const Z = G.br.zone; G.teleport(Z.cx, Z.cz);
    }
  });
  await h.wait(1500);
  const z = await p.evaluate(() => {
    const G = window.__G3D, Z = G.br.zone;
    return { cx: Z.cx, cz: Z.cz, r: Z.r, phase: G.br.phase };
  });
  h.log('zone', JSON.stringify(z));
  // stand well inside, looking out at the wall
  const stand = async (frac, name, pitch) => {
    await p.evaluate(([cx, cz, r, f]) => {
      const G = window.__G3D;
      G.teleport(cx + r * f, cz);
      G.look(0, f > 1 ? 0.05 : 0.38);      // a 1750 unit tower needs the chin up
    }, [z.cx, z.cz, z.r, frac]);
    await h.wait(9000);
    await h.shot('shots/' + name + '.png');
    h.log(name, JSON.stringify(await p.evaluate(() => Object.assign({ cloud: window.__G3D.cloudCount },
      window.__G3D.weather.state))));
  };
  await stand(0.80, 'wall_out');      // inside the ring, wall ahead
  await stand(1.06, 'wall_in');       // in the band
};
