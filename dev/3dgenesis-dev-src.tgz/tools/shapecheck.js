// Fast pre-render check. The contact sheet is the judge, but there is no point
// spending three minutes rendering a plan whose head is buried inside its own
// chest or whose feet are under the floor. Everything here is measured off the
// real skeleton the game builds.
const C = require('../core.js');
const ids = process.argv.slice(2).map(Number);
const hdr = ['plan', 'headClr', 'headY', 'W', 'H', 'D', 'aspect', 'legs', 'legMin', 'legMax', 'asym'];
console.log(hdr.map(h => h.padStart(9)).join(''));
for (const pi of ids) {
  const d = C.defaultDesign(pi);
  const sk = C.buildDesignSkeleton(d);
  const B = sk.balls, H = B[sk.headIdx];
  // clearance: head surface to the nearest BODY ball surface, in head radii.
  // Negative means the head is inside the torso and will render as a bulge.
  let clr = 1e9;
  for (const q of B) {
    if (q.g !== 'body' || q.hide || q.r < 0.01) continue;
    const dist = Math.hypot(H.x - q.x, H.y - q.y, H.z - q.z);
    clr = Math.min(clr, (dist - q.r - H.r) / H.r);
  }
  let lo = [1e9, 1e9, 1e9], hi = [-1e9, -1e9, -1e9];
  for (const q of B) { if (q.hide || q.r < 0.01) continue;
    lo = [Math.min(lo[0], q.x - q.r), Math.min(lo[1], q.y - q.r), Math.min(lo[2], q.z - q.r)];
    hi = [Math.max(hi[0], q.x + q.r), Math.max(hi[1], q.y + q.r), Math.max(hi[2], q.z + q.r)]; }
  const W = hi[0] - lo[0], Ht = hi[1] - lo[1], D = hi[2] - lo[2];
  const st = sk.plan.stand;
  const lens = (d.limbs || []).map(l => Math.hypot(l.f[0], l.f[1], l.f[2]));
  // asymmetry that a viewer can actually see: horizontal reach and thickness.
  // Foot height is identical by design, so it is left out of the measure.
  const key = (d.limbs || []).map(l => Math.hypot(l.f[0], l.f[2]) * l.th);
  const mean = key.reduce((x, y) => x + y, 0) / (key.length || 1);
  const spread = key.length ? (Math.max(...key) - Math.min(...key)) / (mean || 1) : 0;
  const row = [pi, clr.toFixed(2), (H.y + st).toFixed(2),
               W.toFixed(2), Ht.toFixed(2), D.toFixed(2), (W / Math.max(Ht, 0.01)).toFixed(2),
               lens.length, (lens.length ? Math.min(...lens) : 0).toFixed(2),
               (lens.length ? Math.max(...lens) : 0).toFixed(2), spread.toFixed(2)];
  console.log(row.map((v) => String(v).padStart(9)).join(''));
}
