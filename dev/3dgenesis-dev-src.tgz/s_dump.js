module.exports = async (p, T) => {
  const r = await p.evaluate(() => {
    const G = window.__G3D, C = G.core, M = G.meshDbg, out = [];
    for (let pl = 0; pl < C.PLANS.length; pl++) { const d = C.defaultDesign(pl); out.push(M.creaturePrims(d, M.designGeo(d))); }
    return JSON.stringify(out);
  });
  require('fs').writeFileSync('prims.json', r);
};
