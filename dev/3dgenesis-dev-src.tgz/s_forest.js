module.exports = async (p, T) => {
  const info = await p.evaluate(() => { const G = window.__G3D, F = G.meshDbg.FOL; document.getElementById('start').style.display = 'none';
    return { buildMs: F.buildMs | 0, lod0: F.lod0Tris, trees: G.world.forest.trees.length }; });
  T.log(JSON.stringify(info));
  // find a forest spot
  const spot = await p.evaluate(() => { const G = window.__G3D, w = G.world; const t = w.forest.trees.filter(t => t.kind === 0 || t.kind === 1); const a = t[(t.length * 0.37) | 0]; return [a.x, a.y]; });
  const views = JSON.parse(process.env.VIEWS || '[[60,0.25,0.05,200],[40,1.3,0.1,90],[0,2.0,0.35,700]]');
  for (let k = 0; k < views.length; k++) {
    const [off, yaw, pitch, dist] = views[k];
    await p.evaluate(([x, y, off, yaw, pitch, dist]) => { const G = window.__G3D; G.teleport(x + off, y + off); G.look(yaw, pitch); G.setDist(dist); }, [spot[0], spot[1], off, yaw, pitch, dist]);
    await T.wait(3000);
    await T.shot('fo' + k + '.png');
  }
  T.log(await p.evaluate(() => { const F = window.__G3D.meshDbg.FOL; let tris = 0; for (const b of F.batches) tris += b.mesh.tris * b.count; return 'inst ' + F.count + ' batches ' + F.batches.length + ' tris ' + tris; }));
};
