module.exports = async (p, T) => {
  await p.click('[data-act="create"]');
  await T.wait(5000);
  await p.click('[data-tab="eyes"]'); await T.wait(300);
  const r = await p.evaluate(() => {
    const E = window.__G3D.ED, C = window.__G3D.core;
    const sk = C.buildDesignSkeleton(E.des), h = sk.balls[sk.headIdx];
    const st = C.classifyLimbs(E.des, sk).stand + 0.34;
    const s = window.__G3D.edProject([h.x + 0.1 * h.r, h.y + st + 1.0 * h.r, h.z + 0.35 * h.r]);
    const hit = window.__G3D.edBodyHit(s[0], s[1]);
    const el = document.elementFromPoint(s[0], s[1]);
    return { s, hit: hit && hit.p, el: el && (el.id || el.tagName) };
  });
  T.log(JSON.stringify(r));
  const bb = await p.locator('[data-item="e_round"]').boundingBox();
  await p.mouse.move(bb.x + 40, bb.y + 40); await p.mouse.down();
  await p.mouse.move(r.s[0], r.s[1], { steps: 10 }); await T.wait(500);
  T.log('ghost', await p.evaluate(() => JSON.stringify(window.__G3D.ED.ghost && window.__G3D.ED.ghost.kind)), await p.evaluate(() => JSON.stringify(window.__G3D.ED.drag)));
  await T.shot('dbg.png');
  await p.mouse.up(); await T.wait(300);
  T.log('parts', await p.evaluate(() => window.__G3D.ED.des.parts.length));
};
