const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ ...(process.env.PW_EXEC ? { executablePath: process.env.PW_EXEC } : {}), args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-webgpu','--use-webgpu-adapter=swiftshader','--enable-features=Vulkan','--use-vulkan=swiftshader'], headless: true });
  const ctx = await b.newContext({ viewport: { width: +(process.env.VW||1600), height: +(process.env.VH||900) } });
  await ctx.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
  const p = await ctx.newPage();
  const logs = []; p.on('console', m => { if (m.type() === 'error' || m.type() === 'warning') logs.push(m.type() + ': ' + m.text()); }); p.on('pageerror', e => logs.push('PAGEERR ' + e.message));
  await p.goto('http://localhost:8765/g3.html' + (process.argv[3] || '?seed=5'));
  await p.waitForFunction(() => window.__G3D && window.__G3D.ready, null, { timeout: +(process.env.TMO || 120000) });
  const steps = require(require('path').resolve(process.argv[2]));
  try { await steps(p, { shot: async (n) => p.screenshot({ path: n, timeout: 180000 }), wait: (ms) => p.waitForTimeout(ms), log: (...a) => console.log(...a) }); }
  catch (e) { console.log('STEP ERROR', e.message); await p.screenshot({ path: 'fail.png' }); }
  console.log(logs.filter(l => !/ERR_TUNNEL|fonts/.test(l)).slice(0, 30).join('\n'));
  await b.close();
})();
