// The three things Finn asked for on 2026-09-25, checked as BEHAVIOUR rather
// than as code that exists: nothing can see a veiled player, noise gives it
// away, and rage spends no stamina.
module.exports = async (p, h) => {
  const fail = [];
  const t = (n, c, x) => { h.log((c ? 'ok  ' : 'FAIL') + '  ' + n + (x != null ? '  ' + x : '')); if (!c) fail.push(n); };
  const errs = []; p.on('pageerror', (e) => errs.push(e.message));

  await p.evaluate(() => {
    const G = window.__G3D, C2 = window.GenesisCore;
    G.gfxSet('low');
    G.becomeDesigned ? G.becomeDesigned(C2.defaultDesign(10)) : G.becomeArchetype('theropod');
    G.beginPlay();
  });
  await h.wait(2500);

  // ---------------------------------------------------------------- VEIL
  const seenPlain = await p.evaluate(() => window.__G3D.spell.muls().seen);
  t('unveiled, the island sees you exactly as it always did', seenPlain === 1, 'seen=' + seenPlain);

  const v = await p.evaluate(() => {
    const G = window.__G3D;
    G.spell.give('veil', 1); G.spell.use('veil');
    return { on: G.spell.on(), seen: G.spell.muls().seen };
  });
  t('VEIL makes you completely invisible, not merely harder to see', v.seen === 0, JSON.stringify(v));

  // the core must actually consult it: a hidden animal is never picked up by
  // another animal's perception, whatever its sight range
  const core = await p.evaluate(() => {
    const W = window.__G3D.world;
    const c = window.__G3D.player.c;
    const before = W.seenMul ? W.seenMul(c) : -1;
    const other = W.creatures.find(o => o !== c && o.alive);
    const otherSeen = other && W.seenMul ? W.seenMul(other) : -1;
    return { hook: typeof W.seenMul === 'function', me: before, other: otherSeen };
  });
  t('the core has a visibility hook and it is wired to the sim', core.hook);
  t('it hides the player and nothing else', core.me === 0 && core.other === 1, JSON.stringify(core));

  // noise: a swing is loud, and loud is how you are found
  const noisy = await p.evaluate(() => {
    const G = window.__G3D;
    const threw = G.br.swing();
    return { threw, seen: G.spell.muls().seen };
  });
  t('swinging gives you away while the sound is still in the air', noisy.seen > 0 && noisy.seen < 1, JSON.stringify(noisy));
  // stepped rather than waited: dt is clamped per tick, so wall-clock time on
  // a software renderer is not simulated time
  const quiet = await p.evaluate(() => {
    const G = window.__G3D;
    for (let i = 0; i < 60; i++) G.step(0.05);
    return G.spell.muls().seen;
  });
  t('and you are gone again once you are quiet', quiet === 0, 'seen=' + quiet);

  // you can still see yourself, faintly, and you are still drawn
  const drawn = await p.evaluate(() => ({ inst: window.__G3D.instCount }));
  t('a veiled body is still drawn (you can see yourself)', drawn.inst > 0, JSON.stringify(drawn));

  // ---------------------------------------------------------------- RAGE
  await p.evaluate(() => { window.__G3D.spell.reset(); });
  // driven through the harness's own step, so the sprint is the real sprint
  const drain = await p.evaluate(() => {
    const G = window.__G3D;
    G.br.clearDodge();
    G.br.setKeys({ shift: true, w: true });
    for (let i = 0; i < 50; i++) G.step(0.05);
    const s = G.br.stam();
    G.br.setKeys({});
    return s;
  });
  const raged = await p.evaluate(() => {
    const G = window.__G3D;
    G.br.clearDodge();
    G.spell.give('rage', 1); G.spell.use('rage');
    const s0 = G.br.stam().v;
    G.br.setKeys({ shift: true, w: true });
    for (let i = 0; i < 50; i++) G.step(0.05);
    const s1 = G.br.stam().v;
    G.br.setKeys({});
    return { s0, s1, on: G.spell.on() };
  });
  t('sprinting normally costs stamina', drain.v < 100, JSON.stringify(drain));
  t('sprinting in a RAGE costs none of it', raged.s1 >= raged.s0 - 0.001, JSON.stringify(raged));

  t('no page errors from any of it', errs.length === 0, errs.slice(0, 3).join(' | '));
  h.log(fail.length ? '\nFAILED: ' + fail.join(', ') : '\nALL VEIL/RAGE TESTS PASS');
};
