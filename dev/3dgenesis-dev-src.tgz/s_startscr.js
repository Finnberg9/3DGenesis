module.exports = async (p, T) => { await T.wait(800); await T.shot('start.png'); };
