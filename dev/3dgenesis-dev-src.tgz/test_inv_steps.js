// Parts are counted, not flagged. One spike taken off a corpse is ONE spike:
// you can wear it, you cannot wear four of it. These checks drive the real
// editor's own add path, because the rule only means anything where the part
// actually lands.
module.exports = async (p, h) => {
  const fail = [];
  const t = (n, c, x) => { h.log((c ? 'ok  ' : 'FAIL') + '  ' + n + (x != null ? '  ' + x : '')); if (!c) fail.push(n); };

  await p.evaluate(() => { const G = window.__G3D; G.bones.reset(); G.becomeArchetype('theropod'); G.beginPlay(); });
  await h.wait(500);
  await p.evaluate(() => window.__G3D.openEditor('game'));
  for (let k = 0; k < 16; k++) { await h.wait(2000); if (await p.evaluate(() => !!(window.ED && ED.thumbsReady))) break; }
  await p.evaluate(() => window.__G3D.inv.addSpace(40));   // kills grow the genome budget; this test is about stock, not space
  await p.evaluate(() => window.__G3D.bones.tab('armor'));
  await h.wait(600);

  // A part of the armour tab this body is not wearing and owns none of.
  const ID = await p.evaluate(() => window.__G3D.inv.pickUnowned('armor'));
  t('found an armour part to test with', !!ID, ID);
  if (!ID) { h.log('\nFAILED: no test part'); return; }

  // ---- a part you own none of is locked -----------------------------------
  const a = await p.evaluate((id) => {
    const B = window.__G3D.bones;
    return { n: B.count(id), stock: B.stock(id), spare: B.spare(id),
             card: (document.querySelector('#edGrid .edcard[data-item="' + id + '"] .edstock') || {}).textContent };
  }, ID);
  t('a part you hold none of has no stock', a.n === 0 && a.stock === 0 && a.spare === 0, JSON.stringify(a));
  t('and its card says you own none', /own none/.test(a.card || ''), a.card);

  // ---- one kill is one copy ----------------------------------------------
  const b = await p.evaluate((id) => {
    const B = window.__G3D.bones;
    B.take(id);                                       // exactly what one kill grants
    B.refresh();
    return { n: B.count(id), spare: B.spare(id),
             one: B.canUse(id, 1), two: B.canUse(id, 2),
             card: (document.querySelector('#edGrid .edcard[data-item="' + id + '"] .edstock') || {}).textContent,
             badge: (document.querySelector('#edGrid .edcard[data-item="' + id + '"] .edhave') || {}).textContent };
  }, ID);
  t('taking one part gives exactly one copy', b.n === 1 && b.spare === 1, JSON.stringify(b));
  t('one copy places once', b.one === true);
  t('one copy does NOT place twice (mirror)', b.two === false);
  t('the tile carries a count badge', /1/.test(b.badge || ''), b.badge);
  t('the card reads the stock', /own 1/.test(b.card || ''), b.card);

  // ---- placing it uses it up ---------------------------------------------
  const c = await p.evaluate((id) => {
    const G = window.__G3D, B = G.bones;
    const placed = G.inv.place(id, 1);
    return { placed, worn: B.wornCount(id), spare: B.spare(id), n: B.count(id), again: B.canUse(id, 1) };
  }, ID);
  t('it drops onto the body', c.placed === true && c.worn === 1, JSON.stringify(c));
  t('that was your only one: no spare left', c.spare === 0 && c.again === false, JSON.stringify(c));
  t('owning one is not owning as many as you like', c.n === 1 && c.spare === 0);

  // ---- the editor actually refuses the second one -------------------------
  const d = await p.evaluate((id) => {
    const G = window.__G3D, B = G.bones;
    const placed = G.inv.place(id, 2);
    return { placed, worn: B.wornCount(id), flash: (document.getElementById('edFlash') || {}).textContent };
  }, ID);
  t('the second one is refused', d.placed === false && d.worn === 1, JSON.stringify(d));
  t('and it says why', /already on the body|Locked/.test(d.flash || ''), d.flash);
  t('the refusal was the stock, not the genome budget', await p.evaluate(() => window.__G3D.inv.space() > 12));

  // ---- a second copy lets a second one on ---------------------------------
  const e = await p.evaluate((id) => {
    const G = window.__G3D, B = G.bones;
    B.take(id);
    const placed = G.inv.place(id, 2);
    return { n: B.count(id), placed, worn: B.wornCount(id), spare: B.spare(id) };
  }, ID);
  t('a second copy lets a second one on', e.n === 2 && e.placed === true && e.worn === 2, JSON.stringify(e));
  t('and the spare is back to zero', e.spare === 0, JSON.stringify(e));

  // ---- removing one puts the copy back on the shelf -----------------------
  const f = await p.evaluate((id) => {
    const G = window.__G3D, B = G.bones;
    const removed = G.inv.remove(id);
    return { removed, worn: B.wornCount(id), spare: B.spare(id), n: B.count(id) };
  }, ID);
  t('taking it off returns the copy to stock', f.removed === true && f.worn === 1 && f.spare === 1 && f.n === 2, JSON.stringify(f));
  await p.evaluate((id) => window.__G3D.inv.place(id, 2), ID);   // put it back on for the sell checks

  // ---- buying adds copies, and keeps adding -------------------------------
  // Bought against a limb this body is NOT wearing. The four legs it stands on
  // are all spoken for, so every copy of THOSE is worn and none can be sold --
  // which is the rule working, not a sale failing. The sell checks below are
  // about selling, so they need a part with a genuine spare.
  const SELLID = await p.evaluate(() => window.__G3D.inv.pickUnowned('limbs')) || 'l_thin';
  const g = await p.evaluate((id) => {
    const B = window.__G3D.bones;
    B.earn(10000); B.tab('limbs'); B.refresh();
    const r = [B.buy(id), B.buy(id), B.buy(id), B.buy(id)];
    B.refresh();
    return { id, n: B.count(id), worn: B.wornCount(id), oks: r.map(q => q.ok), stillBuyable: B.buyButtons().includes(id) };
  }, SELLID);
  t('buying the same part four times gives four copies', g.n === 4 && g.oks.every(Boolean), JSON.stringify(g));
  t('and none of them is on the body, so all four are spare', g.worn === 0, JSON.stringify({ worn: g.worn }));
  t('the card never stops selling you another', g.stillBuyable === true);

  // ---- selling takes one copy, never a worn one ---------------------------
  const i = await p.evaluate((id) => {
    const B = window.__G3D.bones;
    const sold = B.sell(id);
    return { sold: sold.ok, why: sold.msg, left: B.count(id) };
  }, SELLID);
  t('selling removes one copy, not the lot', i.sold === true && i.left === 3, JSON.stringify(i));
  const j = await p.evaluate((id) => {
    const B = window.__G3D.bones;
    let guard = 0;
    while (B.count(id) > B.wornCount(id) && guard++ < 20) B.sell(id);
    const worn = B.wornCount(id), n = B.count(id);
    const r = B.sell(id);
    return { worn, n, ok: r.ok, msg: r.msg };
  }, ID);
  t('you cannot sell a copy the creature is wearing', j.ok === false && j.n === j.worn && j.n > 0, j.msg + ' ' + JSON.stringify(j));

  // ---- persistence: the counts survive a reload ---------------------------
  const before = await p.evaluate((id) => {
    const B = window.__G3D.bones;
    window.__G3D.closeEditor(true);
    return { leg: B.count('l_leg'), test: B.count(id) };
  }, ID);
  await p.reload({ timeout: 180000, waitUntil: 'domcontentloaded' });
  await p.waitForFunction(() => window.__G3D && window.__G3D.ready, null, { timeout: 180000 });
  const after = await p.evaluate((id) => {
    const B = window.__G3D.bones;
    return { leg: B.count('l_leg'), test: B.count(id) };
  }, ID);
  t('counts are remembered across a reload', after.leg === before.leg && after.test === before.test,
    JSON.stringify(before) + ' -> ' + JSON.stringify(after));

  // ---- an old save migrates to counts, not to one of everything -----------
  await p.evaluate(() => {
    localStorage.removeItem('genesis3d.progress.v2');
    localStorage.setItem('genesis3d.progress.v1', JSON.stringify({
      // not the pre-v2 free starters, which a v1 migration deliberately drops
      kills: 9, unlocked: ['l_thick', 's_plate', 'e_big'],
      saved: [{ design: { parts: [{ id: 's_plate' }, { id: 's_plate' }, { id: 's_plate' }, { id: 'e_big' }],
                          limbs: [{ id: 'l_thick' }, { id: 'l_thick' }, { id: 'l_thick' }, { id: 'l_thick' }] } }],
      last: null,
    }));
  });
  await p.reload({ timeout: 180000, waitUntil: 'domcontentloaded' });
  await p.waitForFunction(() => window.__G3D && window.__G3D.ready, null, { timeout: 180000 });
  const n = await p.evaluate(() => {
    const B = window.__G3D.bones;
    return { spike: B.count('s_plate'), leg: B.count('l_thick'), eye: B.count('e_big'), kinds: B.kinds() };
  });
  t('an old save keeps enough copies for the body it built', n.spike === 3 && n.leg === 4 && n.eye === 1, JSON.stringify(n));
  t('and grants nothing it never had', n.kinds === 3, n.kinds);

  h.log(fail.length ? '\nFAILED: ' + fail.join(', ') : '\nALL INVENTORY CHECKS PASS');
  
};
