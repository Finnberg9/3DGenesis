module.exports = async (p, T) => {
  await p.evaluate(() => { window.__G3D.begin(); });
  await p.evaluate(() => {
    const G = window.__G3D, F = G.FIGHT, me = G.player.c;
    let carn = null;
    for (const c of G.world.creatures) if (c.alive && c !== me && c.ph.carnivory > 0.5) { carn = c; break; }
    window.__fl = { seen: 0, hits: 0, carn: !!carn };
    if (!carn) { let bd = 1e9; for (const c of G.world.creatures) if (c.alive && c !== me && c.ph.mass > 0.5) { const d = Math.hypot(c.x - me.x, c.y - me.y); if (d < bd) { bd = d; carn = c; } } }
    G.teleport(carn.x + 30, carn.y);
    window.__prov = setInterval(() => { if (carn.alive && me.alive) { carn.react = 'fight'; carn.foe = me; carn.foeT = 5; } }, 100);
    const orig = G.world.hitFilter;
    window.__fl.trace = []; setInterval(() => { if (F.pending.length && window.__fl.trace.length < 30) window.__fl.trace.push(F.pending.map(q => q.t.toFixed(2) + '/' + q.att.alive + '/' + Math.hypot(q.att.x - me.x, q.att.y - me.y).toFixed(0)).join(',') + ' me=' + (G.player.c === me)); window.__fl.seen = Math.max(window.__fl.seen, F.pending.length); window.__fl.hits = me._hitSeq || 0; }, 50);
    G.player.dist = 140;
  });
  await T.wait(4000);
  await p.keyboard.press('t'); await T.wait(300);
  await p.keyboard.press('f'); await T.wait(800);
  await p.keyboard.down('q'); await T.wait(1500); await p.keyboard.up('q');
  await p.keyboard.press('z'); await T.wait(600);
  await p.keyboard.down('Shift'); await p.keyboard.down('w'); await T.wait(1500); await p.keyboard.up('w'); await p.keyboard.up('Shift');
  await p.keyboard.press('Shift'); await T.wait(4000);
  await T.wait(15000); await T.shot('live.png');
  T.log(JSON.stringify(await p.evaluate(() => { const G = window.__G3D, F = G.FIGHT; window.__fl.trace = window.__fl.trace.slice(-4); return Object.assign({ simT: G.simT.toFixed(1) }, window.__fl, { stam: F.stam.toFixed(0), lock: !!F.lock, splats: F.splatN, log: F.log, e: G.player.c.energy.toFixed(1), alive: G.player.c && G.player.c.alive, deaths: G.player.deaths }); })));
};
