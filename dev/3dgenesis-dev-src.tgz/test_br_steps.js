// A whole battle royale played through the simulation clock, plus the checks
// that a match cannot be tampered with. Run with:
//   python3 -m http.server 8765 &   node play.js test_br_steps.js
module.exports = async (p, h) => {
  const fail = [];
  const t = (name, cond, extra) => { h.log((cond ? 'ok  ' : 'FAIL') + '  ' + name + (extra != null ? '  ' + extra : '')); if (!cond) fail.push(name); };

  // ---- free roam: the panel is the source of truth
  const free = await p.evaluate(() => {
    const G = window.__G3D;
    document.getElementById('mut').value = '0.31';
    return { locked: G.br.locked, mut: G.br.panelOpts().mutationRate };
  });
  t('free roam reads the panel', free.locked === false && free.mut === 0.31);

  // ---- enter a match: the island is built from the match seed
  await p.evaluate(() => { const G = window.__G3D; G.becomeArchetype('theropod'); G.beginPlay(); return G.br.enter(); });
  await p.waitForFunction(() => window.__G3D.br.on, null, { timeout: 200000 });
  const start = await p.evaluate(() => {
    const G = window.__G3D;
    return { locked: G.br.locked, phase: G.br.phase, bays: G.br.bays.length, players: G.br.players.length,
             seed: G.br.seed, worldSeed: G.world.seed, net: G.br.netKind(), alive: G.br.alive.n };
  });
  t('the match builds its own island', start.worldSeed === start.seed, 'seed ' + start.seed);
  t('twenty-four bays, twenty-four players', start.bays === 24 && start.players === 24 && start.alive === 24);
  t('everyone starts caged', start.phase === 'cage');
  t('settings lock on entry', start.locked === true);

  // ---- the lock holds against every control
  const cheat = await p.evaluate(() => {
    const G = window.__G3D;
    const before = JSON.stringify({ p: G.world.params, f: G.world.flags });
    for (const id of ['mut', 'tscale', 'plant', 'pe', 'dayl', 'yearl', 'clife', 'cy', 'ttree', 'startPop', 'trelief', 'twater', 'tregion', 'fd', 'fp', 'prerun']) {
      const el = document.getElementById(id);
      if (el) { el.value = el.max || '999'; el.dispatchEvent(new Event('input', { bubbles: true })); }
    }
    for (const id of ['f_climate', 'f_day', 'f_season', 'f_tox', 'f_brains', 'f_sex']) {
      const el = document.getElementById(id);
      if (el) { el.checked = !el.checked; el.dispatchEvent(new Event('change', { bubbles: true })); }
    }
    const s0 = G.world.seed;
    G.br.resetClick(); G.br.resetClick();
    return { unchanged: JSON.stringify({ p: G.world.params, f: G.world.flags }) === before,
             seedHeld: G.world.seed === s0, matchAlive: G.br.on,
             optsPinned: G.br.panelOpts().mutationRate === G.br.rules().mutationRate &&
                         G.br.panelOpts().timeScale === G.br.rules().timeScale,
             climateOff: G.br.panelFlags().climate === false,
             warmupPinned: G.br.panelWarmup() === G.br.rules().prerun,
             disabled: ['mut', 'tscale', 'seed', 'f_climate', 'startPop'].every(i => document.getElementById(i).disabled) };
  });
  t('no slider or flag reaches the running world', cheat.unchanged);
  t('panelOpts answers with the match ruleset', cheat.optsPinned);
  t('climate drift stays off', cheat.climateOff);
  t('the pre-run is pinned', cheat.warmupPinned);
  t('the controls are visibly disabled', cheat.disabled);
  t('reset will not fire mid-match', cheat.seedHeld && cheat.matchAlive);

  // ---- who may hit whom
  const caged = await p.evaluate(() => {
    const G = window.__G3D, B = G.br, me = G.player.c;
    const wild = G.world.creatures.find(c => c._br == null && c !== me);
    return { botVbot: B.hitAllowed(B.players[1].c, B.players[2].c), wildVme: B.hitAllowed(me, wild), self: B.hitAllowed(B.players[1].c, B.players[1].c) };
  });
  t('nothing can reach you in the cage', caged.botVbot === false && caged.wildVme === false);
  // ---- nameplates. Checked here, in the cage, because it is the one moment
  // the player is reliably alive in a headless run. The bays ring a
  // 51200 x 32000 island, so every rival starts far beyond plate range: that
  // is the range rule doing its job, not a missing feature.
  const far = await p.evaluate(() => { const B = window.__G3D.br; B.drawNames(); return B.names().length; });
  t('a rival across the island carries no plate', far === 0, far);
  // The camera sits behind and above the animal, so a rival dropped a few
  // paces in front of it is under the lens, not in it. Walk it out until it
  // is in shot, which is what a rival at a fighting distance looks like.
  const near = await p.evaluate(() => {
    const G = window.__G3D, B = G.br;
    const rival = B.players.find(q => q.slot !== 0 && q.alive && q.c && q.c.alive);
    rival.c.hp = G.br.hpMaxOf(rival.c) * 0.5;   // health is its own pool now, not the food tank
    const cy = Math.cos(G.player.yaw), sy = Math.sin(G.player.yaw);
    // The camera sits behind and above the animal, and the ground in front of
    // a bay on the ring is not flat, so sweep both distance and bearing: a
    // rival at SOME fighting distance in view must carry a plate.
    const tried = [];
    for (const off of [0, 0.25, -0.25, 0.5, -0.5]) {
      const cx = Math.cos(G.player.yaw + off), cz = Math.sin(G.player.yaw + off);
      for (const R of [150, 250, 400, 600, 900]) {
        rival.c.x = G.player.camX + cx * R;
        rival.c.y = G.player.camZ + cz * R;
        B.drawNames();
        const why = B.nameWhy(rival.slot);
        tried.push(off.toFixed(2) + '/' + R + ':' + why);
        if (why === 'shown') return { want: rival.name, at: R, why, plates: B.names(), tried };
      }
    }
    return { want: rival.name, at: null, why: 'none', plates: B.names(), tried };
  });
  const plate = near.plates.find(q => q.name === near.want);
  t('a rival in view carries a nameplate', !!plate, near.tried.join(' | ') + ' -> ' + JSON.stringify(near.plates));
  t('the plate names them', !!plate && plate.name === near.want, near.want + ' at ' + near.at);
  t('and shows the health they have left', !!plate && /^(4\d|5\d)%$/.test(plate.hp), plate && plate.hp);
  const hidden = await p.evaluate(() => {
    const G = window.__G3D, B = G.br;
    const rival = B.players.find(q => q.slot !== 0 && q.alive && q.c && q.c.alive);
    rival.c.x = G.player.camX - Math.cos(G.player.yaw) * 90;   // directly behind the camera
    rival.c.y = G.player.camZ - Math.sin(G.player.yaw) * 90;
    B.drawNames();
    return { n: B.names().length, why: B.nameWhy(rival.slot) };
  });
  t('a rival behind you carries none', hidden.n === 0 && /behind|offscreen/.test(hidden.why), JSON.stringify(hidden));
  t('nothing hits itself', caged.self === false);

  // ---- play the match out
  const snaps = [];
  for (let k = 0; k < 40; k++) {
    await p.evaluate(() => { const G = window.__G3D; for (let i = 0; i < 500; i++) G.step(0.05); });
    const s = await p.evaluate(() => {
      const B = window.__G3D.br;
      return { t: Math.round(B.t), r: Math.round(B.zone.r), alive: B.alive.n, sides: B.alive.sides, phase: B.phase };
    });
    snaps.push(s);
    // gate at 30 s, first sample is t=25. There is no grace period: the
    // gates open straight into open combat.
    if (k === 1) t('the gates open straight into open combat', s.phase === 'open', s.phase);
    if (k === 1) {
      const live = await p.evaluate(() => {
        const B = window.__G3D.br;
        return { botVbot: B.hitAllowed(B.players[1].c, B.players[2].c),
                 wild: B.hitAllowed(window.__G3D.world.creatures.find(c => c._br == null), B.players[1].c) };
      });
      t('players can hit each other the moment the gates open', live.botVbot === true, JSON.stringify(live));
      t('and the wildlife is still there to hunt', live.wild === true);
      const wild = await p.evaluate(() => Math.round(window.__G3D.br.wildSecs));
      t('the island empties on its own clock', wild === 300, wild);
    }
    if (s.phase === 'over') break;
  }
  for (const s of snaps) h.log('   t=' + s.t + ' zone=' + s.r + ' alive=' + s.alive + ' sides=' + s.sides + ' ' + s.phase);
  const last = snaps[snaps.length - 1];
  t('the match ends', last.phase === 'over');
  t('the zone closed', last.r < snaps[0].r / 2, snaps[0].r + ' -> ' + last.r);
  const res = await p.evaluate(() => window.__G3D.br.result);
  t('a result is recorded', !!res && typeof res.won === 'boolean', JSON.stringify(res));
  const after = await p.evaluate(() => ({ locked: window.__G3D.br.locked, mutOff: document.getElementById('mut').disabled }));
  t('the panel comes back when the match is over', after.locked === false && after.mutOff === false);

  h.log(fail.length ? '\nFAILED: ' + fail.join(', ') : '\nALL BATTLE ROYALE CHECKS PASS');
};
