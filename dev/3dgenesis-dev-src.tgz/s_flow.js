module.exports = async (p, T) => {
  await p.click('[data-arch="random"]');
  await T.wait(1500);
  T.log('designed before?', await p.evaluate(() => !!window.__G3D.player.c.genome.design));
  await p.keyboard.press('b'); await T.wait(5000);
  T.log('editor', await p.evaluate(() => { const E = window.__G3D.ED; return JSON.stringify({ open: E.open, mode: E.mode, plan: E.des.plan, parts: E.des.parts.map(q => q.id), limbs: E.des.limbs.length }); }));
  await T.shot('f1.png');
  await p.click('#edDone'); await T.wait(1500);
  T.log('after done', await p.evaluate(() => { const c = window.__G3D.player.c; return JSON.stringify({ designed: !!c.genome.design, mass: c.ph.mass.toFixed(2), alive: c.alive }); }));
  // a kill: offer parts from a random prey
  const opts = await p.evaluate(() => { const G = window.__G3D; const prey = G.world.creatures.find(c => c.alive && c !== G.player.c && !c.genome.design); G.onKill(prey); return G.picker && G.picker.opts; });
  T.log('picker', JSON.stringify(opts));
  await T.wait(2500);
  await T.shot('f2.png');
  await p.keyboard.press('1'); await T.wait(500);
  T.log('unlocked', await p.evaluate(() => JSON.stringify({ kills: window.__G3D.PROG.kills, n: window.__G3D.PROG.unlocked.size })));
  // designed prey offers its own parts
  const opts2 = await p.evaluate(() => { const G = window.__G3D; const C = G.core; const g = C.seedHerbivore(G.world, G.world.rng); g.design = C.defaultDesign(8); C.compileDesign(g); const c = C.makeCreature(g, 100, 100, 100); G.onKill(c); return G.picker && G.picker.opts; });
  T.log('picker2', JSON.stringify(opts2));
  await p.click('#picker [data-pick="1"]'); await T.wait(300);
  await p.keyboard.press('b'); await T.wait(1500);
  const first = opts2[0];
  const cat = await p.evaluate((id) => { const v = { m: 'mouth', e: 'eyes', h: 'horns', s: 'armor', l: 'limbs', t: 'limbs', f: 'fins', w: 'wings', d: 'details' }; return v[id[0]]; }, first);
  await p.click(`[data-tab="${cat}"]`); await T.wait(500);
  T.log('tile locked?', await p.evaluate((id) => document.querySelector(`[data-item="${id}"]`).classList.contains('locked'), first));
  await T.shot('f3.png');
  // serpent with plates and bat wings, limb selected to show handles
  await p.evaluate(() => {
    const G = window.__G3D, C = G.core, E = G.ED;
    E.des = C.defaultDesign(3); E.des._rev = 77; E.mirror = true;
    const sk = C.buildDesignSkeleton(E.des);
    for (const x of [-0.6, -0.2, 0.2, 0.6]) { const h = C.surfaceAt(sk, x * sk.a, sk.b, 0, 0, 1, 0); if (h) { E.des.parts.push({ id: 's_plate', b: 0, o: [0,0,0], n: [0,1,0], spin: 0, s: 1, c: null, m: 0 }); C.setAnchor(sk, E.des.parts[E.des.parts.length - 1], h.p, h.n, h.b); } }
    const h = C.surfaceAt(sk, 0.5 * sk.a, 0.5 * sk.b, 0.8 * sk.b, 0, 0.6, 0.8); G.edAddPart('w_bat', h);
    const h2 = C.surfaceAt(sk, 0.75 * sk.a, -0.2 * sk.b, 0.8 * sk.b, 0, -0.4, 0.9); G.edAddLimb('l_leg', h2);
    E.cam.yaw = 0.7; E.cam.pitch = 0.45; E.cam.zoom = 0.75;
  });
  await T.wait(2000);
  await T.shot('f4.png');
};
