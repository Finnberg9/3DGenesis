// Core-side checks for combat v2: bleeding wounds and the hit filter.
const C = require('./core.js');
const assert = (c, m) => { if (!c) { console.log('FAIL', m); process.exitCode = 1; } else console.log('ok  ', m); };
const w = C.makeWorld({ w: 12800, h: 8000, tileSize: 48, seed: 11, startPop: 0, startPlants: 50 });
const mk = (plan, x, y) => { const g = C.seedHerbivore(w, w.rng); g.design = C.defaultDesign(plan); C.compileDesign(g); const c = C.makeCreature(g, x, y, 400); for (const q of c.cellState) q.grow = 1; c.ph = C.develop(g, c.cellState); c.energy = c.ph.storage * 0.8; return c; };
const X = w.terrain.island.cx, Y = w.terrain.island.cy;
const a = mk(2, X, Y), b = mk(0, X + 20, Y);
w.creatures.push(a, b);
// small hit: no wound
C.onHit(b, a, b.ph.storage * 0.05);
assert(!(b.bleedT > 0), 'hit under 10% of storage does not bleed');
// big hit: wound, drains roughly 35% of the hit over its duration
const big = b.ph.storage * 0.2;
C.onHit(b, a, big);
assert(b.bleedT > 5 && b.bleedR > 0, 'hit over 10% opens a wound (t=' + b.bleedT.toFixed(1) + ' r=' + b.bleedR.toFixed(2) + ')');
const total = b.bleedT * b.bleedR;
assert(total > big * 0.2 && total < big * 0.5, 'wound drain ~35% of hit (' + (total / big).toFixed(2) + ')');
// stacking is capped
for (let i = 0; i < 20; i++) C.onHit(b, a, big);
assert(b.bleedT <= 14 + 1e-9 && b.bleedR <= b.ph.storage * 0.02 + 1e-9, 'wound stacking capped');
// zero-damage hit does not block eating
const c2 = mk(0, X + 400, Y); w.creatures.push(c2);
C.onHit(c2, a, 0);
assert(!(c2.hurtT > 0), 'zero damage hit leaves eating allowed');
// bleeding ticks down in world.step and costs energy
const e0 = b.energy; b.bleedT = 2; b.bleedR = 1;
for (let i = 0; i < 30; i++) { b.hurtT = 0; w.step(0.1); }
assert(b.bleedT === 0 && b.bleedR === 0, 'wound closes after its time');
assert(b.energy < e0, 'bleeding cost energy');
// hitFilter: null skips the exchange (no damage, no onHit); a number is applied
const v = mk(0, X + 800, Y), k = mk(2, X + 815, Y); w.creatures.push(v, k);
C.onHit(k, v, 1);                      // provoke k (a fighter) into retaliating on v
assert(k.react === 'fight', 'provoked plan-2 creature fights back');
let calls = 0; w.hitFilter = (vic, at, d) => { calls++; return null; };
const ev = v.energy, seq = v._hitSeq || 0;
for (let i = 0; i < 20 && !calls; i++) { k.x = v.x - 10; k.y = v.y; k.foeT = 5; v.hurtT = 0; w.step(0.05); }
assert(calls > 0, 'core routes the strike through world.hitFilter');
assert((v._hitSeq || 0) === seq, 'deferred strike does not register a hit');
calls = 0; w.hitFilter = (vic, at, d) => { calls++; return 7; };
k.cooldown = 0; const e1 = v.energy;
for (let i = 0; i < 40 && !calls; i++) { k.x = v.x - 10; k.y = v.y; k.foeT = 5; w.step(0.05); }
assert(calls > 0 && (v._hitSeq || 0) > seq && Math.abs(v._lastDmg - 7) < 1e-9, 'filtered damage is what lands');
w.hitFilter = null;
