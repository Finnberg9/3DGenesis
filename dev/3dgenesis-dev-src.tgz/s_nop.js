module.exports = async (p, T) => { T.log(await p.evaluate(() => JSON.stringify({ fol: window.__G3D.meshDbg.FOL.buildMs, tris: window.__G3D.meshDbg.FOL.lod0Tris }))); };
