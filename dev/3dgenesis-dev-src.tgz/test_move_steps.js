// Walking is forward and back. Sideways is a lunge you spend, not a gait you
// hold. These checks drive the real movement function and the real roll.
module.exports = async (p, h) => {
  const fail = [];
  const t = (n, c, x) => { h.log((c ? 'ok  ' : 'FAIL') + '  ' + n + (x != null ? '  ' + x : '')); if (!c) fail.push(n); };

  await p.evaluate(() => { const G = window.__G3D; G.becomeArchetype('theropod'); G.beginPlay(); });
  await h.wait(900);
  // face due east, so forward is +x and the player's left is -z
  await p.evaluate(() => { window.__G3D.player.yaw = 0; });

  const mv = async (o) => p.evaluate((keys) => {
    const G = window.__G3D;
    G.br.clearDodge();
    G.br.setKeys(keys);
    return G.br.moveVec(0.016);
  }, o);

  const fwd = await mv({ w: 1 });
  t('W walks you forward', fwd.vx > 1 && Math.abs(fwd.vy) < 0.01, JSON.stringify(fwd));
  const back = await mv({ s: 1 });
  t('S walks you back', back.vx < -1 && Math.abs(back.vy) < 0.01, JSON.stringify(back));
  const left = await mv({ a: 1 });
  t('holding A does not slide you sideways', Math.abs(left.vx) < 0.01 && Math.abs(left.vy) < 0.01, JSON.stringify(left));
  const right = await mv({ d: 1 });
  t('nor does holding D', Math.abs(right.vx) < 0.01 && Math.abs(right.vy) < 0.01, JSON.stringify(right));
  const diag = await mv({ w: 1, d: 1 });
  t('and W+D is just forward, not a diagonal',
    Math.abs(diag.vx - fwd.vx) < 0.01 && Math.abs(diag.vy) < 0.01, JSON.stringify(diag));
  const up = await mv({ arrowup: 1 });
  t('the d-pad walks you too', up.vx > 1 && Math.abs(up.vy) < 0.01, JSON.stringify(up));

  // ---- the lunge ------------------------------------------------------------
  const L = await p.evaluate(() => { const G = window.__G3D; G.br.clearDodge(); G.player.yaw = 0; const ok = G.br.lunge(-1); return { ok, v: G.br.dodgeVec() }; });
  t('A throws you left', L.ok === true && L.v.z < -0.95 && Math.abs(L.v.x) < 0.05, JSON.stringify(L));
  const R = await p.evaluate(() => { const G = window.__G3D; G.br.clearDodge(); G.player.yaw = 0; const ok = G.br.lunge(1); return { ok, v: G.br.dodgeVec() }; });
  t('D throws you right', R.ok === true && R.v.z > 0.95 && Math.abs(R.v.x) < 0.05, JSON.stringify(R));
  const turned = await p.evaluate(() => { const G = window.__G3D; G.br.clearDodge(); G.player.yaw = Math.PI / 2; G.br.lunge(-1); return G.br.dodgeVec(); });
  t('and the lunge follows where you are looking', turned.x > 0.95 && Math.abs(turned.z) < 0.05, JSON.stringify(turned));

  const spam = await p.evaluate(() => {
    const G = window.__G3D;
    G.br.clearDodge(); G.player.yaw = 0;
    const first = G.br.lunge(1);
    const second = G.br.lunge(-1);          // immediately after: must be refused
    return { first, second };
  });
  t('a lunge cannot be spammed: the cooldown holds', spam.first === true && spam.second === false, JSON.stringify(spam));

  const tired = await p.evaluate(() => {
    const G = window.__G3D;
    G.br.clearDodge(); G.stam ? 0 : 0;
    G.br.drainStam();
    return G.br.lunge(1);
  });
  t('and an exhausted animal cannot lunge at all', tired === false, String(tired));

  h.log(fail.length ? '\nFAILED: ' + fail.join(' | ') : '\nALL MOVEMENT CHECKS PASS');
};
