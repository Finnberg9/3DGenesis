// Fourteen shapes, each one a different animal from the one next to it.
const C = require('./core.js');
const world = C.makeWorld({ w: 12800, h: 8000, tileSize: 48, seed: 3, startPop: 4, startPlants: 20 });
const rng = world.rng;
let fails = 0;
const t = (n, c, x) => { console.log((c ? 'ok  ' : 'FAIL') + '  ' + n + (x != null ? '  ' + x : '')); if (!c) fails++; };

const LAND = [30, 31, 32, 33, 22, 23, 26, 27, 25, 24];
const AIR = [34, 35, 37, 36];
const NAME = { 30: 'lurker', 31: 'maw', 32: 'hollow', 33: 'centipede', 22: 'scorpion', 23: 'stiltwalker',
               26: 'crab', 27: 'brute', 25: 'mantis', 24: 'hydra', 34: 'flit', 35: 'mothwing', 37: 'skimmer', 36: 'drake' };
const info = {};
for (const pi of LAND.concat(AIR)) {
  const d = C.defaultDesign(pi);
  const g = C.seedHerbivore(world, rng); g.design = d; C.compileDesign(g);
  const ph = C.develop(g);
  const sk = C.buildDesignSkeleton(d);
  const cls = C.classifyLimbs(d, sk);
  cls.armN = (d.limbs || []).length - cls.legs;
  const bad = Object.keys(ph).filter(k => typeof ph[k] === 'number' && !isFinite(ph[k]));
  info[pi] = { d, ph, cls, sk, bad, P: C.PLANS[pi] };
  console.log('  ' + String(pi).padStart(2) + ' ' + NAME[pi].padEnd(12) +
    'legs ' + cls.legs + '  arms ' + cls.armN + '  mass ' + ph.mass.toFixed(1).padStart(5) +
    '  hp ' + C.hpMaxOf(ph).toFixed(0).padStart(4) + '  land ' + ph.speedLand.toFixed(0).padStart(3) +
    '  air ' + ph.speedAir.toFixed(0).padStart(3) + '  stand ' + String(C.PLANS[pi].stand).padEnd(5) +
    ' a/b ' + C.PLANS[pi].a.toFixed(2) + '/' + C.PLANS[pi].b.toFixed(2));
}
t('all fourteen plans exist', LAND.concat(AIR).every(pi => C.PLANS[pi]));
t('none of them develops a broken number', Object.values(info).every(v => v.bad.length === 0),
  JSON.stringify(Object.entries(info).filter(([k, v]) => v.bad.length).map(([k]) => NAME[k])));
t('every one of them starts on exactly 100 hp',
  Object.values(info).every(v => Math.abs(C.hpMaxOf(v.ph) - 100) < 1e-9),
  Object.entries(info).filter(([k, v]) => Math.abs(C.hpMaxOf(v.ph) - 100) > 1e-9).map(([k, v]) => NAME[k] + ':' + C.hpMaxOf(v.ph).toFixed(0)).join(' '));
t('every land shape walks', LAND.every(pi => info[pi].cls.legs > 0),
  LAND.map(pi => NAME[pi] + ':' + info[pi].cls.legs).join(' '));
t('the moth has no legs, as intended', info[35].cls.legs === 0, String(info[35].cls.legs));
t('the other three fliers can still stand', [34, 37, 36].every(pi => info[pi].cls.legs > 0));
t('all four fliers actually fly', AIR.every(pi => info[pi].ph.speedAir > 0),
  AIR.map(pi => NAME[pi] + ':' + info[pi].ph.speedAir.toFixed(0)).join(' '));
t('and no land shape does', LAND.every(pi => info[pi].ph.speedAir === 0),
  LAND.filter(pi => info[pi].ph.speedAir > 0).map(pi => NAME[pi]).join(' '));
t('every one of them can see', Object.values(info).every(v => v.d.parts.some(pt => C.ITEM_SIM[pt.id] && C.ITEM_SIM[pt.id].t === 'EYE')));
t('and every one has a mouth', Object.values(info).every(v => v.d.parts.some(pt => C.ITEM_SIM[pt.id] && C.ITEM_SIM[pt.id].t === 'MOUTH')));

// distinctness: no two share a silhouette, measured on the numbers a
// silhouette is actually made of
// Wingspan is in here because it is the single most visible thing about a
// silhouette that has one, and leaving it out let a winged drake and a
// wingless mantis score as near neighbours.
const sig = (pi) => { const v = info[pi], P = v.P;
  return [ (P.a / P.b).toFixed(2), P.stand.toFixed(2), v.cls.legs, (v.sk.neckLen / P.a).toFixed(2),
           (v.sk.tailLen / P.a).toFixed(2), (v.sk.balls[v.sk.headIdx].r / P.b).toFixed(2),
           (v.ph.wingEff / Math.max(0.1, v.ph.mass)).toFixed(2) ].join('/'); };
const sigs = LAND.concat(AIR).map(sig);
t('no two of the fourteen share a silhouette', new Set(sigs).size === sigs.length,
  sigs.filter((x, i) => sigs.indexOf(x) !== i).join(' '));
// and no two are even close: every pair differs on at least two of the six axes
let closest = 99, pair = '';
const all = LAND.concat(AIR);
for (let i = 0; i < all.length; i++) for (let j = i + 1; j < all.length; j++) {
  const A = sig(all[i]).split('/'), B = sig(all[j]).split('/');
  let diff = 0;
  for (let k = 0; k < A.length; k++) if (Math.abs((+A[k]) - (+B[k])) > Math.max(0.12, Math.abs(+A[k]) * 0.18)) diff++;
  if (diff < closest) { closest = diff; pair = NAME[all[i]] + ' vs ' + NAME[all[j]] + ' (' + diff + ' axes)'; }
}
t('and the closest pair still differs on several axes', closest >= 2, pair);

// the headline feature of each is actually extreme
t('the lurker really is one huge body', info[30].P.b > info[30].P.a, info[30].P.a + '/' + info[30].P.b);
// The maw was rebuilt off the white-xeno reference rather than off its own
// name: the silhouette is a back that peaks hard over the shoulders with the
// skull slung down and forward, not a head bigger than the animal.
t('the maw arches hard over its shoulders and slings its head forward',
  info[31].P.hump > 0.9 && info[31].P.ny < -0.5 && info[31].sk.tailLen > info[31].P.a,
  JSON.stringify({ hump: info[31].P.hump, ny: info[31].P.ny, tail: +info[31].sk.tailLen.toFixed(2) }));
// and the whole set now hangs its head low rather than perching it on top
const lowHead = [30, 31, 32, 33, 22, 23, 26, 27, 25, 24].filter(pi => C.PLANS[pi].ny < 0).length;
t('nearly every land shape carries its head below the shoulder line', lowHead >= 9, lowHead + ' of 10');
t('the hollow really is vertical, with arms as well as legs', info[32].P.stand > 2.2 && info[32].cls.armN > 0, info[32].P.stand + ', arms ' + info[32].cls.armN);
t('the centipede really is long and many-legged', info[33].P.a / info[33].P.b > 5 && info[33].cls.legs >= 10,
  (info[33].P.a / info[33].P.b).toFixed(1) + ':1, ' + info[33].cls.legs + ' legs');
t('the mothwing really is mostly wing', info[35].ph.wingEff > info[35].ph.mass * 0.2,
  info[35].ph.wingEff.toFixed(2) + ' wing on mass ' + info[35].ph.mass.toFixed(1));
t('the drake really has the long neck and tail', info[36].sk.neckLen > info[36].P.a && info[36].sk.tailLen > info[36].P.a,
  info[36].sk.neckLen.toFixed(2) + ' / ' + info[36].sk.tailLen.toFixed(2) + ' vs a ' + info[36].P.a);

// and they survive being alive, and being mutated
for (let i = 0; i < 28; i++) {
  const pi = all[i % all.length];
  const g = C.seedHerbivore(world, rng); g.design = C.defaultDesign(pi); C.compileDesign(g);
  const c = C.makeCreature(g, 5800 + i * 40, 4000, 400);
  for (const q of c.cellState) q.grow = 1;
  c.ph = C.develop(g, c.cellState); c.energy = c.ph.storage; c.age = C.maturity(c.ph) + 1;
  world.creatures.push(c);
}
for (let s = 0; s < 900; s++) world.step(0.1);
t('a world full of them runs without falling over',
  world.creatures.filter(c => c.alive).length > 0, world.creatures.filter(c => c.alive).length + ' alive');
let broke = 0;
for (let i = 0; i < 280; i++) {
  const g = C.seedHerbivore(world, rng); g.design = C.defaultDesign(all[i % all.length]); C.compileDesign(g);
  let m = g;
  for (let k = 0; k < 20; k++) m = C.mutate(world, m, rng, 0.8);
  const ph = C.develop(m);
  if (Object.keys(ph).some(k => typeof ph[k] === 'number' && !isFinite(ph[k]))) broke++;
}
t('twenty generations of mutation never breaks one', broke === 0, broke + ' broken');

console.log(fails ? '\n' + fails + ' FAILED' : '\nALL BODY TESTS PASS');
process.exit(fails ? 1 : 0);
