#!/bin/bash
set -e
cd "$(dirname "$0")"
cp g3.v3 g3.html
python3 src/patch_core.py
python3 src/patch_core2.py
python3 src/patch_render1.py
python3 src/patch_tube.py
python3 src/patch_render2.py
python3 src/patch_skin.py
python3 src/patch_editor.py
python3 src/patch_combat.py
python3 src/patch_designall.py
python3 src/patch_world_core.py
python3 src/patch_world_render.py
python3 src/patch_foliage.py
python3 src/patch_moves.py
python3 src/patch_jump.py
python3 src/patch_atmos.py
python3 src/patch_final.py
python3 src/patch_fight.py
python3 src/patch_spatial.py
python3 src/patch_fp.py
python3 src/patch_remains.py
python3 src/patch_heading.py
python3 src/patch_ui.py
python3 src/patch_defaults.py
python3 src/patch_gfx2.py
python3 src/patch_terrain2.py
python3 src/patch_sky.py
python3 src/patch_dino.py
python3 src/patch_flight.py
python3 src/patch_menu.py
python3 src/patch_name.py
python3 src/patch_sea.py
python3 src/patch_water.py
python3 src/patch_bones.py
python3 src/patch_br.py
python3 src/patch_ground.py
python3 src/patch_chunk.py
python3 src/patch_carve.py
python3 src/patch_pause.py
python3 src/patch_cloud.py
python3 src/patch_aim.py
python3 src/patch_rivers.py
python3 src/patch_idle.py
python3 src/patch_inv.py
python3 src/patch_names.py
python3 src/patch_spawn.py
python3 src/patch_pack.py
python3 src/patch_zone.py
python3 src/patch_polish.py
python3 src/patch_carcass.py
python3 src/patch_fly.py
python3 src/extract_core.py g3.html core.js
node -e "require('./core.js')" && echo BUILD_OK
