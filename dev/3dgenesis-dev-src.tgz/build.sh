#!/bin/bash
set -e
cd /home/claude/w
cp g3.v3 g3.html
python3 src/patch_core.py
python3 src/patch_core2.py
python3 src/patch_render1.py
python3 src/patch_tube.py
python3 src/patch_render2.py
python3 src/patch_skin.py
python3 src/patch_editor.py
python3 src/patch_combat.py
python3 src/patch_designall.py
python3 src/patch_world_core.py
python3 src/patch_world_render.py
python3 src/patch_foliage.py
python3 src/patch_moves.py
python3 src/patch_jump.py
python3 src/patch_atmos.py
python3 src/patch_final.py
python3 src/patch_fight.py
python3 src/patch_spatial.py
python3 src/patch_fp.py
python3 src/patch_remains.py
python3 src/patch_heading.py
python3 src/patch_ui.py
python3 src/patch_defaults.py
python3 src/patch_gfx2.py
python3 src/extract_core.py g3.html core.js
node -e "require('./core.js')" && echo BUILD_OK
