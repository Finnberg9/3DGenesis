// The first screen is two decisions and a drawer. These checks read the real
// DOM the menu builds, and click the real buttons.
module.exports = async (p, h) => {
  const fail = [];
  const t = (n, c, x) => { h.log((c ? 'ok  ' : 'FAIL') + '  ' + n + (x != null ? '  ' + x : '')); if (!c) fail.push(n); };

  const items = await p.evaluate(() => [...document.querySelectorAll('#mmNav .mmItem .mmLabel')].map(e => e.textContent.trim()));
  t('the front page offers exactly three lines', items.length === 3, JSON.stringify(items));
  t('and the first two are CAMPAIGN and ONLINE', items[0] === 'CAMPAIGN' && items[1] === 'ONLINE', JSON.stringify(items));
  t('with nothing else competing with them', !items.includes('NEW GAME') && !items.includes('LOAD CREATURE') &&
    !items.includes('CONTROLS') && !items.includes('OPTIONS') && !items.includes('ABOUT'), JSON.stringify(items));

  const on = await p.evaluate(() => {
    window.__G3D.menu.page('online');
    const el = document.getElementById('mmPage');
    return { shown: el.classList.contains('show'), h2: (el.querySelector('h2') || {}).textContent, txt: el.textContent };
  });
  t('ONLINE opens the battle royale page', on.shown && /BATTLE ROYALE/.test(on.h2 || ''), on.h2);
  t('and it says everyone starts with nothing', /spawns as a bare body/.test(on.txt));
  t('and that there is no wildlife', /no wildlife/i.test(on.txt));
  t('and describes the mushrooms', /mushrooms/i.test(on.txt));

  const cp = await p.evaluate(() => {
    window.__G3D.menu.page('campaign');
    const el = document.getElementById('mmPage');
    return { h2: (el.querySelector('h2') || {}).textContent, btns: [...el.querySelectorAll('.mmb')].map(b => b.textContent.trim()) };
  });
  t('CAMPAIGN opens its own page', /CAMPAIGN/.test(cp.h2 || ''), cp.h2);
  t('and offers a way to start playing', cp.btns.some(b => /new creature/.test(b)), JSON.stringify(cp.btns));

  const mr = await p.evaluate(() => {
    window.__G3D.menu.page('more');
    return [...document.querySelectorAll('#mmPage .mmb')].map(b => b.textContent.trim());
  });
  t('MORE still reaches everything that left the front page',
    ['controls', 'options', 'saved creatures', 'about'].every(k => mr.includes(k)), JSON.stringify(mr));

  const ctl = await p.evaluate(() => {
    const b = [...document.querySelectorAll('#mmPage .mmb')].find(x => x.textContent.trim() === 'controls');
    b.click();
    return (document.querySelector('#mmPage h2') || {}).textContent;
  });
  t('and those buttons work', /CONTROLS/.test(ctl || ''), ctl);

  h.log(fail.length ? '\nFAILED: ' + fail.join(' | ') : '\nALL MENU CHECKS PASS');
};
