module.exports = async (p, h) => {
  const fail = []; const t = (n, c, x) => { h.log((c ? 'ok  ' : 'FAIL') + '  ' + n + (x != null ? '  ' + x : '')); if (!c) fail.push(n); };
  await p.evaluate(() => window.__G3D.openEditor('start'));
  for (let k = 0; k < 14; k++) { await h.wait(2000); if (await p.evaluate(() => !!(window.ED && ED.thumbsReady))) break; }
  await p.evaluate(() => window.__G3D.bones.tab('body'));
  await h.wait(500);
  const r = await p.evaluate(() => {
    const tiles = [...document.querySelectorAll('#edGrid .edtile.plan')];
    return { n: tiles.length, silho: tiles.filter(e => e.classList.contains('silho')).length,
             names: tiles.filter(e => e.querySelector('.edcname2')).length,
             filt: tiles.length ? getComputedStyle(tiles[0].querySelector('img') || tiles[0]).filter : null,
             plans: tiles.map(e => +e.dataset.plan) };
  });
  // Fourteen, not everything: ten that walk and four that fly. The other
  // sixteen plans are still in the table so saved designs keep their shape;
  // they are simply not offered.
  t('the body tab offers exactly fourteen shapes', r.n === 14, String(r.n));
  t('as silhouettes', r.silho === r.n, r.silho + '/' + r.n);
  t('with no names at all', r.names === 0, String(r.names));
  t('rendered pure black', /brightness\(0\)/.test(r.filt || ''), r.filt);
  t('and the ten land shapes come first', r.plans.slice(0, 10).every(v => v >= 22), JSON.stringify(r.plans));
  t('including the scorpion, the lurker and the drake', [22, 30, 36].every(v => r.plans.includes(v)), JSON.stringify(r.plans));
  h.log(fail.length ? '\nFAILED: ' + fail.join(' | ') : '\nALL SILHOUETTE CHECKS PASS');
};
