module.exports = async (p, h) => {
  const fail = []; const t = (n, c, x) => { h.log((c ? 'ok  ' : 'FAIL') + '  ' + n + (x != null ? '  ' + x : '')); if (!c) fail.push(n); };
  await p.evaluate(() => window.__G3D.openEditor('start'));
  for (let k = 0; k < 14; k++) { await h.wait(2000); if (await p.evaluate(() => !!(window.ED && ED.thumbsReady))) break; }
  await p.evaluate(() => window.__G3D.bones.tab('body'));
  await h.wait(500);
  const r = await p.evaluate(() => {
    const tiles = [...document.querySelectorAll('#edGrid .edtile.plan')];
    return { n: tiles.length, silho: tiles.filter(e => e.classList.contains('silho')).length,
             names: tiles.filter(e => e.querySelector('.edcname2')).length,
             filt: tiles.length ? getComputedStyle(tiles[0].querySelector('img') || tiles[0]).filter : null,
             plans: tiles.map(e => +e.dataset.plan) };
  });
  t('the body tab shows every plan', r.n >= 27, String(r.n));
  t('as silhouettes', r.silho === r.n, r.silho + '/' + r.n);
  t('with no names at all', r.names === 0, String(r.names));
  t('rendered pure black', /brightness\(0\)/.test(r.filt || ''), r.filt);
  t('and the mythical shapes come first', r.plans.slice(0, 7).every(v => v >= 22), JSON.stringify(r.plans.slice(0, 10)));
  t('including the scorpion', r.plans.includes(22));
  h.log(fail.length ? '\nFAILED: ' + fail.join(' | ') : '\nALL SILHOUETTE CHECKS PASS');
};
