module.exports = async (p, T) => {
  await p.evaluate(() => document.getElementById('start').style.display = 'none');
  await p.keyboard.press('n'); await p.keyboard.press('n');   // user gesture, toggles twice
  await T.wait(500);
  T.log(await p.evaluate(async () => {
    const G = window.__G3D, S = G.sndDbg, out = {};
    if (!S.SND.ctx) return 'no ctx';
    const kinds = {};
    for (const c of G.world.creatures.slice(0, 60)) { const v = S.voxOf(c); kinds[v.kind] = (kinds[v.kind] || 0) + 1; }
    out.kinds = kinds;
    let errs = 0;
    for (const c of G.world.creatures.slice(0, 12)) for (const w of ['call', 'attack', 'pain', 'threat', 'win']) { try { S.voxCall(c, w); } catch (e) { errs++; out.err = e.message; } await new Promise(r => setTimeout(r, 20)); }
    try { S.roar(); } catch (e) { out.roarErr = e.message; }
    out.errs = errs; out.state = S.SND.ctx.state;
    return JSON.stringify(out);
  }));
  await T.wait(3000);
};
