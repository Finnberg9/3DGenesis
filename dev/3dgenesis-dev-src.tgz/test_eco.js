const C = require('./core.js');
const world = C.makeWorld({ w: 12800, h: 8000, tileSize: 48, seed: 11, startPop: 50, startPlants: 400, founderDiversity: 0.4 });
const t0 = Date.now();
const N = +(process.env.N || 6000);
for (let s = 0; s < N; s++) {
  world.step(0.1);
  if (s % 1000 === 0 || s === N - 1) {
    const cs = world.creatures.filter(c => c.alive !== false);
    const des = cs.filter(c => c.genome.design).length;
    const carn = cs.filter(c => c.ph.carnivory > 0.5).length;
    const plans = {}; for (const c of cs) if (c.genome.design) plans[c.genome.design.plan] = (plans[c.genome.design.plan] || 0) + 1;
    console.log('t', (s / 10) | 0, 'alive', cs.length, 'designed', des, 'carn', carn, JSON.stringify(plans));
  }
}
console.log('ms', Date.now() - t0);
