module.exports = async (p, T) => {
  await p.evaluate(() => { window.__G3D.begin(); });
  await p.keyboard.press('n'); await p.keyboard.press('n');   // user gesture -> audio context
  const r = await p.evaluate(() => {
    const G = window.__G3D, C = G.core, me0 = G.player.c;
    G.becomeDesigned(C.defaultDesign(0));
    G.stop();
    const me = G.player.c, out = {};
    out.gfx = G.GFX.name;
    G.gfxSet('ultra'); out.ultra = G.GFX.name === 'ultra' && localStorage.getItem('g3d_gfx');
    // growth by eating
    for (const q of me.cellState) q.grow = 1; me.ph = C.develop(me.genome, me.cellState);
    const r0 = me.ph.radius; me.energy = me.ph.storage * 0.5;
    for (let i = 0; i < 6; i++) G.feedGrowth(me, me.ph.mass);
    out.grow = +(me.ph.radius / r0).toFixed(3); out.bulk = +me._bulk.toFixed(3);
    for (let i = 0; i < 40; i++) G.feedGrowth(me, me.ph.mass * 2);
    out.bulkCap = +me._bulk.toFixed(3);
    // proximity: put moving animals around us
    const others = G.world.creatures.filter(c => c.alive && c !== me).slice(0, 4);
    const ang = [0, Math.PI / 2, Math.PI, -Math.PI / 2];
    others.forEach((o, i) => { o.x = me.x + Math.cos(G.player.yaw + ang[i]) * (120 + i * 90); o.y = me.y + Math.sin(G.player.yaw + ang[i]) * (120 + i * 90); o.vx = 30; o.vy = 0; });
    others[2].foe = me;
    // step intervals and audio placement
    out.stepIv = +G.spat.stepInterval(others[0], 60).toFixed(3);
    out.surf = G.spat.stepSurface(me.x, me.y);
    G.player.dist = 0; G.player.pitch = -1.15;
    for (let i = 0; i < 20; i++) { others.forEach((o, i2) => { o.vx = 30; }); G.step(0.02); }
    out.fpOff = me._fpOff ? { f: +me._fpOff.f.toFixed(1), y: +me._fpOff.y.toFixed(1) } : null;
    out.spatOk = G.spat.ok;
    out.audio = !!(G.sndDbg.SND.ctx);
    return out;
  });
  T.log(JSON.stringify(r));
  await p.evaluate(() => { const G = window.__G3D; G.renderFrame(G.simT); G.step(0.02); G.step(0.02); G.renderFrame(G.simT); G.step(0.02);  });
  await T.wait(1500); await p.evaluate(() => { const G = window.__G3D; G.renderFrame(G.simT);  }); await T.wait(800);
  await T.shot('fp_down.png');
  await p.evaluate(() => { const G = window.__G3D; G.player.pitch = 0.0; G.step(0.02); G.renderFrame(G.simT);  });
  await T.wait(1200); await T.shot('fp_ahead.png');
  // eye close-up: third person, near the face of another animal
  await p.evaluate(() => {
    const G = window.__G3D, me = G.player.c;
    let o = null; for (const c of G.world.creatures) if (c.alive && c !== me && c.genome.design && c.ph.mass > 2) { o = c; break; }
    // stand the camera in front of its face, looking back at it
    const fx = Math.cos(o._yaw3 || 0), fz = Math.sin(o._yaw3 || 0);
    G.player.spectator = true; o.vx = 0; o.vy = 0;
    const R = o.ph.radius * 0.55;
    G.player.camX = o.x + fx * R * 3.2 + fz * R * 0.8; G.player.camZ = o.y + fz * R * 3.2 - fx * R * 0.8;
    G.player.camY = G.world && (o.ph.standH || o.ph.radius) * 0.55 * 1.9 + window.__G3D.terrain.height(o.x, o.y) * window.__G3D.HEIGHT_SCALE;
    G.player.yaw = Math.atan2(o.y - G.player.camZ, o.x - G.player.camX); G.player.pitch = -0.1;
    window.__eyeC = o;
    G.renderFrame(G.simT);
  });
  await T.wait(2500); await p.evaluate(() => { const G = window.__G3D; G.renderFrame(G.simT); }); await T.wait(800);
  await T.shot('eyes.png');
};
