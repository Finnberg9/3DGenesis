module.exports = async (p, T) => {
  await p.evaluate(() => {
    const G = window.__G3D, C = G.core; document.getElementById('start').style.display = 'none';
    const d = C.defaultDesign(+(window.PLAN || 2));
    G.becomeDesigned(d);
    const me = G.player.c; for (const q of me.cellState) q.grow = 1; me.ph = C.develop(me.genome, me.cellState); me._growthAvg = 1;
    // open ground
    const T = G.terrain; let best = null;
    for (let k = 0; k < 4000 && !best; k++) { const x = 3000 + Math.random() * 19000, y = 2000 + Math.random() * 12000; if (T.biomeAt(x, y) === 'plains') best = [x, y]; }
    G.teleport(best[0], best[1]);
    G.player.dist = 70; G.look(0, -0.05);
    for (const c of G.world.creatures) if (c !== me && Math.hypot(c.x - me.x, c.y - me.y) < 400) c.alive = false;
    me.vx = 0; me.vy = 0;
  });
  await T.wait(4000);
  const moves = (process.env.MOVES || 'claw,punch,headbutt,bite,sweep').split(',');
  for (const mv of moves) {
    for (const ms of [140, 260]) {
      await p.evaluate(([mv]) => { const G = window.__G3D; G.look(Math.PI / 2 + 0.3, -0.12); G.startAnim(G.player.c, mv, 1.6); }, [mv]);
      await T.wait(ms * 3.2);
      await T.shot(`mv_${mv}_${ms}.png`);
      await T.wait(1800);
    }
  }
};
