module.exports = async (p, T) => {
  await p.click('[data-act="create"]');
  await T.wait(3000);
  const set = async (plan, body, f, yaw) => { await p.evaluate(([plan, body, yaw]) => {
    const G = window.__G3D, C = G.core, E = G.ED;
    E.des = C.defaultDesign(plan); Object.assign(E.des.body, body); C.reseatDesign(E.des); E.des._rev = Math.random();
    E.cam.yaw = yaw; E.cam.pitch = 0.15; E.cam.zoom = 0.85; E.sel = null;
  }, [plan, body, yaw]); await T.wait(1500); await T.shot(f); };
  await set(0, { len: 1.6, girth: 0.7, neck: 2.2, tail: 1.8 }, 'gap1.png', 1.4);
  await set(1, { len: 1.6, girth: 0.7, neck: 2.2, tail: 1.8 }, 'gap2.png', 1.4);
  await set(3, { len: 1.6, girth: 0.7, neck: 2.2, tail: 1.8 }, 'gap3.png', 1.2);
  await set(5, { len: 0.6, girth: 1.45, neck: 0, tail: 0 }, 'gap4.png', 1.2);
  T.log(await p.evaluate(() => { const E = window.__G3D.ED; return [E.des.parts.length, E.des.limbs.length, E.open]; }));
  T.log('palette locked tiles', await p.evaluate(() => { const E = window.__G3D.ED; E.tab = 'eyes'; return 0; }));
  await p.click('[data-tab="eyes"]'); await T.wait(300);
  T.log(await p.evaluate(() => [...document.querySelectorAll('[data-item]')].map(t => t.getAttribute('data-item') + (t.classList.contains('locked') ? ':L' : ':open')).join(' ')));
};
