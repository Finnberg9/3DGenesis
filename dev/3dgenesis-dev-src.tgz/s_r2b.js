module.exports = async (p, T) => {
  await p.evaluate(() => { const G = window.__G3D; G.begin(); G.gfxSet('high'); G.R2.auto = false; G.stop();
    const t = G.world.forest.trees.filter(t => t.kind === 1); const a = t[(t.length * 0.5) | 0]; G.teleport(a.x + 60, a.y + 60); G.player.yaw = -2.3; G.player.pitch = -0.15; G.player.dist = 120; for (let i = 0; i < 4; i++) G.step(0.02); G.renderFrame(G.simT); });
  const shots = [['r2_noao', { ao: 0 }], ['r2_nothing', { ao: 0, shadow: 0, bloom: 0, rays: 0 }]];
  for (const [n, o] of shots) {
    await p.evaluate((o) => { const G = window.__G3D; Object.assign(G.GFX, o); G.renderFrame(G.simT); }, o);
    await T.wait(1800); await p.evaluate(() => { const G = window.__G3D; G.renderFrame(G.simT); }); await T.wait(900);
    await p.screenshot({ path: n + '.png', clip: { x: 500, y: 250, width: 700, height: 450 }, timeout: 180000 });
  }
};
