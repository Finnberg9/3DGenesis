module.exports = async (p, T) => {
  const r = await p.evaluate(() => { const G = window.__G3D; G.begin(); G.becomeDesigned(G.core.defaultDesign(0)); G.gfxSet('high'); G.R2.auto = false; G.stop();
    const me = G.player.c; for (const q of me.cellState) q.grow = 1; me.ph = G.core.develop(me.genome, me.cellState);
    G.player.dist = 0; G.player.pitch = -1.1; G.pumpMesh(); G.player.yaw = 0.4;
    for (let i = 0; i < 60; i++) { G.step(0.02); G.renderFrame(G.simT); } G.renderFrame(G.simT);
    return { off: me._fpOff, camY: G.player.camY - G.terrain.height(me.x, me.y) * G.HEIGHT_SCALE, R: me.ph.radius }; });
  T.log(JSON.stringify(r));
  await T.wait(2000); await p.evaluate(() => { const G = window.__G3D; G.step(0.02); G.renderFrame(G.simT); }); await T.wait(900);
  await T.shot('fp2.png');
  await p.evaluate(() => { const G = window.__G3D; G.player.pitch = -0.4; G.player.yaw += 1.2; for (let i = 0; i < 10; i++) G.step(0.02); G.renderFrame(G.simT); });
  await T.wait(2000); await p.evaluate(() => { const G = window.__G3D; G.renderFrame(G.simT); }); await T.wait(900);
  await T.shot('fp3.png');
};
