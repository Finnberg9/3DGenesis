// The loadout screen: the skin, the kit/shop split, and the one interact key.
module.exports = async (p, h) => {
  const fail = [];
  const t = (n, c, x) => { h.log((c ? 'ok  ' : 'FAIL') + '  ' + n + (x != null ? '  ' + x : '')); if (!c) fail.push(n); };
  const errs = [];
  p.on('console', (m) => { if (m.type() === 'warning' && /bound|handled more than once/.test(m.text())) errs.push(m.text()); });

  await p.evaluate(() => { const G = window.__G3D; G.bones.reset(); G.becomeArchetype('theropod'); G.beginPlay(); });
  await h.wait(700);
  await p.evaluate(() => window.__G3D.openEditor('game'));
  for (let k = 0; k < 16; k++) { await h.wait(2000); if (await p.evaluate(() => !!(window.ED && ED.thumbsReady))) break; }

  // ---- it opens on your kit -------------------------------------------------
  t('the builder opens on your kit, not on a category', await p.evaluate(() => window.__G3D.bones.curTab) === 'kit');

  // ---- no key is bound twice ------------------------------------------------
  t('no key is handled twice in the play handler', errs.length === 0, errs.join(' | '));

  // ---- the skin -------------------------------------------------------------
  const sk = await p.evaluate(() => {
    const pal = getComputedStyle(document.getElementById('edPal'));
    const go = document.getElementById('edDone') || document.querySelector('#edTop button.go');
    const gs = go ? getComputedStyle(go) : null;
    const tile = document.querySelector('#edGrid .edtile');
    return {
      palRadius: pal.borderRadius, palBorder: pal.borderLeftWidth + '/' + pal.borderTopWidth,
      goBg: gs && gs.backgroundColor, goRadius: gs && gs.borderRadius, goSpacing: gs && gs.letterSpacing,
      tileRadius: tile ? getComputedStyle(tile).borderRadius : null,
      vig: !!document.getElementById('edVig'), grain: !!document.getElementById('edGrain'), scan: !!document.getElementById('edScan'),
    };
  });
  t('the palette is an edge, not a rounded frame', sk.palRadius === '0px' && /^0px\//.test(sk.palBorder) === false, JSON.stringify({ r: sk.palRadius, b: sk.palBorder }));
  t('nothing is rounded any more', sk.tileRadius === '0px' && sk.goRadius === '0px', JSON.stringify({ tile: sk.tileRadius, go: sk.goRadius }));
  t('the play button is not green', !/^rgb\(\s*(?:1[0-9]{2}|[5-9][0-9])\s*,\s*2[0-9]{2}/.test(sk.goBg || ''), sk.goBg);
  t('and the type is spaced out like a loadout screen', parseFloat(sk.goSpacing) > 1.5, sk.goSpacing);
  t('grain, vignette and scan are all present', sk.vig && sk.grain && sk.scan);

  // ---- the kit list ---------------------------------------------------------
  // The body you walked in with counts as kit: its own parts stay usable
  // whether or not you own copies, which is what stops an inherited animal
  // being locked out of its own anatomy. So the kit is not empty at open.
  const k0 = await p.evaluate(() => { const B = window.__G3D.bones; B.tab('kit'); return { rows: B.rows(), empty: B.empty() }; });
  t('the kit opens listing the parts the body is already wearing', k0.rows.length > 0, k0.rows.length + ' rows');
  t('and every one of them is draggable', k0.rows.every(r => r.drag), JSON.stringify(k0.rows.map(r => r.id)));

  const k1 = await p.evaluate(() => {
    const G = window.__G3D, B = G.bones;
    B.earn(100000);
    B.tab('shop');
    const shop = B.rows();
    return { n: shop.length, allBuy: shop.every(r => r.buy), noneDrag: shop.every(r => !r.drag), first: shop.slice(0, 3) };
  });
  t('the shop lists what you do not own', k1.n > 20, String(k1.n));
  t('every shop row has a price on it', k1.allBuy === true);
  t('and nothing in the shop can be dragged onto the body', k1.noneDrag === true);
  t('cheapest first', k1.first.length === 3, JSON.stringify(k1.first.map(r => r.id)));

  const k2 = await p.evaluate(() => {
    const G = window.__G3D, B = G.bones;
    B.buy('m_rex'); B.buy('s_spike'); B.buy('s_spike');
    B.tab('kit');
    const rows = B.rows();
    return { rows, ids: rows.map(r => r.id), shopHas: (B.tab('shop'), B.rows().map(r => r.id)) };
  });
  t('what you buy appears in your kit', k2.ids.includes('m_rex') && k2.ids.includes('s_spike'), JSON.stringify(k2.ids));
  t('and leaves the shop', !k2.shopHas.includes('m_rex') && !k2.shopHas.includes('s_spike'), k2.shopHas.length + ' left in the shop');
  const rex = k2.rows.find(r => r.id === 'm_rex'), spike = k2.rows.find(r => r.id === 's_spike');
  t('a kit row says how many you have', /×2/.test(spike.name) || /×2/.test(spike.name), spike.name);
  t('and how many are spare to place', /to place/.test(spike.meta), spike.meta);
  t('and can be dragged onto the creature', spike.drag === true && rex.drag === true);
  t('the rarest thing you own is at the top', k2.ids[0] === 'm_rex', JSON.stringify(k2.ids));

  // a category tab now shows only what you own
  const cat = await p.evaluate(() => { const B = window.__G3D.bones; B.tab('armor'); return { cards: B.cards(), empty: B.empty() }; });
  // s_knob is on the creature's own body, so it is kit too.
  const worn = await p.evaluate(() => window.__G3D.bones.wornCount('s_knob'));
  t('a category tab lists only what you own or are wearing',
    cat.cards.length > 0 && cat.cards.every(id => id === 's_spike' || worn > 0), JSON.stringify({ cards: cat.cards, wornKnob: worn }));
  const cat2 = await p.evaluate(() => { const B = window.__G3D.bones; B.tab('wings'); return { cards: B.cards(), empty: B.empty() }; });
  t('and an empty one points at the shop', cat2.cards.length === 0 && /shop/i.test(cat2.empty || ''), JSON.stringify(cat2.empty));

  h.log(fail.length ? '\nFAILED: ' + fail.join(' | ') : '\nALL LOADOUT CHECKS PASS');
};
