module.exports = async (p, T) => {
  // start straight into a saved-style design: the default quadruped with extra parts
  await p.evaluate(() => {
    const G = window.__G3D, C = G.core;
    const d = C.defaultDesign(0);
    G.becomeDesigned(d);
    document.getElementById('start').style.display = 'none';
  });
  await T.wait(1500);
  // look at the nearest grown kin from the side
  const info = await p.evaluate(() => {
    const G = window.__G3D, me = G.player.c;
    let best = null, bd = 1e9;
    for (const c of G.world.creatures) if (c.alive && c !== me && c.genome.design) { const d = Math.hypot(c.x - me.x, c.y - me.y); if (d < bd) { bd = d; best = c; } }
    G.player.c = best;                 // steer the adult so the camera frames it
    G.player.dist = 130; G.player.pitch = -0.18; G.player.yaw = 0.3;
    return { r: best.ph.radius, stand: best.ph.standH, legs: best.ph.dLegs };
  });
  T.log(JSON.stringify(info));
  await T.wait(2500);
  await T.shot('g1.png');
  await p.keyboard.down('w'); await T.wait(2500); await T.shot('g2.png'); await p.keyboard.up('w');
  await p.evaluate(() => { const G = window.__G3D; G.player.yaw += 1.6; });
  await p.keyboard.down('w'); await T.wait(1500); await T.shot('g3.png'); await p.keyboard.up('w');
};
