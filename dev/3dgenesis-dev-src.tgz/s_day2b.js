module.exports = async (p, T) => {
  await p.evaluate(() => { window.__G3D.begin(); });
  const info = await p.evaluate(() => {
    const G = window.__G3D, C = G.core;
    G.becomeDesigned(C.defaultDesign(0)); G.stop();
    const me = G.player.c;
    const vict = G.world.creatures.filter(c => c.alive && c !== me && c.genome.design).slice(0, 3);
    vict.forEach((v, i) => { v.x = me.x + 60 + i * 55; v.y = me.y + (i - 1) * 40; for (const q of v.cellState) q.grow = 1; v.ph = C.develop(v.genome, v.cellState); G.remainsAdd(v); v.alive = false; });
    const R = G.REMAINS; if (R[1]) R[1].t0 -= 120; if (R[2]) R[2].t0 -= 300;
    G.player.yaw = 0; G.player.dist = 170; G.player.pitch = -0.6;
    for (let i = 0; i < 4; i++) G.step(0.02);
    return { remains: R.length, plans: vict.map(v => v.genome.design.plan) };
  });
  T.log(JSON.stringify(info));
  for (let i = 0; i < 2; i++) { await p.evaluate(() => { const G = window.__G3D; G.step(0.02); G.renderFrame(G.simT); }); await T.wait(1500); }
  await T.shot('bones.png');
  // first person looking down
  await p.evaluate(() => { const G = window.__G3D; G.player.dist = 0; G.player.pitch = -1.2; G.player.yaw = 2.5; for (let i = 0; i < 3; i++) { G.step(0.02); G.renderFrame(G.simT); } });
  await T.wait(1500); await p.evaluate(() => { const G = window.__G3D; G.step(0.02); G.renderFrame(G.simT); }); await T.wait(800);
  await T.shot('fp_down.png');
  // trees
  await p.evaluate(() => { const G = window.__G3D;
    const t = G.world.forest.trees.filter(t => t.kind === 0); const a = t[(t.length * 0.4) | 0];
    G.player.spectator = true; G.player.camX = a.x + 75; G.player.camZ = a.y + 25; G.player.camY = G.terrain.height(a.x + 75, a.y + 25) * G.HEIGHT_SCALE + 18;
    G.player.yaw = Math.atan2(-25, -75); G.player.pitch = 0.25; G.step(0.02); G.renderFrame(G.simT); });
  await T.wait(3000); await p.evaluate(() => { const G = window.__G3D; G.renderFrame(G.simT); }); await T.wait(1000);
  await T.shot('trees2.png');
};
