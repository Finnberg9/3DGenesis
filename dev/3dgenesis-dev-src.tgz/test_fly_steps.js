// You fly through the air, not over the ground, and one press is one flap.
module.exports = async (p, h) => {
  const fail = [];
  const t = (n, c, x) => { h.log((c ? 'ok  ' : 'FAIL') + '  ' + n + (x != null ? '  ' + x : '')); if (!c) fail.push(n); };

  await p.evaluate(() => { const G = window.__G3D; G.becomeArchetype('flier'); G.beginPlay(); });
  await h.wait(1000);
  // a flier hatches as a baby that cannot yet carry itself; the model is what
  // is under test, so give this one its adult wings
  const fly = await p.evaluate(() => {
    const c = window.__G3D.player.c;
    if (!c) return false;
    c.ph.canFly = true;
    if (!(c.ph.wingEff > 0.4)) c.ph.wingEff = 0.9;
    return !!c.ph.canFly;
  });
  t('we have a body that flies', fly === true, fly);
  if (!fly) { h.log('\nFAILED: no flier'); return; }

  // ---- the terrain no longer moves you ------------------------------------
  const ride = await p.evaluate(() => {
    const G = window.__G3D, c = G.player.c;
    // find a spot with a real hill next to it, and put the flier over the low side
    let bx = c.x, bz = c.y, best = 0, hx = c.x, hz = c.y;
    for (let i = 0; i < 600; i++) {
      const x = 4000 + Math.random() * 42000, z = 4000 + Math.random() * 24000;
      const g0 = G.groundY(x, z), g1 = G.groundY(x + 700, z);
      if (g1 - g0 > best && g0 > 5) { best = g1 - g0; bx = x; bz = z; hx = x + 700; hz = z; }
    }
    return { rise: Math.round(best), x: bx, z: bz, hx, hz };
  });
  t('found a hill to fly over', ride.rise > 60, ride.rise + ' units of rise over 700');

  const flight = await p.evaluate((r) => {
    const G = window.__G3D, c = G.player.c;
    c.x = r.x; c.y = r.z;
    G.teleport(r.x, r.z);
    G.flight.set(400, 300);
    G.player.pitch = 0;                      // dead level
    const y0 = G.flight.worldY;
    const samples = [];
    // walk the body across the hill by hand, ticking flight each step, so the
    // only thing that can move the altitude is the flight model
    const steps = 70;
    for (let i = 0; i < steps; i++) {
      c.x += (r.hx - r.x) / steps;
      c.y += (r.hz - r.z) / steps;
      G.flight.tick(0.05);
      samples.push(G.flight.worldY);
    }
    const ground = [];
    for (let i = 0; i <= steps; i++) ground.push(G.groundY(r.x + (r.hx - r.x) * i / steps, r.z + (r.hz - r.z) * i / steps));
    // biggest jump in world height between consecutive frames
    let jolt = 0;
    for (let i = 1; i < samples.length; i++) jolt = Math.max(jolt, Math.abs(samples[i] - samples[i - 1]));
    return { y0: Math.round(y0), yEnd: Math.round(samples[samples.length - 1]), jolt: Math.round(jolt),
             groundRise: Math.round(ground[ground.length - 1] - ground[0]),
             drift: Math.round(samples[samples.length - 1] - y0) };
  }, ride);
  // gliding level, the only height you should lose is the wing's own sink
  t('the hill does not lift you with it',
    Math.abs(flight.drift) < Math.max(60, flight.groundRise * 0.35),
    'ground rose ' + flight.groundRise + ', you moved ' + flight.drift);
  t('and the path is smooth, frame to frame', flight.jolt < 14, 'worst step ' + flight.jolt + ' units');

  // ---- one press, one flap ------------------------------------------------
  const flap = await p.evaluate(() => {
    const G = window.__G3D;
    G.flight.set(400, 300);
    const before = G.flight.vy;
    G.flight.flap();
    G.flight.tick(0.016);
    const after = G.flight.vy;
    // a second tick with NO new press must not beat again
    const beat0 = G.flight.beat;
    G.flight.tick(0.016);
    const held = G.flight.vy;
    return { before: Math.round(before), after: Math.round(after), held: Math.round(held), beat: beat0 > 0 };
  });
  t('a press lifts you', flap.after > flap.before + 20, JSON.stringify(flap));
  t('and holding does not flap again', flap.held <= flap.after + 1, JSON.stringify(flap));
  t('the wing has a beat period', flap.beat === true);

  // ---- bigger wings lift more per beat ------------------------------------
  const lift = await p.evaluate(() => {
    const G = window.__G3D;
    const c = G.player.c, p0 = c.ph;
    const one = (w) => {
      p0.wingEff = w;
      G.flight.set(400, 300);
      const v0 = G.flight.vy;
      G.flight.flap(); G.flight.tick(0.016);
      return G.flight.vy - v0;
    };
    const small = one(0.25), big = one(1.6);
    return { small: Math.round(small), big: Math.round(big), wSmall: G.flight.wing({ wingEff: 0.25 }), wBig: G.flight.wing({ wingEff: 1.6 }) };
  });
  t('a bigger wing lifts more per beat', lift.big > lift.small * 1.8, JSON.stringify(lift));

  h.log(fail.length ? '\nFAILED: ' + fail.join(', ') : '\nALL FLIGHT CHECKS PASS');
};
