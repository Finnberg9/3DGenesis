module.exports = async (p, T) => {
  await p.evaluate(() => { const G = window.__G3D; document.getElementById('start').style.display = 'none';
    const t = G.world.forest.trees.filter(t => t.kind === 1); const a = t[(t.length * 0.51) | 0]; G.teleport(a.x + 40, a.y + 40); G.look(0.7, 0.02); G.setDist(90); });
  await T.wait(3500); await T.shot('at_day.png');
  for (const [nm, ph] of [['dusk', 0.52], ['night', 0.75]]) {
    await p.evaluate((ph) => { const G = window.__G3D, w = G.world, dl = w.params.dayLen; w.bt = Math.floor(w.bt / dl) * dl + ph * dl; }, ph);
    await T.wait(3000); await T.shot('at_' + nm + '.png');
  }
  T.log(await p.evaluate(() => JSON.stringify({ light: window.__G3D.world.light, obj: document.getElementById('objective') && document.getElementById('objective').textContent })));
};
