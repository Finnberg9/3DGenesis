module.exports = async (p, T) => {
  await p.evaluate(() => { const G = window.__G3D; G.begin(); G.becomeDesigned(G.core.defaultDesign(0)); G.gfxSet('high'); G.R2.auto = false; G.stop();
    const me = G.player.c; for (const q of me.cellState) q.grow = 1.4; me.ph = G.core.develop(me.genome, me.cellState);
    // open ground near the forest edge
    const t = G.world.forest.trees.filter(t => t.kind === 1); const a = t[(t.length * 0.3) | 0];
    G.teleport(a.x + 50, a.y + 20);
    const dl = G.world.params.dayLen; G.world.bt = Math.floor(G.world.bt / dl) * dl + 0.12 * dl;
    G.player.dist = 90; G.player.pitch = -0.45; G.player.yaw = 1.0;
    for (let i = 0; i < 5; i++) G.step(0.02); G.renderFrame(G.simT); });
  await T.wait(2000); await p.evaluate(() => { const G = window.__G3D; G.renderFrame(G.simT); }); await T.wait(1000);
  await T.shot('r2_shadow.png');
  T.log(await p.evaluate(() => JSON.stringify({ light: window.__G3D.world.light, casc: window.__G3D.R2.cascades })));
};
