module.exports = async (p, h) => {
  const fail = [];
  const t = (n, c, x) => { h.log((c ? 'ok  ' : 'FAIL') + '  ' + n + (x != null ? '  ' + x : '')); if (!c) fail.push(n); };
  await p.evaluate(() => { const G = window.__G3D; G.bones.reset(); G.bones.earn(1450); G.becomeArchetype('theropod'); G.beginPlay(); });
  await h.wait(500);
  await p.evaluate(() => window.__G3D.openEditor('game'));
  for (let k = 0; k < 14; k++) { await h.wait(2000); if (await p.evaluate(() => !!(window.ED && ED.thumbsReady))) break; }
  await p.evaluate(() => window.__G3D.bones.tab('mouth'));
  await h.wait(800);
  const a = await p.evaluate(() => {
    const B = window.__G3D.bones;
    return { noShopBox: !document.getElementById('edShopBox'), noShopBtn: !document.getElementById('edShopBtn'),
             hud: B.hudBones(), buys: B.buyButtons(), sells: B.sellButtons() };
  });
  t('the separate shop panel is gone', a.noShopBox && a.noShopBtn);
  t('the balance reads in the toolbar', a.hud === '1450', a.hud);
  t('locked cards carry a buy button', a.buys.length > 0, a.buys.join(','));
  // buy a jaw right off the card
  const b = await p.evaluate(() => {
    const B = window.__G3D.bones;
    const before = B.balance;
    const clicked = B.clickBuy('m_jaws');
    return { clicked, before, after: B.balance, hud: B.hudBones(),
             nowSellable: B.sellButtons().includes('m_jaws'), stillBuyable: B.buyButtons().includes('m_jaws') };
  });
  t('clicking buy on the card unlocks it', b.clicked && b.before - b.after === 100, b.before + ' -> ' + b.after);
  t('the card turns into a sell', b.nowSellable && !b.stillBuyable);
  t('the toolbar balance follows', b.hud === '1350', b.hud);
  // selling takes two clicks
  const c = await p.evaluate(() => {
    const B = window.__G3D.bones;
    B.clickSell('m_jaws');                       // arms
    const armed = B.balance;
    const armedText = (document.querySelector('#edGrid [data-sell="m_jaws"]') || {}).textContent;
    B.clickSell('m_jaws');                       // confirms
    return { armed, armedText, after: B.balance, backToBuy: B.buyButtons().includes('m_jaws') };
  });
  t('one click on sell only arms it', c.armed === 1350, c.armed + ' | ' + c.armedText);
  t('the second click sells at a quarter', c.after === 1375, c.after);
  t('and the card goes back to buyable', c.backToBuy);
  // a part you are wearing cannot be sold
  const d = await p.evaluate(() => {
    const B = window.__G3D.bones;
    const worn = B.worn()[0];
    B.grant(worn); B.refresh();
    const r = B.sell(worn);
    return { worn, ok: r.ok, msg: r.msg };
  });
  t('a part on your body cannot be sold', d.ok === false, d.msg);
  // cannot afford
  const e = await p.evaluate(() => {
    const B = window.__G3D.bones;
    B.reset(); B.earn(10); B.tab('mouth');
    const poor = !!document.querySelector('#edGrid [data-buy="m_rex"].poor');
    B.clickBuy('m_rex');
    return { poor, bal: B.balance, owns: B.sellButtons().includes('m_rex') };
  });
  t('an unaffordable card is dimmed and refuses', e.poor && e.bal === 10 && !e.owns);
  h.log(fail.length ? '\nFAILED: ' + fail.join(', ') : '\nALL PALETTE-SHOP CHECKS PASS');
  await h.shot('/home/claude/w/pic_palette_buy.png');
};
