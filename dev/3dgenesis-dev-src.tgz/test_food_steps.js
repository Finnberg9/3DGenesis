// Food is a standing crop you take bites out of, some of it is poison, and the
// prompt says which before you press E.
module.exports = async (p, h) => {
  const fail = [];
  const t = (n, c, x) => { h.log((c ? 'ok  ' : 'FAIL') + '  ' + n + (x != null ? '  ' + x : '')); if (!c) fail.push(n); };
  const strip = (s) => String(s || '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();

  await p.evaluate(() => { const G = window.__G3D; G.becomeArchetype('grazer'); G.beginPlay(); });
  await h.wait(1200);
  const body = await p.evaluate(() => {
    const G = window.__G3D, c = G.player.c;
    if (!c) return null;
    const q = c.ph;
    // this body has to be able to stand up, or the reach prompt has nothing to
    // offer; everything else about it is left alone
    if ((q.dLegs || 0) < 2) q.dLegs = 2;
    c.hurtT = 0;
    return { gut: G.food.gut(), scav: +(q.scavenger || 0).toFixed(2), digest: +q.digest.toFixed(2),
             carrion: +q.carrionDigest.toFixed(2), smells: G.food.smell() };
  });
  t('we have a body with a gut', !!body && body.gut > 0, JSON.stringify(body));
  if (!body) { h.log('\nFAILED: no player'); return; }

  // ---- a bite, not the whole plant --------------------------------------
  const bite = await p.evaluate(() => {
    const G = window.__G3D, c = G.player.c;
    G.food.clear();
    G.food.clearSick();
    const placed = G.food.place({ kind: 'grass', crop: 1, bites: 4, e: 120, high: 0 });
    const before = G.food.near();
    const plants0 = G.world.plants.length;
    c.energy = Math.max(1, c.ph.storage * 0.3);
    const e0 = c.energy;
    const r = G.food.eat();
    const after = G.food.near();
    return { placed, before, after, r, plants0, plants1: G.world.plants.length,
             e0: Math.round(e0), e1: Math.round(c.energy) };
  });
  t('a plant in front of you is the food in reach',
    !!bite.before && bite.before.kind === 'grass' && bite.before.crop > 0.99 && bite.before.left === 4,
    JSON.stringify(bite.before));
  t('one press is one bite, and it pays', bite.r.ok === true && bite.r.gain > 0, JSON.stringify(bite.r));
  t('the bite lowers the standing crop', bite.after && bite.after.crop < bite.before.crop - 0.2,
    bite.before.crop + ' -> ' + (bite.after && bite.after.crop));
  t('and it raises your energy', bite.e1 > bite.e0, bite.e0 + ' -> ' + bite.e1);
  t('the plant is still there afterwards', bite.plants1 === bite.plants0 && !!bite.after,
    bite.plants0 + ' plants before, ' + bite.plants1 + ' after');
  t('and it still has bites left in it', bite.after && bite.after.left === 3, JSON.stringify(bite.after));

  // eat it all the way down, counting mouthfuls
  const drain = await p.evaluate(() => {
    const G = window.__G3D;
    const got = [];
    for (let i = 0; i < 8; i++) { const r = G.food.eat(); if (!r.ok) break; got.push(Math.round(r.gain)); }
    return { got, near: G.food.near(), plants: G.world.plants.length };
  });
  t('a four-bite plant gives four mouthfuls in total', drain.got.length === 3,
    '3 more after the first: ' + drain.got.join('+'));
  t('and is then bare, not gone', !!drain.near && drain.near.bare === true, JSON.stringify(drain.near));

  // ---- a bare plant refuses, and says when to come back -------------------
  const bare = await p.evaluate(() => {
    const G = window.__G3D;
    const r = G.food.eat();
    return { r, wait: G.food.wait(), prompt: G.food.prompt() };
  });
  t('a bare plant refuses', bare.r.ok === false && bare.r.why === 'bare', JSON.stringify(bare.r));
  t('and says it was grazed down and roughly how long to wait',
    /grazed down/i.test(bare.r.msg) && /\d+\s*s|coming back|grow back/i.test(bare.r.msg), bare.r.msg);
  t('the panel says the same thing', /grazed down/i.test(strip(bare.prompt)), strip(bare.prompt));

  // ---- height: too high for a short body, fine when it rears --------------
  const high = await p.evaluate(() => {
    const G = window.__G3D, c = G.player.c, q = c.ph;
    G.food.clear();
    // a known vertical reach, so the height under test is a known multiple of it
    let rr = (q.reach || 0) + (q.radius || 0) * 0.5 + (q.neck || 0) * 20;
    if (rr > 18) { q.reach = Math.max(1, 12 - (q.radius || 0) * 0.5 - (q.neck || 0) * 20); rr = (q.reach || 0) + (q.radius || 0) * 0.5 + (q.neck || 0) * 20; }
    const hgt = Math.min(0.99, Math.max(0.06, rr * 1.4 / 34));    // 1.4x reach: out flat, in reared
    G.food.place({ kind: 'bush', crop: 1, bites: 4, e: 120, high: hgt });
    G.food.rear(0);
    const flat = G.food.near(), flatPrompt = G.food.prompt(), flatEat = G.food.eat();
    G.food.rear(1);
    const up = G.food.near(), upEat = G.food.eat();
    G.food.rear(0);
    return { rr: Math.round(rr), hgt: +hgt.toFixed(3), flat, flatPrompt, flatEat, up, upEat };
  });
  t('food up in a bush is out of reach standing flat', high.flat && high.flat.reach === false,
    'reach ' + high.rr + ', food at ' + high.hgt);
  t('and E says exactly why', high.flatEat.ok === false && high.flatEat.why === 'high' && /rear up with G/i.test(high.flatEat.msg),
    high.flatEat.msg);
  t('the panel says it too', /out of reach/i.test(strip(high.flatPrompt)) && /rear up/i.test(strip(high.flatPrompt)),
    strip(high.flatPrompt));
  t('reared up, the same bush is in reach', high.up && high.up.reach === true, JSON.stringify(high.up));
  t('and you get the berries', high.upEat.ok === true && high.upEat.gain > 0, JSON.stringify(high.upEat));

  // a body that simply is not tall enough is told that instead
  const short = await p.evaluate(() => {
    const G = window.__G3D;
    G.food.set({ high: 0.99, crop: 1 });
    G.food.rear(1);
    const r = G.food.eat();
    G.food.rear(0);
    return r;
  });
  t('food no amount of rearing reaches says you are not tall enough',
    short.ok === false && short.why === 'high' && /not tall enough/i.test(short.msg), short.msg);

  // ---- the prompt names the food and what you get ------------------------
  const named = await p.evaluate(() => {
    const G = window.__G3D;
    G.food.clear();
    G.food.place({ kind: 'bush', crop: 1, bites: 4, e: 120, high: 0 });
    const a = G.food.prompt();
    G.food.clear();
    G.food.place({ kind: 'fungus', crop: 1, bites: 3, e: 90, high: 0 });
    const b = G.food.prompt();
    return { bush: a, fungus: b, near: G.food.near() };
  });
  named.bush = strip(named.bush); named.fungus = strip(named.fungus);
  t('the panel names a bush in plain words and counts the bites',
    /berry bush/i.test(named.bush) && /4 bites left/i.test(named.bush) && /\bE\b/.test(named.bush) && /\+\d+ energy/.test(named.bush),
    named.bush);
  t('and names a mushroom cluster', /mushroom cluster/i.test(named.fungus), named.fungus);

  // ---- only a good nose smells the poison ---------------------------------
  const nose = await p.evaluate(() => {
    const G = window.__G3D, q = G.player.c.ph;
    const keep = q.sGut, keepS = q.scavenger;
    G.food.clear();
    G.food.place({ kind: 'fungus', crop: 1, bites: 3, e: 90, high: 0, toxic: 0.9 });
    q.sGut = 0; q.scavenger = 0;
    const dull = { smell: G.food.smell(), html: G.food.prompt() };
    q.sGut = 2.4;
    const keen = { smell: G.food.smell(), html: G.food.prompt() };
    q.sGut = keep; q.scavenger = keepS;
    return { dull, keen };
  });
  nose.dull.html = strip(nose.dull.html); nose.keen.html = strip(nose.keen.html);
  t('a body with no gut to speak of cannot tell it is poison',
    nose.dull.smell === false && !/smells wrong/i.test(nose.dull.html), nose.dull.html);
  t('a body built to eat is warned before it swallows',
    nose.keen.smell === true && /smells wrong/i.test(nose.keen.html), nose.keen.html);

  // ---- poison makes you ill, and the illness passes -----------------------
  const ill = await p.evaluate(() => {
    const G = window.__G3D, c = G.player.c;
    G.food.clearSick();
    c.energy = c.ph.storage;
    const before = G.food.sick;
    const r = G.food.eat();
    const now = G.food.sick;
    const e0 = c.energy, stam = G.food.stamMul();
    const hud = document.getElementById('v-stats') ? (G.food.prompt(), document.getElementById('v-stats').innerHTML) : '';
    const fx0 = G.food.sick.fx;
    const half = G.food.tickSick(now.t * 0.5);
    const e1 = c.energy;
    const fx1 = G.food.sick.fx;
    const rest = G.food.tickSick(now.t + 4);
    return { before, r, now, e0: Math.round(e0), e1: Math.round(e1), half, rest, stam,
             hud: String(hud).replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim(), fx0, fx1,
             after: G.food.sick, stamAfter: G.food.stamMul() };
  });
  t('a toxic mushroom is eaten and makes you ill',
    ill.r.ok === true && ill.r.why === 'plant' && ill.r.sick > 0 && ill.now.t > 0,
    JSON.stringify({ sick: ill.r.sick, t: ill.now.t, src: ill.now.src }));
  t('the HUD says you are ill and for how long', /ill from/i.test(ill.hud) && /\d+ s/.test(ill.hud), ill.hud);
  t('stamina recovery is cut while it lasts', ill.stam < 1 && ill.stam > 0, 'x' + ill.stam);
  t('the tint comes up', ill.fx1 > 0.02, 'vignette ' + ill.fx0 + ' -> ' + ill.fx1);
  t('it drains you steadily', ill.e1 < ill.e0, ill.e0 + ' -> ' + ill.e1 + ' energy');
  t('it ticks down', ill.half > 0 && ill.half < ill.now.t, ill.now.t + ' -> ' + ill.half);
  t('and it clears on its own', ill.rest === 0 && ill.after.t === 0 && ill.after.src === '' && ill.stamAfter === 1,
    JSON.stringify(ill.after));

  // ---- and it is wired into the real frame, not just callable -------------
  const framed = await p.evaluate(() => {
    const G = window.__G3D, c = G.player.c;
    G.food.clearSick();
    G.food.clear();
    G.food.place({ kind: 'fungus', crop: 1, bites: 3, e: 90, high: 0, toxic: 1 });
    c.hurtT = 0;
    const r = G.food.eat();
    const t0 = G.food.sick.t, e0 = c.energy;
    // the stamina bar climbs back at the rate fightTick chooses, so measure it
    // through fightTick rather than through the multiplier on its own
    G.FIGHT.stam = 10; G.FIGHT.stamDelay = 0; G.FIGHT.sprinting = false;
    for (let i = 0; i < 20; i++) { c.hurtT = 0; G.step(0.05); }
    const illGain = G.FIGHT.stam - 10;
    const t1 = G.food.sick.t, e1 = c.energy;
    const fx = +(document.getElementById('sickfx') || {}).style.opacity;
    G.food.prompt();
    const hud = document.getElementById('v-stats').innerHTML.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
    G.food.clearSick();
    G.FIGHT.stam = 10; G.FIGHT.stamDelay = 0; G.FIGHT.sprinting = false;
    for (let i = 0; i < 20; i++) { c.hurtT = 0; G.step(0.05); }
    const wellGain = G.FIGHT.stam - 10;
    return { r: r.sick, t0, t1, e0: Math.round(e0), e1: Math.round(e1), fx, hud,
             illGain: +illGain.toFixed(2), wellGain: +wellGain.toFixed(2) };
  });
  t('the illness ticks down on the ordinary frame path', framed.t1 > 0 && framed.t1 < framed.t0,
    framed.t0 + ' -> ' + framed.t1 + ' over one second of frames');
  t('the vignette is driven every frame', framed.fx > 0.05, 'opacity ' + framed.fx);
  t('the HUD line is there without being asked for', /ill from/i.test(framed.hud), framed.hud);
  t('and the frame drain costs you energy', framed.e1 < framed.e0, framed.e0 + ' -> ' + framed.e1);
  t('stamina really does come back slower while ill',
    framed.illGain > 0 && framed.illGain < framed.wellGain * 0.8,
    '+' + framed.illGain + ' ill vs +' + framed.wellGain + ' well, over one second');

  // ---- a new body is a new stomach ---------------------------------------
  const swap = await p.evaluate(() => {
    const G = window.__G3D;
    G.food.clear();
    G.food.place({ kind: 'fungus', crop: 1, bites: 3, e: 90, high: 0, toxic: 1 });
    G.player.c.hurtT = 0;
    const r = G.food.eat();
    const sickNow = G.food.sick.t;
    G.becomeArchetype('grazer');
    G.food.tickSick(0.05);
    return { r: r.sick, sickNow, after: G.food.sick.t };
  });
  t('becoming a new creature ends the sickness',
    swap.sickNow > 0 && swap.after === 0, 'was ' + swap.sickNow + ' s, now ' + swap.after);

  // ---- an old body on the ground is food, once -----------------------------
  const rot = await p.evaluate(() => {
    const G = window.__G3D;
    G.carc.flush();
    const at = G.carc.walkTo(0);
    if (!at) return null;
    G.food.clear();
    G.food.clearSick();
    const c = G.player.c;
    c.hurtT = 0;
    c.energy = Math.max(1, c.ph.storage * 0.25);
    const q = c.ph;
    q.sGut = 0.8; q.scavenger = 0; q.carrionDigest = 0.65;   // a plain generalist
    const seen = G.food.carcass();
    const prompt = G.food.prompt();
    const e0 = c.energy;
    const r = G.food.eat();
    const again = G.food.eat();
    return { at, seen, prompt, r, again, e0: Math.round(e0), e1: Math.round(c.energy),
             sick: G.food.sick, left: G.food.carcass() };
  });
  if (rot) rot.prompt = strip(rot.prompt);
  t('there is an old body you can walk up to', !!rot && !!rot.seen, JSON.stringify(rot && rot.seen));
  if (rot) {
    t('the panel offers to strip it', /strip the old carcass/i.test(rot.prompt) && /\+\d+ energy/.test(rot.prompt), rot.prompt);
    t('E feeds on it for real energy', rot.r.ok === true && rot.r.why === 'carcass' && rot.r.gain > 0 && rot.e1 > rot.e0,
      JSON.stringify({ gain: Math.round(rot.r.gain), rot: rot.r.rot, e: rot.e0 + '->' + rot.e1 }));
    t('a generalist is sickened by rot', rot.r.sick > 0 && rot.sick.t > 0 && /rotten/i.test(rot.sick.src),
      JSON.stringify(rot.sick));
    t('and the same body cannot be eaten twice',
      rot.again.why !== 'carcass' && (!rot.left || rot.left.eaten === true), JSON.stringify(rot.again));
  }

  // a scavenger-tuned mouth takes the same body in its stride, and gets more
  const scav = await p.evaluate(() => {
    const G = window.__G3D;
    // the body the generalist stripped is bone now: find one still worth eating
    let seen = null;
    for (let i = 0; i < 6 && !seen; i++) { if (!G.carc.walkTo(i)) break; seen = G.food.carcass(); }
    if (!seen) return null;
    G.food.clear();
    G.food.clearSick();
    const c = G.player.c, q = c.ph;
    c.hurtT = 0;
    c.energy = Math.max(1, c.ph.storage * 0.25);
    q.sGut = 0.8; q.scavenger = 1; q.carrionDigest = 1.8;
    const e0 = c.energy;
    const r = G.food.eat();
    return { r, seen, gained: Math.round(c.energy - e0), sick: G.food.sick.t };
  });
  if (scav && scav.r) {
    t('a scavenger eats the same rot without falling ill', scav.r.ok === true && scav.r.sick === 0 && scav.sick === 0,
      JSON.stringify({ sick: scav.r.sick, t: scav.sick }));
    t('and gets far more out of it', scav.r.gain > 0, '+' + Math.round(scav.r.gain) + ' energy');
  }

  // ---- being hit still stops you eating ----------------------------------
  const hurt = await p.evaluate(() => {
    const G = window.__G3D;
    G.food.clear();
    G.food.place({ kind: 'grass', crop: 1, bites: 2, e: 100, high: 0 });
    G.player.c.hurtT = 4.2;
    const r = G.food.eat();
    const n = G.food.near();
    G.player.c.hurtT = 0;
    return { r, crop: n && n.crop };
  });
  t('you still cannot eat for five seconds after a hit',
    hurt.r.ok === false && hurt.r.why === 'hurt' && hurt.crop > 0.99, JSON.stringify(hurt));

  // ---- nothing in reach at all -------------------------------------------
  const none = await p.evaluate(() => {
    const G = window.__G3D;
    G.food.clear(1200);
    G.player.c.hurtT = 0;
    return { r: G.food.eat(), near: G.food.near(), prompt: G.food.prompt() };
  });
  t('bare ground says so and does nothing',
    none.near === null && none.r.ok === false && ['none', 'carcass'].includes(none.r.why), JSON.stringify(none.r));

  h.log(fail.length ? '\nFAILED: ' + fail.join(', ') : '\nALL FOOD CHECKS PASS');
};
