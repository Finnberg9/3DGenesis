module.exports = async (p, T) => {
  await p.click('[data-act="create"]'); await T.wait(3000);
  const plan = +(process.env.PLAN || 2);
  const moves = (process.env.MOVES || 'claw,punch,headbutt,bite,sweep').split(',');
  await p.evaluate(([pl]) => { const G = window.__G3D, C = G.core, E = G.ED; E.des = C.defaultDesign(pl); E.des._rev = 1; E.sel = null; E.cam.yaw = 1.57; E.cam.pitch = 0.12; E.cam.zoom = 0.62; }, [plan]);
  await T.wait(2500);
  T.log(await p.evaluate(() => [...document.querySelectorAll('[data-try]')].map(b => b.getAttribute('data-try')).join(',')));
  let i = 0;
  for (const mv of moves) for (const k of [0.3, 0.5]) {
    await p.evaluate(([mv, k]) => { const E = window.__G3D.ED; E.anim = { kind: mv, t0: performance.now() - k * 100000, dur: 100, seq: 1 }; }, [mv, k]);
    await T.wait(900);
    await p.screenshot({ path: `em_${i++}.png`, clip: { x: 350, y: 60, width: 830, height: 780 } });
  }
};
