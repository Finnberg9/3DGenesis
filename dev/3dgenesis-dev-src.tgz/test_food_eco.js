// Ecology side of the food model: grazing, regrowth, toxins, rot.
// Run: node test_food_eco.js
const C = require('./core.js');

let fails = 0;
function ok(cond, msg) {
  if (cond) console.log('  PASS  ' + msg);
  else { console.log('  FAIL  ' + msg); fails++; }
}
function head(t) { console.log('\n== ' + t); }
const f = (v, n) => (typeof v === 'number' ? v.toFixed(n == null ? 3 : n) : String(v));

// ---------------------------------------------------------------------------
head('1. a bite takes a mouthful and leaves the plant standing');
{
  const w = C.makeWorld({ w: 2400, h: 1600, tileSize: 48, seed: 3, startPop: 4, startPlants: 120 });
  const pl = w.plants.find(p => !p.isTree && p.bites >= 2);
  const before = C.plantCrop(w, pl);
  const gain = C.plantBite(w, pl);
  const after = C.plantCrop(w, pl);
  const expect = 1 / pl.bites;
  console.log(`  kind=${pl.kind} bites=${pl.bites} e=${f(pl.e, 2)} crop ${f(before)} -> ${f(after)} gain ${f(gain, 3)}`);
  ok(w.plants.indexOf(pl) >= 0, 'plant is still in world.plants after being eaten');
  ok(!pl.gone, 'plant is not flagged gone');
  ok(Math.abs((before - after) - expect) < 1e-6, `crop fell by exactly one bite (${f(expect)})`);
  ok(Math.abs(gain - pl.e * expect) < 1e-6, 'gain is e * bite fraction');

  // bare plant yields nothing and never goes negative
  for (let i = 0; i < 40; i++) C.plantBite(w, pl);
  console.log('  after 40 more bites: crop ' + f(C.plantCrop(w, pl)));
  ok(C.plantCrop(w, pl) >= 0 && C.plantCrop(w, pl) <= 0.05, 'a stripped plant reads bare, not negative');
  ok(C.plantBite(w, pl) === 0, 'biting a bare plant yields 0');
  ok(w.plants.indexOf(pl) >= 0, 'a stripped plant is STILL in world.plants');

  // edge cases: fields a plant made before this change would not have
  ok(C.plantCrop(w, { }) === 1, 'a plant with no c0 reads as full crop');
  ok(C.plantCrop(w, null) === 0, 'null plant reads 0');
  ok(C.plantCrop({ bt: 0, flags: {} }, { c0: 0, gt: 0, regrow: 0 }) === 0, 'bt 0 / regrow 0 is finite');
  const legacy = { e: 10, c0: 0.5, gt: 0 };            // no bites field
  ok(isFinite(C.plantBite(w, legacy)), 'plant with no bites field does not divide by zero');
}

// ---------------------------------------------------------------------------
head('2. a grazed plant grows back over simulated time');
{
  const w = C.makeWorld({ w: 2400, h: 1600, tileSize: 48, seed: 3, startPop: 4, startPlants: 120 });
  const pl = w.plants.find(p => !p.isTree && p.regrow > 0);
  for (let i = 0; i < 10; i++) C.plantBite(w, pl);
  const bare = C.plantCrop(w, pl);
  const marks = [];
  for (const dt of [1, 2, 4, 8, 40]) {
    w.bt = dt;                                          // fast-forward the world clock
    marks.push(C.plantCrop(w, pl));
  }
  console.log(`  kind=${pl.kind} regrow=${f(pl.regrow, 4)}/bt  bare ${f(bare)} -> ` +
              marks.map(v => f(v, 3)).join(' -> ') + '  (bt 1,2,4,8,40)');
  ok(bare <= 0.05, 'started bare');
  let rising = true;
  for (let i = 1; i < marks.length; i++) if (marks[i] < marks[i - 1]) rising = false;
  ok(rising, 'crop is non-decreasing as the clock advances');
  ok(marks[0] > bare, 'crop recovered measurably after 1 bt');
  ok(marks[marks.length - 1] > 0.9, 'crop reaches full again given time');
  ok(marks[marks.length - 1] <= 1, 'crop never exceeds 1');
}

// ---------------------------------------------------------------------------
head('3. toxic plants cost energy, and a gut resists them');
{
  const w = C.makeWorld({ w: 1200, h: 800, tileSize: 48, seed: 3, startPop: 4, startPlants: 40 });
  const ph = C.develop(C.seedHerbivore(w, w.rng));
  ok(typeof ph.gut === 'number' && isFinite(ph.gut), `develop() exposes a numeric gut (${f(ph.gut, 2)})`);

  const lowGut  = { gut: 0.0, scavenger: 0, carrionDigest: 0.65 };
  const highGut = { gut: 2.6, scavenger: 0, carrionDigest: 0.96 };
  const scav    = { gut: 1.0, scavenger: 1, carrionDigest: 1.80 };
  const tox = 0.9;
  const cl = C.plantToxinCost(lowGut, tox), ch = C.plantToxinCost(highGut, tox), cs = C.plantToxinCost(scav, tox);
  console.log(`  toxin ${tox}: low-gut costs ${f(cl, 2)}, high-gut ${f(ch, 2)}, scavenger ${f(cs, 2)} energy`);
  ok(cl > 8, 'a low-gut eater pays a real price (> 8 energy per mouthful)');
  ok(ch < cl * 0.45, `a high-gut eater pays much less (${f(ch / cl * 100, 0)}% of low-gut)`);
  ok(cs < cl, 'a scavenger mouth also resists plant toxins');
  ok(C.plantToxinCost(lowGut, 0) === 0, 'a clean plant costs nothing');
  ok(C.plantToxinCost(null, 1) === 0 && C.plantToxinCost({}, 1) > 0, 'missing phenotype fields do not throw');
  ok(C.plantToxinCost({ gut: 99, scavenger: 9, carrionDigest: 99 }, 1) > 0, 'nothing is fully immune');

  // in the sim: the same world, same seed, toxins switch on vs off, every
  // plant forced poisonous. Only the toxin rule differs.
  function poisonRun(toxins) {
    const wr = C.makeWorld({ w: 2400, h: 1600, tileSize: 48, seed: 12, startPop: 40, startPlants: 200,
                             timeScale: 0.05, flags: { toxins } });
    for (let s = 0; s < 4000; s++) {
      if (s % 20 === 0) for (const p of wr.plants) if (!p.isTree) p.toxic = 0.9;
      wr.step(0.1);
    }
    const alive = wr.creatures.filter(c => c.alive);
    const e = alive.reduce((a, c) => a + c.energy, 0) / Math.max(1, alive.length);
    const tox = wr.deathLog.filter(d => d.cause === 'toxin').length;
    return { alive: alive.length, e, tox, deaths: wr.deathLog.length };
  }
  const off = poisonRun(false), on = poisonRun(true);
  console.log(`  all-poison world: toxins OFF alive ${off.alive} (mean energy ${f(off.e, 1)}) | ` +
              `toxins ON alive ${on.alive} (mean energy ${f(on.e, 1)})`);
  console.log(`  recent deaths logged: OFF ${off.tox}/${off.deaths} by toxin | ON ${on.tox}/${on.deaths} by toxin`);
  ok(on.alive < off.alive || on.e < off.e, 'a poisoned world is measurably harder than a clean one');
  ok(off.tox === 0, 'with toxins off, nothing dies of poison');
  ok(on.tox > 0, 'poison deaths are attributed to deathCause toxin, not starvation');
}

// ---------------------------------------------------------------------------
head('4. carrion rots, and rot flips who the meal is for');
{
  const w = C.makeWorld({ w: 1200, h: 800, tileSize: 48, seed: 3, startPop: 4, startPlants: 40 });
  const fresh  = { e: 90, life: 12, decay: 12 };
  const half   = { e: 90, life: 12, decay: 6 };
  const putrid = { e: 90, life: 12, decay: 0.2 };
  console.log(`  rot: fresh ${f(C.carrionRot(w, fresh))} half ${f(C.carrionRot(w, half))} putrid ${f(C.carrionRot(w, putrid))}`);
  ok(C.carrionRot(w, fresh) === 0, 'an untouched corpse is 0 rot');
  ok(Math.abs(C.carrionRot(w, half) - 0.5) < 1e-9, 'half its life spent reads 0.5');
  ok(C.carrionRot(w, putrid) > 0.95, 'nearly gone reads near 1');
  ok(C.carrionRot(w, { e: 1 }) >= 0 && C.carrionRot(w, { e: 1 }) <= 1, 'a corpse with no life field is in range');
  ok(C.carrionRot(w, { e: 1, life: 0, decay: 0 }) <= 1, 'life 0 does not divide by zero');
  ok(C.carrionRot(w, { e: 1, life: 12, decay: 99 }) === 0, 'decay above life clamps to fresh');
  ok(C.carrionRot(w, null) === 1, 'no corpse reads fully rotten');

  const gen  = { carrionDigest: 0.65, scavenger: 0 };     // generalist / herbivore mouth
  const spec = { carrionDigest: 1.80, scavenger: 1 };     // dedicated scavenger
  const gf = C.carrionYield(w, fresh, gen), sf = C.carrionYield(w, fresh, spec);
  const gp = C.carrionYield(w, putrid, gen), sp = C.carrionYield(w, putrid, spec);
  console.log(`  fresh  body e=90: generalist +${f(gf.gain, 1)} (ill ${f(gf.ill, 1)}) | scavenger +${f(sf.gain, 1)} (ill ${f(sf.ill, 1)})`);
  console.log(`  putrid body e=90: generalist +${f(gp.gain, 1)} (ill ${f(gp.ill, 1)}) | scavenger +${f(sp.gain, 1)} (ill ${f(sp.ill, 1)})`);
  ok(sp.gain > gp.gain * 2, `a rotten body is worth far more to a scavenger (${f(sp.gain / gp.gain, 1)}x)`);
  ok(gf.gain > sf.gain, 'a FRESH body is worth more to the generalist -- the trade runs both ways');
  ok(gp.gain < gf.gain, 'the generalist gets less and less out of a rotting body');
  ok(sp.gain > sf.gain, 'the scavenger gets MORE out of a rotten one than a fresh one');
  ok(gp.ill > 0, 'a putrid body makes a non-scavenger ill');
  ok(sp.ill === 0, 'a scavenger is not sickened by rot');
  ok(gf.ill === 0, 'a fresh body sickens nobody');
  ok(gp.ill > gp.gain, 'eating putrid meat as a generalist is a net loss');
  ok(C.carrionYield(w, { e: 0, life: 12, decay: 1 }, gen).gain === 0, 'an empty corpse yields nothing');
  ok(C.carrionYield(w, null, gen).gain === 0, 'no corpse yields nothing');
  ok(isFinite(C.carrionYield(w, fresh, {}).gain), 'a phenotype with no diet fields does not produce NaN');
}

// ---------------------------------------------------------------------------
head('5. long run: plants hold near maxPlants, herbivores survive');
// Pre-change baselines for this exact scenario, measured by re-running the
// same build with patch_food_eco.py dropped out of build.sh:
//   seed 3: alive 14 herbivores 14 plants  190/1440 min 10
//   seed 9: alive 12 herbivores 12 plants  156/1440 min 30
// Plants were deleted on eating, so the standing stock sat at a small
// fraction of maxPlants and the population it could carry sat with it.
// Two seeds, because a carrying-capacity claim off a single seed is an
// anecdote.
const BASE = { 3: { alive: 14, plants: 190, min: 10 }, 9: { alive: 12, plants: 156, min: 30 } };
for (const seed of [3, 9]) {
  const base = BASE[seed];
  console.log('\n  --- seed ' + seed + ' ---');
  const w = C.makeWorld({ w: 2400, h: 1600, tileSize: 48, seed, startPop: 30, startPlants: 150, timeScale: 0.05 });
  let minPlants = Infinity, prevPlants = w.plants.length, shrank = 0;
  const trace = [];
  for (let s = 0; s < 20000; s++) {
    w.step(0.1);
    if (w.plants.length < prevPlants) shrank++;
    prevPlants = w.plants.length;
    if (s > 2000) minPlants = Math.min(minPlants, w.plants.length);
    if (s % 4000 === 0 || s === 19999) {
      const al = w.creatures.filter(c => c.alive);
      trace.push(`bt ${f(w.bt, 0)}: alive ${al.length} plants ${w.plants.length}`);
    }
  }
  const alive = w.creatures.filter(c => c.alive);
  const herb = alive.filter(c => c.ph.carnivory <= 0.5 && c.ph.scavenger <= 0.5).length;
  const grazed = w.plants.filter(p => !p.isTree && p.c0 != null && p.c0 < 0.999).length;
  const meanCrop = w.plants.reduce((a, p) => a + C.plantCrop(w, p), 0) / Math.max(1, w.plants.length);
  for (const t of trace) console.log('  ' + t);
  console.log(`  final: bt ${f(w.bt, 0)} alive ${alive.length} (herbivores ${herb}) plants ${w.plants.length}/${w.maxPlants} ` +
              `min-since-warmup ${minPlants} grazed-at-least-once ${grazed} mean crop ${f(meanCrop)}`);
  console.log(`  baseline (change disabled, same seed): alive ${base.alive} plants ${base.plants} min ${base.min}`);
  ok(shrank === 0, `world.plants never shrank over 20k steps (${shrank} shrink events)`);
  ok(w.plants.length >= w.maxPlants * 0.9, `plant stock holds near maxPlants (${f(w.plants.length / w.maxPlants * 100, 0)}%)`);
  ok(w.plants.length > base.plants * 4, `standing stock far above the pre-change baseline (${w.plants.length} vs ${base.plants})`);
  ok(minPlants > w.maxPlants * 0.25, 'stock never collapsed during the run');
  ok(grazed > 20, 'plants are actually being grazed, not ignored');
  // The equilibrium the rules predict: grazers crop a patch until it drops
  // under the 0.15 perception bar, move on, and it regrows back up to it. So
  // the mean sits just below the bar -- pressure, not a stripped map.
  ok(meanCrop > 0.04 && meanCrop < 0.6, 'mean standing crop settles in a grazing equilibrium, not stripped and not untouched');
  ok(herb >= 10, `herbivores survive the long run (${herb}, baseline was ${base.alive})`);
  ok(herb >= base.alive, `and are no worse off than before the change (${herb} vs ${base.alive})`);
  ok(!w.extinct, 'no extinction');
}

console.log('\n' + (fails ? fails + ' FAILURES' : 'ALL OK'));
process.exit(fails ? 1 : 0);
