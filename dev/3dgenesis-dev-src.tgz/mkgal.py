import sys
from PIL import Image
n=int(sys.argv[1]) if len(sys.argv)>1 else 10
ims=[Image.open(f'gal_{i}.png').resize((415,390)) for i in range(n)]
cols=5; rows=(n+cols-1)//cols
W=Image.new('RGB',(415*cols,390*rows))
for i,im in enumerate(ims): W.paste(im,((i%cols)*415,(i//cols)*390))
W.save('gal.png')
