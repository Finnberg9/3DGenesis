module.exports = async (p, T) => {
  await T.wait(4500); await T.shot('ui_start.png');
  await p.mouse.click(800, 450); await T.wait(2500);
  T.log(JSON.stringify(await p.evaluate(() => ({ edOpen: window.__G3D.ED.open, startHidden: document.getElementById('start').style.display, panelHidden: document.getElementById('panel').classList.contains('hidden'), tscale: window.__G3D.world.params.timeScale, pop: document.getElementById('startPop').value }))));
  await T.shot('ui_editor.png');
  await p.evaluate(() => { const G = window.__G3D; G.closeEditor(false); });
  await T.wait(800);
  T.log('after cancel start visible:', await p.evaluate(() => document.getElementById('start').style.display));
  await p.evaluate(() => { const G = window.__G3D; G.begin(); G.becomeDesigned(G.core.defaultDesign(0)); G.showDeath({ deathCause: 'drowned' }); });
  await T.wait(1200); await T.shot('ui_death.png');
  // drowning: put the player in water over its head
  const dr = await p.evaluate(() => {
    const G = window.__G3D, t = G.terrain, me = G.player.c; G.stop();
    let best = null;
    for (let i = 0; i < 20000 && !best; i++) { const x = Math.random() * G.WORLD_W, y = Math.random() * G.WORLD_H; if (t.isWater(x, y) && !t.isDeep(x, y) && (t.LV.water - t.height(x, y)) * t.heightScale > 25) best = [x, y]; }
    if (!best) return 'no water';
    G.teleport(best[0], best[1]); me.energy = me.ph.storage;
    const e0 = me.energy; for (let i = 0; i < 50; i++) G.step(0.02);
    return { drown: me._drown, lost: +(e0 - me.energy).toFixed(1), storage: +me.ph.storage.toFixed(0), canSwim: me.ph.canSwim };
  });
  T.log(JSON.stringify(dr));
  await p.evaluate(() => { const G = window.__G3D; G.renderFrame(G.simT); }); await T.wait(900);
  await T.shot('ui_drown.png');
};
