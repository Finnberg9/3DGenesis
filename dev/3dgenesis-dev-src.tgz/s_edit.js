module.exports = async (p, T) => {
  const G = 'window.__G3D';
  await p.click('[data-act="create"]');
  await T.wait(6000);   // thumbnails
  const state = async () => p.evaluate(() => { const E = window.__G3D.ED; return { parts: E.des.parts.length, limbs: E.des.limbs.length, sel: E.sel && E.sel.kind, cost: window.__G3D.core.designCost(E.des) }; });
  T.log('start', JSON.stringify(await state()));
  // drag a big eye from the eyes tab onto the top of the head
  await p.click('[data-tab="eyes"]'); await T.wait(300);
  const headScreen = async (dx, dy, dz) => p.evaluate(([dx, dy, dz]) => {
    const E = window.__G3D.ED, C = window.__G3D.core;
    const sk = C.buildDesignSkeleton(E.des), h = sk.balls[sk.headIdx];
    const cy = sk.plan ? null : null;
    // placement cy: stand + hover ~ use body hit search along a ray instead: project head centre offset
    const G2 = window.__G3D;
    const pl = { cy: C.classifyLimbs(E.des, sk).stand + 0.34 };
    return G2.edProject([h.x + dx * h.r, h.y + pl.cy + dy * h.r, h.z + dz * h.r]);
  }, [dx, dy, dz]);
  const drag = async (sel, to) => {
    const bb = await p.locator(sel).boundingBox();
    await p.mouse.move(bb.x + bb.width / 2, bb.y + bb.height / 2);
    await p.mouse.down();
    await p.mouse.move(bb.x - 40, bb.y + 20, { steps: 4 });
    await p.mouse.move(to[0], to[1], { steps: 8 });
    await T.wait(400);
    await p.mouse.up();
    await T.wait(400);
  };
  let hs = await headScreen(0.1, 0.45, 0.3);
  await drag('[data-item="e_round"]', hs);
  T.log('after eye', JSON.stringify(await state()));
  // horns
  await p.click('[data-tab="horns"]'); await T.wait(300);
  hs = await headScreen(-0.35, 0.45, 0.2);
  await drag('[data-item="h_straight"]', hs);
  T.log('after horn', JSON.stringify(await state()));
  // spikes on the back (centre line)
  await p.click('[data-tab="armor"]'); await T.wait(300);
  const back = await p.evaluate(() => { const E = window.__G3D.ED, C = window.__G3D.core; const sk = C.buildDesignSkeleton(E.des); const st = C.classifyLimbs(E.des, sk).stand + 0.34; return window.__G3D.edProject([0, sk.b * 0.55 + st, 0]); });
  await drag('[data-item="s_spike"]', back);
  T.log('after spike', JSON.stringify(await state()));
  // a limb on the side of the chest
  await p.click('[data-tab="limbs"]'); await T.wait(300);
  const side = await p.evaluate(() => { const E = window.__G3D.ED, C = window.__G3D.core; const sk = C.buildDesignSkeleton(E.des); const st = C.classifyLimbs(E.des, sk).stand + 0.34; return window.__G3D.edProject([sk.a * 0.55, st + sk.b * 0.2, sk.b * 0.8]); });
  await drag('[data-item="l_leg"]', side);
  T.log('after limb', JSON.stringify(await state()));
  await T.shot('s1.png');
  // drop claws onto the end of the new limb
  const foot = await p.evaluate(() => { const E = window.__G3D.ED; const lb = E.des.limbs[E.des.limbs.length - 2]; return window.__G3D.edProject(window.__G3D.limbWorld(lb).foot); });
  await drag('[data-item="t_paw"]', foot);
  T.log('after tip', JSON.stringify(await state()), await p.evaluate(() => { const E = window.__G3D.ED; return E.des.limbs.slice(-2).map(l => l.tip && l.tip.id).join(','); }));
  // select the limb and drag its foot handle upward/forward
  const lbSel = await p.evaluate(() => { const E = window.__G3D.ED; const lb = E.des.limbs[E.des.limbs.length - 2]; const w = window.__G3D.limbWorld(lb); return [window.__G3D.edProject(w.knee), window.__G3D.edProject(w.foot)]; });
  await p.mouse.click(lbSel[0][0], lbSel[0][1]); await T.wait(300);
  T.log('sel after click limb', JSON.stringify(await state()));
  const f2 = await p.evaluate(() => { const E = window.__G3D.ED; const lb = E.des.limbs[E.des.limbs.length - 2]; return window.__G3D.edProject(window.__G3D.limbWorld(lb).foot); });
  const before = await p.evaluate(() => JSON.stringify(window.__G3D.ED.des.limbs[window.__G3D.ED.des.limbs.length - 2].f));
  await p.mouse.move(f2[0], f2[1]); await p.mouse.down(); await p.mouse.move(f2[0] + 60, f2[1] - 50, { steps: 6 }); await p.mouse.up(); await T.wait(300);
  const after = await p.evaluate(() => JSON.stringify(window.__G3D.ED.des.limbs[window.__G3D.ED.des.limbs.length - 2].f));
  T.log('foot drag', before, '->', after);
  await T.shot('s2.png');
  // click the horn, recolor it red via swatch
  const hornP = await p.evaluate(() => { const E = window.__G3D.ED; const h = E.des.parts.find(q => q.id === 'h_straight' && q.m); return window.__G3D.edProject(window.__G3D.partWorld(h)); });
  await p.mouse.click(hornP[0], hornP[1]); await T.wait(300);
  T.log('sel horn', JSON.stringify(await state()), await p.evaluate(() => window.__G3D.ED.sel && window.__G3D.ED.sel.ref.id));
  const sw = p.locator('#edInsp [data-pc]').nth(5);
  if (await sw.count()) { await sw.click(); await T.wait(200); }
  T.log('horn color', await p.evaluate(() => JSON.stringify(window.__G3D.ED.des.parts.filter(q => q.id === 'h_straight').map(q => q.c))));
  // body length slider
  await p.click('[data-tab="body"]'); await T.wait(300);
  const sl = p.locator('input[data-body="neck"]');
  const sb = await sl.boundingBox();
  await p.mouse.click(sb.x + sb.width * 0.85, sb.y + sb.height / 2); await T.wait(400);
  T.log('neck', await p.evaluate(() => window.__G3D.ED.des.body.neck));
  // paint tab
  await p.click('[data-tab="paint"]'); await T.wait(300);
  await p.locator('[data-paint="base"]').nth(5).click(); await p.locator('[data-pat="2"]').click(); await T.wait(300);
  await T.shot('s3.png');
  // undo twice
  await p.keyboard.press('Control+z'); await p.keyboard.press('Control+z'); await T.wait(200);
  T.log('after undo', await p.evaluate(() => JSON.stringify([window.__G3D.ED.des.col.pat, window.__G3D.ED.undo.length])));
  await p.keyboard.press('Control+y'); await p.keyboard.press('Control+y'); await T.wait(200);
  // drag the spike off the body to delete it
  const spikeP = await p.evaluate(() => { const E = window.__G3D.ED; const h = E.des.parts.find(q => q.id === 's_spike'); return h ? window.__G3D.edProject(window.__G3D.partWorld(h)) : null; });
  if (spikeP) {
    await p.mouse.move(spikeP[0], spikeP[1]); await p.mouse.down(); await p.mouse.move(spikeP[0] + 20, spikeP[1] - 300, { steps: 8 }); await p.mouse.up(); await T.wait(300);
  }
  T.log('after spike removal', JSON.stringify(await state()), await p.evaluate(() => window.__G3D.ED.des.parts.some(q => q.id === 's_spike')));
  // orbit
  await p.mouse.move(500, 300); await p.mouse.down(); await p.mouse.move(700, 330, { steps: 8 }); await p.mouse.up(); await T.wait(500);
  await T.shot('s4.png');
  // play
  await p.click('#edDone'); await T.wait(3000);
  T.log('play', await p.evaluate(() => { const G = window.__G3D; return JSON.stringify({ open: G.ED.open, designed: !!(G.player.c && G.player.c.genome.design), parts: G.player.c.genome.design.parts.length }); }));
  await p.evaluate(() => { const G = window.__G3D; G.player.dist = 60; G.player.pitch = -0.3; });
  await T.wait(4000);
  await T.shot('s5.png');
};
