// Walking down a hill is walking, not falling. Finn saw the player hop down
// every descent; the test is that a real descent produces no airborne frames,
// while a real cliff still does.
module.exports = async (p, h) => {
  const fail = [];
  const t = (n, c, x) => { h.log((c ? 'ok  ' : 'FAIL') + '  ' + n + (x != null ? '  ' + x : '')); if (!c) fail.push(n); };
  const errs = []; p.on('pageerror', (e) => errs.push(e.message));

  await p.evaluate(() => {
    const G = window.__G3D, C2 = window.GenesisCore;
    G.gfxSet('low');
    G.becomeDesigned ? G.becomeDesigned(C2.defaultDesign(10)) : G.becomeArchetype('theropod');
    G.beginPlay();
  });
  await h.wait(2500);

  const rule = await p.evaluate(() => window.__G3D.br.fallRule());
  t('a fall is only a fall past 80 degrees', Math.abs(rule.slopeTan - 5.6713) < 0.01, 'tan=' + rule.slopeTan);
  t('the free-fall height is three times what it was', rule.safeH === 7.5, 'safeH=' + rule.safeH + ' body heights');

  // ---- find the steepest WALKABLE hill on the island and walk down it
  const run = await p.evaluate(() => {
    const G = window.__G3D, T = G.terrain;
    const HS = T.heightScale || 420;
    const gy = (x, z) => T.height(x, z) * HS;
    // a spot with a real, sustained drop that is still under 80 degrees
    let best = null, bestSlope = 0;
    for (let i = 0; i < 6000; i++) {
      const x = Math.random() * T.w, z = Math.random() * T.h;
      if (T.isWater(x, z)) continue;
      const h0 = gy(x, z);
      let bd = 0, ba = 0;
      for (let a = 0; a < 8; a++) {
        const ang = a * Math.PI / 4;
        const d = h0 - gy(x + Math.cos(ang) * 30, z + Math.sin(ang) * 30);
        if (d > bd) { bd = d; ba = ang; }
      }
      const slope = bd / 30;
      // under the 60 degree WALKING limit, or the animal simply refuses to
      // go and the descent never happens
      if (slope > bestSlope && slope < 1.45) { bestSlope = slope; best = { x, z, ang: ba, slope }; }
      if (bestSlope > 1.3) break;
    }
    if (!best) return { none: true };
    G.teleport(best.x, best.z);
    G.look(best.ang, 0);
    G.br.resetFall();
    for (let i = 0; i < 6; i++) G.step(0.032);
    let air = 0, frames = 0, maxJump = 0, drop0 = G.player.camY;
    G.br.setKeys({ w: true });
    for (let i = 0; i < 160; i++) {
      G.step(0.032);
      const f = G.br.fallRule();
      frames++;
      if (!f.grounded) air++;
      maxJump = Math.max(maxJump, f.jumpY);
    }
    G.br.setKeys({});
    return { slope: +best.slope.toFixed(2), deg: +(Math.atan(best.slope) * 180 / Math.PI).toFixed(1),
             air, frames, maxJump: +maxJump.toFixed(2), descended: +(drop0 - G.player.camY).toFixed(1) };
  });
  h.log('walked', JSON.stringify(run));
  t('the hill was a real hill, and a steep one', run.slope > 0.5, run.deg + ' degrees');
  t('you actually went down it', run.descended > 5, 'dropped ' + run.descended);
  t('and you never left the ground doing it', run.air === 0, run.air + ' of ' + run.frames + ' frames airborne, peak hop ' + run.maxJump);

  // ---- a real cliff still drops you
  // ---- this terrain has no vertical faces at all: it is a height field with
  // a slope limit, so with an 80 degree rule the only way off the ground is a
  // JUMP. That path still has to work, and still has to cost you on landing.
  const jump = await p.evaluate(() => {
    const G = window.__G3D;
    G.br.resetFall();
    for (let i = 0; i < 4; i++) G.step(0.032);
    G.jump();
    let air = 0, peak = 0;
    for (let i = 0; i < 90; i++) {
      G.step(0.032);
      const f = G.br.fallRule();
      if (!f.grounded) air++;
      peak = Math.max(peak, f.jumpY);
    }
    return { air, peak: +peak.toFixed(1) };
  });
  t('a jump still leaves the ground', jump.air > 0 || jump.peak > 0, JSON.stringify(jump));

  // ---- the damage curve starts three times higher than it did
  const dmg = await p.evaluate(() => {
    const G = window.__G3D;
    const safe = G.br.fallRule().safe;
    return { safe, justUnder: G.br.fallDamage(safe * 0.95), wayOver: G.br.fallDamage(safe * 3) };
  });
  t('a fall inside the new free height costs nothing', dmg.justUnder === 0, JSON.stringify(dmg));
  t('a real drop still hurts', dmg.wayOver > 0, JSON.stringify(dmg));

  t('no page errors', errs.length === 0, errs.slice(0, 3).join(' | '));
  h.log(fail.length ? '\nFAILED: ' + fail.join(', ') : '\nALL FALL TESTS PASS');
};
