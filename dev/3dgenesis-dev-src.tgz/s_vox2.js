module.exports = async (p, T) => {
  await p.evaluate(() => document.getElementById('start').style.display = 'none');
  await p.keyboard.press('n'); await p.keyboard.press('n');
  await T.wait(2500);
  T.log(await p.evaluate(async () => {
    const G = window.__G3D, S = G.sndDbg;
    let errs = 0, err = null;
    for (const c of G.world.creatures.slice(0, 16)) for (const w of ['call', 'attack', 'pain', 'threat', 'win']) { try { S.voxCall(c, w); } catch (e) { errs++; err = e.message; } await new Promise(r => setTimeout(r, 30)); }
    return JSON.stringify({ errs, err, ctx: S.SND.ctx && S.SND.ctx.state, sfx: S.SFX.ready, n: Object.keys(S.SFX.buf).length });
  }));
};
