module.exports = async (p, T) => {
  await p.click('[data-act="create"]');
  await T.wait(3000);
  for (const [id, f] of [['w_bat', 'w1.png'], ['w_feather', 'w2.png'], ['w_insect', 'w3.png']]) {
    await p.evaluate((id) => {
      const G = window.__G3D, C = G.core, E = G.ED;
      E.des = C.defaultDesign(7); E.des.parts = E.des.parts.filter(q => !q.id.startsWith('w_')); E.des._rev = Math.random();
      const sk = C.buildDesignSkeleton(E.des);
      const h = C.surfaceAt(sk, 0.1 * sk.a, 0.55 * sk.b, 0.55 * sk.b, 0, 0.7, 0.7); G.edAddPart(id, h);
      E.sel = null; E.cam.yaw = 2.6; E.cam.pitch = 0.75; E.cam.zoom = 0.7;
    }, id);
    await T.wait(1500); await T.shot(f);
  }
};
