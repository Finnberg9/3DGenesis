module.exports = async (p, T) => {
  await p.evaluate(() => { const G = window.__G3D, C = G.core; G.begin(); G.becomeDesigned(C.defaultDesign(7)); G.stop();
    const me = G.player.c; for (const q of me.cellState) q.grow = 1; me.ph = C.develop(me.genome, me.cellState);
    G.setFly(60); G.player.dist = 90; G.player.pitch = -0.25; G.player.yaw = 0.3;
    for (let i = 0; i < 5; i++) G.step(0.02); G.renderFrame(G.simT); });
  await T.wait(1500);
  for (let k = 0; k < 3; k++) { await p.evaluate((k) => { const G = window.__G3D; G.step(0.05 + k * 0.03); G.renderFrame(G.simT); }, k); await T.wait(700); await T.shot('wing' + k + '.png'); }
  // skeleton close-up
  await p.evaluate(() => { const G = window.__G3D, me = G.player.c; G.setFly(0);
    const v = G.world.creatures.find(c => c.alive && c !== me && c.genome.design && c.genome.design.plan === 0) || G.world.creatures.find(c => c.alive && c !== me && c.genome.design);
    v.x = me.x + 40; v.y = me.y; for (const q of v.cellState) q.grow = 1; v.ph = G.core.develop(v.genome, v.cellState); G.remainsAdd(v); v.alive = false;
    G.REMAINS[G.REMAINS.length - 1].t0 -= 60;
    G.player.spectator = true; G.player.camX = v.x - 30; G.player.camZ = v.y - 30; G.player.camY = G.terrain.height(v.x, v.y) * G.HEIGHT_SCALE + 22; G.player.yaw = Math.PI / 4; G.player.pitch = -0.5;
    G.step(0.02); G.renderFrame(G.simT); });
  await T.wait(1500); await p.evaluate(() => { const G = window.__G3D; G.renderFrame(G.simT); }); await T.wait(700);
  await T.shot('skel.png');
};
