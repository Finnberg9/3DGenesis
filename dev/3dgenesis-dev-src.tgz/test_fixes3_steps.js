// A body you can see, a body you loot once, and nothing hitting you from
// behind its own shoulder.
module.exports = async (p, h) => {
  const fail = [];
  const t = (n, c, x) => { h.log((c ? 'ok  ' : 'FAIL') + '  ' + n + (x != null ? '  ' + x : '')); if (!c) fail.push(n); };

  await p.evaluate(() => { const G = window.__G3D; G.bones.reset(); G.becomeArchetype('theropod'); G.beginPlay(); });
  await h.wait(900);

  // ---- 1. bodies stand out of the ground -----------------------------------
  const carc = await p.evaluate(() => {
    const G = window.__G3D;
    G.carc.flush();
    const list = G.carc.list().filter(e => e.built);
    return { n: list.length, scale: G.carc.scale, radii: G.carc.radii() };
  });
  t('there are bodies in the field', carc.n > 0, String(carc.n));
  t('and they are drawn bigger than the animal that made them', carc.scale > 1.5, String(carc.scale));
  const sink = await p.evaluate(() => window.__G3D.carc.sinkAt([0, 0.3, 0.5, 0.7, 1]));
  t('a fresh body is not sunk at all', sink[0] === 0 && sink[1] === 0, JSON.stringify(sink));
  t('nor is one half way through its life', sink[2] === 0, JSON.stringify(sink));
  t('and even an old one is only part buried', sink[4] > 0 && sink[4] <= 1, JSON.stringify(sink));

  // ---- 2. one kill, one loot ------------------------------------------------
  const kill = await p.evaluate(() => {
    const G = window.__G3D;
    const before = Object.assign({}, G.PROG.owned);
    const r = G.killNearest();
    return { r, before, after: Object.assign({}, G.PROG.owned), picker: !!G.picker };
  });
  t('killing something works', kill.r && kill.r.ok === true, JSON.stringify(kill.r));
  t('and it does NOT open a part picker', kill.picker === false);
  t('and hands you no parts by itself',
    JSON.stringify(kill.after) === JSON.stringify(kill.before), JSON.stringify(kill.after));

  const body = await p.evaluate(() => {
    const G = window.__G3D;
    const t0 = G.inspectTargetDbg();
    const n0 = Object.keys(G.PROG.owned).length;
    G.eat();                                   // E: the one interact key
    const picker = !!G.picker;
    if (picker) G.pick(1);
    return { had: !!t0, picker, owned: Object.assign({}, G.PROG.owned), n0 };
  });
  t('the kill leaves a body you can search', body.had === true);
  t('searching it is what offers the parts', body.picker === true);
  t('and taking one is what actually gives you it', Object.keys(body.owned).length > body.n0, JSON.stringify(body.owned));
  const twice = await p.evaluate(() => { const G = window.__G3D; G.eat(); return { picker: !!G.picker, again: !!G.inspectTargetDbg() }; });
  t('and the same body cannot be searched twice', twice.picker === false && twice.again === false, JSON.stringify(twice));

  // ---- 3. it has to be facing you ------------------------------------------
  const face = await p.evaluate(() => {
    const G = window.__G3D;
    const me = G.player.c;
    const foe = { x: me.x + 40, y: me.y, ph: { mass: 8 }, alive: true, _yaw3: 0 };
    const at = (yaw) => { foe._yaw3 = yaw; return G.br.facing(foe, me); };
    // the foe is EAST of the player, so facing the player means yaw ~ PI
    return { toward: at(Math.PI), away: at(0), side: at(Math.PI / 2), off60: at(Math.PI - 1.05), off100: at(Math.PI - 1.75),
             commit: G.br.FACE_COMMIT, land: G.br.FACE_LAND };
  });
  t('a creature looking straight at you counts as facing you', face.toward === true);
  t('one looking the other way does not', face.away === false);
  t('nor does one side-on', face.side === false);
  t('but a moderate angle still lands', face.off60 === true);
  t('and a wide one does not', face.off100 === false);
  t('starting a swing is allowed from further off than landing one', face.commit < face.land, face.commit + ' vs ' + face.land);

  const turn = await p.evaluate(() => {
    const G = window.__G3D;
    const me = G.player.c;
    const foe = G.spawnFoe(me.x + 60, me.y);
    foe._yaw3 = 0;                              // pointing away from the player
    const before = G.br.facing(foe, me);
    for (let i = 0; i < 120; i++) { foe._faceT = 1e9; G.br.faceTick(1 / 60); }
    return { before, after: G.br.facing(foe, me), yaw: +foe._yaw3.toFixed(2) };
  });
  t('something that wants to hit you turns to face you', turn.before === false && turn.after === true,
    JSON.stringify(turn));

  h.log(fail.length ? '\nFAILED: ' + fail.join(' | ') : '\nALL FIX CHECKS PASS');
};
