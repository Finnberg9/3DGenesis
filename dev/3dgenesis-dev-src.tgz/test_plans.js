// The new body plans have to be real animals, not table entries: each one has
// to compile, develop into finite physiology, stand up, and be distinguishable
// from the others as a silhouette.
const C = require('./core.js');
const world = C.makeWorld({ w: 12800, h: 8000, tileSize: 48, seed: 5, startPop: 4, startPlants: 20 });
const rng = world.rng;
let fails = 0;
const t = (n, c, x) => { console.log((c ? 'ok  ' : 'FAIL') + '  ' + n + (x != null ? '  ' + x : '')); if (!c) fails++; };

const NEW = { 22: 'scorpion', 23: 'stilt-walker', 24: 'hydra', 25: 'mantis', 26: 'crab', 27: 'brute', 28: 'drifter', 29: 'wyrm' };
const info = {};
for (const pi of Object.keys(NEW).map(Number)) {
  const d = C.defaultDesign(pi);
  const g = C.seedHerbivore(world, rng);
  g.design = d; C.compileDesign(g);
  const ph = C.develop(g);
  const sk = C.buildDesignSkeleton(d);
  const cls = C.classifyLimbs(d, sk);
  const bad = Object.keys(ph).filter((k) => typeof ph[k] === 'number' && !isFinite(ph[k]));
  info[pi] = { d, ph, cls, sk, bad };
  console.log('  ' + String(pi).padEnd(3) + NEW[pi].padEnd(13) +
    'parts ' + String(d.parts.length).padStart(2) + '  limbs ' + String(d.limbs.length).padStart(2) +
    '  legs ' + cls.legs + '  mass ' + ph.mass.toFixed(1).padStart(5) +
    '  hp ' + C.hpMaxOf(ph).toFixed(0).padStart(4) +
    '  dmg ' + C.strikeDamage(ph, { mass: 10, defense: 0 }, 1).toFixed(1).padStart(5) +
    '  land ' + ph.speedLand.toFixed(0).padStart(3) + '  cost ' + C.designCost(d));
}
t('every new plan exists in the table', Object.keys(NEW).every((k) => C.PLANS[k]), String(C.PLANS.length) + ' plans');
t('none of them develops a broken number', Object.values(info).every((v) => v.bad.length === 0),
  JSON.stringify(Object.entries(info).filter(([k, v]) => v.bad.length).map(([k, v]) => k + ':' + v.bad)));
t('and every one is a starting body: exactly 100 hp',
  Object.values(info).every((v) => Math.abs(C.hpMaxOf(v.ph) - 100) < 1e-9),
  Object.values(info).map((v) => C.hpMaxOf(v.ph).toFixed(0)).join(','));

// they are animals, not statues
t('the walkers walk', [22, 23, 24, 25, 26, 27].every((k) => info[k].cls.legs >= 2),
  [22, 23, 24, 25, 26, 27].map((k) => k + ':' + info[k].cls.legs).join(' '));
t('the scorpion and the crab are many-legged', info[22].cls.legs >= 8 && info[26].cls.legs >= 6,
  'scorpion ' + info[22].cls.legs + ', crab ' + info[26].cls.legs);
t('the drifter and the wyrm have no legs at all', info[28].cls.legs === 0 && info[29].cls.legs === 0,
  'drifter ' + info[28].cls.legs + ', wyrm ' + info[29].cls.legs);
t('every one of them can see', Object.values(info).every((v) => v.d.parts.some((pt) => C.ITEM_SIM[pt.id] && C.ITEM_SIM[pt.id].t === 'EYE')));
t('and every one of them has a mouth', Object.values(info).every((v) => v.d.parts.some((pt) => C.ITEM_SIM[pt.id] && C.ITEM_SIM[pt.id].t === 'MOUTH')));

// the scorpion's tail is over its back, which is the whole point of it
const sc = info[22].sk, ts = C.PLANS[22].ts;
const tailY = [];
for (let i = 0; i < ts; i++) tailY.push(sc.balls[sc.tailStart + i].y);
t('the scorpion carries its tail up and over its back', tailY[ts - 1] > tailY[0] + sc.b,
  tailY.map((y) => y.toFixed(2)).join(' -> '));
t('and it ends in a stinger', info[22].d.parts.some((pt) => pt.id === 's_spike'));
t('and it has pincers', (info[22].d.limbs || []).some((l) => l.tip && l.tip.id === 't_pincer'));

// No existing plan moved by a hair. Checked against the closed form the tail
// was built with before tailUp existed, rather than against a snapshot of
// numbers, so this stays a real assertion if the table is ever retuned.
function oldTail(pi) {
  const sk = C.buildDesignSkeleton(C.defaultDesign(pi)), P = C.PLANS[pi];
  let tx = -sk.a * 0.92, ty = sk.b * 0.08;
  const seg = sk.tailLen / P.ts, out = [];
  for (let i = 1; i <= P.ts; i++) {
    const u = i / P.ts;
    tx -= seg * Math.cos(0.12 + 0.18 * u);
    ty -= seg * Math.sin(0.12 + 0.18 * u) * 0.6;
    out.push([tx, ty]);
  }
  return out;
}
let moved = 0, worstMove = 0;
for (let pi = 0; pi < 22; pi++) {
  const sk = C.buildDesignSkeleton(C.defaultDesign(pi)), want = oldTail(pi);
  for (let i = 0; i < C.PLANS[pi].ts; i++) {
    const b2 = sk.balls[sk.tailStart + i];
    const e = Math.max(Math.abs(b2.x - want[i][0]), Math.abs(b2.y - want[i][1]));
    if (e > worstMove) worstMove = e;
    if (e > 1e-9) moved++;
  }
}
t('not one of the twenty-two existing plans has its tail moved', moved === 0,
  moved + ' balls moved, worst ' + worstMove.toExponential(2));

// and the health calibration has to keep covering the heaviest thing you can start as
let heaviest = 0, heaviestPlan = -1;
for (let pi = 0; pi < C.PLANS.length; pi++) {
  const g = C.seedHerbivore(world, rng); g.design = C.defaultDesign(pi); C.compileDesign(g);
  const m = C.develop(g).mass;
  if (m > heaviest) { heaviest = m; heaviestPlan = pi; }
}
t('the health reference still covers the heaviest body you can start as',
  C.HP_REF_MASS >= heaviest, 'HP_REF_MASS ' + C.HP_REF_MASS + ' vs plan ' + heaviestPlan + ' at ' + heaviest.toFixed(1));
let allHundred = true, offenders = [];
for (let pi = 0; pi < C.PLANS.length; pi++) {
  const g = C.seedHerbivore(world, rng); g.design = C.defaultDesign(pi); C.compileDesign(g);
  const hp = C.hpMaxOf(C.develop(g));
  if (Math.abs(hp - 100) > 1e-9) { allHundred = false; offenders.push(pi + ':' + hp.toFixed(0)); }
}
t('EVERY body plan in the game, all ' + C.PLANS.length + ' of them, starts on exactly 100 hp', allHundred, offenders.join(' '));

// silhouettes have to actually differ
const shape = (pi) => { const v = info[pi]; return [v.sk.a.toFixed(2), v.sk.b.toFixed(2), v.cls.legs, v.sk.neckLen.toFixed(2), v.sk.tailLen.toFixed(2), C.PLANS[pi].stand].join('/'); };
const sigs = Object.keys(NEW).map(Number).map(shape);
t('no two of the new shapes are the same silhouette', new Set(sigs).size === sigs.length, sigs.join('  '));

// the stilt-walker really is absurd, and the brute really is heavy
t('the stilt-walker stands far higher than anything else', C.PLANS[23].stand > 3 && C.PLANS[23].stand > C.PLANS[27].stand * 1.6,
  C.PLANS[23].stand + ' vs brute ' + C.PLANS[27].stand);
t('the crab is much wider than it is long', C.PLANS[26].wide > 0.8, String(C.PLANS[26].wide));
t('the hydra has by far the longest neck of the new eight',
  Object.keys(NEW).map(Number).every((k) => k === 24 || C.PLANS[24].neck > C.PLANS[k].neck),
  'hydra ' + C.PLANS[24].neck);

// and they survive being alive
for (let i = 0; i < 24; i++) {
  const pi = 22 + (i % 8);
  const g = C.seedHerbivore(world, rng); g.design = C.defaultDesign(pi); C.compileDesign(g);
  const c = C.makeCreature(g, 5800 + i * 40, 4000, 400);
  for (const q of c.cellState) q.grow = 1;
  c.ph = C.develop(g, c.cellState); c.energy = c.ph.storage; c.age = C.maturity(c.ph) + 1;
  world.creatures.push(c);
}
for (let s = 0; s < 900; s++) world.step(0.1);
const aliveNew = world.creatures.filter((c) => c.alive && c.genome.design && c.genome.design.plan >= 22).length;
t('a world full of them runs without falling over', aliveNew > 0, aliveNew + ' of 24 still alive after 90 s');

// mutation must not break them either
let broke = 0;
for (let i = 0; i < 200; i++) {
  const g = C.seedHerbivore(world, rng); g.design = C.defaultDesign(22 + (i % 8)); C.compileDesign(g);
  let m = g;
  for (let k = 0; k < 20; k++) m = C.mutate(world, m, rng, 0.8);
  const ph = C.develop(m);
  if (Object.keys(ph).some((k) => typeof ph[k] === 'number' && !isFinite(ph[k]))) broke++;
}
t('twenty generations of mutation never produces a broken body', broke === 0, broke + ' broken');

console.log(fails ? '\n' + fails + ' FAILED' : '\nALL PLAN TESTS PASS');
process.exit(fails ? 1 : 0);
