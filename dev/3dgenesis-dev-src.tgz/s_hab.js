module.exports = async (p, T) => {
  await p.click('[data-act="create"]'); await T.wait(4000);
  await p.evaluate(() => { const G = window.__G3D, C = G.core, E = G.ED; E.des = C.defaultDesign(0); E.des._rev = 1; E.sel = null; E.cam.yaw = 0.8; E.cam.pitch = 0.18; E.cam.zoom = 0.9; });
  await T.wait(3000); await T.shot('hab1.png');
  await p.evaluate(() => { const E = window.__G3D.ED; E.cam.yaw = 2.6; E.cam.pitch = 0.3; E.cam.zoom = 1.3; });
  await T.wait(2500); await T.shot('hab2.png');
};
