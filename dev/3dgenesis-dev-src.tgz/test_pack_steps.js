// You cannot kill your own, and the interface says so before you try.
// The rule lived in brHitAllowed and nowhere else, so the player was shown an
// attack prompt, a red marker and a red dot for a packmate, swung, and nothing
// happened. These checks tie the affordance to the same filter as the damage.
module.exports = async (p, h) => {
  const fail = [];
  const t = (n, c, x) => { h.log((c ? 'ok  ' : 'FAIL') + '  ' + n + (x != null ? '  ' + x : '')); if (!c) fail.push(n); };

  await p.evaluate(() => { const G = window.__G3D; G.becomeArchetype('theropod'); G.beginPlay(); return G.br.enter(); });
  await p.waitForFunction(() => window.__G3D.br.on, null, { timeout: 200000 });
  await p.evaluate(() => { const G = window.__G3D; for (let i = 0; i < 700; i++) G.step(0.05); });
  await h.wait(400);
  const phase = await p.evaluate(() => window.__G3D.br.phase);
  t('the gates are open', phase === 'open', phase);

  // pick a live rival and put them in your pack
  const slot = await p.evaluate(() => {
    const B = window.__G3D.br;
    const q = B.players.find(x => x.slot !== B.slot && x.alive && x.c && x.c.alive);
    return q ? q.slot : -1;
  });
  t('found a live rival', slot >= 0, slot);
  if (slot < 0) { h.log('\nFAILED: no rival'); return; }

  // ---- as a rival: attackable, and the prompt offers it --------------------
  const foe = await p.evaluate((sl) => {
    const B = window.__G3D.br;
    B.setPack(sl, -1);
    B.aimAt(sl);
    const html = B.actHtml();
    return { friend: B.friend(sl), may: B.mayHit(sl), hits: /hits to kill/.test(html),
             fkey: /class="hit">F</.test(html), pack: /YOUR PACK/.test(html) };
  }, slot);
  t('a rival can be attacked', foe.may === true && foe.friend === false, JSON.stringify(foe));
  t('and the prompt carries the attack key', foe.fkey && foe.hits && !foe.pack, JSON.stringify(foe));
  const swungFoe = await p.evaluate(() => window.__G3D.br.swing());
  t('the swing goes through on a rival', swungFoe === true);

  // ---- as a packmate: not attackable, and the key is gone ------------------
  const mate = await p.evaluate((sl) => {
    const B = window.__G3D.br;
    B.setPack(sl, B.slot);                 // they are now in your pack
    B.aimAt(sl);
    const html = B.actHtml();
    return { friend: B.friend(sl), may: B.mayHit(sl), hits: /hits to kill/.test(html),
             fkey: /class="hit">F</.test(html), pack: /YOUR PACK/.test(html),
             says: /cannot hurt your own/.test(html),
             raw: html.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 90) };
  }, slot);
  t('a packmate is on your side', mate.friend === true, JSON.stringify(mate));
  t('and cannot be attacked', mate.may === false);
  t('THE ATTACK KEY IS NOT THERE', mate.fkey === false, mate.raw);
  t('nor is the hits-to-kill line', mate.hits === false);
  t('the prompt says whose they are', mate.pack === true && mate.says === true, mate.raw);
  const swungMate = await p.evaluate(() => window.__G3D.br.swing());
  t('and the swing is refused outright', swungMate === false);

  // ---- the underlying rule is the same one --------------------------------
  const rule = await p.evaluate((sl) => {
    const B = window.__G3D.br;
    return { pack: B.hitAllowed(B.players[sl].c, window.__G3D.player.c),
             back: B.hitAllowed(window.__G3D.player.c, B.players[sl].c) };
  }, slot);
  t('the damage filter refuses it in both directions', rule.pack === false && rule.back === false, JSON.stringify(rule));

  // ---- and it goes back to normal when they leave your pack ---------------
  const left = await p.evaluate((sl) => {
    const B = window.__G3D.br;
    B.setPack(sl, -1);
    B.aimAt(sl);
    const html = B.actHtml();
    return { may: B.mayHit(sl), fkey: /class="hit">F</.test(html) };
  }, slot);
  t('leaving the pack makes them a target again', left.may === true && left.fkey === true, JSON.stringify(left));

  h.log(fail.length ? '\nFAILED: ' + fail.join(', ') : '\nALL PACK CHECKS PASS');
};
