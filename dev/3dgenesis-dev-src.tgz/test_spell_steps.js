// Mushrooms are the only thing left on the ground worth walking to, so the
// checks drive the real field, the real pouch and the real buffs.
module.exports = async (p, h) => {
  const fail = [];
  const t = (n, c, x) => { h.log((c ? 'ok  ' : 'FAIL') + '  ' + n + (x != null ? '  ' + x : '')); if (!c) fail.push(n); };

  await p.evaluate(() => { const G = window.__G3D; G.becomeArchetype('theropod'); G.beginPlay(); });
  await h.wait(900);

  // ---- the field ----------------------------------------------------------
  const f = await p.evaluate(() => { const G = window.__G3D; for (let i = 0; i < 12; i++) G.spell; return G.spell.field(); });
  t('there are mushrooms on the island', f.length > 0, f.length + ' in range');
  t('and they are of the four kinds', f.every(e => ['power', 'ward', 'veil', 'rage'].includes(e.id)),
    JSON.stringify([...new Set(f.map(e => e.id))]));

  // the same seed lays out the same field
  const again = await p.evaluate(() => window.__G3D.spell.field());
  t('the field is stable frame to frame', JSON.stringify(again) === JSON.stringify(f));

  // Both readings in ONE evaluate: the field streams as the camera moves, so
  // comparing two snapshots taken a round trip apart is comparing two frames.
  const dr = await p.evaluate(() => {
    const G = window.__G3D;
    return { drawn: G.spell.drawn(), caps: G.spell.field().length };
  });
  t('the renderer has a mushroom mesh and queues one instance per cap',
    dr.drawn.mesh === true && dr.drawn.n === dr.caps, JSON.stringify({ mesh: dr.drawn.mesh, n: dr.drawn.n, caps: dr.caps }));
  t('and each is queued in its own colour', dr.drawn.cols.length > 0 && dr.drawn.cols.some(c => c[0] !== c[1]), JSON.stringify(dr.drawn.cols));

  // ---- picking one up ------------------------------------------------------
  const a = await p.evaluate(async () => {
    const G = window.__G3D;
    const w = G.spell.walkTo();
    if (!w) return { w: null };
    await new Promise(r => setTimeout(r, 400));
    const near = G.spell.near();
    const took = G.spell.take();
    return { w, near, took, bag: G.spell.bag() };
  });
  t('you can walk onto one', !!a.w, JSON.stringify(a.w));
  t('and it is in reach when you are on it', !!a.near, JSON.stringify(a.near));
  t('taking it puts it in the pouch', a.took && a.took.ok === true && a.bag[a.w.id] === 1, JSON.stringify(a.bag));

  const b = await p.evaluate(() => { const G = window.__G3D; const r = G.spell.take(); return { r, bag: G.spell.bag() }; });
  t('and the same cap cannot be taken twice', b.r.ok === false, JSON.stringify(b.r));

  // the pouch has a floor and a ceiling
  const cap = await p.evaluate(() => { const G = window.__G3D; for (let i = 0; i < 9; i++) G.spell.give('power'); return G.spell.bag().power; });
  t('you can only carry three of a kind', cap === 3, String(cap));

  // ---- spending one --------------------------------------------------------
  const base = await p.evaluate(() => { const G = window.__G3D; G.spell.reset(); return G.spell.muls(); });
  t('with nothing running, nothing is multiplied',
    base.dmg === 1 && base.size === 1 && base.speed === 1 && base.hp === 1 && base.invuln === false, JSON.stringify(base));

  const pw = await p.evaluate(() => { const G = window.__G3D; G.spell.give('power'); const r = G.spell.use('power'); return { r, m: G.spell.muls(), on: G.spell.on(), bag: G.spell.bag() }; });
  t('POWER doubles your damage', pw.r.ok && pw.m.dmg === 2, JSON.stringify(pw.m));
  t('and spends the mushroom', pw.bag.power === 0, JSON.stringify(pw.bag));
  t('and runs for thirty seconds', Math.abs(pw.on.power - 30) < 0.2, String(pw.on.power));
  const dup = await p.evaluate(() => { const G = window.__G3D; G.spell.give('power'); const r = G.spell.use('power'); return { r, bag: G.spell.bag() }; });
  t('you cannot stack the same spell on itself', dup.r.ok === false && dup.bag.power === 1, JSON.stringify(dup.r));

  const rg = await p.evaluate(() => {
    const G = window.__G3D;
    G.spell.reset(); G.spell.give('rage');
    const hp0 = G.hp(), max0 = G.hpMax();
    G.spell.use('rage');
    return { m: G.spell.muls(), hp0, max0, hp1: G.hp(), max1: G.hpMax() };
  });
  t('RAGE is one and a half times damage', rg.m.dmg === 1.5, String(rg.m.dmg));
  t('and one and a half times health', Math.abs(rg.max1 / rg.max0 - 1.5) < 0.001, rg.max0.toFixed(0) + ' -> ' + rg.max1.toFixed(0));
  t('and it heals you in proportion rather than leaving you on a sliver',
    Math.abs(rg.hp1 / rg.hp0 - 1.5) < 0.001, rg.hp0.toFixed(0) + ' -> ' + rg.hp1.toFixed(0));
  t('and it makes you bigger and faster', rg.m.size > 1.3 && rg.m.speed > 1.25, JSON.stringify({ size: rg.m.size, speed: rg.m.speed }));

  const vl = await p.evaluate(() => { const G = window.__G3D; G.spell.reset(); G.spell.give('veil'); G.spell.use('veil'); return G.spell.muls(); });
  t('VEIL shrinks you', vl.size < 0.5, String(vl.size));
  t('and makes you much harder to notice', vl.seen <= 0.25, String(vl.seen));

  const wd = await p.evaluate(() => {
    const G = window.__G3D;
    G.spell.reset(); G.spell.give('ward'); G.spell.use('ward');
    const before = G.hp();
    G.hurtMe(60);
    return { m: G.spell.muls(), before, after: G.hp() };
  });
  t('WARD refuses damage outright', wd.m.invuln === true && Math.abs(wd.after - wd.before) < 0.001,
    wd.before.toFixed(0) + ' -> ' + wd.after.toFixed(0));

  // ---- it runs out ---------------------------------------------------------
  const ex = await p.evaluate(() => {
    const G = window.__G3D;
    G.spell.reset(); G.spell.give('rage'); G.spell.use('rage');
    const max1 = G.hpMax();
    for (let i = 0; i < 25; i++) G.spell.tick(1);     // past its 20 s
    return { on: G.spell.on(), m: G.spell.muls(), max1, max2: G.hpMax() };
  });
  t('a spell wears off on its own clock', !ex.on.rage && ex.m.dmg === 1, JSON.stringify(ex.on));
  t('and the health it lent you goes back with it', Math.abs(ex.max2 / ex.max1 - 1 / 1.5) < 0.001,
    ex.max1.toFixed(0) + ' -> ' + ex.max2.toFixed(0));

  // ---- two at once ---------------------------------------------------------
  const st = await p.evaluate(() => {
    const G = window.__G3D;
    G.spell.reset(); G.spell.give('power'); G.spell.give('rage');
    G.spell.use('power'); G.spell.use('rage');
    return G.spell.muls();
  });
  t('two different spells stack', st.dmg === 3, String(st.dmg));

  // ---- nothing survives the round ------------------------------------------
  const rs = await p.evaluate(() => { const G = window.__G3D; G.spell.give('ward', 2); G.spell.reset(); return { bag: G.spell.bag(), on: G.spell.on(), m: G.spell.muls() }; });
  t('a reset empties the pouch and stops everything',
    Object.values(rs.bag).every(v => v === 0) && Object.keys(rs.on).length === 0 && rs.m.dmg === 1, JSON.stringify(rs));

  h.log(fail.length ? '\nFAILED: ' + fail.join(' | ') : '\nALL SPELL CHECKS PASS');
};
